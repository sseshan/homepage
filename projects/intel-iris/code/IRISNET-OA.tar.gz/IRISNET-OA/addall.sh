#! /bin/sh

for file in `cat /tmp/files.txt`
do
	cvs add $file
done
