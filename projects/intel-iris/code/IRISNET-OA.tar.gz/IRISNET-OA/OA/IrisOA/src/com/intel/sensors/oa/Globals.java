/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Globals is a static class that defines all the global variables. 
 * The class defines the following globals
 * <ul>
 * <li> OP_CODE for the commands as appeared in the packets
 * <li> Enumeration for the script languages 
 * <li> Different error codes
 * </ul>
 * 
 * @author Suman Kumar Nath
 * @version %I%, %G%
 */
public class Globals {
	public static final String
                COMMAND_UPDATE_DNS_ALL = "A", 
                COMMAND_LOAD_DATA_FROM_SA = "B",
		COMMAND_XUPDATE_FROM_SA = "b",
                COMMAND_DELETE_DATABASE = "C",
                DELEGATE_OWNERSHIP = "D",
		SHARE_OWNERSHIP = "SW",
                COMMAND_EVICT = "E",
                COMMAND_CACHING_ON = "F",
                COMMAND_CACHING_OFF = "G",
                COMMAND_SET_TIME_TO_ZERO = "H",
		COMMAND_STAT_RESET = "I",
                COMMAND_STAT_WRITE="J",
		COMMAND_FETCH_DONE = "K", 

		COMMAND_LOAD = "L", 

		COMMAND_QUERY = "Q",
		COMMAND_REPLY = "R",
		COMMAND_SUBS = "S",
		TAKE_OWNERSHIP = "T", 
		COMMAND_UNSUBS = "U", 

		COMMAND_UNKNOWN = "X",
                COMMAND_SIMPLE_QUERY = "Y",
		COMMAND_SHUTDOWN = "Z",

		// new query and reply
		COMMAND_QUERY2 = "Q2",
		COMMAND_REPLY2 = "R2",

		// stored query
		COMMAND_ADD_STORED_QUERY = "AS",
		COMMAND_REMOVE_STORED_QUERY = "RS",

		COMMAND_MULTIPLE_MESSAGES = "MM",

		// enum Language
		JAVA = "J", C= "C";

		// DB_NAME = "parking";
	
	public static String 
		DOCUMENT ="nodocument",
		SENSELET = "nosenselet";

	public static int
		//error codes
		OK = 0, FILE_ERROR = 1, DL_LOAD_ERROR = 2, SOCK_ERROR = 3, NO_DATA = 4, STREAM_ERROR = 5;

	public static int pending = 0;

	public static boolean 
		XSLTCachingON = true,
		DocCachingON = true,
		DebugON = false,
		LoggingON = false,
		keepStat = false;
	
	// static QueryManager QM;

        private static DatabaseInterface db = null;

        public static DatabaseInterface getDatabase() {
            return db;
        }
        public static void setDatabase(DatabaseInterface _db) {
            db = _db;
        }

	

};
