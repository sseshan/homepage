/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * The class PacketHeaderSubs describes the header of the Subscribe 
 * (COMMAND_SUBSCRIBE) packet and provides methods to create/send/recieve it. 
 * A packet is a String, a sequence of the following
 * fields seperated by space: 1. command op code 2. OA's IP 
 * 3. OA's port 4. script name. (Note that before sending, 
 * <code>PacketHeader::SendPacket<code>, converts the string to byte array 
 * and prepends a byte denoting the packet length.). 
 *
 * Public variable: 
 * <ul>
 * <li> String IP: Organizing agent (OA)'s IP address
 * <li> String port: OA's port
 * <li> String scriptName: name of the script to which OA wants to subscribe
 * </ul>
 *
 * @author Suman Kumar Nath
 * @version %I%, %G%
 */

class  PacketHeaderUnsubs extends Packet{
	public String IP, port, scriptName;
	String command;
	
	PacketHeaderUnsubs() {command = Globals.COMMAND_UNSUBS;};
	
	/**
	 * Constructor. Initializes variables.
	 *
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	PacketHeaderUnsubs(String ip, int prt, String script) {
		command = Globals.COMMAND_UNSUBS;
		IP = ip;
		port = (new Integer(prt)).toString();
		scriptName = script;
	}
	
	/**
	 * Constructs the Subscribe command packet, and writes to output stream
	 *
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	
	public int SendHeader(DataOutputStream outStream) throws Exception {
		/*
		  String s = command + (new Integer(IP.length())).toString() + IP + 
		  (new Integer(port.length())).toString() + port +
		  (new Integer(scriptName.length())).toString() + scriptName; 
		*/
		String s = command + " " + IP + " " + port + " " + scriptName;
		return send(s, outStream);
	}
	
	/**
	 * Reads a LoadScript command packet from input stream, parses it and 
	 * gets the values into the class variables.
	 *
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	public int RecieveHeader(DataInputStream inStream) {
		// TBD. OA does not need to receive COLLAND_LOAD packet :)
		// String s = ReceivePacket(inStream);
		// parse(s);
		return 0;
	}
}
