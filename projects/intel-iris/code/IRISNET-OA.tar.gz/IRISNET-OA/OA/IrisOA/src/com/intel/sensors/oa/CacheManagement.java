/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Thread;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

import org.w3c.dom.*;


/**
 * This class will hopefully serve as the class that decides what to cache
 * and what not, and also be the guy who is in charge of keeping the
 * cache fresh at all times.
 *
 * This class manages the cached objects. At this moment, we cache
 * two types of objects in the in-memory hashtables: 
 * (1) Documents read from the xindice database and 
 * (2) compiles XSLT codes for the queries. Loading the document 
 * from the xindice database and compiling the queries into XSLT codes
 * are currently the most expensive parts of query processing.
 *
 * Note that, the cached XML responses are put in the same XML document as 
 * the "own"ed data is stored. (may be bad for performance -- since caching 
 * may make a local XML document arbitrarily large.
 *
 * The cache sits between the Servant classes and DatabaseInterface class 
 * (i.e., any request to access a document goes through the cache manager) 
 * and the DOMProcessing class (i.e., any request to compile a query to 
 * XSLT goes through the cache manager). In case of a cache hit, the requested
 * object is generated (by accessing the database on disk, or by using the 
 * XSLT_query_generator), put on the cache and then returned. Thus the recently
 * accessed objects are always in the cache.
 *
 * @author Suman Nath
 **/

 

public class CacheManagement {

	/*************************************************************************
	 *     Response caching related functionalities 
     **************************************************************************/

	private class XSLTEntry {
		Object[] _xslt = new Object[2];
		
		public XSLTEntry (Object xslt, Object query) {
			_xslt[0] = xslt;
			_xslt[1] = query;
		}

		public Object[] getEntry() {
			return _xslt;
		}
	}

	private class DocEntry {
		Document _doc;

		public DocEntry(Document doc) {
			_doc = doc;
		}

		public Document getEntry() {
			return _doc;
		}
			
	}

    /*** Given a query response, cache it. */
    public static void CacheResponse(String response, String nodeIdentifyingQuery) {
        try {
			System.out.println("*************************************************************************");
			System.out.println("CacheManagement.CacheResponse(): Caching response:");
			//System.out.println(response);
			System.out.println("*************************************************************************");

            /* Do some simple pre-processing on the response */
            Document responseDoc = DOMProcessing.XMLtoDOM(response);
            DOMProcessing.setOwnAttributesToNo(responseDoc);
			
			// for debugging purpose only
            //DOMProcessing.setExpiryAttributeForAllSpecialNodes(responseDoc, "1000"); 

			
			String root = QueryAnalysis.getRoot(QueryAnalysis.parse(nodeIdentifyingQuery));
			// the document should already be in the cache
            Document hereDoc = Globals.getDatabase().getDocumentWithID(root); 
			// Document hereDoc = Globals.getDatabase().getDocumentContainingAnswer(nodeIdentifyingQuery);
			
            /** Fetch the document here */
            Node previousNode = DOMProcessing.applyXPATHtoDOM(hereDoc, nodeIdentifyingQuery)[0];
            DOMProcessing.mergeResponseAt(responseDoc.getDocumentElement(), (Element) previousNode);

            /** Finally, store the document back into the database. */
			System.out.println("CacheManagement.CachResponse(): Final Merged Document");
			//DOMProcessing.prettyPrint(hereDoc);

			// Since this caching is just for performance, we do not need to 
			// store it in the disk database -- rather put it in the cache
			// (this is to avoid the cost of accessing the disk database)
            //Globals.getDatabase().storeDocument(hereDoc);
			CacheManagement.instance().AddDocumentToCache(root, hereDoc); /* INCORRECT!! */
			
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Evict data older than the specified time. */
    public static void EvictOlderThan(String databaseName, String currentTime) {
        Document doc = Globals.getDatabase().getDocumentWithID(databaseName); 
		// the document should be in the cache
		DOMProcessing.evictOlderThan(doc, currentTime);

		// We do not need to store the modified document back to disk database 
        // Globals.getDatabase().storeDocument(doc);

		// overwrite the old document
		CacheManagement.instance().AddDocumentToCache(databaseName, doc);
    }

    /** Start the cache manager thread -- doesn't do anything right now. */
    public static void start_cache_manager_thread(String databaseName) {
        // CacheManagement cm = new CacheManagement();
        // Thread t = new Thread(cm);
        // t.start();
    }


	/********************************************************************
	 *     In-memory caching functionalities
	 ********************************************************************/

	// If the number of entries in the Java built-in hashtable
	// exceeds the threshold, the capacity is increased by the 
	// formula of 2n+1
	// It is a common practice to keep the hashtable size a prime number.
	// I prefer the initial capacity (default = 101) to be a prime, with a 
	// few prime "2n+1" expansions	
	private Hashtable _docCache = new Hashtable(11); // 11->23->47 
	private Hashtable _xsltCache = new Hashtable(89); // 89->179->359->719->1439->2879
	private Hashtable _q2XsltCache = new Hashtable(89);
	private final int MAXDOCS = 20;
	private final int MAXXSLT = 500;

	/**
	 * Set up the manager instance to follow the singleton pattern.
	 */
	private static final CacheManagement INSTANCE = new CacheManagement();
	
	public static CacheManagement instance() {
		return INSTANCE;
	}
	
	// delete "count" numbers of random element from the hashtable 
	private void DeleteObjectsFromHashtable(Hashtable ht, int count)
	{
		int total = ht.size();
		Random rnd = new Random(System.currentTimeMillis());
		int indices[] = new int[count];
		int i, j, ignore, tmp;
		Object key;

		// generate "count" random indices; objects at those indices will be removed
		for (i = 0; i<count; i++)
			indices[i] = (int)(rnd.nextDouble() * total);

		// sort the generated random indices
		for (i  =0; i< count; i++)
			for (j = i+ 1; j < count; j++) {
				if (indices[i] > indices[j]) {
					tmp = indices[i]; indices[i]=indices[j];indices[j]=tmp;
				}
			}
		
		tmp = 0;
	   	Enumeration e = ht.keys();

		// remove the elements
		for (i = 0; i< count; i++) {
			ignore = indices[i] - tmp -1;
			
			// skip intermediate keys
			for (j = 0; j< ignore; j++)
				key = e.nextElement();
			
			// remove the victim
			if (e.hasMoreElements()) {
				Object victim = e.nextElement();
				System.out.println("Evicting from cache: " + victim.toString());
				ht.remove(victim);
			}
			else {
				System.out.println("ERROR: object could not be deleted from the has table");
			}

			tmp = indices[i];
		}
	}


	public void AddDocumentToCache(String docID, Document doc)
	{
		if (_docCache.size() >= MAXDOCS) {
			System.out.println("Document Cache full. Removing random documents");
			DeleteObjectsFromHashtable(_docCache, (int)(MAXDOCS * 0.2));
		}
		_docCache.put(docID, new DocEntry(doc));
	}

	public Document GetDocumentFromCache(String docID)
	{
		DocEntry entry = (DocEntry)_docCache.get(docID);
		if (entry == null) 
			return null;
		System.out.println("***** Document found in cache *****");
		return entry.getEntry();
	}

	public Object RemoveDocumentFromCache(String docID)
	{
		return _docCache.remove(docID);
	}

	public void AddQ2XSLTToCache(String xsltID, String xslt)
	{
		if (_q2XsltCache.size() >= MAXXSLT) {
			System.out.println("Q2 XSLT Cache full. Removing random elements");
            DeleteObjectsFromHashtable(_q2XsltCache, (int)(MAXXSLT * 0.2));
		}
		
		_q2XsltCache.put(xsltID, xslt);
	}

	public String GetQ2XSLTFromCache(String xsltID)
    {
        String xslt = (String)_q2XsltCache.get(xsltID);
        if (xslt != null)
			System.out.println("***** Q2 XSLT found on cache ****");
        return xslt;
    }

    public Object RemoveQ2XSLTFromCache(String xsltID)
    {
        return _q2XsltCache.remove(xsltID);
    }

	public void AddXSLTToCache(String xsltID, Object[] xslt)
	{
		if (_xsltCache.size() >= MAXXSLT) {
			System.out.println("XSLT Cache full. Removing random elements");
			DeleteObjectsFromHashtable(_xsltCache, (int)(MAXXSLT * 0.2));
		}
		_xsltCache.put(xsltID, new XSLTEntry(xslt[0], xslt[1]));
	}

	public Object[] GetXSLTFromCache(String xsltID)
	{
		XSLTEntry entry = (XSLTEntry)_xsltCache.get(xsltID);
		if (entry == null) 
			return null;
		System.out.println("***** XSLT found on cache ****");
		return entry.getEntry();
	}
	
	public Object RemoveXSLTFromCache(String xsltID)
	{
		return _xsltCache.remove(xsltID);
	}

	public void DisplayXSLTCache()
	{
		System.out.println("XSLT Cache: " + _xsltCache.toString());
	}
	
	public void DisplayDocCache()
	{
		System.out.println("Document Cache: " + _docCache.toString());
	}
	

	// This is semantically equivalent to  DatabaseInterface.getDocumentWithID()
	// But, the request goes through the cache
	public Document GetDocumentWithID(String ID) {
		Document doc = GetDocumentFromCache(ID);
		if (doc == null) {
			doc = Globals.getDatabase().getDocumentWithID(ID);
			AddDocumentToCache(ID, doc);
		}

		return doc;	
	}

	public static void main(String args[])
	{
		CacheManagement CM = CacheManagement.instance();

		for (int i = 0; i < 20; i++) {
			//CM.AddXSLTToCache("Key" + i, new XSLTEntry("Value" + i, ""));
		}

		CM.DisplayXSLTCache();
	}
}
