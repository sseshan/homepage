package com.intel.utils;

import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.stevesoft.pat.*;

import com.intel.sensors.oa.Log;
import com.intel.sensors.oa.*;


/*
 * server for the Query2 type queries
 */

public class Query2Server
 {
     private static boolean DebugON = false;
     private final String logFileName = "access.log";
     private static BufferedWriter logbw = null;

     public Query2Server() {
	 try {
	     logbw = new BufferedWriter(new FileWriter(logFileName, true));
	 } catch (Exception e) {
	     e.printStackTrace();
	 }
     }

     public static synchronized void writeLog(String st) {
	 try {
	     java.util.Date d = new java.util.Date();
	     String s = d.toString() + " " + st;
	     logbw.write(s, 0, s.length());
	     logbw.newLine();	
	     logbw.flush();
	 } catch (Exception e) {};
     }

    public static ServerSocket getListenSocket() {
	ServerSocket sock;
        try {
            sock = new ServerSocket(0);
	    sock.setSoTimeout(120000); // 60 secs timeout	
        } catch (Exception e) {
            e.printStackTrace();
            //System.exit(1);
	    return null;
        }
	
	return sock;
    }

    
    public static String listenToAndReceiveAMessage(ServerSocket listenServersocket) {
        try {
            Socket s = listenServersocket.accept();
	    DataInputStream inStream = new DataInputStream(s.getInputStream());
	    System.out.println("Waiting for response..");
            //Thread.sleep(300);
	    while (inStream.available() == 0) ;	
            String result = null;
	    	
            if(inStream.available() != 0) {
                result = Packet.receive(inStream);
		System.out.println("Response received");
            } else {
                result = "<noresults/>";
		System.out.println("No response received... giving up.");
            }
	    inStream.close();
            s.close();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
	    return "<error> Operation Time Out </error>";	
        }
        //return null;
    }

    /** This accepts the initial request from the client */
    public static void run_server(int port) {
        ServerSocket serversocket = null;
        try {
            serversocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
	
        while(true) {
            Socket s = null;
            try {
		s = serversocket.accept();
                System.out.println("Got a new connection.");
		ProcessRequest req = new ProcessRequest(s);
		req.start();
            } catch (Exception e) {
                e.printStackTrace();
		System.out.println("Continueing");
            }
        }
    }

    private static class ProcessRequest extends Thread
    {
	Socket s;
	boolean errorFlag = false;
	static long qId = 20000;

	public ProcessRequest(Socket _s) {
	    s = _s;
	}

	public void run() 
	{
	    String requestString = null, fromIrisNet = "";
	
	    try {
		InputStreamReader isr = new InputStreamReader(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		try {
		    String str;
		    BufferedReader br = new BufferedReader(isr);
		    requestString = br.readLine();
		    //requestString = "multiCall(/irisnetSigROOT[@id='irisnetSigROOT']/service[@id='irislogSig']/country[@id='usa']/region[@id='usa-east']/site[@id='cmu']/node/sensor[@id='SLICESTAT']/SLICE, 'GROUPBY id', 'avg pmem', 'avg vmem')";
		} catch (Exception e) {
		}
		
		System.out.println("request String: " + requestString);

		StringTokenizer tokens1 = new StringTokenizer(requestString, " ");
		String command = tokens1.nextToken();
		if (command.equalsIgnoreCase("ping")) {
		    dos.writeBytes("pong");
                    dos.write(0);
                    dos.flush();
                    //Thread.sleep(100);
                    dos.close();
                    s.close();
		} else if (command.equalsIgnoreCase("query")) {
		    requestString = tokens1.nextToken("");
		    //1.  create a socket to listen from irisnet 
		    ServerSocket listenSock = getListenSocket();
		    // 2. send the query to irisnet
		    StringTokenizer tokens = new StringTokenizer(requestString, "(,");
		    tokens.nextToken(); // skip "multicall("
		    String dstHost = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(tokens.nextToken());
		    System.out.println("Sensing Query");
		    Protocol.sendQuery2MessageWithPort(qId++, 4, "irisnet5ROOT", null, 
						       requestString, 
						       dstHost, 6788,
						       listenSock.getLocalPort(), false);
		    
		    
		    errorFlag = false;
		    // 3. receive the response from irisnet
		    String response = listenToAndReceiveAMessage(listenSock);
		    System.out.println("Received response: " + response); 
		    dos.writeBytes(response.substring(1, response.indexOf("ENDMESSAGE")));
		    dos.write(0);
		    dos.flush();
		    Thread.sleep(100);
		    dos.close();
		    s.close();
		    //Log.shutdownlogger();
		}
            } catch (Exception e) {
                e.printStackTrace();
                try { 
                    DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                    dos.writeBytes("Error: " + fromIrisNet + "");
                    dos.write(0);
                    dos.flush();
                    //Thread.sleep(100);
                    dos.close();
                    s.close();
                } catch (Exception ee) {
                }
		System.out.println("Continueing");
		errorFlag = true;
            }

	    CannedQueries_threads.writeLog(s.getInetAddress().toString() + " " + requestString + " " + (errorFlag? "ERROR" : "OK"));
	    System.out.println("Done processing request");
	} // run

    } // class

    public static void main(String[] args) {
	Query2Server q2 = new Query2Server();
	ConfigurationManager CM = ConfigurationManager.instance();
	CM.loadConfiguration("oa.cfg");
	CM.printConfiguration();

        try {
	    //com.intel.sensors.oa.Protocol.myPortNumber = Integer.parseInt(args[1]);
	    // start the heartbeat server
	    if (!CM.getHBIP().equals("0.0.0.0")) {
		HeartBeat hb = new HeartBeat(CM.getHBIP(), CM.getHBPort(), CM.getHBPeriod());
		Thread t1 = new Thread(hb);
		t1.start();
	    }

            q2.run_server(Integer.parseInt(args[0]));

	    
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};
