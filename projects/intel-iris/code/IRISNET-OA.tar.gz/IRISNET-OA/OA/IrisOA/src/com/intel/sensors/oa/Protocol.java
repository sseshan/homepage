/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
   met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;

/** Defines the protocol : any message must go through this. No other place in the code
 *  should create the message by itself. Similarly, all the messages should be decoded
 *  here. Currently, all messages are tagged with an " ENDMESSAGE" to get rid of that null
 *  character problem (Note: that null character problem has been resolved, so no need 
 * for this now)
 *
 *  @author Amol */
public class Protocol 
{
    public static int myPortNumber = -1;
	
    public static boolean GET_ACK = true, GET_NOACK = false;
	
    public static ParsedMessage parseIncomingMessage(String _message) throws Exception 
    {
        String message = preprocessMessage(_message);

        StringTokenizer tokens = new StringTokenizer(message, " \n");
        int tokenCount = tokens.countTokens(); // of limited use since two of the things below change the delimiter

        ParsedMessage pm = new ParsedMessage();
		pm.originalMessage = _message;
        pm.opCode = tokens.nextToken();
		if (pm.opCode.equals(Globals.COMMAND_FETCH_DONE)) {
			pm.fetchDone = true;
			pm.opCode = tokens.nextToken();
		} else
			pm.fetchDone = false;
		
        pm.srcIP = tokens.nextToken();
		// since we hear from the host, assuming symmetry, we exlude it from the black list
		Packet.removeFromBlackList(pm.srcIP);


        if(pm.opCode.equals(Globals.COMMAND_LOAD)) {
            if(tokenCount != 6) {
                throw new Exception("Message not in correct format");
            }
            pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.language = tokens.nextToken();
            pm.fileName = tokens.nextToken();
            pm.scriptName = tokens.nextToken();
        } else if(pm.opCode.equals(Globals.COMMAND_SUBS)) { 
            if(tokenCount != 5) {
                throw new Exception("Message not in correct format");
            }
            pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.language = tokens.nextToken();
            // apparantely, fileName is "not needed", but otherwise same as above
            pm.scriptName = tokens.nextToken(); 
        }
        else if(pm.opCode.equals(Globals.COMMAND_UNSUBS)) 
        { 
            if(tokenCount != 5) 
            {
                throw new Exception("Message not in correct format");
            }
            pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.language = tokens.nextToken();
            // apparantely, fileName is "not needed", but otherwise same as above
            pm.scriptName = tokens.nextToken(); 
        }
        else if(pm.opCode.equals(Globals.COMMAND_MULTIPLE_MESSAGES)) 
	{
	    pm.numMessages = Integer.parseInt(tokens.nextToken());
	}
        else if(pm.opCode.equals(Globals.COMMAND_QUERY2)) 
        { 
            pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.queryID = tokens.nextToken(); 
	    pm.resultType = Integer.parseInt(tokens.nextToken());
            pm.rootAtNode = tokens.nextToken(); 
	    String str = tokens.nextToken();
	    if ((str.length() > 2) && (str.charAt(0)=='[') &&
		(str.charAt(str.length()-1) == ']'))
              pm.expirySubtree = str;
	    else
	      pm.expirySubtree = null;
            // changing the original format to return everything afterwards
	    // " " at the beginning
            pm.query = tokens.nextToken("").substring(1);
        }
        else if(pm.opCode.equals(Globals.COMMAND_REPLY2)) 
        { 
            pm.queryID = tokens.nextToken();
	    pm.resultType = Integer.parseInt(tokens.nextToken());
            pm.response = tokens.nextToken("").substring(1);
        }
        else if(pm.opCode.equals(Globals.COMMAND_ADD_STORED_QUERY)) 
        { 
	    pm.rootAtNode = tokens.nextToken();
	    pm.st_name = tokens.nextToken();
	    pm.query = tokens.nextToken("").substring(1);
        }
        else if(pm.opCode.equals(Globals.COMMAND_REMOVE_STORED_QUERY)) 
        { 
	    pm.rootAtNode = tokens.nextToken();
	    pm.st_name = tokens.nextToken();
        }
        else if(pm.opCode.equals(Globals.COMMAND_QUERY)) 
        { 
            pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.queryID = tokens.nextToken(); 
            pm.fragmentNumber = Integer.parseInt(tokens.nextToken());
            pm.rootAtNode = tokens.nextToken(); 
			pm.dstHostName = tokens.nextToken(); 
            // changing the original format to return everything afterwards
            pm.query = tokens.nextToken("").substring(1); // some " " at the beginning
        }
        else if(pm.opCode.equals(Globals.COMMAND_REPLY)) 
        { 
            pm.queryID = tokens.nextToken();
            pm.fragmentNumber = Integer.parseInt(tokens.nextToken());
            pm.nodeIdentifyingQuery = tokens.nextToken();
            // pm.databaseName = tokens.nextToken();
            pm.response = tokens.nextToken("").substring(1);
        }
	else if(pm.opCode.equals(Globals.COMMAND_FETCH_DONE))
        {
            pm.queryID = tokens.nextToken();
            pm.fragmentNumber = Integer.parseInt(tokens.nextToken());
            pm.nodeIdentifyingQuery = tokens.nextToken();
            // pm.databaseName = tokens.nextToken();
            pm.response = tokens.nextToken("").substring(1);
        }
        else if(pm.opCode.equals(Globals.TAKE_OWNERSHIP)) 
        {
            pm.document = tokens.nextToken("").substring(1);
        }
        else if(pm.opCode.equals(Globals.DELEGATE_OWNERSHIP) || pm.opCode.equals(Globals.SHARE_OWNERSHIP)) 
        {
			// old code, no replication
			//pm.targetIP = tokens.nextToken();
			//pm.targetPort = Integer.parseInt(tokens.nextToken());
			//pm.delegateXpathQuery = tokens.nextToken("").substring(1);
			
			int hostCount = Integer.parseInt(tokens.nextToken());
			pm.targetIP = new String[hostCount];
			for (int i = 0; i<hostCount; i++)
				pm.targetIP[i] = tokens.nextToken();
			pm.targetPort = Integer.parseInt(tokens.nextToken());
			pm.delegateXpathQuery = tokens.nextToken("").substring(1);
			
        }
        else if(pm.opCode.equals(Globals.COMMAND_SIMPLE_QUERY)) 
		{ 
				pm.srcPort = Integer.parseInt(tokens.nextToken());
            pm.query = tokens.nextToken("").substring(1); // some " " at the beginning
        }
        else if(pm.opCode.equals(Globals.COMMAND_EVICT)) 
        {
            pm.databaseName = tokens.nextToken();
            pm.currentTime = tokens.nextToken();
            System.out.println("Current Time " + pm.currentTime);
        }
        else if(pm.opCode.equals(Globals.COMMAND_DELETE_DATABASE)) 
        {
            pm.databaseName = tokens.nextToken();
        }
        else if(pm.opCode.equals(Globals.COMMAND_UPDATE_DNS_ALL)) 
        {
            pm.databaseName = tokens.nextToken();
        }
        else if(pm.opCode.equals(Globals.COMMAND_LOAD_DATA_FROM_SA)) 
        {
            int num_values = Integer.parseInt(tokens.nextToken());
            pm.xpath_queries = new String[num_values];
            pm.new_values = new String[num_values];
            for(int i = 0; i < num_values; i++) 
            {
                pm.xpath_queries[i] = tokens.nextToken();
                pm.new_values[i] = tokens.nextToken();
            }
			pm.response = pm.xpath_queries[0];
        } else if (pm.opCode.equals(Globals.COMMAND_XUPDATE_FROM_SA)) {
			pm.xpath_queries = new String[1];
			pm.response = pm.xpath_queries[0] = tokens.nextToken("");
		} else if(pm.opCode.equals(Globals.COMMAND_CACHING_ON)) {
            // nothing to do here really
        }
        else if(pm.opCode.equals(Globals.COMMAND_CACHING_OFF)) 
        {
            // nothing to do here really
        }
        else if(pm.opCode.equals(Globals.COMMAND_SET_TIME_TO_ZERO)) 
        {
            // nothing to do here really
        } else if (pm.opCode.equals(Globals.COMMAND_STAT_RESET)) {
			System.out.println("STAT_RESET received");
			// nothing to do
		} else if (pm.opCode.equals(Globals.COMMAND_STAT_WRITE)) {
			// nothing to do
		} else if (pm.opCode.equals(Globals.COMMAND_SHUTDOWN)) {
			// nothing to do
		}
        else {
            throw new Exception("Message not in correct format");
        }
        return pm;
    }

    /** returns the real IP of the local machine (not 127.0.0.1). XXX should cache this */
    public static String getLocalIP()
    {
	    String _ip = (ConfigurationManager.instance()).getLocalIP();
	    if (_ip != "0.0.0.0")
		    return _ip;
	    try {
		    // old implementation - doesn't always work for private network addresses
		    String hostname = InetAddress.getLocalHost().getHostName();
		    // System.out.println("Protocol.getLocalIP(): Localhost Host Name is " + hostname);
		    InetAddress[] ads = InetAddress.getAllByName(hostname);
		    String IP;
		    for (int i=0; i<ads.length; i++) {
			    IP = ads[i].getHostAddress();
			    // System.out.println(IP);
			    if (!IP.equals("127.0.0.1")) 
				    return IP;
		    }

		    // alternate implementation
		    Socket tmpSock = new Socket("www.cmu.edu", 80); // HTTP to cmu web server
		    InetAddress localAddr = tmpSock.getLocalAddress();
		    System.out.println("Protocol.getLocalIP(): " + localAddr);
		    
		    if (! localAddr.getHostAddress().equals("127.0.0.1"))
			    return localAddr.getHostAddress();
		    
	    } catch (IOException ex) {
		    ex.printStackTrace();
		    // System.exit(1);
		    return new String("127.0.0.1");
	    }
	    //java.lang.Thread.dumpStack();
	    //System.out.println("Can't find any other IP address... fatal error");
	    // System.exit(1);
	    System.out.println("Protocol.getLocalIP(): Can't get real IP address of local machine.  Using 127.0.0.1.");
	    return new String("127.0.0.1");
    }
	
    public static int getLocalPort() 
    {
        return myPortNumber;
    }

    /** Send a message asking for a query to be answered */
	public static String sendQueryMessage(String queryID, String hostName, int port, String query, int fragmentNumber, String rootAtNode, String dstHostName) throws Exception 
	{ 
		return sendQueryMessage(queryID, hostName, port, query, fragmentNumber, rootAtNode,dstHostName, false);
    }

	public static String sendQueryMessage(int queryID, String hostName, int port, String query, int fragmentNumber, String rootAtNode, String dstHostName) throws Exception
	{
		return sendQueryMessage(Integer.toString(queryID), hostName, port, query, fragmentNumber, rootAtNode, dstHostName);
	}


	public static String sendQueryMessage(int queryID, String hostName, int port, String query, int fragmentNumber, String rootAtNode, String dstHostName, boolean getAck) throws Exception
	{
		return sendQueryMessage(Integer.toString(queryID), hostName, port, query, fragmentNumber, rootAtNode, dstHostName, getAck);
	}

    public static String sendQueryMessage(String queryID, String hostName, int port, String query, int fragmentNumber, String rootAtNode, String dstHostName, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_QUERY + " " + getLocalIP() + " " + getLocalPort() + " " +  queryID + " " + fragmentNumber + " " + rootAtNode + " " + dstHostName + " " + query;

		if (Globals.LoggingON) {
			if(getLocalPort() == ConfigurationManager.instance().getOAPort()) {
				Log.sendToReplayServer("REPLAY PACKET QUERY " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + query);
			} else {
				Log.sendToReplayServer("REPLAY PACKET COMMAND " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + query);
			}
		}
        return sendPacket(packet, hostName, port, getAck);
    }


    public static String sendQueryMessageWithPort(String queryID, int myPort, String IP, int port, String query, int fragmentNumber, String 
rootAtNode, String dstHostName, boolean getAck) throws Exception
    {
        String packet = Globals.COMMAND_QUERY + " " + getLocalIP() + " " + myPort + " " +  queryID + " " + fragmentNumber + " " + rootAtNode + " " + dstHostName + " " + query;

        if(myPort  == ConfigurationManager.instance().getOAPort()) {
            Log.sendToReplayServer("REPLAY PACKET QUERY " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(IP).getHostAddress() + " " + packet.length() + " red " + query);
        } else {
            Log.sendToReplayServer("REPLAY PACKET COMMAND " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(IP).getHostAddress() + " " + packet.length() + " red " + query);
        }

        return sendPacket(packet, IP, port, getAck);
    }


	// DNS caching may make the query routing incorrect: a query for a node may be 
	// routed to an OA who does no longer own the corresponding node. 
	// This might happen because, although the DNS mapping of the node name to 
	// owner ip has changed, OAs may still use the old cached DNS mappings
	//
	// this new version of sendQueryMessage sends a query to an OA and receives the 
	// ack. If the ack is "DELEGATED" (meaning the OA the query was sent to
	// no longer owns the node), it tries to send the query again to 
	// the deleated node
	//
	// The rerouting uses IP address, instead of the host name. The IP address
	// of the new target is found in two ways: the target OA of the previous
	// try may ack with "DELEGETEDTO <IP>", in which case the retry uses the <IP>
	// Otherwise, the name is resolved with getAllByName(), and a different IP
	// is picked up
	//
	// We currently retry only once. (hoping that the DNS TTL is small (10 min)
	// and a delegated node is not delegated somewhere else within this time)
	//
	// This method should eventually replace the original sendQueryMessage() 
	
    public static void sendQueryMessageVerify(String queryID, String hostName, int port, String query, int fragmentNumber, String rootAtNode, String dstHostName) throws Exception 
    { 
        String packet = Globals.COMMAND_QUERY + " " + getLocalIP() + " " + getLocalPort() + " " +  queryID + " " + fragmentNumber + " " + rootAtNode + " " + dstHostName + " " + query;

		if (Globals.LoggingON) {
			if(getLocalPort() == ConfigurationManager.instance().getOAPort()) {
				Log.sendToReplayServer("REPLAY PACKET QUERY " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + query);
			} else {
				Log.sendToReplayServer("REPLAY PACKET COMMAND " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + query);
			}
		}
        String response = sendPacket(packet, hostName, port, true);
		System.out.println("sendQueryMessageVerify() response:" + response);
		if (response.equals("SUCCESS")) return ;
		
		// response is "DELEGATEDTO" or "DELEGATEDFROM"
		StringTokenizer tokens = new StringTokenizer(response, " ");
		String responseCode = tokens.nextToken();
		if (responseCode.equals("DELEGATEDTO")) {
			String newIP = tokens.nextToken();
			System.out.println("Received DELEGATEDTO " + newIP);
			response = sendPacketToIP(packet, newIP, port, false);
		} else if (responseCode.equals("DELEGATEDFROM")) {
			// this should not happen. (An OA delegating a node
			// should always remember the new IP). 
			// Still I am keeping this backup plan (to see if I am correct)
			// currently, we just retry to route the message using the hostname
			// and hope that this time the Packet.send() will use a different
			// IP (because of round robin DNS)
			System.out.println("CHECK!! ****** got DELEGATEDFROM!! *****");
			response = sendPacket(packet, hostName, port, true); 
		}
		return;
    }

	/** Send an xupdate message **/
	public static void sendXupdate(String xupdate, String host, int port) throws Exception
	{
		String message = Globals.COMMAND_XUPDATE_FROM_SA + " " + getLocalIP() + " " + xupdate;
		sendPacket(message, host, port, false);
	}
	public static void sendXupdate(String xupdate, String host) throws Exception
	{
		ConfigurationManager CM = ConfigurationManager.instance();
		sendXupdate(xupdate, host, CM.getOAPort());
	}

    /** Send a reply message */
    public static String sendReplyMessage(String queryID, String hostName, int port, String response, int fragmentNumber, String nodeIdentifyingQuery) throws Exception 
    {
        return sendReplyMessage(queryID, hostName, port, response, fragmentNumber, nodeIdentifyingQuery, false);
    }
    public static String sendReplyMessage(String queryID, String hostName, int port, String response, int fragmentNumber, String nodeIdentifyingQuery, boolean getAck) throws Exception 
    {
		ConfigurationManager CM = ConfigurationManager.instance();
        String packet = Globals.COMMAND_REPLY + " " + getLocalIP() + " " + queryID + " " + fragmentNumber + " " + nodeIdentifyingQuery + " " + response;
		
		if (Globals.LoggingON) {
			if(port == CM.getOAPort()) 
				{
					Log.sendToReplayServer("REPLAY PACKET REPLY " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + nodeIdentifyingQuery);
				}
			else 
				{
					Log.sendToReplayServer("REPLAY PACKET ANSWER " + Lamport.getClock() + " " + getLocalIP() + " " + InetAddress.getByName(hostName).getHostAddress() + " " + packet.length() + " red " + nodeIdentifyingQuery);
				}
		}
		
        return sendPacket(packet, hostName, port, getAck);
    }



    /** Send a take ownership of a document message */
    public static String sendTakeOwnershipMessage(String hostName, int port, String document) throws Exception 
    {
        return sendTakeOwnershipMessage(hostName, port, document, false);
    }
    public static String sendTakeOwnershipMessage(String hostName, int port, String document, boolean getAck) throws Exception 
    {
        String packet = Globals.TAKE_OWNERSHIP + " " + getLocalIP() + " " + document;
        return sendPacket(packet, hostName, port, getAck);
    }



    /** Delegate ownership of a part of your document */

	/* Old version, no replication 
	   public static String sendDelegateOwnershipMessage(String hostName, int port, String xpath, String targetHostName, int targetPort) throws Exception 
	   {
	   return sendDelegateOwnershipMessage(hostName, port, xpath, targetHostName, targetPort, false);
	   }
	   public static String sendDelegateOwnershipMessage(String hostName, int port, String xpath, String targetHostName, int targetPort, boolean getAck) throws Exception 
	   {
	   String packet = Globals.DELEGATE_OWNERSHIP + " " + getLocalIP() + " " + targetIP + " " + targetPort + " " + xpath;
	   return sendPacket(packet, hostName, port, getAck);
	   }
	*/

	public static String sendDelegateOwnershipMessage(String hostName, int port, String xpath, String[] targetHostName, int targetPort, boolean removeFromLocalDatabase) throws Exception
	{
		return sendDelegateOwnershipMessage(hostName, port, xpath, targetHostName, targetPort, removeFromLocalDatabase, false);
	}
        public static String sendDelegateOwnershipMessage(String hostName, int port, String xpath, String[] targetHostName, int targetPort, boolean removeFromLocalDatabase, boolean getAck)
		throws Exception {
			String op = removeFromLocalDatabase? Globals.DELEGATE_OWNERSHIP : Globals.SHARE_OWNERSHIP;
			String packet = op + " " + getLocalIP() + " " + targetHostName.length + " ";
			for (int i = 0; i<targetHostName.length; i++)
				packet += (targetHostName[i] + " ");
			packet += (targetPort + " " + xpath);
			return sendPacket(packet, hostName, port, getAck);
        }


    /** A Simple Query Message */
    public static String sendSimpleQueryMessage(String hostName, int port, String query) throws Exception 
    { 
        return sendSimpleQueryMessage(hostName, port, query, false);
    }
    public static String sendSimpleQueryMessage(String hostName, int port, String query, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_SIMPLE_QUERY + " " + getLocalIP() + " " + getLocalPort() + " " +  query;
        return sendPacket(packet, hostName, port, getAck);
    }



    /** Evict your cache */
    public static String sendEvictCacheMessage(String hostName, int port, String databaseName, String currentTime) throws Exception 
    { 
        return sendEvictCacheMessage(hostName, port, databaseName, currentTime, false);
    }
    public static String sendEvictCacheMessage(String hostName, int port, String databaseName, String currentTime, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_EVICT + " " + getLocalIP() + " " + databaseName + " " + currentTime;
        return sendPacket(packet, hostName, port, getAck);
    }

    /** Delete this document */
    public static String sendDeleteDatabaseMessage(String hostName, int port, String databaseName) throws Exception 
    { 
        return sendDeleteDatabaseMessage(hostName, port, databaseName, false);
    }
    public static String sendDeleteDatabaseMessage(String hostName, int port, String databaseName, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_DELETE_DATABASE + " " + getLocalIP() + " " + databaseName;
        return sendPacket(packet, hostName, port, getAck);
    }


    /** Update all DNS entries possibly corresponding to you */
    public static String sendUpdateDNSAll(String hostName, int port, String databaseName) throws Exception 
    { 
        return sendUpdateDNSAll(hostName, port, databaseName, false);
    }
    public static String sendUpdateDNSAll(String hostName, int port, String databaseName, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_UPDATE_DNS_ALL + " " + getLocalIP() + " " + databaseName;
        return sendPacket(packet, hostName, port, getAck);
    }

    /** Set the time to zero -- for measurement purposes only */
    public static String sendSetTimetoZero(String hostName, int port) throws Exception 
    { 
        return sendSetTimetoZero(hostName, port, false);
    }
    public static String sendSetTimetoZero(String hostName, int port, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_SET_TIME_TO_ZERO + " " + getLocalIP();
        return sendPacket(packet, hostName, port, getAck);
    }

    /** Set caching to off */
    public static String sendCachingOff(String hostName, int port) throws Exception 
    { 
        return sendCachingOff(hostName, port, false);
    }
    public static String sendCachingOff(String hostName, int port, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_CACHING_OFF + " " + getLocalIP();
        return sendPacket(packet, hostName, port, getAck);
    }

    /** Set caching to on */
    public static String sendCachingOn(String hostName, int port) throws Exception 
    { 
        return sendCachingOn(hostName, port, false);
    }
    public static String sendCachingOn(String hostName, int port, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_CACHING_ON + " " + getLocalIP();
        return sendPacket(packet, hostName, port, getAck);
    }

	/** Reset Statistics to 0 */
        public static String sendResetStat(String hostName, int port) throws Exception {
                return sendResetStat(hostName, port, false);
        }

        public static String sendResetStat(String hostName, int port, boolean getAck) throws Exception {
                String packet = Globals.COMMAND_STAT_RESET + " " + getLocalIP();
                return sendPacket(packet, hostName, port, getAck);
        }

        /** Write Statistics to local logfile */
        public static String sendWriteStat(String hostName, int port) throws Exception {
                return sendWriteStat(hostName, port, false);
        }

        public static String sendWriteStat(String hostName, int port, boolean getAck) throws Exception {
                String packet = Globals.COMMAND_STAT_WRITE + " " + getLocalIP();
                return sendPacket(packet, hostName, port, getAck);
        }

        /** Shutdown the OA */
	public static String sendShutdown(String hostName, int port) throws Exception {
		return sendShutdown(hostName, port, false);
	}

	public static String sendShutdown(String hostName, int port, boolean getAck) throws Exception {
		String packet = Globals.COMMAND_SHUTDOWN + " " + getLocalIP();
		return sendPacket(packet, hostName, port, getAck);
	}


    /** I got New data */
    public static String sendNewDataMessage(String hostName, int port, String[] xpathqueries, String[] new_values) throws Exception 
    { 
        return sendNewDataMessage(hostName, port, xpathqueries, new_values, false);
    }

    public static String sendNewDataMessage(String hostName, int port, String[] xpathqueries, String[] new_values, boolean getAck) throws Exception 
    { 
        String packet = Globals.COMMAND_LOAD_DATA_FROM_SA + " " + getLocalIP() + " " + xpathqueries.length + " ";
        for(int i = 0; i < xpathqueries.length; i++) 
        {
            packet += xpathqueries[i] + " " + new_values[i] + " ";
        }
        return sendPacket(packet, hostName, port, getAck);
    }


	
    /** Send a V2 query message */
    public static String sendQuery2Message (
	  long queryID, int resultType, String rootAtNode, String query,
	  String hostName, int port) throws Exception
    {
	return sendQuery2Message (queryID, resultType, rootAtNode, query,
				  hostName, port, false);
    }

    public static String sendQuery2Message (
	  long queryID, int resultType, String rootAtNode, String query,
	  String hostName, int port, boolean getAck) throws Exception
    {
	return sendQuery2Message (queryID, resultType, rootAtNode,
		null, query, hostName, port, getAck);
    }

    public static String sendQuery2Message (
	  long queryID, int resultType, String rootAtNode, 
	  String expirySubtree, String query,
	  String hostName, int port, boolean getAck) throws Exception
    {
        final String packet = Globals.COMMAND_QUERY2 
			+ ' ' + getLocalIP() + ' ' + getLocalPort() 
			+ ' ' + queryID      + ' ' + resultType 
			+ ' ' + rootAtNode   
			+ ' ' + ((expirySubtree!=null)?expirySubtree:"null")
			+ ' ' + query;

        if (Globals.LoggingON) {
			if (getLocalPort() == ConfigurationManager.instance().getOAPort()) {
				Log.sendToReplayServer("REPLAY PACKET QUERY " 
									   + Lamport.getClock()
									   + ' ' + getLocalIP() 
									   + ' ' + InetAddress.getByName(hostName).getHostAddress() 
									   + ' ' + packet.length() 
									   + " red " 
									   + queryID + ':' + query);
			} else {
				Log.sendToReplayServer("REPLAY PACKET COMMAND " 
									   + Lamport.getClock() 
									   + ' ' + getLocalIP() 
									   + ' ' + InetAddress.getByName(hostName).getHostAddress() 
									   + ' ' + packet.length() 
									   + " red " 
									   + queryID + ':' + query);
			}
        }
	
		try {
			String s = sendPacket(packet, hostName, port, getAck);
			return s;
		} catch (Exception e) {
			enqueueSelfNullReply2 (packet+" ENDMESSAGE");
			getSelfEntry().flush ();
			return null;
		}
	}
	
    public static String enqueueQuery2Message (
	  long queryID, int resultType, String rootAtNode, 
	  String expirySubtree, String query,
	  String hostName, int port, boolean getAck) throws Exception
    {
		Globals.pending ++;
		//Log.appendLog("query2.log", "Sending QUERY2 to " + hostName);
        String packet = Globals.COMMAND_QUERY2 
			+ ' ' + getLocalIP() + ' ' + getLocalPort() 
			+ ' ' + queryID      + ' ' + resultType 
			+ ' ' + rootAtNode   
			+ ' ' + ((expirySubtree!=null)?expirySubtree:"null")
			+ ' ' + query;

        if (Globals.LoggingON) {
           if (getLocalPort() == ConfigurationManager.instance().getOAPort()) {
             Log.sendToReplayServer("REPLAY PACKET QUERY " 
		 + Lamport.getClock()
		 + ' ' + getLocalIP() 
		 + ' ' + InetAddress.getByName(hostName).getHostAddress() 
		 + ' ' + packet.length() 
		 + " red " 
		 + queryID + ':' + query);
           } else {
             Log.sendToReplayServer("REPLAY PACKET COMMAND " 
		 + Lamport.getClock() 
		 + ' ' + getLocalIP() 
		 + ' ' + InetAddress.getByName(hostName).getHostAddress() 
		 + ' ' + packet.length() 
		 + " red " 
		 + queryID + ':' + query);
           }
        }
        return enqueuePacket(packet, hostName, port, getAck);
    }

	// same as the original version; but it uses an adjustable source port
    // used by the Query2Server
    public static String sendQuery2MessageWithPort
        ( long queryID, int resultType, String rootAtNode,
          String expirySubtree, String query,
          String dstHostName, int dstPort, int srcPort, boolean getAck) throws Exception
    {
        String packet = Globals.COMMAND_QUERY2
            + ' ' + getLocalIP() + ' ' + srcPort
            + ' ' + queryID      + ' ' + resultType
            + ' ' + rootAtNode
            + ' ' + ((expirySubtree!=null)?expirySubtree:"null")
            + ' ' + query;
        return sendPacket(packet, dstHostName, dstPort, getAck);
    }


    /** Send a V2 reply message */
    public static String sendReply2Message (
          long queryID, int resultType, String response,
          String hostName, int port) throws Exception
    {
	return sendReply2Message (queryID, resultType, response,
				  hostName, port, false);
    }
    public static String sendReply2Message (
	  long queryID, int resultType, String response,
	  String hostName, int port, boolean getAck) throws Exception
    {
        String packet = Globals.COMMAND_REPLY2 
			+ ' ' + getLocalIP() 
			+ ' ' + queryID + ' ' + resultType 
			+ ' ' + response;

        if (Globals.LoggingON) {
           if (port == ConfigurationManager.instance().getOAPort()) {
             Log.sendToReplayServer("REPLAY PACKET REPLY " 
		 + Lamport.getClock() 
		 + ' ' + getLocalIP() 
		 + ' ' + InetAddress.getByName(hostName).getHostAddress() 
		 + ' ' + packet.length() 
		 + " red " 
		 + queryID);
           } else {
             Log.sendToReplayServer("REPLAY PACKET ANSWER "
		 + Lamport.getClock() 
		 + ' ' + getLocalIP()
		 + ' ' + InetAddress.getByName(hostName).getHostAddress()
		 + ' ' + packet.length()
		 + " red "
		 + queryID);
           }
        }

        return sendPacket(packet, hostName, port, getAck);
    }

    public static String enqueueReply2Message (
          long queryID, int resultType, String response,
          String hostName, int port, boolean getAck) throws Exception
    {
        String packet = Globals.COMMAND_REPLY2
                        + ' ' + getLocalIP()
                        + ' ' + queryID + ' ' + resultType
                        + ' ' + response;
                                                                                
        if (Globals.LoggingON) {
           if (port == ConfigurationManager.instance().getOAPort()) {
             Log.sendToReplayServer("REPLAY PACKET REPLY "
                 + Lamport.getClock()
                 + ' ' + getLocalIP()
                 + ' ' + InetAddress.getByName(hostName).getHostAddress()
                 + ' ' + packet.length()
                 + " red "
                 + queryID);
           } else {
             Log.sendToReplayServer("REPLAY PACKET ANSWER "
                 + Lamport.getClock()
                 + ' ' + getLocalIP()
                 + ' ' + InetAddress.getByName(hostName).getHostAddress()
                 + ' ' + packet.length()
                 + " red "
                 + queryID);
           }
        }
                                                                                
        return enqueuePacket(packet, hostName, port, getAck);
    }

    public static String sendAddStoredProcedureMessage (
	String query_for_element, String st_name, String st_query,
	String hostName, int port) throws Exception
    {
	String packet = Globals.COMMAND_ADD_STORED_QUERY
		        + ' ' + getLocalIP()
			+ ' ' + query_for_element
			+ ' ' + st_name
			+ ' ' + st_query;

	return sendPacket(packet, hostName, port, false);
    }

    public static String sendRemoveStoredProcedureMessage (
        String query_for_element, String st_name,
        String hostName, int port) throws Exception
    {
        String packet = Globals.COMMAND_REMOVE_STORED_QUERY
                        + ' ' + getLocalIP()
                        + ' ' + query_for_element
                        + ' ' + st_name;
                                                                                
        return sendPacket(packet, hostName, port, false);
    }

    public static String constructMultipleMessageHeader (int num_messages)
    {
        String packet = Globals.COMMAND_MULTIPLE_MESSAGES
                        + ' ' + getLocalIP()
                        + ' ' + num_messages + " ENDMESSAGE";

	return packet;
    }

    public static String sendPacket(String message, String hostName, int port, boolean getAck) throws Exception 
    {
        String ack = null;

        System.out.println("Protocol.sendPacket(): SendPacket to "
                + hostName + ":" + port +" :");

        if(getAck) 
        {
            ack = Packet.sendReceiveAck(message+" ENDMESSAGE", hostName, port);
        }
        else 
        {
            Packet.send(message+" ENDMESSAGE", hostName, port);
        }
        return ack;
    }

    public static String sendPacketToIP(String message, String IP, int port, boolean getAck) throws Exception 
    {
        String ack = null;

        System.out.println("Protocol.sendPacket(): SendPacket to " 
                + IP + ":" + port +" :");

        if(getAck) 
        {
            ack = Packet.sendReceiveAckToIP(message+" ENDMESSAGE", IP, port);
        }
        else 
        {
            Packet.sendToIP(message+" ENDMESSAGE", IP, port);
        }
        return ack;
    }

    public static String preprocessMessage(String message) throws Exception 
    {
		try {
			int index = message.indexOf(" ENDMESSAGE");
			// System.out.println(message);
			// System.out.println("Index is " + index);
			return message.substring(0, index);
		} catch (Exception e) {
			System.out.println("WEIRd MESSAGE: " + message);
			throw e;
		}
    }

    // combining messages
    static Hashtable  host_packets_table = new Hashtable ();
    static Hashtable  thread_packets_table = new Hashtable ();
    static IPPacketEntry self_entry = null;
    static String     COMMAND_QUERY2_PREFIX = Globals.COMMAND_QUERY2 + ' ';

    public static IPPacketEntry getSelfEntry ()
    {
	if (self_entry == null) {
	  String IP = getLocalIP();
	  int port = getLocalPort();
	  String key = IP + ':' + port;
	  self_entry = (IPPacketEntry) host_packets_table.get (key);
	  if (self_entry == null) {
	    self_entry = new IPPacketEntry (IP, port);
	    host_packets_table.put (key, self_entry);
	  }
	}

	return self_entry;
    }

	public static String enqueuePacket(String message,
                                       String hostName, int port, boolean getAck) throws Exception
	{
		if (!getAck ) {
			final String _message = message + " ENDMESSAGE";
			final String _hostName = hostName;
			final int _port = port;
			new Thread() {
				public void run() {
					if (_message.startsWith(Protocol.COMMAND_QUERY2_PREFIX))
                        Timeout.instance().add(_message);
                    else
                        System.out.println("Non QUERY2 message");

					int ret = Globals.SOCK_ERROR;
					try {
						ret = Packet.send (_message, _hostName, _port);
						Log.appendLog("query2.log", "Sending QUERY2 to " + _hostName);
					} catch (Exception e) {
						Log.appendLog("query2.log", "Sending QUERY2 to " + "128.2.77.231");
					}

					if (ret != Globals.OK
						&& _message.startsWith(Protocol.COMMAND_QUERY2_PREFIX))
						Protocol.enqueueSelfNullReply2 (_message);

				}
			}.start();
			return "";
		}  // if (!getAck)
		else {
			return enqueuePacket2(message, hostName, port, getAck);
		}
		
	}

    public static String enqueuePacket2(String message, 
									   String hostName, int port, boolean getAck) throws Exception
    {
		String IP = Packet.getIPforHostName (hostName);
		
		String key = IP + ':' + port;
		IPPacketEntry entry = (IPPacketEntry) host_packets_table.get (key);
		
		if (entry == null) {
			entry = new IPPacketEntry (IP, port);
			host_packets_table.put (key, entry);
		}
		
		if (! getAck) {
			entry.enqueue (hostName, message);
			
			// record the activity in thread_packets_table
			Thread th = Thread.currentThread();
			ArrayList active_entries = (ArrayList) thread_packets_table.get (th);
			if (active_entries == null) {
				active_entries = new ArrayList ();
				thread_packets_table.put (th, active_entries);
			}
			active_entries.add (entry);
			
			return null;
		}
		else {
			entry.flush ();

			message = message+" ENDMESSAGE";
			String ack = null;
			try {
				ack = Packet.sendReceiveAckToIP (message, IP, port);
			} catch (Exception e) {
				ack = Packet.sendReceiveAck(message, hostName, port);
			}
			
			return ack;
		}
    }

    public static void flushPackets () throws Exception
    {
	ArrayList active_entries = getFlushList ();
	flushFlushList (active_entries);
    }

    // return the active entries and set the active entries to empty
    public static ArrayList getFlushList ()
    {
        Thread th = Thread.currentThread();
        ArrayList previous_entries = (ArrayList) 
			thread_packets_table.put (th, new ArrayList());
	return previous_entries;
    }

    public static void flushFlushList (ArrayList active_entries) 
		throws Exception
    {
        if (active_entries != null) {
          int num_active_entries = active_entries.size();
          for (int ii=0; ii<num_active_entries; ii++) {
             IPPacketEntry entry = (IPPacketEntry) active_entries.get (ii);
             entry.flush ();
          }
	  // flush null reply2 messages sent to the OA itself
	  getSelfEntry().flush ();
        }
    }

    // for generating null reply when a query2 destination is down
    public static void enqueueSelfNullReply2 (String query2_packet)
    {
      try {
	ParsedMessage pm = parseIncomingMessage(query2_packet);

	enqueueReply2Message (
		Long.parseLong (pm.queryID), pm.resultType, "null",
		pm.srcIP, pm.srcPort, false);

      } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
      }
    }
};

class IPPacketEntry {
   String    IP;
   int       port;
   ArrayList hosts;	// used in case the machine at IP is down
   ArrayList packets;

   IPPacketEntry (String my_IP, int my_port)
   {
	IP = my_IP;
	port = my_port;
	hosts = new ArrayList();
	packets = new ArrayList();
   }

   void enqueue (String host_name, String message)
   {
	hosts.add (host_name);
	packets.add (message+" ENDMESSAGE");
   }

   void flush () 
   {
	if (packets.size () == 0) return;

	// only one packet
	if (packets.size () == 1) {
		System.out.println("SINGLE MSG");
		final String message = (String) packets.get(0);

		new Thread() {
			public void run() {
				if (message.startsWith(Protocol.COMMAND_QUERY2_PREFIX))
					Timeout.instance().add(message);
				int ret = Globals.SOCK_ERROR;
				try {
					ret = Packet.sendToIP (message, IP, port);
					Log.appendLog("query2.log", "Sending QUERY2 to " + IP);
				} catch (Exception e) {
					Log.appendLog("query2.log", "Sending QUERY2 to " + "128.2.77.231");
				}
				
				if (ret != Globals.OK) {
					try {
						ret = Packet.send (message, (String)hosts.get(0), port);
					} catch (Exception e) {}
					
					if ((ret != Globals.OK)
						&&message.startsWith(Protocol.COMMAND_QUERY2_PREFIX))
						Protocol.enqueueSelfNullReply2 (message);
				}
			}
		}.start();
	}

	// many packets
	else {
		System.out.println("MULTIPLE MSG");
	  int ret = Globals.SOCK_ERROR;
	  try {
	     ret = Packet.sendToIP (packets, IP, port);
	  } catch (Exception e) {}

	  if (ret != Globals.OK) {
	    for (int ii=0; ii<packets.size(); ii++) {
	       String message = (String) packets.get (ii);
	       String host_name = (String) hosts.get (ii);
	       ret = Globals.SOCK_ERROR;
	       try {
	          ret = Packet.send (message, host_name, port);
	       } catch (Exception e) {}
	       if ((ret != Globals.OK)
		  &&message.startsWith(Protocol.COMMAND_QUERY2_PREFIX))
		 Protocol.enqueueSelfNullReply2 (message);
	    }
	  }
	}

	hosts.clear ();
	packets.clear ();
   }
} // IPPacketEntry
