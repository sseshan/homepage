/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;


/** Servant class that decides what to do with a message. In some cases, it calls other Servant*.
 *
 *  @author Suman, Amol
 *  */
public class Servant implements Runnable {
    // socket for connection making the request
    Socket socket = null;
    OAInformation oainfo = null;

    public static String previous_message = "dummy";

    public Servant(Socket sock, OAInformation oainfo_) {
        socket = sock;
        oainfo = oainfo_;
    }

    private void Clean() throws IOException {
        if (socket != null)
            socket.close();
    }


    public void run()
    {
        try {

            DataInputStream inStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());

            String packet = null;
            ParsedMessage pm = null;

            // get the packet that contains the OPCODE and the parameters
            packet = Packet.receive(inStream);
			if (Globals.DebugON) {
				System.out.println("Servant.run(): Received packet from " + socket.getInetAddress().toString());
				System.out.println(packet);
			}

            pm = Protocol.parseIncomingMessage(packet);
			pm.srcIP = socket.getInetAddress().getHostAddress();

	    if (! pm.opCode.equals(Globals.COMMAND_MULTIPLE_MESSAGES)) {
	      processOneMessage (pm, packet, outStream);
            }
	    else {
		// multiple messages
			if (Globals.DebugON) {
				System.out.println("Process Multiple Messages");
			}
		int num_messages = pm.numMessages;
		for (int ii=0; ii<num_messages; ii++) {
		   packet = Packet.receive(inStream);
			if (Globals.DebugON) {
				System.out.println("Servant.run(): Received packet:");
				System.out.println(packet);
			}
		   pm = Protocol.parseIncomingMessage(packet);
		   pm.srcIP = socket.getInetAddress().getHostAddress();
		   processOneMessage (pm, packet, outStream);
		}
	    }

	    // flush all the outgoing query2 and reply2 messages
		//Thread.currentThread().sleep(ConfigurationManager.instance().getTimeOut());
	    Protocol.flushPackets ();

            Clean();

        } catch (Throwable e) {
            System.out.println("Servant.run(): Exception caught.  Please debug the code.");
            e.printStackTrace();
            return;
        }
    }
			
    public void processOneMessage (ParsedMessage pm, String packet, 
				   DataOutputStream outStream) throws Exception
    {
	    ConfigurationManager CM = ConfigurationManager.instance();

			if (!pm.fetchDone &&
                        (pm.opCode.equals(Globals.COMMAND_REPLY) ||
                         pm.opCode.equals(Globals.COMMAND_LOAD_DATA_FROM_SA) ||
                         pm.opCode.equals(Globals.COMMAND_XUPDATE_FROM_SA) )) {

                        FetchHandler fh = new FetchHandler(pm);
                        fh.start();
            } else if (pm.opCode.equals(Globals.COMMAND_LOAD)) {
                SensingAgent sa = new SensingAgent(pm.srcIP, pm.srcPort);
                Script script = new Script(pm.language, pm.fileName, pm.scriptName);
                OrgAgent oa = new OrgAgent();
                oa.LoadScript(sa, script);
            } else if (pm.opCode.equals(Globals.COMMAND_SUBS)) {
                ServantSubs subs = new ServantSubs(pm);
                Thread t = new Thread(subs);
                t.start();
                // subs.run();
            } else if (pm.opCode.equals(Globals.COMMAND_QUERY2)) {
                System.out.println("Servant: Received COMMAND_QUERY2 packet.");
				Log.appendLog("query2.log", "-----------------------------------");
				processQuery2Request (pm);
				System.out.println("Servant: Processed COMMAND_QUERY2 packet.");
            } else if (pm.opCode.equals(Globals.COMMAND_REPLY2)) {
				processReply2Request (pm);
				System.out.println("Servant: Processed COMMAND_REPLY2 packet. Pending: " +  (--Globals.pending));
				Log.appendLog("query2.log", "RECEIVED REPLY2 FROM: " + pm.srcIP);
            } else if (pm.opCode.equals(Globals.COMMAND_ADD_STORED_QUERY)) {
				
				processAddStoredQuery (pm);
				
            } else if (pm.opCode.equals(Globals.COMMAND_REMOVE_STORED_QUERY)) {
				
				processRemoveStoredQuery (pm);

            } else if (pm.opCode.equals(Globals.COMMAND_QUERY)) {
                System.out.println("Servant.run(): Received COMMAND_QUERY packet.");
                if (Globals.LoggingON) {
					Log.Debug("QUERY START"); 
					Log.Debug("PACKET RECEIVE");
				}
				String response = ServantQuery.ackQuery(pm.dstHostName);
				System.out.println("******* Sending Ack: " + response);
				Packet.send(response, outStream);
                if (response.equals("SUCCESS")) {
					ServantQuery.processRequest(pm);
					System.out.println("Servant.run(): Processed COMMAND_QUERY packet.");
				} else {
					System.out.println("Servant.run(): Received query for delegated node. Redirected." + response);
				}

            } else if (pm.opCode.equals(Globals.COMMAND_REPLY)) {
                System.out.println("Servant.run(): Received COMMAND_REPLY packet.");
                ServantReply.processRequest(pm); 
                if (Globals.LoggingON)
					Log.Debug("QUERY END"); 
                System.out.println("Servant.run(): Processed COMMAND_REPLY packet.");
			} else if (pm.opCode.equals(Globals.TAKE_OWNERSHIP)) {

                System.out.println("Servant.run(): Received TAKE_OWNERSHIP packet.");
                Log.Debug("PACKET RECEIVE");
                String response = ServantTakeownership.takeOwnerShip(pm.document);

                // This message, as may others later, requires a response be sent back 
                // XXX breakage of protocol; direct talk with the class Packet
                Packet.send(response, outStream);

                System.out.println("Servant.run(): Processed TAKE_OWNERSHIP packet.");

            } else if (pm.opCode.equals(Globals.DELEGATE_OWNERSHIP)) {
                System.out.println("Servant.run(): Received DELEGATE_OWNERSHIP packet.");
                if (Globals.LoggingON)
					Log.Debug("PACKET RECEIVE");
			
				String response = "ERROR";
				try {
					response = ServantDelegateOwnership.delegateOwnerShip(pm.delegateXpathQuery,
																		  pm.targetIP, pm.targetPort, true);
					System.out.println("Servant.run(): Processed DELEGATE_OWNERSHIP packet.");
				} catch (Exception e) {
					e.printStackTrace();
					Log.logFailedOperation("breakfile 127.0.0.1 " + pm.targetIP[0] + " " + pm.delegateXpathQuery); 
				}
                Packet.send(response, outStream);
            } else if (pm.opCode.equals(Globals.SHARE_OWNERSHIP)) {
                System.out.println("Servant.run(): Received SHARE_OWNERSHIP packet.");
                if (Globals.LoggingON)
                    Log.Debug("PACKET RECEIVE");

				String response = "ERROR";
				try {
					response = ServantDelegateOwnership.delegateOwnerShip(pm.delegateXpathQuery,
																				 pm.targetIP, pm.targetPort, false);
					System.out.println("Servant.run(): Processed SHARE_OWNERSHIP packet.");
				} catch (Exception e) {
					e.printStackTrace();
					Log.logFailedOperation("replicatefile 127.0.0.1 " + pm.targetIP + " " + pm.delegateXpathQuery);
				}
				Packet.send(response, outStream);
            } else if(pm.opCode.equals(Globals.COMMAND_SIMPLE_QUERY)) {
                String response = Globals.getDatabase().executeQuery(pm.query);
                if (Globals.DebugON)
					System.out.println("Response :  "+ response);
                Protocol.sendPacket(response, pm.srcIP, pm.srcPort, Protocol.GET_NOACK);
            } else if(pm.opCode.equals(Globals.COMMAND_EVICT)) {
                System.out.println("Servant.run(): Received COMMAND_EVICT packet.");
                CacheManagement.EvictOlderThan(pm.databaseName, pm.currentTime);
                System.out.println("Servant.run(): Processed COMMAND_EVICT packet.");
            } else if(pm.opCode.equals(Globals.COMMAND_DELETE_DATABASE)) {

                System.out.println("Servant.run(): Received COMMAND_DELETE_DATABASE packet");
                org.w3c.dom.Document doc = Globals.getDatabase().getDocumentWithID(pm.databaseName);
				//org.w3c.dom.Document doc = CacheManagement.instance().GetDocumentWithID(pm.databaseName);
                DNSHelper.getDNSHelper().removeAllOwnedHostNames(doc);

                System.out.println("Servant.run(): Unsubscribing from SA's");
                /** Find the SA's that are reporting to the elements in newDoc */
                Node[] nodes = DOMProcessing.applyXPATHtoDOM(doc, "//*[@owner-sensor]");
                String[] reportingSAs = new String[nodes.length];
                for(int i = 0; i < nodes.length; i++) {
                    reportingSAs[i] = ((Element) nodes[i]).getAttribute("owner-sensor");
                }

                System.out.println("Servant.run(): There are " + reportingSAs.length + " SA's");
                /** Unsubscribe */
                for(int i = 0; i < reportingSAs.length; i++) {
                    ServantUnsubs.processRequest(reportingSAs[i], CM.getSAPort(), "C", Globals.SENSELET);
                }

		// remove continuous query
		ContinuousQuery.terminateContinuousQuery (pm.databaseName);

                System.out.println("Servant.run(): Deleting database.");
                Globals.getDatabase().deleteDocumentWithID(pm.databaseName);
                System.out.println("Servant.run(): Processed COMMAND_DELETE_DATABASE packet");

            } else if(pm.opCode.equals(Globals.COMMAND_UPDATE_DNS_ALL)) {

                System.out.println("Servant.run(): Received COMMAND_UPDATE_DNS_ALL packet");

                org.w3c.dom.Document doc = Globals.getDatabase().getDocumentWithID(pm.databaseName);
                DNSHelper.getDNSHelper().removeAllOwnedHostNames(doc);
                DNSHelper.getDNSHelper().addAllOwnedHostNames(doc);

                System.out.println("Servant.run(): Processed COMMAND_UPDATE_DNS_ALL packet");

            } else if(pm.opCode.equals(Globals.COMMAND_UNSUBS)) {
                ServantUnsubs.processRequest(pm);
            } else if(pm.opCode.equals(Globals.COMMAND_CACHING_OFF)) {
                System.out.println("Servant.run(): Received and processed COMMAND_CACHING_OFF packet");
                ServantReply.cacheResponse = false;
            } else if(pm.opCode.equals(Globals.COMMAND_CACHING_ON)) {
                System.out.println("Servant.run(): Received and processed COMMAND_CACHING_ON packet");
                ServantReply.cacheResponse = true;
            } else if(pm.opCode.equals(Globals.COMMAND_LOAD_DATA_FROM_SA)) {

                System.out.println("Servant.run(): Received COMMAND_LOAD_DATA_FROM_SA packet");

                for(int i = 0; i < pm.xpath_queries.length; i++) {
                    String xupdate_query = "<xu:modifications version='1.0' xmlns:xu='http://www.xmldb.org/xupdate'>" + 
                        "  <xu:update select=\"" + pm.xpath_queries[i] + "\">"  
                        + pm.new_values[i] + "</xu:update>" + "</xu:modifications>";
                    Globals.getDatabase().applyXUpdate(xupdate_query);
                }


                // Send a message to replay server only if there is a change; above is needed for freshness of
                // data
		int expiry_index = packet.indexOf("expiry");
                String firstpart = (expiry_index>=0)?
				    packet.substring(0, expiry_index):
				    packet;
                //String firstpart = packet.substring(0, packet.indexOf("expiry"));
                if(! firstpart.equals(previous_message)) {
		    // check if there are continuous queries depend on the changes
		    ContinuousQuery.monitorUpdates (pm.xpath_queries, pm.new_values);

                    StringBuffer messagestring = new StringBuffer();
                    for(int i = 0; i < pm.xpath_queries.length; i++) {
                        messagestring.append(pm.new_values[i]);
                        messagestring.append(" ");
                    }
                    if (Globals.LoggingON)
						Log.sendToReplayServer("REPLAY PACKET SA "
											   + Lamport.getClock() + " "
											   + pm.srcIP + " " + Protocol.getLocalIP()
											   + " " + packet.length() + " green "
											   + messagestring.toString());

                    if (Globals.DebugON)
						System.out.println("REPLAY PACKET SA "
										   + Lamport.getClock() + " "
										   + pm.srcIP + " " + Protocol.getLocalIP()
										   + " " + packet.length() + " green "
										   + messagestring.toString());
					
                    previous_message = firstpart;

                }

                System.out.println("Servant.run(): Processed COMMAND_LOAD_DATA_FROM_SA packet");
				
            } else if (pm.opCode.equals(Globals.COMMAND_XUPDATE_FROM_SA)) {
				Globals.getDatabase().applyXUpdate(pm.xpath_queries[0]);
			} else if (pm.opCode.equals(Globals.COMMAND_STAT_RESET)) {
				Statistics.instance().resetStat();
			} else if (pm.opCode.equals(Globals.COMMAND_STAT_WRITE)) {
				Statistics.instance().writeStat();
			} else if (pm.opCode.equals(Globals.COMMAND_SHUTDOWN)) {
				Statistics.instance().writeStat();
				System.exit(0);
			}

    }

    void processQuery2Request (ParsedMessage pm)
    {
		try {
			RootOperator  r = new RootOperator ();
			boolean answered_locally = r.setup (
												Long.parseLong (pm.queryID),
												pm.resultType,
												pm.rootAtNode, 
												pm.expirySubtree,
												pm.query,
												pm.srcIP,
												pm.srcPort);
			
			if (answered_locally) {
				// send query result to client
				r.processResult ();
			} else {
				r.expandRemotely ();
			}
		} catch (Exception e) {
			if (! (e instanceof NumberFormatException)) {
				handleError (e, Long.parseLong (pm.queryID), pm.srcIP, pm.srcPort);
			}
		}
    }

    void processReply2Request (ParsedMessage pm)
    {
		try {
			// no timeout for this subquery
			Timeout.instance().remove(pm.queryID);
			// parse the response part of the REPLY2 message
			long query_id = Long.parseLong (pm.queryID);
			if (pm.response.equals ("null")) {
				// null
				QueryNotify.call (query_id);
			}
			else if (pm.resultType == QueryOperator.RESULT_ERROR) {
				// error processing
				throw new QueryException (pm.response);
			}
			else if (QueryOperator.isResultTree (pm.resultType)) {
				// tree
				QueryNotify.call (query_id, pm.response);
			}
			else {
				// string[]
				
				// num_strings ' ' len0 ' ' string0 ' ' len1 ' ' string1
				String response = pm.response;
				int pos = response.indexOf (' ');
				int num_strings = (pos>=0)? 
					Integer.parseInt (response.substring(0,pos)):
					0;
				String[] reply = new String[num_strings];
				for (int ii=0; ii<num_strings; ii++) {
					pos ++;
					int next_pos = response.indexOf (' ', pos);
					int len = Integer.parseInt (response.substring(pos,next_pos));
					next_pos ++;
					reply[ii] = response.substring (next_pos, next_pos+len);
					pos = next_pos+len;
				}
				
				QueryNotify.call (query_id, reply);
			}
			
		} catch (Exception e) {
			if (! (e instanceof NumberFormatException)) {
				QueryOperator rq = 
					QueryNotify.get (Long.parseLong (pm.queryID));
				while (rq.getParent () != null) {
					rq = rq.getParent ();
				}
				RootOperator root = (RootOperator)rq;
				handleError (e, root.query_id, root.client_ip, root.client_port);
			}
		}
    }

    // generate Reply2 error response
    void handleError (Exception e, long query_id, String host, int port)
    {
	String message = (e instanceof QueryException)?
			 e.getMessage ():
			 e.getClass().toString() + ':' + e.getMessage();
	try {
	Protocol.enqueueReply2Message (query_id, QueryOperator.RESULT_ERROR,
				    message, host, port, false);
	} catch (Exception e2) {
	  System.out.println ("can't send error message!");
	}
    }

    void processAddStoredQuery (ParsedMessage pm)
    {
	// compose xupdate query
        StringBuffer xupdate_query = new StringBuffer();
        xupdate_query.append(
    "<xu:modifications version='1.0' xmlns:xu='http://www.xmldb.org/xupdate'>");
        xupdate_query.append("<xu:append select=\"");
        xupdate_query.append(pm.rootAtNode);
        xupdate_query.append("\">");
                                                                                
        boolean is_continuous = pm.query.startsWith ("continuous");
        if (is_continuous) {
          xupdate_query.append ("<xu:attribute name='");
          xupdate_query.append (pm.st_name);
          xupdate_query.append ("'>0</xu:attribute>");
        }
        xupdate_query.append ("<stored_query name='");
        xupdate_query.append (pm.st_name);
        xupdate_query.append ("' query=\"");
        xupdate_query.append (pm.query);
        xupdate_query.append ("\"/></xu:append></xu:modifications>");

	// update the database
	Globals.getDatabase().applyXUpdate(xupdate_query.toString());

	// register the continuous query
	if (is_continuous) {
	 try {
	  ContinuousQuery.addContinuousStoredQuery (pm.rootAtNode,
			null, pm.st_name);
	 } catch (Throwable e) {
	  System.out.println ("Error starting continuous stored query!");
	 }
	}
    }

    void processRemoveStoredQuery (ParsedMessage pm)
    {
	Element n = null;
	try {
	  Node node =  QueryUtils.getContextNode (pm.rootAtNode);
          n = (node instanceof Document) ?
                ((Document) node).getDocumentElement() :
                (Element) node;
	} catch (Exception e) {};
	if (n == null) return;
	String query = ContinuousQuery.getStoredQuery (pm.rootAtNode, 
						       n, pm.st_name);
						       
	// compose xupdate query
	StringBuffer xupdate_query = new StringBuffer();
	xupdate_query.append(
    "<xu:modifications version='1.0' xmlns:xu='http://www.xmldb.org/xupdate'>");
	xupdate_query.append("<xu:remove select=\"");
	xupdate_query.append(pm.rootAtNode + "/stored_query[@name='" 
			     + pm.st_name + "']");
	xupdate_query.append("\"/>");

	boolean is_continuous = query.startsWith ("continuous");
	if (is_continuous) {
	  xupdate_query.append("<xu:remove select=\"");
	  xupdate_query.append(pm.rootAtNode + "/@" + pm.st_name);
	  xupdate_query.append("\"/>");
	}
	xupdate_query.append("</xu:modifications>");

	// update the database
        Globals.getDatabase().applyXUpdate(xupdate_query.toString());

        // unregister the continuous query
        if (is_continuous) {
          ContinuousQuery.removeContinuousStoredQuery (pm.rootAtNode,
                        n, pm.st_name);
        }
    }
}
