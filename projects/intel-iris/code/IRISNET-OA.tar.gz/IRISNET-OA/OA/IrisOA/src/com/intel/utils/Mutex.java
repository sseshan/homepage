package com.intel.utils;


/** Implementation of a mutual-exclusion semaphore. It can be owned by
 *  only one thread at a time. The thread can acquire it multiple times,
 *  but there must be a release for every acquire.
 */

public final class Mutex
{
    private Thread	owner 	   = null;// Owner of mutex, null if nobody
    private int 	lock_count = 0;
    public static final long FOREVER = Long.MAX_VALUE;

    private static  Object  id_lock = new Object();
    private static  int     id_pool = 0;

    public static int new_id( ) 
    {                       
	synchronized( id_lock ) { 
	    return id_pool++;       
	} 
    }

    private final int my_id	= new_id();
    public  int id()	{ 	return my_id; 		}
    
        
    /**
     * Acquire the mutex. The mutex can be acquired multiple times
     * by the same thread, provided that it is released as many
     * times as it is acquired. The calling thread blocks until
     * it has acquired the mutex. (There is no timeout).
     *
     * @param timeout  is the the maximum amount of time that you'll wait
     *		   (in milliseconds).
     *		   Use Mutex.FOREVER to wait forever. 
     *
     * @return false  if the timeout was 0 and you did not acquire the
     *				  lock. True otherwise.
     *
     * @throw InterruptedException if the waiting thread is interrupted
     *				  before the timeout expires.
     *
     * @throw Mutex.Timed_out if the specified time elapses before the
     *		 mutex on which we are waiting is released.
     *
     */
    
    public synchronized boolean acquire( long timeout )
	throws InterruptedException,
	Timed_out
    {	
	if( timeout == 0 )
	    {	return acquire_without_blocking();
	    }
	else if( timeout == FOREVER )	
	    {	while( !acquire_without_blocking() ) 
		this.wait( FOREVER );
	    }
	else	
	    {	
		long expiration = System.currentTimeMillis() + timeout;
		while( !acquire_without_blocking() )
		    {	
			long time_remaining = 
			    expiration - System.currentTimeMillis();
			if( time_remaining <= 0 )
			    throw new Timed_out(
						"Timed out waiting for Mutex");
			
			this.wait( time_remaining );
		    }
	    }
	return true;
    }

    /** A convenience method, effectively waits forever. 
     *  @return false if interrupted, otherwise returns true.
     */
    public boolean acquire()
    {	
	try {	
	    acquire( FOREVER );	}
	catch( Exception e ){	return false;		}
	return true;
    }
    
    /**
     * Attempts to acquire the mutex. Returns false (and does not
     * block) if it can't get it. This method does not need to
     * be synchronized because it's always called from a
     * synchronized method.
     *
     * @return true if you get the mutex, false otherwise.
     */
    
    private boolean acquire_without_blocking()
    {
	Thread current = Thread.currentThread();
	
	if( owner == null )
	    {	owner = current;
	    lock_count = 1;
	    }
	else if( owner == current )
	    {	++lock_count;
	    }
	
	return owner == current;
    }
    
    /**
     * Release the mutex. The mutex has to be released as many times
     * as it was acquired to actually unlock the resource. The mutex
     * must be released by the thread that acquired it.
     *
     * @throws Ownership (a <code>RuntimeException</code>) if a thread
     *		other than the current owner tries to release the mutex.
     *		Also thrown if somebody tries to release a mutex that's
     *		not owned by any thread.
     */
    
    public synchronized void release()
    {
	if( owner != Thread.currentThread() )
	    throw new Ownership();
	
	if( --lock_count <= 0 )
	    {	owner = null;
	    this.notify();
	    }
    }

    /*********************************************
     * Exceptions
     ********************************************
     */
    
    // Thrown in the event of expired timeout
    public static final class Timed_out extends RuntimeException
    {       
	public Timed_out(){ 
	    super( "Timed out while waiting to acquire mutexs"); 
	}
	public Timed_out(String s) { 
	    super(s); 
	}
    }

  
    // Thrown when a thread tries to release a semaphore illegally, e.g.
    // a Mutex that it has not acquired successfully.
    public static final class Ownership extends RuntimeException
    {       
	public Ownership(){ 
	    super("Calling Thread doesn't own the Mutex"); 
	}
    }

}
