/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.util.Timer;
import java.net.*;
import java.io.*;
//import java.util.*;
import java.util.StringTokenizer;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

import org.w3c.dom.*;

/** Process a delegate ownership message. Static functions only. */
public class ServantDelegateOwnership extends Globals {
    /** Process a delegate ownership message. */
	public static String delegateOwnerShip(String xpathQuery, String targetIP[], int targetPort, boolean removeFromLocalDatabase) throws Exception {
		ConfigurationManager CM = ConfigurationManager.instance();
		System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Delegating part of document.");
        Document doc = Globals.getDatabase().getDocumentContainingAnswer(xpathQuery);

        System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Breaking document...");
        Document newDoc = DOMProcessing.breakDocument(doc, xpathQuery);
		String newDocString = DOMProcessing.DOMtoXML(newDoc);

        // first commit this document on the other side... do not proceed without that, 
		// 'cause we might lose data otherwise
        String ack = null;
        try {
            // postponing this till after getting an ACK creates the problem that the deletes happen after updates... not good
            // other way to take care of this is to hcange the delete command to only delete this node entry
            if (removeFromLocalDatabase) {
				System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Removing DNS entries delegated to someone else.");
				DNSHelper.getDNSHelper().removeAllOwnedHostNames(newDoc);
			}

			for (int i =0; i<targetIP.length; i++) {
				System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Asking " 
								   + targetIP[i] + ":" + targetPort
								   + " to ownership of part of document.");
				ack = Protocol.sendTakeOwnershipMessage(targetIP[i], targetPort, newDocString, Protocol.GET_ACK);
				System.out.println("ServantDelegateOwnership.delegateOwnerShip(): RECEIVED " + ack);
            }
			
			if(ack.indexOf("SUCCESS") != -1) {
				Log.saveInFile("irislog_" + targetIP[0] + ".xml", newDocString);
				if (removeFromLocalDatabase) {
					DNSHelper.getDNSHelper().addAllOwnedHostNames(doc);
					System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Unsubscribing from old SA's");
					/** Find the SA's that are reporting to the elements in newDoc */
					Node[] nodes = DOMProcessing.applyXPATHtoDOM(newDoc, "//*[@owner-sensor]");
					String[] reportingSAs = new String[nodes.length];
					for(int i = 0; i < nodes.length; i++) {
						reportingSAs[i] = ((Element) nodes[i]).getAttribute("owner-sensor");
					}
					
					/** Unsubscribe */
					for(int i = 0; i < reportingSAs.length; i++) {
						ServantUnsubs.processRequest(reportingSAs[i], CM.getSAPort(), "C", Globals.SENSELET);
					}
					
					// store doc back... this is already updated
					Globals.getDatabase().storeDocument(doc);
					
					//final Document fDoc = doc; 
					//Timer timer = new java.util.Timer(true);
					//timer.schedule(new java.util.TimerTask() {
					//		public void run() {
					//			System.out.println("Forgeting delegated out nodes ");
					//			Globals.getDatabase().storeDocument(fDoc);
					//		}
					//	}, (long) ConfigurationManager.instance().getDNSTTL() * 1000);
					
					
					// Cache the part just delegated out. Because of DNS caching, 
					// other OAs may think for a while that this is the owner of 
					// the delegated nodes
					// CacheManagement.CacheResponse(newDocString, xpathQuery);
					
					
					// Update the statistics 
					String hosts[] = DOMProcessing.findAllOwnedHostNames(newDoc);
					Statistics.instance().removeOwnedNodes(hosts, targetIP[0]);
					
					// renew continuous query
					ContinuousQuery.renewContinuousQuery (doc.getDocumentElement().getTagName());
				} // if (removeFromLocalDatabase)

				System.out.println("ServantDelegateOwnership.delegateOwnerShip(): I have delegated out:");
				DOMProcessing.prettyPrint(newDoc);

				System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Now I own:");
				DOMProcessing.prettyPrint(doc);

                return "SUCCESS";
            } else {
                // readd the entries for DNS ... even though this exits,
                // we still have a valid DNS
				if (removeFromLocalDatabase) {
					System.out.println("ServantDelegateOwnership.delegateOwnerShip(): Delegation failed.  Restoring DNS entries");
					DNSHelper.getDNSHelper().addAllOwnedHostNames(newDoc);
				}

                System.out.println("Did not get valid response");
                return "FAILURE";
            }

        } catch (Exception e) {
            e.printStackTrace();
			throw e;
            //System.exit(1);
            //return null;
        }

    }
}
