/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
 
package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

public class QueryScript extends Globals{
	static String IPaddr;
  
	static void InitIP() {
            System.exit(1); // XXX Amol... seems like a test program
            //try {
            //		//InetAddress me = InetAddress.getLocalHost();
            // IPaddr = QM.getLocalIP();
            //} catch (UnknownHostException e){
            //	IPaddr = "127.0.0.1";
            //}
	}

	public static void main(String[] args) {
		ConfigurationManager CM = ConfigurationManager.instance();

		DataInputStream inStream = null;
		DataOutputStream outStream = null;
	  
		if (args.length == 0) {
			System.out.println("<b>Query Error:</b> No query given.");
		}
		else if (!args[0].startsWith("db=") || args[0].length() <= 3) {
			System.out.println("<b>Bug:</b> Database not specified.");
		}
		else if (args.length == 1 || args[1].length() <= 11) {
			System.out.println("<b>Query Error:</b> No query given.");
		}
		else if (!args[1].startsWith("xpathQuery=")) {
			System.out.println("<b>Bug:</b> Expected \"xpathQuery=\" "
						    + "in QUERY_STRING.");
		}
		else if (args.length > 3) {
			System.out.println("<b>Bug:</b> Too many arguments "
						    + "in QUERY_STRING.");
		}
		else {
			InitIP();

			// First create the socket to listen from OA
			ServerSocket lSocket;
			try {
				lSocket = new ServerSocket(0);
			}
			catch (IOException sockEx) {
                            sockEx.printStackTrace();
				return ;
			}
	    
			int port = lSocket.getLocalPort();

			try {
				String db = args[0].substring(3);
				String query = QueryScript.convertQuery(args[1].substring(11));
				System.out.println("<b>Executing Query:&nbsp;&nbsp; </b>"
							    + query + "<p>");

				String packet = Globals.COMMAND_QUERY + " " + 1 /*QM.getQID()*/ +" " + IPaddr + " " + port + " " + db + " " + query;

				// create the socket to talk to local OA 
				// XXX: later we may want to talk to the appropriate OA (may be remote)
				Socket sock;
				try {
					String OAipAddr = QueryScript.getOAipAddr(query);
					sock = new Socket(OAipAddr, CM.getOAPort());
					outStream = new DataOutputStream(sock.getOutputStream());
				}
				catch (IOException streamEx) {
                                    streamEx.printStackTrace();
					//MCloseConnection();
					System.out.println("error in opening socket..");
					return ;
				}

				// send the packet
				//System.out.println("<i>Sending the request: " + packet + "</i><p>");
				Packet.send(packet, outStream);

				// receive the response
				try {
					Socket aSocket = lSocket.accept();
					inStream =  new DataInputStream(aSocket.getInputStream());
				} catch (IOException ioEx) {
                                    ioEx.printStackTrace();
				}
	    
				String response = Packet.receive(inStream);

				// print the response
				//System.out.println("<i>Response received: " + response + "</i><p>");
				//int status = Integer.parseInt(response.substring(0,1));
				StringTokenizer ans = new StringTokenizer(response, " ");
				String cmd = ans.nextToken();
				String qID = ans.nextToken();
				String srcIP = ans.nextToken();
				int status = Integer.parseInt(ans.nextToken());
				String answer = ans.nextToken("");
				
				System.out.println("Received result: " + response +" Calling printAnswer" +  status + ":" + answer);

				QueryScript.printAnswer(status, answer, true);

			}
			catch (Exception e) {
                            e.printStackTrace();
				System.err.println( "Exception: " + e.getMessage() );
			}

		}	    
	}

	public static String getOAipAddr(String query) throws Exception {
		return "127.0.0.1";
	}

	public static String convertQuery(String querystr) throws Exception {
		StringBuffer buf = new StringBuffer("");

		if (querystr.length() == 0) {
			return querystr;
		}

		querystr = querystr.replace('+',' ');

		int k = querystr.indexOf("%");
		int i = 0;
		while (k >= 0 && i < querystr.length()) {
			if (k > i) {
				buf.append(querystr.substring(i,k));
			}
			String hexstr = new String(querystr.substring(k+1,k+3));
			if (hexstr.equalsIgnoreCase("2F")) {
				buf.append("/");
			}
			else if (hexstr.equalsIgnoreCase("21")) {
				buf.append("!");
			}
			else if (hexstr.equalsIgnoreCase("22")) {
				buf.append("\"");
			}
			else if (hexstr.equalsIgnoreCase("24")) {
				buf.append("$");
			}
			else if (hexstr.equalsIgnoreCase("27")) {
				buf.append("\'");
			}
			else if (hexstr.equalsIgnoreCase("28")) {
				buf.append("(");
			}
			else if (hexstr.equalsIgnoreCase("29")) {
				buf.append(")");
			}
			else if (hexstr.equalsIgnoreCase("2B")) {
				buf.append("+");
			}
			else if (hexstr.equalsIgnoreCase("2C")) {
				buf.append(",");
			}
			else if (hexstr.equalsIgnoreCase("3A")) {
				buf.append(":");
			}
			else if (hexstr.equalsIgnoreCase("3C")) {
				buf.append("<");    // problematic for html
			}
			else if (hexstr.equalsIgnoreCase("3D")) {
				buf.append("=");
			}
			else if (hexstr.equalsIgnoreCase("3E")) {
				buf.append(">");
			}
			else if (hexstr.equalsIgnoreCase("40")) {
				buf.append("@");
			}
			else if (hexstr.equalsIgnoreCase("5B")) {
				buf.append("[");
			}
			else if (hexstr.equalsIgnoreCase("5D")) {
				buf.append("]");
			}
			i = k+3;
			k = querystr.indexOf("%",i);
		}
		buf.append(querystr.substring(i));
		return buf.toString();
	}

	public static void printAnswer (int status, String ans, boolean showXml) 
		throws Exception {

		if (status == 1) {  // Normal result
			if (ans.length() > 0) {
				System.out.println("<b>Result is: </b><p>");

				if (showXml == false) {
					System.out.println(ans);
				}
				else {
					System.out.println("<i>*** Hiding xml tags:</i><br><br>");
					System.out.println(ans + "<br>");
					System.out.println("<i>*** Showing xml tags:</i><br><br>");

					// replace "<" with "&lt;", ">" with "&gt;" but leave "<br>" alone
					String xmlans = QueryScript.myReplace(ans, "<", "&lt;");
					xmlans = QueryScript.myReplace(xmlans, ">", "&gt;<br>");
					xmlans = QueryScript.myReplace(xmlans, "&lt;br&gt;<br>", "<br>");

					System.out.println(xmlans);
				}
			}
			else {
				System.out.println("<b>No DB entries satisfy the query.</b>");
			}
		}
		else if (status == 2) {  // Error processing query, print error message
			System.out.println("<b>" + ans + "<b><br>");
		}
		else {
			System.out.println("<b>Bug: Unknown status=" + status + "in printAnswer<b><br>");
		}
	}

	public static String myReplace (String origString, String oldSubstring, 
							  String newSubstring) throws Exception {

		StringBuffer buf = new StringBuffer("");
		int k = origString.indexOf(oldSubstring);
		int i = 0;

		while (k >= 0 && i < origString.length()) {
			if (k > i) {
				buf.append(origString.substring(i,k));
			}
			buf.append(newSubstring);
			i = k + oldSubstring.length();
			k = origString.indexOf(oldSubstring,i);
		}
		buf.append(origString.substring(i));

		return buf.toString();
	}
}


