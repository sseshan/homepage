/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * The class PacketHeader is the base class for other packet classes, that 
 * are used for communication between the sensing and organizing agents.
 * This base class provides the basic methods to send and receive packets.
 *
 * @author Suman Kumar Nath
 * @author Amol
 * @version %I%, %G%
 */
public class Packet {

	/**
	 * Sends a packet to a specified output stream (socket).
	 * Takes a packet in String format, converts it to byte array,
	 * updates the first **three** bytes to be the packet length, and writes it 
	 * to the output stream.
	 *
	 * @param pkt       the packet in String format
	 * @param outStream output stream where the packet is written
	 *
	 * @return OK (success) or SOCK_ERROR (error)
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	
	// For performance reason, once a host is found to be down, it is 
	// added to a black list. During message routing, all the "send()"
	// operation to the blacklisted hosts are assumed to be failed.
	// This avoids trying to send messages to hosts that are down.
	// The IP addresses of the blacklisted nodes are kept in a hash table.
	public static Hashtable blackList = new Hashtable(89);
	public static long punishmentPeriod = 10*60; // a blacklisted IP remains so for 10*60 secs, unless we hear from it before that
	
	/**
	 * Adds a host to the blacklist
	 * Note: a host is added to the blacklist if the Packet.send() operation
	 * generates an exception (ServantQuery.java)
	 *
	 * @param host  name or IP address of the host
	 * @see removeFromBlackList(), inBlackList() 
	 * @author Suman
	 * @version %I%, %G%
	 */
	public static void addToBlackList(String host)
	{
		//System.out.println("Adding " + host + " to black list");
		try {
			InetAddress[] list = InetAddress.getAllByName(host);
			long now = System.currentTimeMillis();
			for (int i = 0; i < list.length; i++) {
				if (blackList.get(list[i].getHostAddress()) == null)
					blackList.put(list[i].getHostAddress(), new Long(now));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Removes a host from the blacklist
	 * Note: a host is removed from the black list when a message is recieved 
	 * from it (Protocol.java) or  punishmentPeriod has passed after it 
	 * has been added to the list
	 *
	 * @param host  name or IP address of the host
	 * @see addToBlackList(), inBlackList() 
	 * @author Suman
	 * @version %I%, %G%
	 */
	public static void removeFromBlackList(String host)
	{
		//System.out.println("Removing from black list: " + host);
		// we are being a bit optimistic here, by removing all
		// the IP address of the given name
		try {
			InetAddress[] list = InetAddress.getAllByName(host);
			for (int i = 0; i < list.length; i++)
				blackList.remove(list[i].getHostAddress());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Determines if a host is blacklisted
	 *
	 * @param host  name or IP address of the host
	 * @return true, if the host is blacklisted; false, otherwise
	 * @see addToBlackList(), removeFromBlackList() 
	 * @author Suman
	 * @version %I%, %G%
	 */
	public static boolean inBlackList(String host)
	{
		long now = System.currentTimeMillis();
		
		try {
			InetAddress[] list = InetAddress.getAllByName(host);
			for (int i = 0; i < list.length; i++) {
				Long entry = (Long)blackList.get(list[i].getHostAddress());
				if (entry == null) return false;
				
				if ((now - entry.longValue()) > punishmentPeriod * 1000) {
					System.out.println("Removing from black list: " + host);
					blackList.remove(list[i].getHostAddress());
					return false;
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	/**
	 * Writes a packet to the given DataOutputStream. The output stream 
	 * is NOT closed after the write.
	 * This is the basic class and used by other ovearloaded methods
	 *
	 * @param packet data to write
	 * @param outStream DataOutputStream to write the data       
	 * @author Suman
	 */
	public static int send(String packet, DataOutputStream outStream) throws Exception { 
		//Lamport.incClock();

		// the first three spaces are for the message length
		String pkt = " " + " " + " " + Lamport.getClock() + " " + packet; 
		int dataLen = pkt.length();
		byte[] packetBytes = new byte[dataLen];
		
		//System.out.println("Packet.Send(): Packet = " + packet + "length = " + dataLen);
		
		if(dataLen > 128 * 128 * 128) {
			System.out.println("Packet.Send(): Message just tooooo large");
			Utils.shouldnthappen();
		}
		
		packetBytes = pkt.getBytes();
		packetBytes[0] = (byte)(dataLen / (128 * 128)); 
		packetBytes[1] = (byte)((dataLen%(128*128)) / 128); 
		packetBytes[2] = (byte)(dataLen % 128); 

		outStream.write(packetBytes, 0, dataLen);
		
		// update statistics
		if (Globals.keepStat) {
			if (!packet.startsWith("ALIVE"))
				Statistics.instance().bytesSent(dataLen);
		}
		return Globals.OK;
	}
	
	/**
	 * Given a hostname, tries all the primary and backup IP addresses
	 * to connect and returns a connected socket. Used by 
	 * the method: send(packet, hostname) 
	 *
	 * @param hostname DNS name of the host
	 * @param port port to connect
	 * @return a connected socket, or null if no socket could be created
	 * 
	 * @author suman
	 */
	private static final Socket getSocket(String hostname, int port) throws Exception {
		InetAddress[] ads = InetAddress.getAllByName(hostname);
		ConfigurationManager CM = ConfigurationManager.instance();
		
		try {
			// try the primary DNS hierarchy
			for (int i = 0; i<ads.length; i++) {
				System.out.print("getSocket(): Creating a connection to " + hostname + "(" + ads[i].getHostAddress() + "):" + port);
				if (inBlackList(ads[i].getHostAddress())) continue;
				Socket sock = TimedSocket.getSocket(ads[i], port, ConfigurationManager.instance().getTimeOut()); 
				if (sock != null) System.out.println(", connected");
				return sock;
			}

			// try the backup hierarchy
			if (hostname.lastIndexOf(CM.getDNSSuffix()) >= 0) {
				String backupHostname = hostname.substring(0, hostname.lastIndexOf(CM.getDNSSuffix())) + "backup." + CM.getDNSSuffix();
				ads = InetAddress.getAllByName(backupHostname);
				for (int i = 0; i<ads.length; i++) {
					System.out.println("getSocket(): Creating a connection to " + backupHostname + "(" + ads[i].getHostAddress() + "):" + port);
					if (inBlackList(ads[i].getHostAddress())) continue;
					Socket sock = TimedSocket.getSocket(ads[i], port, ConfigurationManager.instance().getTimeOut()); 
					if (sock != null) System.out.println(", connected..");
					return sock;
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return null;
	}

	/** 
	 * Returns the IP address of the given host name
	 */
	public static String getIPforHostName (String hostname)
	{
	    try {
			return InetAddress.getByName(hostname).getHostAddress();
	    } catch (Exception e) {
			Utils.error ("Unknown host: " + hostname);
			return null;
	    }
	}
 
	/**
	 * Sends a packet to the given host name. If the hostname is resolved to multiple
	 * IP addresses, all the addresses are tried. Moreover, if the name has the suffix
	 * .dsan.net, all the IP addresses of the corresponding .backup.dsan.net names
	 * are tried (by using the method Packet.getSocket())
	 *
	 * @author suman
	 */
	public static int send(String packet, String hostname, int port) throws Exception {
		Socket sock = null;
		//System.out.println("Sending to " + hostname + " : " + packet);
		try {
			sock = getSocket(hostname, port);
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			int k = send(packet, outStream);
			sock.close();
			return k;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}
	

	/**
	 * Sends a packet to the host given by the IP address
	 *
	 * @author suman
	 */
	public static int send(String packet, String IP) throws Exception {
		ConfigurationManager CM = ConfigurationManager.instance();
		return send(packet, IP, CM.getOAPort());
	}

	/**
	 * Sends multiple packets to the same destination
	 * format will be: MultipleMessage message0 message1 ... messagek
	 *
	 * @author shimin
	 */
	public static int send(ArrayList packets, String hostname, int port) throws Exception {
		Socket sock = null;
		try { 
			sock = getSocket(hostname, port);
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			int num_messages = packets.size ();
			int k = send (
						  Protocol.constructMultipleMessageHeader (num_messages),
						  outStream);
			for (int ii=0; ii<num_messages; ii++) {
				String packet = (String) packets.get (ii);
				k = send(packet, outStream); 
			}
			sock.close();
			return k;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}

	public static int send(ArrayList packets, String hostname) throws Exception {
		ConfigurationManager CM = ConfigurationManager.instance();
		return send(packets, hostname, CM.getOAPort());
	}
	
	/** 
	 * Sends a packet to a host and receives the ack.
	 * This function is needed to open a 2-way channel between the two OAs. 
	 * In case, acks are required. 
	 *
	 * @author amol
	 */
	public static String sendReceiveAck(String packet, String hostName, int port) throws Exception {
		Socket sock = null;
		try {
			System.out.println("Packet.SendReceiveAck(): Opening connection to "
							   + hostName + ":" + port);
			sock = getSocket(hostName, port);
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			DataInputStream inStream = new DataInputStream(sock.getInputStream());
			
			// Send our message
			send(packet, outStream);
			
			System.out.println("Packet.SendReceiveAc(): Waiting for acknowledgement.");
			String response = receive(inStream);
			sock.close();
			return response;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}
	

	// these are the only interfaces where the destination hosts are given
	// as IP address, instead of the hostname
	public static int sendToIP(String packet, String IP, int port) throws Exception {
		Socket sock = null;
		try {
			sock = TimedSocket.getSocket(IP, port, ConfigurationManager.instance().getTimeOut());
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			int k = send(packet, outStream);
			sock.close();
			return k;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}

	// send multiple packets to the same destination
	public static int sendToIP(ArrayList packets, String IP, int port) throws Exception {
		Socket sock = null;
		try {
			sock = TimedSocket.getSocket(IP, port, ConfigurationManager.instance().getTimeOut());
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			
			int num_messages = packets.size ();
			int k = send (
						  Protocol.constructMultipleMessageHeader (num_messages),
						  outStream);
			for (int ii=0; ii<num_messages; ii++) {
				String packet = (String) packets.get (ii);
				k = send(packet, outStream);
			}
			
			sock.close();
			return k;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}

	public static String sendReceiveAckToIP(String packet, String IP, int port) throws Exception {
		Socket sock = null;
		try {
			System.out.println("Packet.SendReceiveAck(): Opening connection to "
							   + IP + ":" + port);
			sock = TimedSocket.getSocket(IP, port, ConfigurationManager.instance().getTimeOut());
			DataOutputStream outStream = new DataOutputStream(sock.getOutputStream());
			DataInputStream inStream = new DataInputStream(sock.getInputStream());
			
			// Send our message
			send(packet, outStream);
			System.out.println("Packet.SendReceiveAc(): Waiting for acknowledgement.");
			String response = receive(inStream);
			sock.close();
			return response;
		} catch (IOException streamEx) {
			streamEx.printStackTrace();
			if (sock != null) sock.close();
			throw streamEx;
		}
	}

	/**
	 * Receives a packet from a specified input stream (socket).
	 * Reads the packet as byte array from the input stream, converts 
	 * the byte array to string and returns it.
	 *
	 * @param inStream  input stream to read from
	 *
	 * @author suman
	 * @author Amol --- changed to 3 byte length format -- can handle upto 2MB now 
	 * @version %I%, %G%
	 */
	
	public static String receive(DataInputStream inStream) throws Exception {
		byte[] lengthBytes = new byte[3];
		int packLen = 0;
		int nRead;
		
		try {
			nRead = inStream.read(lengthBytes, 0, 3); // Get the length byte
			if (nRead != 3)
				return null;
			packLen = lengthBytes[0] * 128 * 128 + lengthBytes[1] * 128 + lengthBytes[2];
			System.out.println("Packet.Receive(): Expecting packet of length " + packLen);
			
			int rest = packLen - 3;
			int offset = 0;
			byte[] packetBytes = new byte[rest];
			while (rest > 0){
				nRead = inStream.read(packetBytes, offset, rest);
				rest -= nRead;
				offset += nRead;
			}
			// System.out.println(packetBytes);
			// System.out.println(packLen);
			String s = new String(packetBytes, 0, packLen-3);
			// at the end... we should only be reading packlen-3 bytes
			StringTokenizer tokens = new StringTokenizer(s, " ");
			String clock_ = tokens.nextToken();
			long lamport_clock = Long.parseLong(clock_);
	
			if (lamport_clock >= 0)
				Lamport.updateClock(lamport_clock);
			
			String packet = tokens.nextToken("");

			 // update statistics
			if (Globals.keepStat) {
				if (lamport_clock >= 0) // if SA is on same host, use -1 in the mesage coming from SA
					Statistics.instance().bytesReceived(packet.length());
			}

			System.out.println("receive(): packet received = " + packet);
			return packet;
		}
		catch (IOException ioEx) {
			ioEx.printStackTrace();
			System.err.println("ReceivePacket failed: " + ioEx);
			throw ioEx;
		}
	}
	
	public static void main(String args[]) throws Exception {
		long starttime = System.currentTimeMillis();
		send("help", args[0], 80);
		System.out.println("Total time : " + (System.currentTimeMillis() - starttime));
	}
	
}
