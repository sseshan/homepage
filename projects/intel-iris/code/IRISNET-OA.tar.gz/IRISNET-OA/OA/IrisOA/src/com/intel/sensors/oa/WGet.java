/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
package com.intel.sensors.oa;

import java.io.IOException;
import java.io.EOFException;
import java.io.DataInputStream;
import java.io.PrintStream;
import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;

import java.util.Iterator;
import java.util.List;

// This class provides methods to download (and save) objects using http protocol
public class WGet {
    final PrintStream out = System.out;
    boolean verb = false;
    boolean output = true;
    int count = 0;
    String dirPrefix = "./";

    WGet (boolean _verb) {
		verb = _verb;
    }

    WGet(String _prefix) {
		dirPrefix = _prefix;
    }
    
    WGet(boolean _verb, String _prefix) {
		verb = _verb;
		dirPrefix = _prefix;
    }

    // Returns the page as String. Embedded images are NOT retrieved
    public String getPage(String _url) throws IOException {
		String _out = "";
		
		URLConnection url = (new URL(_url)).openConnection();
		
		if (url instanceof HttpURLConnection) {
			_out = readHttpURL((HttpURLConnection) url);
		} else {
			_out = readURL(url);
		}
		
		return _out;
    }
    
	public String readURL(URLConnection url) throws IOException {
		StringBuffer _out = new StringBuffer(1024*16);
		
		DataInputStream in = new DataInputStream(url.getInputStream());
		printHeader(url);
		
		try {
			while (true) {
				_out.append((char) in.readUnsignedByte());
				count++;
			}
		} catch (EOFException e) {
			verbose("\n");
			verbose("WGet" +
					": Read " + count +
					" bytes from " + url.getURL());
		} catch (IOException e) {
			out.println( e + ": " + e.getMessage());
			verbose("\n");
			verbose("WGet" +
					": Read " + count +
					" bytes from " + url.getURL());
		}
		// System.exit(0);
		return _out.toString();
	}
	
	public String readHttpURL(HttpURLConnection url) 
		throws IOException {
		
		StringBuffer _out = new StringBuffer(1024 * 16);
		long before, after;
		
		url.setAllowUserInteraction (true);
		verbose("WGet" + ": Contacting the URL ...");
		url.connect();
		verbose("WGet" + ": Connect. Waiting for reply ...");
		before = System.currentTimeMillis();
		DataInputStream in = new DataInputStream(url.getInputStream());
		after = System.currentTimeMillis();
		verbose("WGet" + ": The reply takes " + 
				((int) (after - before) / 1000) + " seconds");
		
		before = System.currentTimeMillis();
      
		
		try {
			if (url.getResponseCode() != HttpURLConnection.HTTP_OK) {
				out.println("WGet" + ": " + url.getResponseMessage());
			} else {
				printHeader(url);
				while (true) {
					_out.append((char) in.readUnsignedByte());
					count++;
				}
			}
		} catch (EOFException e) {
			after = System.currentTimeMillis();
			int milliSeconds = (int) (after-before);
			verbose("\n");
			verbose("WGet" +
					": Read " + count +
					" bytes from " + url.getURL());
			verbose("WGet" + ": HTTP/1.0 " + url.getResponseCode() +
					" " + url.getResponseMessage());
			url.disconnect();
			
			verbose("WGet" + ": It takes " + (milliSeconds/1000) + 
					" seconds" + " (at " + round(count/(float) milliSeconds) + 
					" K/sec).");
			if (url.usingProxy()) {
				verbose("WGet" + ": This URL uses a proxy");
			}
		} catch (IOException e) {
			out.println( e + ": " + e.getMessage());
			verbose("\n");
			verbose("WGet" +
					": I/O Error : Read " + count +
					" bytes from " + url.getURL());
			out.println("WGet" + ": I/O Error " + url.getResponseMessage());
		}
		//System.exit(0);
		
		return _out.toString();
  }
	
    public void printHeader(URLConnection url) {
		verbose(WGet.class.getName() + ": Content-Length   : " + 
				url.getContentLength() );
		verbose(WGet.class.getName() + ": Content-Type     : " + 
				url.getContentType() );
		if (url.getContentEncoding() != null)
			verbose(WGet.class.getName() + ": Content-Encoding : " + 
					url.getContentEncoding() );
		verbose("");
    }
    
    public void  writeChar(char c) {
	if (verb) out.print(c);
	//count++;
    }
    
    public void verbose(String s) {
	if (verb) out.println( s );
    }
    
    public  float round(float f) {
	return Math.round(f * 100) / (float) 100;
    }

    // The page is saved to disk
    public void save(URL _url, String _fName, boolean _overwrite) {
		verbose(".save(): " + _url);
		File file = new File(_fName);
		if (!_overwrite && file.exists())
			return;
		byte[] sresponse = null;
		
		try {
			sresponse = getResource(_url);
			saveToFile(_fName, sresponse);
		} catch (MalformedURLException e) {
			System.out.println(".save(): " + e);
		} catch (FileNotFoundException e) {
			System.out.println(".save(): " + e);
		} catch (IOException e) {
			System.out.println(".save(): " + e);
		}
		
	return ;
    }

    public void save(URL url) {
	save(url, createFileName(url), false);
    }
    
    public void save(URL url, String fName) {
	save(url, dirPrefix + "/" + fName, false);
    }

    public void save(URL url, boolean overwrite) {
	save(url, createFileName(url), overwrite);
    }

    public void save(String url) {
	try {
	    URL _url = new URL(url);
	    save(_url, createFileName(_url), false);
	} catch(MalformedURLException e) {
	    System.out.println(".save(): " + e);
	} 
    }
    
    public void save(String url, String fName) {
	try {
	    URL _url = new URL(url);
	    save(_url,  dirPrefix + "/" + fName, false);
	} catch (MalformedURLException e) {
	    System.out.println(".save(): " + e);
	}
    }

    public void save(String url, boolean overwrite){
	try {
	    URL _url = new URL(url);
	    save(_url, createFileName(_url), overwrite);
	}  catch (MalformedURLException e) {
	    System.out.println(".save(): " + e);
	}
    }

    public byte[] getResource(URL url) throws IOException {
        verbose(".getResource(): " + url);

        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
        InputStream in = httpConnection.getInputStream();
        byte[] buffer = new byte[1024];
        int bytes_read;
        ByteArrayOutputStream bufferOut = new ByteArrayOutputStream();

        while ((bytes_read = in.read(buffer)) != -1) {
            bufferOut.write(buffer, 0, bytes_read);
        }

        byte[] sresponse = bufferOut.toByteArray();
        httpConnection.disconnect();

        return sresponse;
    }

    public void saveToFile(String filename, byte[] bytes)
        throws FileNotFoundException, IOException {
        File file = new File(filename);
        File parent = new File(file.getParent());

        if (!parent.exists()) {
            System.out.println(".saveToFile(): Directory will be created: " + parent.getAbsolutePath());
            parent.mkdirs();
        }

        FileOutputStream out = new FileOutputStream(file.getAbsolutePath());
        out.write(bytes);
        out.close();
    }

    public List getLinks(URL url) throws IOException {
	List links = null;

	// TODO

	return links;
    }


     public String createFileName(URL url) {
        File file = new File(dirPrefix + File.separator + url.getFile());
        return file.getAbsolutePath();
    }


    // Usage: WGet URL_String prefix [fileName]
    public static void main(String args[]) throws Exception {
	
	if (args.length == 3) {
	    //dirPrefix = args[0];
	    WGet wget = new WGet(args[0]);
	    wget.save(args[1], args[2]);
	} else if (args.length == 2) {
	   WGet wget = new WGet (args[0]);
	   wget.save(args[1]);	
	} 
    }
}

      
