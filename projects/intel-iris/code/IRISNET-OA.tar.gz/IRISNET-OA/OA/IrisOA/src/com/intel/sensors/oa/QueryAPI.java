/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.net.*;
import java.util.*;
import java.io.*;

// sixpath
import de.fzi.XPath.*;

// dom
import org.w3c.dom.*;

/** QueryAPI class provides facilities to use IrisNet query2/reply2
 *  interface easily
 *  
 *  @author Shimin
 */
public class QueryAPI implements Runnable {

  public  static int           server_port;
  private static ServerSocket  server_socket = null;
  private static long          current_query_id;
  static  Hashtable    	       remote_query_table;// associate a query with
						  // a QueryCallBack
  private static Thread        server_thread;

  private static Timer	       my_timer = null;

  /** Initiate the server socket and related structures.
   *  There will be a server thread waiting for reply messages on this socket.
   *
   *  @param port the socket port
   *
   */
  public static void init (int port)
  {
	server_port = port;
	Protocol.myPortNumber = server_port;
	startServer ();

	initTimer ();
  }

  private static void startServer ()
  {
        try {
            server_socket = new ServerSocket(server_port);
            current_query_id = 1;
            remote_query_table = new Hashtable ();

	    server_thread = new Thread(new QueryAPI());
	    server_thread.setDaemon (true);
	    server_thread.start ();

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
  }

  private static void initTimer ()
  {
	my_timer = new Timer (true);      // running as Daemon
  }

  // ---
  // instance members
  // ---

  public String root_query;
  public String root_id;

  /** Constructor. 
   *  @param root_tag_id_query should be of the form root_element[@id='root_id']
   */
  public QueryAPI (String root_tag_id_query)
  {
	setupRootId (root_tag_id_query);
  }

  // this is used to create a runnable object for server thread
  private QueryAPI ()
  { }

  /*  Set up the root_query and root_id fields in QueryAPI.
   *  root_tag_id_query should be of the form 
   *  root_element[@id='root_id']
   */
  private void setupRootId (String root_tag_id_query)
  {
     try {
	// 1. parse the query
        Expr expr = XPathQueryParser.parsequery (root_tag_id_query);

	// 2. check format and get the root_id part
	if (expr instanceof LocationPath) {
	  LocationPath lp = (LocationPath) expr;
	  if (lp.getStepsCount () == 1) {
	    Step st = lp.getStep (0);
	    if ((st.getAxis() == Axis.CHILD) &&
		(st.getPredicatesCount() == 1) &&
		QueryAnalysis.isIdPredicate (st.getPredicate(0)) ) {

	      String str = 
                     ((EqualityExpr) st.getPredicate(0)).getExpr(1).toString();
              int len = str.length ();
              if (((str.charAt(0) == '\'') && (str.charAt(len-1) == '\''))
                 || ((str.charAt(0) == '\"') && (str.charAt(len-1) == '\"'))){
                        str = str.substring (1, len-1);
              }
	      root_query = root_tag_id_query;
	      root_id = str;

	      return;
	    }
	  }
	}

     } catch (Exception e) {}

	System.err.println ("Format error: " + root_tag_id_query);
	System.exit (1);
  }


  /** Get the LCA Host name of a query.
   *  @param query input query
   *  @return Returns the full LCA host domain name if successful
   *          returns null, if the query has bad format
   *  This method is thread-safe.
   */
  public String getLcaHost (String query)
  {
	// 1. parse the query
        Expr expr = null;
        try {
          expr = XPathQueryParser.parsequery (query);
        } catch (Exception e) {
          System.err.println ("Format error: " + query);
	  return null;
        }

	// 2. analyze the query structure using SubXpathOperator
        SubXpathOperator sub = new SubXpathOperator (null);
	sub.lca_bound = -1;
	sub.xpath = expr;

	String lca = getLCA (sub);
	if (lca == null) return null;

	return lca + '.' + ConfigurationManager.instance().getDNSSuffix();
  }

  // return null if the xpath has bad format
  private String getLCA (SubXpathOperator sub)
  {
	sub.determineQueryType ();

	int which_step = -1;

	switch (sub.query_type) {
          case SubXpathOperator.QUERY_TYPE_SP:
		if (((FunctionCall)sub.xpath).getArgumentCount () == 0) {
		  System.err.println ("Stored procedure must have arguments!");
		  return null;
		}

		sub.xpath = ((FunctionCall)sub.xpath).getArgument (0);
		return getLCA (sub);

          case SubXpathOperator.QUERY_TYPE_FOR:
		sub.xpath = ((ForExpr)sub.xpath).getInExpr ();
		return getLCA (sub);

          case SubXpathOperator.QUERY_TYPE_BASIC:
		which_step = ((LocationPath)sub.xpath).getStepsCount ()-1;
		break;

          case SubXpathOperator.QUERY_TYPE_FORWARD:
          case SubXpathOperator.QUERY_TYPE_BACKWARD:
          case SubXpathOperator.QUERY_TYPE_COMPLEX:
		which_step = sub.which_step;
		break;

          case SubXpathOperator.QUERY_TYPE_CONSTANT:
          case SubXpathOperator.QUERY_TYPE_ATTR: 
		return root_id;

	  default:
		return null;
	}

	// location path and which_step is set
	LocationPath lp = (LocationPath)sub.xpath;
	StringBuffer sb = new StringBuffer ();

	for (int ii=0; ii<=which_step; ii ++) {
	   Step st = lp.getStep(ii);

	   if (st.getAxis() != Axis.CHILD) break;

	   if ((st.getPredicatesCount() == 1) &&
               (QueryAnalysis.isIdPredicate (st.getPredicate(0)))) {
               String str = 
                     ((EqualityExpr) st.getPredicate(0)).getExpr(1).toString();
               int len = str.length ();
               if (((str.charAt(0) == '\'') && (str.charAt(len-1) == '\''))
                 || ((str.charAt(0) == '\"') && (str.charAt(len-1) == '\"'))){
                   str = str.substring (1, len-1);
               }
               if (ii != 0) 
		 sb.insert (0, str + '.');
	       else
                 sb.append (str);
           }
	   else break;
	}

	return ((sb.length()>0) ? sb.toString () : root_id);
  }

  /** send a snapshot query to lca_host.
   *
   *   @param query     the query to send
   *   @param lca_host  LCA host name
   *   @param callback  the call back procedure for query reply
   *
   *   @return greater than 0 if the sending is successful, -1 otherwise.
   *           The return value is the assigned query ID.
   *   
   *   This method is thread-safe.
   */
  public long sendQuery (String query, String lca_host, 
			    QueryCallBack callback)
  {
	if (server_socket == null) {
	  System.err.println ("Server socket is not initiated!");
	  return -1;
	}

	// put into remote_query_table
	synchronized(remote_query_table) {
	  long query_id = current_query_id ++;

	  QueryCallBackEntry one = new QueryCallBackEntry ();
	  one.call_back = callback;
	  one.continuous = false;

        try {
	  Protocol.sendQuery2Message (
		query_id, QueryOperator.RESULT_UNKNOWN, root_query, query, 
		lca_host, ConfigurationManager.instance().getOAPort());
	 } catch (Exception e) {
	  System.err.println ("error sending message!");
	  return -1;
	 }

	  remote_query_table.put (new Long(query_id), one);
	  return query_id;
	}
  }

  /** send a continuous query to lca_host.
   *
   *   @param query     the query to send
   *   @param lca_host  LCA host name
   *   @param mode      0 or pulling, 1 or triggered
   *   @param period_ms the minimum period to send result
   *   @param lease_ms  the lease time (0 for default value, 10 min)
   *   @param duration_ms the duration to run this query
   *   @param callback  the call back procedure for query reply
   *
   *   @return greater than 0 if the sending is successful, -1 otherwise.
   *           The return value is the assigned query ID.
   *   
   *   This method is thread-safe.
   */
  public long sendContinuousQuery (String query, String lca_host, String mode,
	long period_ms, long lease_ms, long duration_ms, QueryCallBack callback)
  {
	if (server_socket == null) {
          System.err.println ("Server socket is not initiated!");
          return -1;
        }

        // put into remote_query_table
        synchronized(remote_query_table) {
          long query_id = current_query_id ++;

          QueryCallBackEntry one = new QueryCallBackEntry ();
          one.call_back = callback;
          one.continuous = true;

	  String query_without_lease = "continuous(" + query
                          + ",'mode="     + mode
                          + "','period="  + period_ms
                          + "','lease=";

	  if (lease_ms <= 0) lease_ms = 600000;	// 10 min
	  if (lease_ms < 2000) lease_ms = 2000;

	  String my_query = query_without_lease + lease_ms + "')";
        try {
          Protocol.sendQuery2Message (
                query_id, QueryOperator.RESULT_UNKNOWN, root_query, my_query,
                lca_host, ConfigurationManager.instance().getOAPort());
         } catch (Exception e) {
          System.err.println ("error sending message!");
	  return -1;
         }

	 one.lease_sponsor =  new CQLeaseSponsor (my_timer, 
		query_id, root_query, lca_host,
		query_without_lease, lease_ms, duration_ms);

         remote_query_table.put (new Long(query_id), one);

	 return query_id;
        }
  }

  /** cancel an existing query. 
   *
   *  @param query_id the return value of sendQuery or sendContinuousQuery
   *
   *  Note that the state for a snapshot query will be automatically removed
   *  after the reply is received.  A continuous query will be automatically
   *  terminated after the specified duration time.
   *
   *  This method is useful in two situations:
   *  1) cancel a snapshot query before the reply comes back
   *     the provided call back function will not be called.
   *  2) terminate a continuous query before the specified duration time.
   *
   *   This method is thread-safe.
   */
  public void cancelQuery (long query_id)
  {
	synchronized(remote_query_table) {
	  QueryCallBackEntry one = (QueryCallBackEntry)
                        remote_query_table.remove (new Long(query_id));
	  if ((one != null) && one.continuous && (one.lease_sponsor != null)) {
	     one.lease_sponsor.cancelQuery();
	  }
	}
  }

  /** This is main method for the server thread.
   *  DO NOT call this method!
   */
  // instance fields are not used in this method!
  public void run ()
  {
    for (;;) {
	Socket aSocket = null;

     try {
	aSocket = server_socket.accept ();
	DataInputStream inStream = new DataInputStream(
					aSocket.getInputStream());
	String packet = Packet.receive(inStream);
	ParsedMessage pm = Protocol.parseIncomingMessage(packet);   
	pm.srcIP = aSocket.getInetAddress().getHostAddress();

	if (pm.opCode.equals(Globals.COMMAND_REPLY2)) {
	  long query_id = Long.parseLong (pm.queryID);
	  QueryCallBack callback = null;

	  synchronized(remote_query_table) {
	    QueryCallBackEntry one = (QueryCallBackEntry)
			remote_query_table.get (new Long(query_id));
	    if (one != null) {
	      callback = one.call_back;
	      if (! one.continuous) {
		remote_query_table.remove (new Long(query_id));
	      }
	    }
	  } // access remote_query_table

	  // parsing the response of REPLY2 message
	  if (callback != null) {
	    // parse package to get result
	    Object result = null;
            if (pm.response.equals ("null")) {
              // null
            }
            else if (pm.resultType == QueryOperator.RESULT_ERROR) {
              // error processing
	      result = pm.response;
            }
            else if (QueryOperator.isResultTree (pm.resultType)) {
              // tree
	      result = pm.response;
            }
            else {
              // string[]
              // num_strings ' ' len0 ' ' string0 ' ' len1 ' ' string1
              String response = pm.response;
              int pos = response.indexOf (' ');
              int num_strings = (pos>=0)? 
                                 Integer.parseInt (response.substring(0,pos)):
                                 0;
              String[] reply = new String[num_strings];
              for (int ii=0; ii<num_strings; ii++) {
                 pos ++;
                 int next_pos = response.indexOf (' ', pos);
                 int len = Integer.parseInt (response.substring(pos,next_pos));
                 next_pos ++;
                 reply[ii] = response.substring (next_pos, next_pos+len);
                 pos = next_pos+len;
              }

	      result = reply;
            }

	    // call the callback
	    callback.callBack (pm.resultType, result);

	  } // callback != null
	}
	else {
	     System.err.println ("Receiving strange messages!");
	}
     } catch (Exception e) {e.printStackTrace();}

	// clean up
	if (aSocket != null) {
	  try {
	    aSocket.close ();
	  }
	  catch (Exception e) {}
	}
    } // end of for
  }

  // --------------------------------------------------------------------
  // testing

  public static void main (String[] args)
  {
   try {
    BufferedReader in
      = new BufferedReader(new InputStreamReader(System.in));

    System.out.print ("root_tag_id_query: ");
    String query = in.readLine ();
    QueryAPI one = new QueryAPI (query);
    System.out.println ("root_query: " + one.root_query);
    System.out.println ("root_id: " + one.root_id);
    System.out.println ("port: " + one.server_port);

    while (true) {
        query = in.readLine ();
        System.out.println (query);
        if (query.equals ("exit")) {
          break;
        }
	String lca_host = one.getLcaHost (query);
	System.out.println ("Lca host: " + ((lca_host==null)?"null":lca_host));
    }

   } catch (Throwable e) {
        System.out.println ("Exception!");
	e.printStackTrace ();
   }
  }
} // QueryAPI

class QueryCallBackEntry {
  QueryCallBack  call_back;
  boolean        continuous;
  CQLeaseSponsor lease_sponsor = null;
} // QueryCallBackEntry

class CQLeaseSponsor extends TimerTask {

  long   query_id;
  String root_query;
  String lca_host;

  String partial_query;
  long  lease;
  long  end_time;

  CQLeaseSponsor (Timer timer, long queryId, String rootQuery, String lcaHost,
	String query_without_lease, long lease_ms, long duration_ms)
  {
	query_id = queryId;
	root_query = rootQuery;
	lca_host = lcaHost;

	partial_query = query_without_lease;
	lease = lease_ms;
	end_time = System.currentTimeMillis() + duration_ms;

	long period = lease_ms - 1000;

	timer.schedule (this, period, period);
  }

  public void run ()
  {
	long now = System.currentTimeMillis();

	if (now + lease >= end_time) {
	  lease = end_time - now;

	  if (lease <= 0) {
	    // clean up
	    cancel ();
	    synchronized (QueryAPI.remote_query_table) {
		QueryAPI.remote_query_table.remove (new Long(query_id));
	    }
	    return;
	  }
	}

	// renew lease
	String my_query = partial_query + lease + "')";
     try {
        Protocol.sendQuery2Message (
                query_id, QueryOperator.RESULT_UNKNOWN, root_query, my_query,
                lca_host, ConfigurationManager.instance().getOAPort());
     } catch (Exception e) {
	System.err.println ("Exception!");
     }
  }

  void cancelQuery ()
  {
	cancel ();
        String my_query = partial_query + 0 + "')";
     try {
        Protocol.sendQuery2Message (
                query_id, QueryOperator.RESULT_UNKNOWN, root_query, my_query,
                lca_host, ConfigurationManager.instance().getOAPort());
     } catch (Exception e) {
        System.err.println ("Exception!");
     }
  }
} // CQLeaseSponsor
