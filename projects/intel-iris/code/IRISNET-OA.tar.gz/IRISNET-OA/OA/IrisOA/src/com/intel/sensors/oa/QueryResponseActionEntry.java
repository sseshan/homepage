/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.w3c.dom.*;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xpath.XPathAPI;
import org.apache.xml.utils.TreeWalker;
import org.apache.xml.utils.DOMBuilder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException; 

/** The class that manages the query entries corresponding to a single query. Also contains some static variables and
 *  functions to access the metaqueryentries at any point. The metaqueryentris are identified by the queryID of the
 *  response which are made unique for each OA. 
 *
 *  @author Amol */
public class QueryResponseActionEntry extends ResponseActionEntry {
    /** Some information about the original query since the final action of this class will be to send the response 
     *  back */
    public String srcQueryID;
    public int srcFragmentID;
    public String srcIP;
    public int srcPort;
    public String myQueryString;
    private static Object lock1 = new Object(), lock2 = new Object();
	
    /** Answer till now as a org.w3c.dom.Node. The answers returned by the
     *  descendants will be directly added to this document */
    protected Node answer = null;

    /** these are nodes at which the answers being returned by 
     *  the children are located. */
    protected Node[] toBeReplacedNodes = new Node[100]; 

    /** The action entries corresponding to this query */
    protected ResponseActionEntry[] actionentries = new ResponseActionEntry[100];

    /** Number of pending query entries */
    protected int numPending;

    /** Create a query entry given a parsed message and stuff */
    QueryResponseActionEntry(ParsedMessage pm, Node doc) 
    {
	super();
        srcQueryID = pm.queryID;
        srcIP = pm.srcIP;
        srcPort = pm.srcPort;
        srcFragmentID = pm.fragmentNumber;
        answer = doc;
        myQueryString = pm.query;
        numPending = 0;
    }

    public void addActionQueryEntry(Node n, ResponseActionEntry rae) 
    {
	synchronized (lock1) {
        toBeReplacedNodes[numPending] = n;
        actionentries[numPending] = rae;
        rae.setUniqueID(numPending);
        rae.setParent(this);
        numPending++;
       }
    }

    /** A new response for this query just came in; contact the appropriate actionentry */
    public void processResponse(ParsedMessage pm, StringTokenizer st) {
        int fragmentID = Integer.parseInt(st.nextToken());
        try {
            // call the correct action query entry
            actionentries[fragmentID].processResponse(pm, st);
            if(actionentries[fragmentID].doneProcessing()) {
                Document finalanswer = actionentries[fragmentID].getFinalAnswer();
                Node parent = toBeReplacedNodes[fragmentID].getParentNode();
                parent.replaceChild(finalanswer.getDocumentElement(), toBeReplacedNodes[fragmentID]);

                // decrement the pending requests number
                numPending--;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }


        if(numPending == 0) {
            sendReplyBack();
        }
    }

    public boolean doneProcessing() {
        return numPending == 0;
    }

    public void decrementPending() {
	synchronized (lock2) {
        	numPending--;
	}
    }
    
    public int getPending() {
	return numPending;
    }
	
    public void sendReplyBack() {
        try {
            String response = DOMProcessing.DOMtoXML(answer);
            Protocol.sendReplyMessage(srcQueryID, srcIP, srcPort, response, srcFragmentID, DOMProcessing.findQueryForThisNode(answer));
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Couldn't send reply back");
        }
    }
}
