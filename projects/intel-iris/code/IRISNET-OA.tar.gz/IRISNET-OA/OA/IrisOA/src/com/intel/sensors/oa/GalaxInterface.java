/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
//import java.util.*;
import java.util.StringTokenizer;
import java.util.Vector;

import galapi.*;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;
import org.w3c.dom.*;
import org.apache.xindice.client.xmldb.services.*;
import org.apache.xindice.xml.dom.*;

import de.fzi.XPath.Expr;


/** Separate out the calls to Galax in a different class.
 *
 * @author Suman.
 */
public class GalaxInterface implements DatabaseInterface {
	
	String collectionName="default";
	String collectionPath=".";
	Object lock = new Object();

    public GalaxInterface(String cName) throws Exception {
		collectionName = cName;
		File cPath = new File(collectionPath + "/" + collectionName);
		if (cPath.mkdirs()) 
			System.out.println("Collection " + collectionName + " created.");
		
		try {
			Galax.init();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}


		
	public synchronized org.w3c.dom.Document getDocumentWithID(String id) {
		org.w3c.dom.Document doc;
		
		if (Globals.DocCachingON) {
			doc = CacheManagement.instance().GetDocumentFromCache(id);
			if (doc != null)
				return doc;
		}
		
		String dbFile = collectionPath + "/" + collectionName + "/" + id;
		// caching is off, or document not found in the cache
		try {
			FileInputStream fis = new FileInputStream(dbFile);
			byte[] fileData = new byte[fis.available()];
			fis.read(fileData);
			String allData = new String(fileData);
			doc = DOMProcessing.XMLtoDOM(allData);
			
			if (Globals.DocCachingON) {
				CacheManagement.instance().AddDocumentToCache(id, doc);
			}
	
			fis.close();
			return doc;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

    public synchronized void deleteDocumentWithID(String id) {
		if (Globals.DocCachingON) {
			CacheManagement.instance().RemoveDocumentFromCache(id);
		}
		
		String dbFile = collectionPath + "/" + collectionName + "/" + id;
		
		try {
			File doc = new File (dbFile);
			if (doc.delete()) 
				System.out.println("Document " + id + " deleted.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	


    /** Get root of the xpath query and use that to get the document. */
    public synchronized org.w3c.dom.Document getDocumentContainingAnswer(String xpath) {
        try {
            return getDocumentContainingAnswer(QueryAnalysis.parse(xpath));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    public synchronized org.w3c.dom.Document getDocumentContainingAnswer(Expr parsetree) {
        try  {
            String root = QueryAnalysis.getRoot(parsetree);

            return getDocumentWithID(root);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Store a document with id = its root. Overwrites existing document if any. */
    public synchronized void storeDocument(org.w3c.dom.Document doc) {
        try {
            String root = ((org.w3c.dom.Element) doc.getDocumentElement()).getTagName();
            String docName = collectionPath + "/" + collectionName + "/" + root;
			File dbFile = new File(docName);
			dbFile.createNewFile();
			String allData = DOMProcessing.DOMtoXML(doc);
			FileWriter fw = new FileWriter(dbFile);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(allData, 0, allData.length());
			bw.close();
			fw.close();
			
			// invalidate cache
			CacheManagement.instance().RemoveDocumentFromCache(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Given a new document, find the corresponding document in the collection */
    public synchronized org.w3c.dom.Document getCorrespondingDocument(org.w3c.dom.Document doc) {
        String root = ((org.w3c.dom.Element) doc.getDocumentElement()).getTagName();
        return getDocumentWithID(root);
    }

    /** Do XUpdate */
	// the name of this method is a bit misleading
	// Galax supports UpdateX, an update language based on XQuery
	public synchronized void applyXUpdate(String updateXQuery) {
		StringTokenizer tokens = new StringTokenizer(updateXQuery, " \n");
		String document = tokens.nextToken();
		String query = tokens.nextToken("");
		applyXUpdate(document, query);
	}
	
    public synchronized void applyXUpdate(String docID, String updateXQuery) {
		CacheManagement.instance().RemoveDocumentFromCache(QueryAnalysis.getDocumentWrittenByXupdate(updateXQuery));
        try{
            System.out.println("GalaxInterface.applyUpdateX(): " + updateXQuery);
			String docFile = collectionPath + "/" + collectionName + "/" + docID;
            galapi.NodeList docitems = Galax.loadDocument (docFile);
			galapi.Node rootAtNode = docitems.ItemsFirst().getNode();
			galapi.ItemList items = Galax.evalStatementWithContextItemFromXML(rootAtNode, updateXQuery);
			Galax.serializeToFile (docFile, docitems);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Check if an document with this ID is already present in the document */
    public synchronized boolean existsDocumentWithName(String name) {
        try {
			String docName = collectionPath + "/" + collectionName + "/" + name;
			File docFile = new File(docName);

            return docFile.exists() && docFile.canRead();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return false;
        }
    }

    /** Replace an element identified by this query with this node */
    public synchronized void replaceElement(String xpathQuery, org.w3c.dom.Element elm) {
        try {
			System.out.println("Not Implemented");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /** Apply XSLT to the document given by the ID */
    public synchronized org.w3c.dom.Document applyXSLT(String documentID, String xsltQuery) {
        org.w3c.dom.Document doc = getDocumentWithID(documentID);
        return DOMProcessing.applyXSLTtoDOM(doc, xsltQuery);
    }

    /** Break document at the point specified by the xpathQuery. The xpathQuery should result in exactly 
     *  one result. The original document is updated so that this node is doesn't own that part any more.
     *
     *  Returns the breakAway document as a DOM which can be sent directly to the other node. */
    public synchronized org.w3c.dom.Document breakDocument(String xpathQuery) {
        Utils.shouldnthappen();
		return null;
	}

    /** Execute query normally and return all answers */
    public String executeQuery(String xpathQuery) {

		return "";
    }

	/**
    * listDocuments returns a list of all document keys stored by IrisNet
    * collection.
    *
    * @return the list of document keys
    */
	public synchronized final String[] listDocuments() {
		String retval[] = null;
		String collection = collectionPath + "/" + collectionName;
		try {
			File colFile = new File (collection);
			retval = colFile.list();
		} catch (Exception dbEx) {
			System.out.println("ERROR:XindiceInterface.listDocuments()");
			dbEx.printStackTrace();
		}
		
		return retval;
	}



    public static void main(String[] args) {
    }
}










// String document2 = "<cached> <usRegion id=\"NE\" owner-agent=\"101\" xmlns:src=\"http://xml.apache.org/xindice/Query\" src:col=\"/db/parkingblock100\" src:key=\"26fd2bf64e04f326000000ee8032cd73\"> <state id=\"PA\" owner-agent=\"201\"> <county id=\"Allegheny\" owner-agent=\"301\"> <city id=\"Pittsburgh\" owner-agent=\"401\"> <neighborhood id=\"Oakland\" owner-agent=\"509\"> <block id=\"100\" owner-agent=\"601\"> <name>400 South Craig</name> <GPS> <latitude>40.27N</latitude> <longitude>80.00W</longitude> <altitude>100</altitude> </GPS> <total-spaces>4</total-spaces> <available-spaces type=\"sensor-aggregate\"> <total>4</total> <min-sensor-readtime>20020403133800</min-sensor-readtime> </available-spaces> <parkingSpace id=\"10000\" owner-sensor=\"701\" xmlns:src=\"http://xml.apache.org/xindice/Query\" src:col=\"/db/parkingblock100\" src:key=\"26fd2bf64e04f326000000ee8032cd73\"> <streetAddress>405 South Craig</streetAddress> <usage seconds-until-stale=\"300\"> <in-use>no</in-use> <latest-event-time>20020403085521</latest-event-time> <latest-sensor-readtime>20020403133800</latest-sensor-readtime> </usage> <meter> <max-hours>2</max-hours> <operation-hours> <sunday-start>none</sunday-start> <sunday-end>none</sunday-end> <weekday-start>0800</weekday-start> <weekday-end>2000</weekday-end> <saturday-start>1000</saturday-start> <saturday-end>1800</saturday-end> </operation-hours> <cost> <price-in-dollars>0.25</price-in-dollars> <time-in-hours>0.50</time-in-hours> </cost> </meter> </parkingSpace> <parkingSpace id=\"10001\" owner-sensor=\"701\" xmlns:src=\"http://xml.apache.org/xindice/Query\" src:col=\"/db/parkingblock100\" src:key=\"26fd2bf64e04f326000000ee8032cd73\"> <streetAddress>409 South Craig</streetAddress> <usage seconds-until-stale=\"300\"> <in-use>no</in-use> <latest-event-time>20020403115531</latest-event-time> <latest-sensor-readtime>20020403133840</latest-sensor-readtime> </usage> <meter> <max-hours>2</max-hours> <operation-hours> <sunday-start>none</sunday-start> <sunday-end>none</sunday-end> <weekday-start>0800</weekday-start> <weekday-end>2000</weekday-end> <saturday-start>1000</saturday-start> <saturday-end>1800</saturday-end> </operation-hours> <cost> <price-in-dollars>0.25</price-in-dollars> <time-in-hours>0.50</time-in-hours> </cost> </meter> </parkingSpace> <parkingSpace id=\"10002\" owner-sensor=\"701\" xmlns:src=\"http://xml.apache.org/xindice/Query\" src:col=\"/db/parkingblock100\" src:key=\"26fd2bf64e04f326000000ee8032cd73\"> <streetAddress>413 South Craig</streetAddress> <usage seconds-until-stale=\"300\"> <in-use>no</in-use> <latest-event-time>20020403115531</latest-event-time> <latest-sensor-readtime>20020403133840</latest-sensor-readtime> </usage> <meter> <max-hours>2</max-hours> <operation-hours> <sunday-start>none</sunday-start> <sunday-end>none</sunday-end> <weekday-start>0800</weekday-start> <weekday-end>2000</weekday-end> <saturday-start>1000</saturday-start> <saturday-end>1800</saturday-end> </operation-hours> <cost> <price-in-dollars>0.25</price-in-dollars> <time-in-hours>0.50</time-in-hours> </cost> </meter> </parkingSpace> <parkingSpace id=\"10003\" owner-sensor=\"701\" xmlns:src=\"http://xml.apache.org/xindice/Query\" src:col=\"/db/parkingblock100\" src:key=\"26fd2bf64e04f326000000ee8032cd73\"> <streetAddress>417 South Craig</streetAddress> <usage seconds-until-stale=\"300\"> <in-use>no</in-use> <latest-event-time>20020403115531</latest-event-time> <latest-sensor-readtime>20020403133840</latest-sensor-readtime> </usage> <meter> <max-hours>2</max-hours> <operation-hours> <sunday-start>none</sunday-start> <sunday-end>none</sunday-end> <weekday-start>0800</weekday-start> <weekday-end>2000</weekday-end> <saturday-start>1000</saturday-start> <saturday-end>1800</saturday-end> </operation-hours> <cost> <price-in-dollars>0.25</price-in-dollars> <time-in-hours>0.50</time-in-hours> </cost> </meter> </parkingSpace> </block> </neighborhood> </city> </county> </state> </usRegion> </cached>";
