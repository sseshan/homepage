/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
   met:

   * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;

/**
 * This class handles the timeouts of the queries.
 * For each queryID, it creates a hashtable where all 
 * the subqueries sent out are maintained. On arrival of
 * each reply, the corresponding subquery is deleted.
 * After the timeout period, all selfNullReply messages are 
 * generated for all the pending subqueries
 *
 * Should not be on the critical path. Use threads.
 */

class PendingQuery{
	int resultType;
	int pending = 0;
	Object lock = new Object();
	long queryID;

	public PendingQuery(String qID, int rType) {
		queryID = Long.parseLong(qID);
		resultType = rType;
	}

	void add() {
		synchronized(lock) {
			pending++;
		}
	}

	void remove() {
		synchronized(lock) {
			pending--;
		}
	}

	boolean terminate() {
		boolean OK = true;
		synchronized(lock) {
			try {
				for (int i = 0; i< pending; i++) {
					Protocol.enqueueReply2Message ( queryID, resultType, "null",
													"127.0.0.1", Protocol.getLocalPort(), false);
				}
				//System.out.println("Pending queries terminated");
			} catch (Exception e) {
				e.printStackTrace();
				OK = false;
			}
		}

		return OK;
	}
}

public class Timeout {
	Object lock = new Object();

    // For all the subqueries generated from the same
    // query has one entry in this global table.
    // The key of this table is "query id", the value
    // for each key is a PendingQuery class;
    static Hashtable globalTable = new Hashtable();

    // add a new pending subquery
    // should be invoked when a QUERY/QUERY2 message is sent out
    public static void add(String message){
		ParsedMessage pm;
		try {
			pm = Protocol.parseIncomingMessage(message);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		PendingQuery pq = (PendingQuery) globalTable.get(pm.queryID);
		final String qID = pm.queryID;

        if (pq == null) {
            // this is the first pending subquery for this query
            final PendingQuery pq1 = new PendingQuery(pm.queryID, pm.resultType);
            pq1.add();

            // schedule the termination
            Timer timer = new Timer (true); // make it a daemon
            timer.schedule(new TimerTask() {
                    public void run() {
                        if (pq1.terminate()) {
                            globalTable.remove(qID);
                        }
                    }
                }, (long)ConfigurationManager.instance().getQTimeOut());

            // add the entry to the globalTable
            globalTable.put(pm.queryID, pq1);
        } else {
            pq.add();
        }
	}

	// removes a pending subquery
	// should be called when a REPLY/REPLY2 message is received
	public static void remove(String queryID) {
		PendingQuery pq = (PendingQuery)globalTable.get(queryID);
		if (pq == null) return;

		pq.remove();
	}

	static Timeout INSTANCE = new Timeout();
    public static Timeout instance() {
        return INSTANCE;
    }

}


class PendingQuery2 {
    Hashtable localTable = new Hashtable();
    Object lock = new Object();
	public int numPending = 0;
	String resultType;

    // add a new pending query
    void add(String IP)
    {
		synchronized (lock) {
			localTable.put(IP, new Object());
			numPending++;
		} 
    }

    // deletes a pending query
    Object delete(String IP)
    {
		Object o = null;
		synchronized(lock) {
			o = localTable.remove(IP);
			numPending--;
		}
		return o;
    }
	
    // generate the selfNullReplies
    boolean terminate()
    {
		String pendingQuery = null;
		synchronized (lock) {
			for (Enumeration e = localTable.elements(); e.hasMoreElements(); ) {
				pendingQuery = (String) e.nextElement();
				Protocol.enqueueSelfNullReply2 (pendingQuery + " ENDMESSAGE");
				//Protocol.getSelfEntry().flush();
			}
			Protocol.getSelfEntry().flush();
			localTable.clear();
		}
		
		return true; 
    }
	
}


class Timeout2 {
   
    Object lock = new Object();

    // For all the subqueries generated from the same
    // query has one entry in this global table.
    // The key of this table is "query id", the value 
    // for each key is a PendingQuery class;
    static Hashtable globalTable = new Hashtable();
    
    // add a new pending subquery
	// should be invoked when a QUERY/QUERY2 message is sent out
    public static void add(String queryId, String subquery)
    {
		final String qId = queryId;
		PendingQuery2 pq = (PendingQuery2) globalTable.get(queryId);
		if (pq == null) {
			// this is the first pending subquery for this query
			final PendingQuery2 pq1 = new PendingQuery2();
			pq1.add(subquery);
			
			// schedule the termination 
			Timer timer = new Timer (true); // make it a daemon
			timer.schedule(new TimerTask() {
					public void run() {
						if (pq1.terminate()) {
							globalTable.remove(qId);
						}
					}
				}, (long)ConfigurationManager.instance().getQTimeOut()); 
			
			// add the entry to the globalTable
			globalTable.put(queryId, pq1);
		} else {
			pq.add(subquery);
		}
	}
    

	public static void remove(String queryID, String subquery)
	{
		PendingQuery2 pq = (PendingQuery2) globalTable.get(queryID);
		if (pq != null) {
			pq.delete(subquery);
			if (pq.numPending == 0)
				globalTable.remove(queryID);
		}
	}

    static Timeout INSTANCE = new Timeout();
    public static Timeout instance() {
		return INSTANCE;
    }
}
