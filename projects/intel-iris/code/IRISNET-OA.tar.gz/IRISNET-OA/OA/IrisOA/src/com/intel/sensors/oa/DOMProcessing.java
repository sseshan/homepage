/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
package com.intel.sensors.oa;

import java.util.Vector;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.FileReader;

import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xpath.XPathAPI;
import org.apache.xml.utils.TreeWalker;
import org.apache.xml.utils.DOMBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Attr;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.traversal.*;

import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;

// Imported JAVA API for XML Parsing 1.0 classes
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException; 

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

// DocumentImpl
import org.apache.xindice.xml.dom.DocumentImpl;

/** 
 *   Some static functions to do document processing using the DOM model. There might be some inconsistencies in the
 *   defined functions since we have been changing the design quite a bit. For example, some of the functions though
 *   defined, may not be useful any more. 
 *
 *  @author Amol */
public class DOMProcessing {

    public static Transformer serializer = null;
    public static DocumentBuilderFactory dfactory = null;
    public static TransformerFactory tFactory = null;

    public static void init() {
        try {
            tFactory = TransformerFactory.newInstance();
            serializer = tFactory.newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            dfactory = DocumentBuilderFactory.newInstance();
            dfactory.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion", new Boolean(false));
            dfactory.setNamespaceAware(false);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void printSpaces(int n) {
        for(int i = 0; i < n; i++) 
            System.out.print(" ");
    }


    /** Find all the hostnames that we own. This is done by first finding all the nodes that are
     *  'own'ed and then finding the owner-agent for each of them.
     *
     *  Update: With the new meaning of `own' tag that allows for `part' tags, this is much easier
     *  to express. 
     *
     *  More update: With abdication of the own tag, and introduction of `status' tag, this is still
     *  straightforward. */
    public static String[] findAllOwnedHostNames(Document doc) {
        if(doc == null) 
            return null;

        try {
            // also, if parent is owned, don't need to send this to the DNS as well XXX not used currently
            // Node[] ownednodes = applyXPATHtoDOM(doc, "//*[(@status='ownsthis' or @status='ownsall') and not(../.[@status='ownsthis' or @status='ownsall'])]");

            Node[] ownednodes = applyXPATHtoDOM(doc, "//*[@status='ownsthis']");

            String[] ret_val = new String[ownednodes.length];
            for(int i = 0; i < ret_val.length; i++) {
                ret_val[i] = findOwnerAgent(ownednodes[i]);
            }
            return ret_val;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** A node such that `all' its children are owned, is owned. 
	 * The `own' tag itself is not very useful here. XXX This probably 
	 * speaks for bad design or bad usage of the term `own'. 
     *
     *  Update: Not used any more. See above. */
    public static Vector findAllOwnedNodes(Document doc) {
        Utils.shouldnthappen();
        Vector ret_val = new Vector();
        myNormalize(doc);
        findAllOwnedNodes(doc.getDocumentElement(), ret_val);
        return ret_val;
    }


    /** Recursive function to determine if `n' is owned. `n' is owned if all 
	 * its children are owned. This is a veto procedure. If there is any 
	 * descedant that has an own attribute set to no, this node is not `own'ed. 
	 * All nodes without an 'id' attribute are owned.
     *
     *  Returns a boolean denoting whether the node is owned. 
     *  */
    private static boolean findAllOwnedNodes(Node n, Vector v) {
        Utils.shouldnthappen();
        boolean owned = ! DOMHelper.isSpecial(n) || DOMHelper.isOwned(n);
        // if all children are owned, then we are too
        NodeList nl = n.getChildNodes();
        Vector ownedChildren = new Vector();
        for(int i = 0; i < nl.getLength(); i++) {
            boolean b = findAllOwnedNodes(nl.item(i), v);
            if(b && DOMHelper.isSpecial(nl.item(i))) 
                ownedChildren.add(nl.item(i));
            owned = owned && b; // Veto if not
        }

        if(DOMHelper.isSpecial(n) && !owned) {
            for(int i = 0; i < ownedChildren.size(); i++)
                v.add(ownedChildren.get(i));
        }
        return owned;
    }

    /** Set all own attributes below this node to `no'. 
	 * This is used when breaking up a document. */
    public static void setOwnAttributesToNo(Node n) {
        NodeIterator ni = ((DocumentImpl) n.getOwnerDocument()).createNodeIterator(n, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
       while((iter = (Element) ni.nextNode()) != null) { 
            if(iter.hasAttribute("status") && iter.getAttribute("status").equals("ownsthis")) {
                iter.setAttribute("status", "complete");
            }
        }
    }

    /** Set all the expiry attributes below this node to `newval'. This is only for initial testing purposes, and
     *  doesn't really have a place in the final deployed version. */
    public static void setAllExpiryAttributes(Node n, String newVal) {
        NodeIterator ni = ((DocumentImpl) n.getOwnerDocument()).createNodeIterator(n, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
        while((iter = (Element) ni.nextNode()) != null) { 
            if(iter.hasAttribute("expiry"))
                iter.setAttribute("expiry", newVal);
        }
    }

    /** Print the document so that only the special nodes are shown in a nice tree-like format */
    public static void prettyPrint(Node n) {
        if (n instanceof Element) {
            prettyPrint((Element) n, 0);
        } else if (n instanceof Document) {
            prettyPrint(((Document) n).getDocumentElement(), 0);
        }
        System.out.println("DOMProcessing.prettyPrint(): Key: [1mcached [31mincomplete [32mowned [0m");
    }

    /** Pretty print a document given as a string */
    public static void prettyPrint(String str) throws Exception {
        prettyPrint(XMLtoDOM(str));
    }

    private static Vector getOnlyElementChildren(Node n) {
        Vector ret_val = new Vector();
        NodeList nl = n.getChildNodes();
        for(int i = 0; i < nl.getLength(); i++) {
            if(nl.item(i) instanceof Element) 
                ret_val.add(nl.item(i));
        }
        return ret_val;
    }

    /** Helper function for the prettyPrint */
    private static void prettyPrint(Element e, int num_spaces) {
        String print_val;

        if(e.hasAttribute("id")) {
            print_val = e.getAttribute("id");
        }  else {
            print_val = e.getTagName();
        }

        if(DOMHelper.isOwned(e)) {
            System.out.print("[1m[32m" + print_val + "[0m");
        } else if(DOMHelper.isIncomplete(e)) {
            System.out.print("[1m[31m" + print_val + "[0m");
        } else {
            System.out.print("[1m" + print_val + "[0m");
        }



        //if(! DOMHelper.isOwned(e)) {
        //    print_val += "*";
        //}
        // System.out.print(print_val);

        boolean printCR = true; // whether to print carriage return at the end

        Vector children = getOnlyElementChildren(e);
        if(children.size() == 1) {
            System.out.print("----");
            if (Globals.DebugON)
				prettyPrint((Element) children.get(0), num_spaces + print_val.length() + 4);
            printCR = false;
        } else if(children.size() > 1) {
            // in that case, only print `special' children
            boolean first = true;
            for(int i = 0; i < children.size(); i++) {
                if(DOMHelper.isSpecial((Node) children.get(i)) && (! ((Element) children.get(i)).getTagName().equals("parkingSpace"))) {
                    printCR = false;
                    if(first) {
                        first = false;
                        System.out.print("----");
                    } else {
                        printSpaces(num_spaces + print_val.length());
                        System.out.print("|---");
                    }
					if (Globals.DebugON)
						prettyPrint((Element) children.get(i), num_spaces + print_val.length() + 4);
                }
            }
        }

        // if none of the children printed, print new line
        if(printCR)
            System.out.println();
    }


    /** Create a new text node with specified number of spaces preappended with a new line */
    private static Text newText(Node n, int num_spaces) {
        StringBuffer s = new StringBuffer("\n");
        for(int i = 0; i < num_spaces; i++)
            s.append(" ");
        return n.getOwnerDocument().createTextNode(s.toString());
    }


    /** Add new text nodes so that the document is readable */
    private static void myDenormalize(Node n, int spaces) {
        // add if this is an element and does not have a `single text node'
        if(n instanceof Element) {
            if(!((n.getChildNodes().getLength() == 1) && (n.getFirstChild()) instanceof Text)) {
                // add an empty space in the beginning, in the end, and between every two elements
                n.appendChild(newText(n, spaces));
                Vector v = new Vector();
                for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                    myDenormalize(n.getChildNodes().item(i), spaces+4);
                    if(n.getChildNodes().item(i) instanceof Element)
                        v.add(n.getChildNodes().item(i));
                }
                for(int i = 0; i < v.size(); i++) {
                    n.insertBefore(newText(n, spaces), (Node) v.get(i));
                }
            }
        }
    }

    /** Add new text nodes to the document so that it is readable */
    public static void myDenormalize(Document d) {
        /** Just make sure that it is in a normalized form */
        myNormalize(d);
        myDenormalize(d.getDocumentElement(), 0);
    }

    /** Denormalize and print the document. Only prints a clone. XXX no need to create a new document.
     *  should directly print. */
    public static void printDeNormalized(Document doc) {
        try {
            Document clone = XMLtoDOM(DOMtoXML(doc)); 
            myDenormalize(clone);
            System.out.println(DOMtoXML(clone));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Find owner agent for this node by going up the tree till the top and using either the 
     * IDs or the tag names of the ancestors. */
    public static String findOwnerAgent(Node n) {
        Element e = (Element) n;

        String idHere;

        if(e.hasAttribute("id")) {
            idHere = e.getAttribute("id");
        } else {
            idHere = e.getTagName();
        }

        if(n.getParentNode() instanceof Element) {
            return idHere + "." + findOwnerAgent(n.getParentNode());
        } else {
            return idHere;
        }
    }

    /** Find a query that uniquely identifies this node. It is assumed that it is possible to uniquely identify the
     *  node. */
    public static String findQueryForThisNode(Node n) {
        Element e = (Element) n;

        String ret_val;

        if(e.hasAttribute("id")) {
            ret_val = "/" + e.getTagName() + "[@id='" + e.getAttribute("id") + "']";
        } else {
            ret_val = "/" + e.getTagName();
        }

        if(n.getParentNode() instanceof Element) {
            return findQueryForThisNode(n.getParentNode()) + ret_val;
        } else {
            return ret_val;
        }
    }

    /** Convert from DOM to XML */
    public static String DOMtoXML(Node n) {
        if (n == null)
            return null;
        return org.apache.xindice.xml.TextWriter.toString(n);
    }

    /** Convert from XML to DOM */
    public static Document XMLtoDOM(String xml) throws Exception {
        if (xml == null)
            return null;
        return org.apache.xindice.xml.dom.DOMParser.toDocument(xml);
    }

    /** Another converter: given a file name, construct the DOM */
    public static Document fileToDOM(String fileName) throws Exception {
        if(fileName == null) 
            return null;
        return org.apache.xindice.xml.dom.DOMParser.toDocument(new FileReader(fileName));
    }

    public static Transformer getXSLTTransformer(String xsltQuery) {
        if(serializer == null) 
            init();
        try {
            return tFactory.newTransformer(new StreamSource(new StringReader(xsltQuery)));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    public static Document applyXSLTtoDOM(Node doc, Transformer transformer) {
        try {
            Document ret_val = new org.apache.xindice.xml.dom.DocumentImpl();

            transformer.transform(new DOMSource(doc), new DOMResult(ret_val));

            return ret_val;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    /** Given a document in the DOM format, apply XSLT to it */
    public static Document applyXSLTtoDOM(Node doc, String xsltQuery) {
        if(serializer == null) 
            init();
        try {
            if (doc == null || xsltQuery == null)
                return null;

            if(serializer == null) 
                init();

            Transformer transformer = tFactory.newTransformer(new StreamSource(new StringReader(xsltQuery)));
            Document ret_val = new org.apache.xindice.xml.dom.DocumentImpl();
            transformer.transform(new DOMSource(doc), new DOMResult(ret_val));
            return ret_val;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    /** Given a document in the DOM format, apply XSLT to it */
    public static Document applyFileXSLTtoDOM(Node doc, String fileName) {
        if(serializer == null) 
            init();
        try {
            Transformer transformer = tFactory.newTransformer(new StreamSource(new FileReader(fileName)));
            Document ret_val = new org.apache.xindice.xml.dom.DocumentImpl();
            transformer.transform(new DOMSource(doc), new DOMResult(ret_val));
            return ret_val;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    /** Given a document in the DOM format, apply XPath to it. Return the result as an array of nodes. */
    public static Node[] applyXPATHtoDOM(Node n, String xpath) throws Exception {
        if (n == null || xpath == null)
            return null;

        if(serializer == null) 
            init();

        NodeIterator ni = XPathAPI.selectNodeIterator(n, xpath);
        Vector dummy = new Vector();
        Node _n;
        while((_n = ni.nextNode()) != null) {
            dummy.add(_n);
        }

        Node[] ret_val = new Node[dummy.size()];
        for(int i = 0; i < dummy.size(); i++)
            ret_val[i] = (Node)dummy.get(i);

        return ret_val;
    }

    /** Find closest ancestors that are not owned by the current OA nodes. */
    public static Node findLowestUnownedAncestor(Node n) {
        if(DOMHelper.isSpecial(n)) {
            if(! ((Element) n).getAttribute("status").equals("ownsthis")) {
                return n;
            } else {
                // This is the funny case; XXX if this node is owned,
                // what should we do ? right now, we return `null', but the semantics are not
                // completely clear.
                return null;
            }
        } else {
            return findLowestUnownedAncestor(n.getParentNode());
        }
    }


    /** Here we know that both the nodes correspond to the same `real' node. They have the same tag and
     *  same value for "id" */
    private static void mergeNodesSameRoot(Node origNode, Node newNode) {
        // for all the attributes common in the two nodes, we should use newNode attributes

        // for every attribute of origNode, if it is also present in newNode, use the attribute in newNode
        NamedNodeMap nnmOrig = origNode.getAttributes();
        NamedNodeMap nnmNew = newNode.getAttributes();
        for(int i = 0; i < nnmOrig.getLength(); i++) {
            Attr origAt = (Attr) nnmOrig.item(i);
            for(int j = 0; j < nnmNew.getLength(); j++) {
                Attr newAt = (Attr) nnmNew.item(i);
                // if the attribute names are the same; replace by the new one
                if(origAt.getValue().equals(newAt.getValue())) {
                    origNode.replaceChild(origAt, newAt);
                    break; // better not to duplicate matches
                }
            }
        }
    }

    /* newNode is always a descedant of orgNode. */
    private static void mergeNodes(Node orgNode, Node newNode) {
        if(newNode instanceof Element) {
            Element orgElm = (Element) orgNode; // can't see how this can be not an element
            Element newElm = (Element) newNode;

            boolean addExpiryTag = false;

            if(checkIfMatchElements(orgElm, newElm)) {
                // cool. we found a match. 
                // System.out.println("Bingo");

                // Utils.printStars(5);
                // printNode(orgElm);
                // printNode(newElm);

                // for Elements, recurse. For text nodes, use the new values
                NodeList orgnl = orgElm.getChildNodes();
                NodeList newnl = newElm.getChildNodes();

                // for text nodes, prefer the newer version
                for(int i = 0; i < newnl.getLength(); i++) {
                    if(newnl.item(i) instanceof Text) {
                        if(newnl.getLength() != 1)
                            Utils.shouldnthappen();
                        orgElm.replaceChild(newnl.item(i), orgnl.item(i));
                    }
                }

                // do merge-join kind of thing with elements
                for(int i = 0; i < newnl.getLength(); i++) {
                    if(newnl.item(i) instanceof Element) {
                        Element _newelm = (Element) newnl.item(i);
                        boolean foundMatch = false;

                        for(int j = 0; j < orgnl.getLength(); j++) {
                            if(orgnl.item(j) instanceof Element) {
                                Element _oldelm = (Element) orgnl.item(j);
                                // if find an element that matches, call merge nodes on that
                                if(checkIfMatchElements(_oldelm, _newelm)) {
                                    mergeNodes(_oldelm, _newelm);
                                    foundMatch = true;
                                }
                            }
                        }

                        // if not found, insert this node here
                        if(!foundMatch) {
                            // if this is true, then should add an expiry tag XXX 
                            // addExpiryTag = true;
                            orgElm.appendChild(orgElm.getOwnerDocument().importNode(_newelm, true));
                        }
                    }
                }

                // if expiry tag needs to be added, do it here
                // if(addExpiryTag)
                //     orgElm.setAttribute("expiry", "10");

                // for attributes, replace with the new attribute node
                NamedNodeMap orgnnm = orgElm.getAttributes();
                NamedNodeMap newnnm = newElm.getAttributes();
                for(int i = 0; i < orgnnm.getLength(); i++) {
                    Attr attr = (Attr) orgnnm.item(i);
                    Attr corresAttr = (Attr) newnnm.getNamedItem(attr.getName());
                    if(corresAttr != null)  {
                        orgnnm.setNamedItem(orgElm.getOwnerDocument().importNode(corresAttr, false));
                    }
                }

                // printNode(orgElm);

            } else {
                // no match here... recurse
                NodeList nl = orgElm.getChildNodes();
                for(int i = 0; i < nl.getLength(); i++) {
                    if(nl.item(i) instanceof Element) {
                        // // System.out.println("No match here -- recursiving on");
                        // printNode(nl.item(i));
                        mergeNodes(nl.item(i), newNode);
                    }
                }
            }
        } else {
            // don't see how this can happen
            Utils.shouldnthappen();
        }
    }

    public static void printNode(Node n) {
        System.out.println("- start -");
        // System.out.println("*"+DOMtoXML(n)+"*");
        // prettyPrint(n, 0);
        System.out.println(findOwnerAgent(n));
        System.out.println("- end -");
    }

    /** Check if the tagNames and @id attributes match for two element nodes */
    private static boolean checkIfMatchElements(Element e1, Element e2) {
        // check tag names
        System.out.println(e1.getTagName() + " " + e2.getTagName());
        if(e1.getTagName().equals(e2.getTagName())) {
            Attr orgID = (Attr) e1.getAttributes().getNamedItem("id");
            Attr newID = (Attr) e2.getAttributes().getNamedItem("id");

            if(orgID == null) {
                if(newID == null) {
                    // can't have two elements with same tag but no id's to distinguish
                    // need to document the assumptions about XML we are making XXX
                    return true; 
                } else {
                    Utils.shouldnthappen(); // one has id the other doesn't... shouldn't really happen
                    return false; 
                }
            }

            System.out.println("	*" + orgID.getValue() + "*" + newID.getValue() + "*");
            System.out.println("	*" + orgID.getValue().length() + "*" + newID.getValue().length() + "*");

            if(orgID.getValue().equals(newID.getValue())) {
                System.out.println("comes here");
                return true;
            }
        }
        return false;
    }

    /** Given two nodes, merge the second one into the first  */
    public static void mergeDocuments(Document origDocument, Document newDocument) {
        myNormalize(origDocument);
        myNormalize(newDocument);
        mergeNodes(origDocument.getDocumentElement(), newDocument.getDocumentElement());
        myDenormalize(origDocument);
    }

    /** Remove all the final and leaf tags */
    public static void removeFinalLeafTags(Node doc) {
        NodeIterator ni = ((DocumentImpl) doc.getOwnerDocument()).createNodeIterator(doc, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
        Vector tobedeleted = new Vector();
        while((iter = (Element) ni.nextNode()) != null) { 
            if(iter.getTagName().equals("final") || iter.getTagName().equals("leaf"))
                tobedeleted.add(iter);
        }

        for(int i = 0; i < tobedeleted.size(); i++) {
            Node del = (Node) tobedeleted.get(i);
            del.getParentNode().removeChild(del);
        }
    }

    /** Set the status attribute for those nodes which are special but don't have any children at all */
    public static void setIncompleteStatusForIncompleteNodes(Node doc) {
        NodeIterator ni = ((DocumentImpl) doc.getOwnerDocument()).createNodeIterator(doc, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
        while((iter = (Element) ni.nextNode()) != null) { 
            if(DOMHelper.isSpecial(iter)) {
                if(!iter.hasChildNodes()) {
                    iter.setAttribute("status", "incomplete");
                }
            }
        }
    }

    /** Remove the incorrect "incomplete" tags. An incomplete tag is removed if it is not the only child of
     *  its parent */
    public static void removeIncorrectIncompleteTags(Node doc) {
        Utils.shouldnthappen();
        NodeIterator ni = ((DocumentImpl) doc.getOwnerDocument()).createNodeIterator(doc, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
        Vector tobedeleted = new Vector();
        while((iter = (Element) ni.nextNode()) != null) { 
            if(iter.getTagName().equals("incomplete") && (iter.getParentNode().getChildNodes().getLength() == 1))
                tobedeleted.add(iter);
        }

        for(int i = 0; i < tobedeleted.size(); i++) {
            Node del = (Node) tobedeleted.get(i);
            del.getParentNode().removeChild(del);
        }
    }

    /** 'Deleting' a node means that replacing it with a new element that has the same tag, `own' set to no
     *  and `incomplete' tag associated. */
    private static void deleteThisNode(Node node) {
        Element e = (Element) node;
        e.getParentNode().replaceChild(DOMHelper.createDanglingElement(e), e);
    }

    /** In a similar fashion to above, `delete' all siblings of this node, and also of all its ancestors. */
    private static void deleteSiblingsHereAndAbove(Node node) {
        if(node.getParentNode() instanceof Element) {
            Element parent = (Element) node.getParentNode();
            NodeList nl = parent.getChildNodes();

            Vector toBeDeletedNodes = new Vector();
            Vector toBeInsertedNodes = new Vector();
            for(int i = 0; i < nl.getLength(); i++) {
                if(nl.item(i) instanceof Element) {
                    Element sibling = (Element) nl.item(i);
                    if(sibling.getTagName().equals(((Element)node).getTagName()) && (sibling != node)) {

                        toBeDeletedNodes.add(sibling);
                        toBeInsertedNodes.add(DOMHelper.createDanglingElement(sibling));

                    }
                }
            }

            for(int i = 0; i < toBeDeletedNodes.size(); i++) {
                parent.replaceChild((Node) toBeInsertedNodes.get(i), (Node) toBeDeletedNodes.get(i)); 
            }
            deleteSiblingsHereAndAbove(parent);
        }
    }

    /** Set some attribute for all ancestors */
    public static void setAllAncestorsAttr(Node n, String attrName, String attrValue) {
        if((n != null) && (n instanceof Element)) {
            ((Element) n).setAttribute(attrName, attrValue);
            setAllAncestorsAttr(n.getParentNode(), attrName, attrValue);
        }
    }

    public static void deleteStatusAttributeRecursive(Node n) {
        if((n instanceof Element) && ((Element) n).hasAttribute("status")) {
            ((Element) n).removeAttribute("status");
            deleteStatusAttributeRecursive(n.getParentNode());
        }
    }

    public static void removeOwnershipHereAndAbove(Node n) {
        if((n instanceof Element) && ((Element) n).hasAttribute("status")) {
            if( ((Element) n).getAttribute("status").equals("ownsthis") ) {
                ((Element) n).setAttribute("status", "complete");
            }
            removeOwnershipHereAndAbove(n.getParentNode());
        }
    }

    /** Given a document, update all the `own' tags if required so that there is a clear distinction
     *  between 'yes', 'part' 'no'. */
    public static void updateOwnTags(Node n) {
        Utils.shouldnthappen();
        if (n instanceof Element) {
            // just go over the children first
            for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                updateOwnTags(n.getChildNodes().item(i));
            }

            // now if the tag for this node is "part", check if we want to change that to either "yes" or "no"
            if(((Element) n).getAttribute("own").equals("part")) {
                boolean owned = true, partowned = false;  
                for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                    Node child = n.getChildNodes().item(i);
                    if((child instanceof Element) && ((Element) child).hasAttribute("own")) {
                        String val = ((Element) child).getAttribute("own");
                        if(val.equals("yes")) {
                            partowned = true;
                        } else if(val.equals("no")) {
                            owned = false;
                        }
                    }
                }

                if(owned) 
                    ((Element) n).setAttribute("own", "yes");
                if(!owned && !partowned) 
                    ((Element) n).setAttribute("own", "no");
            }
        } else if(n instanceof Document) {
            updateOwnTags(((Document) n).getDocumentElement());
        }
    }

    /** Given a document, and a xpath query, find the node pointed to be 
	 * the query and break the document at that point. This should not 
	 * require using the entire document. Really should be able to do
     * this without that. Especially, if part of the document resides on 
	 * the disk, we shouldn't have to get it into memory. 
	 * XXX I think this can be done by using few XSLT queries. */
    public static Document breakDocument(Document doc, String xpath) {
        if (doc == null || xpath == null)
            return null;

        try {
            // Document clone = (Document) doc.cloneNode(true); // XXX not working.. hack below
            Document clone = XMLtoDOM(DOMtoXML(doc));

            // original document
            Node []  tmpNodes = applyXPATHtoDOM(doc, xpath);

            if (tmpNodes.length == 0) {
                System.out.println("DOMProcess.breakDocument(): Error applying xpath to dom");
                return null;
            }

            Node breakAtOrig = tmpNodes[0];
            deleteThisNode(breakAtOrig);

            // new document
            Node breakAtNew = applyXPATHtoDOM(clone, xpath)[0];
            removeOwnershipHereAndAbove(breakAtNew.getParentNode());
            deleteSiblingsHereAndAbove(breakAtNew);

            return clone;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }

    /** String version of the above. Mainly for testing purposes. */
    public static String[] breakDocument(String document, String xpath) {
        try {
            Document thisdoc = XMLtoDOM(document);

            Document second = breakDocument(thisdoc, xpath);
            String[] ret = new String[2];
            ret[0] = DOMtoXML(thisdoc);
            ret[1] = DOMtoXML(second);
            return ret;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public static void testBreakDocument() {
        String doc = "<usRegion> <state> <county id='a'><city id='d'/></county><county id='b'><city id='c'/></county></state></usRegion>";
        String xpath = "/usRegion/state/county[@id='a']/";
        String[] docs = breakDocument(doc, xpath);
        System.out.println(docs[0]);
        System.out.println(docs[1]);
        System.exit(1);
    }


    /** Normalize a document by removing all empty whitespaces. These create way too many problems. XXX The documents
     * inside hte database should always be in this format. */
    public static void myNormalize(Node n) {
        if((n instanceof Element) || (n instanceof Document)) {
            Vector toBeDeleted = new Vector();
            for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                Node child = n.getChildNodes().item(i);
                if(child instanceof Text) {
                    if(org.apache.xml.utils.XMLCharacterRecognizer.isWhiteSpace(((Text) child).getData()))
                        toBeDeleted.add(child);
                } else {
                    myNormalize(child);
                }
            }
            for(int i = 0; i < toBeDeleted.size(); i++)
                n.removeChild((Node) toBeDeleted.get(i));
        }
    }

    /** Check if this element has an expiry tag, and if yes, whether it has expired. 
     * Sending currentTime to be -1 evicts everything. */
    private static boolean hasExpired(Element elm, String currentTime) {
        System.out.println("DOMProcessing.hasExpired(): Evicting elements older than " + currentTime);

        if (currentTime.equals("-1")) {
            System.out.println("DOMProcessing.hasExpired(): Forced expiry of element: " + elm);
            return true;
        }

        if (elm.hasAttribute("expiry")) {
            if (Long.parseLong(elm.getAttribute("expiry")) < Long.parseLong(currentTime)) {
                System.out.println("DOMProcessing.hasExpired(): Expiring " + elm.getAttribute("expiry") + " " + currentTime);
                return true;
            } else {
                System.out.println("DOMProcessing.hasExpired(): NOT Expiring " + findOwnerAgent(elm));
                return false;
            }
        }
        return false;
    }

    /** Recursively evict nodes older than the `currentTime'. */
    private static boolean evictOlderThanRecursively(Element elm, String currentTime) {
        if(elm.hasAttribute("expiry")) {
            // System.out.println("Found one with expiry tag" + elm.getTagName() + elm.getAttribute("expiry"));
            // System.out.println(hasExpired(elm, currentTime));
            return hasExpired(elm, currentTime);
        } else {
            // can't evict this Element if it is owned by us
            boolean evictThis = !(elm.hasAttribute("status") && elm.getAttribute("status").equals("ownsthis"));

            // go over the children recursively
            NodeList nl = elm.getChildNodes();
            Vector tobeevicted = new Vector();
            for(int i = 0; i < nl.getLength(); i++) {
                if(nl.item(i) instanceof Element) {
                    Element child = (Element) nl.item(i);
                    if(evictOlderThanRecursively(child, currentTime)) {
                        if(child.hasAttribute("id")) { // non-ID nodes can not be evicted on their own
                            tobeevicted.add(child);
                        }
                    } else {
                        evictThis = false; // any child can veto parent's eviction
                    }
                }
            }

            // evict the children to be evicted; no need to actually delete 
			// if this element is also going to be deleted 
            if(!evictThis) {
                for(int i = 0; i < tobeevicted.size(); i++) {
                    deleteThisNode((Element) tobeevicted.get(i)); // this creates new substitute children as well
                }
            }

            return evictThis;
        }
    }

    /** Clean up the cache, by deleting all elements that only contain expired data. 
	 * The definition of expired is that the expiry tag is less than currentTime. */
    public static void evictOlderThan(Document doc, String currentTime) {
        evictOlderThanRecursively(doc.getDocumentElement(), currentTime);
    }

    /** Construct an XSLT query that can retrieve all the ancestors of `involved' nodes in any document */
    public static String constructXSLTQueryForRetrievingInvolvedAncestors(Document newDoc) {
        String root = newDoc.getDocumentElement().getTagName();

        StringBuffer sb = new StringBuffer();

        sb.append("<xsl:transform version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'>\n");
        sb.append("<xsl:strip-space elements='*'/>\n");
        sb.append("<xsl:template match='*'/>\n");
        sb.append(constructXSLTQueryForRetrievingInvolvedAncestors(newDoc.getDocumentElement(), ""));
        sb.append("</xsl:transform>\n");

        return sb.toString();
    }

    /** Helper for above */
    private static String constructXSLTQueryForRetrievingInvolvedAncestors(Element elm, String modeString) {
        if(elm.getAttribute("involved").equals("true")) {
            // Either id attr or the tag name is used as the unique identifier.
            String idAttrOrTagName, idCheckString, modeSetString;
            if(elm.hasAttribute("id")) {
                idAttrOrTagName = elm.getAttribute("id");
                idCheckString = "[@id=\"" + elm.getAttribute("id") + "\"]";
            } else {
                idAttrOrTagName = elm.getTagName();
                idCheckString = "";
            }
            if(modeString.equals("")) {
                modeSetString = "";
            } else {
                modeSetString = " mode = '" + modeString + "'";
            }

            String myModeString = modeString + idAttrOrTagName;

            StringBuffer sb = new StringBuffer();

            // main template
            sb.append("<xsl:template match='" + elm.getTagName() + idCheckString + "'" + modeSetString + ">");
            sb.append("<xsl:copy>\n");
            if(elm.hasAttribute("id"))
                sb.append("<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>\n");
            sb.append("<xsl:apply-templates select='node()' mode='" + myModeString + "'/>\n");
            sb.append("</xsl:copy>\n");
            sb.append("</xsl:template>\n\n");

            // dummy template for this mode that matches "*" and doesn't do anything
            sb.append("<xsl:template match='*' mode='" + myModeString + "'/>\n\n");

            // recurse; note that for a node to be 'involved' its ancestors must be too
            for(int i = 0; i < elm.getChildNodes().getLength(); i++) {
                if(elm.getChildNodes().item(i) instanceof Element) {
                    sb.append(constructXSLTQueryForRetrievingInvolvedAncestors((Element) elm.getChildNodes().item(i), 
                                myModeString));
                }
            }

            return sb.toString();
        } else {
            return "";
        }
    }

    private static final int MAX_SPECIAL_CHILDREN_POSSIBLE = 100;

    /** If multiple nodes having IDs are siblings, put them in correct order */
    public static void orderByIDs(Node n) {
        if((n instanceof Element) || (n instanceof Document)) {
            Node[] specialchildren = new Node[MAX_SPECIAL_CHILDREN_POSSIBLE]; // ought to be sufficient
            for(int i = 0; i < MAX_SPECIAL_CHILDREN_POSSIBLE; i++) {
                specialchildren[i] = null;
            }

            for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                Node child = n.getChildNodes().item(i);
                if((child instanceof Element) && ((Element) child).hasAttribute("id")) {
                    String s = ((Element) child).getAttribute("id");
                    if(Character.isDigit(s.charAt(0))) {
                        int idNumber = Integer.parseInt(((Element) child).getAttribute("id"));
                        specialchildren[idNumber] = child;
                    }
                }
            }

            // now remove all the special children and insert in the correct order
            for(int i = 0; i < MAX_SPECIAL_CHILDREN_POSSIBLE; i++) {
                if(specialchildren[i] != null)
                    n.removeChild(specialchildren[i]);
            }

            for(int i = 0; i < MAX_SPECIAL_CHILDREN_POSSIBLE; i++) {
                if(specialchildren[i] != null)
                    n.appendChild(specialchildren[i]);
            }

            // recurse
            for(int i = 0; i < n.getChildNodes().getLength(); i++) {
                orderByIDs(n.getChildNodes().item(i));
            }
        }
    }

    public static void setExpiryAttributeForAllSpecialNodes(Document doc, String expiryTime) 
    {
        NodeIterator ni = ((DocumentImpl) doc).createNodeIterator(doc, NodeFilter.SHOW_ELEMENT, (NodeFilter) null, false);
        Element iter = null;
        while((iter = (Element) ni.nextNode()) != null) { 
            if(DOMHelper.isSpecial(iter) && iter.getAttribute("status").equals("complete")) {
                iter.setAttribute("expiry", expiryTime);
            }
        }
    }

    /** Merge a new node into the current nodes. This implementation does not try to be general and 
     * uses the status fields to full extent possible. */
    public static void mergeResponseAt(Element newElm, Element oldElm)
    {
	if (newElm == null) System.out.println("newElm is null");
	if (oldElm == null) System.out.println("oldElm is null");
	System.out.println("Checking sanity: " + newElm.getTagName() + " " + oldElm.getTagName());
        /** Sanity Check */
        Utils.myassert(newElm.getTagName().equals(oldElm.getTagName()));
        Utils.myassert(newElm.hasAttribute("status") && oldElm.hasAttribute("status"));
        Utils.myassert(newElm.getAttribute("id").equals(oldElm.getAttribute("id")));
        Utils.myassert(! newElm.getAttribute("status").equals("ownsthis"));

        /** Now that we know both of these are special nodes, we can proceed. */
        String newStatus = newElm.getAttribute("status");
        String oldStatus = oldElm.getAttribute("status");

        /* If the node here is owned, then just recurse, there is nothing else to do here. */
        if(oldStatus.equals("ownsthis")) {
            mergeResponseAtRecurseOnSpecialNodes(newElm, oldElm);
            return;
        }
        /* If the node here is incomplete, that is also a simple case. */
        if(oldStatus.equals("incomplete")) {
            oldElm.getParentNode().replaceChild(newElm, oldElm);
            return;
        }
        /* If the node here is id-complete, then see if the new node has more information and if yes, 
         * copy and recurse. */
        if(oldStatus.equals("id-complete")) {
            if(newStatus.equals("complete")) {	
// this should be fixed the same as in the complete-complete case
// However, this case seems rare.  I have not used this code
// in my tests. - Shimin
                // append every attribute
                oldElm.removeAttribute("id");
                oldElm.removeAttribute("status");
                NamedNodeMap nnm = newElm.getAttributes();
                if(nnm != null) {
                    for(int i = 0; i < nnm.getLength(); i++)
                        oldElm.appendChild((Attr) nnm.item(i));
                }

                // add every child that is not special
                NodeList nl = newElm.getChildNodes();
                if(nl != null) {
                    for(int i = 0; i < nl.getLength(); i++) {
                        Node child = nl.item(i);
                        Utils.myassert(!(child instanceof Attr));
                        if(! DOMHelper.isSpecial(child)) {
                            oldElm.appendChild(child);
                        }
                    }
                }

                // recurse on the special children; which both of these guys have
                mergeResponseAtRecurseOnSpecialNodes(newElm, oldElm);
            }
            return;
        }

        /* Finally, if the node here is complete and the new node is also complete, we have to do something
         * different. Currently, we will defer to the new node, and basically do what was done above. */
        if(oldStatus.equals("complete")) {
            if(newStatus.equals("complete")) {
                // XXX there is some bug here that i am not able to figure out right now ... this shouldn't affect the experiments -- Amol 11/01/02
                // it possibly has to do with the appendchild's and the fact that we are not ``importing'' but just appending, but I don't understand
                // why this is not causing a problem at other places.

		// fixed by Shimin
                if(true) { 
                    /* since we defer to the new information, delete all the old information except special children. */
                    NamedNodeMap _nnm = oldElm.getAttributes();
                    if(_nnm != null) {
			String[] names = new String[_nnm.getLength()];
                        for(int i = 0; i < _nnm.getLength(); i++) {
			    Attr attr = (Attr) _nnm.item(i);
			    names[i] = attr.getName();
			}
                        for(int i = 0; i < names.length; i++) {
                            oldElm.removeAttribute (names[i]);
			}
                    }
                    NodeList _nl = oldElm.getChildNodes();
                    if(_nl != null) {
                        for(int i = 0; i < _nl.getLength(); i++) {
                            Node child = _nl.item(i);
                            if(! DOMHelper.isSpecial(child)) {
                                oldElm.removeChild(child);
                            }
                        }
                    }

                    /* Now, add the information from the new element; once again, don't do anything about the special children */
                    NamedNodeMap nnm = newElm.getAttributes();
                    if(nnm != null) {
                        for(int i = 0; i < nnm.getLength(); i++) {
			    Attr attr = (Attr) nnm.item(i);
			    oldElm.setAttribute (attr.getName(), attr.getValue());
                            //oldElm.appendChild((Attr) nnm.item(i));
			    // oldElm.setAttributeNode((Attr) nnm.item(i));
			}
                    }

                    // add every child that is not special
                    NodeList nl = newElm.getChildNodes();
                    if(nl != null) {
                        for(int i = 0; i < nl.getLength(); i++) {
                            Node child = nl.item(i);
                            Utils.myassert(!(child instanceof Attr));
                            if(! DOMHelper.isSpecial(child)) {
				newElm.removeChild(child);
                                oldElm.appendChild(child);
                            }
                        }
                    }
                }

                /* recurse on the special children; which both of these guys have. */
                mergeResponseAtRecurseOnSpecialNodes(newElm, oldElm);
            } else if(newStatus.equals("id-complete")) {
                mergeResponseAtRecurseOnSpecialNodes(newElm, oldElm);
            }
            return;
        }
    }

    /** Recurse on the special children for the two elements. Just find the correspondence and call
     * the above function mutually recursively. */
    private static void mergeResponseAtRecurseOnSpecialNodes(Element newElm, Element oldElm)
    {
        NodeList oldNL = oldElm.getChildNodes();
        NodeList newNL = newElm.getChildNodes();

        Vector oldSpecialNodes = new Vector();
        Vector correspondenceToNew = new Vector();
        for(int i = 0; i < oldNL.getLength(); i++) 
        {
            if(DOMHelper.isSpecial(oldNL.item(i))) 
            {
                Element oldChild = (Element) oldNL.item(i);
                for(int j = 0; j < newNL.getLength(); j++) 
                {
                    if(DOMHelper.isSpecial(newNL.item(j))) 
                    {
                        Element newChild = (Element) newNL.item(j);
                        if(newChild.getAttribute("id").equals(oldChild.getAttribute("id"))) 
                        {
                            // found the match
                            oldSpecialNodes.add(oldChild);
                            correspondenceToNew.add(newChild);
                            break;
                        }
                    }
                }
            }
        }

        for(int i = 0; i < oldSpecialNodes.size(); i++)
        {
            mergeResponseAt((Element) correspondenceToNew.get(i), (Element) oldSpecialNodes.get(i));
        }
    }

    public static void main(String[] args) {
        try {
            // testBreakDocument();

            DOMProcessing.init();
            Document doc1, doc2;

            // doc1 = XMLtoDOM("<a id='bb' dummy='c'><leaf/><final/><incomplete id='a'>original</incomplete><tag1/><tag2/></a>");
            doc1 = fileToDOM("/home/amol/cvs/IRIS/data/demodata.xml");

            // System.out.println(DOMtoXML(doc1.getDocumentElement().getChildNodes().item(9)));

            prettyPrint(doc1);
            System.exit(1);

            doc2 = fileToDOM("pspot/doc2.xml");
            prettyPrint(doc2);

            String[] strarray = findAllOwnedHostNames(doc1);
            for(int i = 0; i < strarray.length; i++)
                System.out.println(strarray[i]);
            System.exit(1);
            setAllExpiryAttributes(doc1, "amol");
            System.out.println(DOMtoXML(doc1));
            printDeNormalized(doc1);
            System.exit(1);

            prettyPrint(doc1);
            String xpath = "/parking/usRegion/state/county/city/neighborhood[@id='Oakland']/block/";
            String xslt = (String) QueryAnalysis.findXSLTQuery(xpath, true)[0];
            System.out.println(DOMtoXML(applyXSLTtoDOM(doc1, xslt)));

            System.exit(1);
            removeFinalLeafTags(doc1);
            printNode(doc1);
            System.exit(1);

            doc2 = XMLtoDOM("<tag1>TAG1</tag1>");
            doc2 = XMLtoDOM("<a id='bb' dummy='d'><incomplete id='b'>new</incomplete><tag1>TAG1</tag1></a>");

            System.out.println("--- original ----");
            System.out.println(DOMtoXML(doc1));
            System.out.println("--- new ----");
            System.out.println(DOMtoXML(doc2));

            mergeDocuments(doc1, doc2);

            System.out.println("--- merged ----");
            System.out.println(DOMtoXML(doc1));
            System.exit(1);

            // Node n = findNodeWithName(doc, "city");
            // System.out.println(DOMtoXML(n));

            // Node[] ni = DOMProcessing.applyXPATHtoDOM(doc, "//*[./lelaksjdfaf and not(./final)]");

            // System.out.println("Found " + ni.length);

            // for(int i = 0; i < ni.length; i++) {
            // System.out.println(DOMtoXML(ni[i]));
            // }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
};
