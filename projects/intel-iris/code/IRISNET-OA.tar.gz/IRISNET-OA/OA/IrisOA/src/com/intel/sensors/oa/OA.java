/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;


public class OA {

	static void Initialize(int port)
	{
		// QM = new QueryManager(port);
	}


	public static void main(String args[]) throws Exception
	{
		if(args.length != 1) {
			System.err.println("Usage: OA <config-file>");
			System.exit(1);
		}
		
		ConfigurationManager CM = ConfigurationManager.instance();		
		CM.loadConfiguration(args[0]);
		CM.printConfiguration();
		Protocol.myPortNumber = CM.getOAPort();
		
		if (CM.getDBInterface().equalsIgnoreCase("xindice")) {
			Globals.setDatabase(new XindiceInterface(CM.getDatabase() + 
													 CM.getOAPort()));
		} else if (CM.getDBInterface().equalsIgnoreCase("galax")) {
			Globals.setDatabase(new GalaxInterface(CM.getDatabase() +
                                                     CM.getOAPort()));
		} else {
			System.out.println("Unknown database interface");
			return;
		}


		if(ServantQuery.useFastXSLTTransform) {
				FastXSLTCreation.initTemplates();
			}

		// initiate SPUtils
		SPUtils.init (CM.getSpUrls());
		// initiate continuous Query
		ContinuousQuery.init ();
		
		//if (Globals.DOCUMENT != "nodocument")			
		//	ServantTakeownership.subscribeToSAs(Globals.DOCUMENT);
		
		System.out.println("OA(): Connected to Xindice database.\n");
		
		Statistics.instance().initOwnedNodes();
		Statistics.instance().initOwnedDocuments();
		Statistics.instance().printLoad();
 
		if (!CM.getLogIP().equals("0.0.0.0")) {
			System.out.println("OA(): Sending logs to " + CM.getLogIP() + ":" + CM.getLogPort());
			Log.setReplayLog(CM.getLogIP(), CM.getLogPort());
		}
		// Log.logToStdOut();

		// initiate the continuous stored queries
		ContinuousQuery.initAllOwnedContinuousStoredQuery ();
		
		// OAInformation should probably be removed completely.
		// I don't see any use of this clasee any more --- Amol.
		OAInformation oainfo = new OAInformation(); 
		oainfo.portNumber = CM.getOAPort();
		
		// Create the thread that will create a listening socket.
		// Other OAs, SAs, CGI Scripts - all talks to this socket
		
		Daemon daemon = new Daemon(oainfo);
		Thread t = new Thread(daemon);
		t.start();
		
		// start a timer that would periodically clean the pending query buffer
		// It would purge the queries that sit in the buffer for a long time
		Timer timer = new Timer (true); // make it a daemon
		timer.schedule(new TimerTask() {
				public void run() {
					ResponseActionEntry.getOALevelResponseActionEntry().purgeQueries(5*60*1000);
				}
			}, 10*60*1000, 10*60*1000); //Check every 10 mins. purge the entries 5 mins old
		

		// start the heartbeat server
		if (!CM.getHBIP().equals("0.0.0.0")) {
			//HeartBeat hb = new HeartBeat(CM.getHBIP(), CM.getHBPort(), CM.getHBPeriod());
			HeartBeat hb = new HeartBeat(CM.getHBPort());
			Thread t1 = new Thread(hb);
			t1.start();
		}

		// start the HTTP Server
		if (CM.getHTTPPort() != 0) {
			HTTPServer httpServer = new HTTPServer(CM.getHTTPPort(),
												   CM.getHTTPDocRoot());
			Thread t1 = new Thread(httpServer);
			t1.start();
		}
	}
}
