package com.intel.utils;

import java.net.*;
import java.lang.*;
import java.io.*;
import java.util.*;
import com.intel.sensors.oa.*;

//------------------
// Private classes
//------------------

//------------------------------------------------
// Classes to handle the requests from the clients
//------------------------------------------------
class RequestHandler {
    static int port = 3457; // port to listen from clients
  
    public RequestHandler (int p) {
	port = p;
    }

    /** This accepts the initial request from the client */
    public static void run_server() {
        ServerSocket serversocket = null;
        try {
            serversocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        while(true) {
            Socket s = null;
            try {
                s = serversocket.accept();
                System.out.println("Got a new connection.");
                ProcessRequest req = new ProcessRequest(s);
                req.start();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Continuing");
            }
        }
    }

}

class ProcessRequest extends Thread
{
    Socket s;
    boolean errorFlag = false;
    String response;
    
    public ProcessRequest(Socket _s) {
	s = _s;
    }

    public void run()
    {
	String requestString = null, fromIrisNet = "";

	try {

	    //PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            //BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

	    //requestString = in.readLine();
	    //in.close();
	    InputStreamReader isr = new InputStreamReader(s.getInputStream());
	    DataOutputStream dos = new DataOutputStream(s.getOutputStream());
	    //String str;
	    BufferedReader br = new BufferedReader(isr);
	    requestString = br.readLine();
	    //requestString="cquery CQUERY/europe.cq cpu_user 120000 600000";
	    // requestString = "{cquery|cancel} <query_file> <metric> <period> <duration>"
	    System.out.println("request String: " + requestString);

	    // parse the request
	    StringTokenizer tokens = new StringTokenizer(requestString, " ");
	    String command = tokens.nextToken();
	    	    
	    if (command.equals("cquery")) {
		String queryFile = tokens.nextToken();
		String metric = tokens.nextToken();
		long period = Long.parseLong(tokens.nextToken());
		long duration = Long.parseLong(tokens.nextToken());

		CQuery cq = new CQuery(queryFile, period, duration);
		cq.dispatch();
		fromIrisNet = cq.getLatestResponse(metric);
	
		// send the answer to the client
		// ...
		dos.writeBytes(fromIrisNet);
		dos.write(0);
		dos.flush();
		//Thread.currentThread().sleep(500);
		br.close();
		dos.close();
		s.close();

		//out.println(fromIrisNet);
		//Thread.currentThread().sleep(500);
		//out.close();
		//in.close();
		//s.close();
		System.out.println("=======================\n" + fromIrisNet 
				   + "==========================\n");
	    } else if (command.equals("cancel")) {
		
	    } else if (command.equals("ping")) {
		dos.writeBytes("pong");
                dos.write(0);
                dos.flush();
		br.close();
                dos.close();
                s.close();
	    } else if (command.equals("nodeinfo")) {
		String nodeId = tokens.nextToken();
		if (nodeId != null) {
		    int id = Integer.parseInt(nodeId);
		    Responses r = Responses.instance();
		    StringBuffer info = new StringBuffer(1024);
		    info.append("<table align=center cellpadding=0 cellspacing=0 bgcolor=white>" +
				"<tr><td colspan=2 bgcolor=#669900>" +
				"<p align=center><font face=Arial color=white><b>Node Name: " +
				r.sites[id].niceName +
				"(" + InetAddress.getByName("pl1."+r.sites[id].name).getHostAddress()+")" + 
				"</b></font></p></td></tr>" +
				"<tr><td><p align=center><font face=Arial>&nbsp;</font></p></td>" + 
				"<td><p align=center><font face=Arial>&nbsp;</font></p></td></tr>" +
				
				"<tr><td colspan=2> <p align=center><font face=Arial><i>Detailed Statistics" +
				"</i></td></tr>");

		    
		    for (int k = 0; k < r.metricCount; k++) {
			info.append("<tr><td bgcolor=" + (k % 2 == 0? "#CCCC99" : "F2D0F2") + ">" +
				    "<p align=center><font face=Arial>" +
				    r.metrics[k].description + "</font></p></td>" +
				    "<td bgcolor=" + (k % 2 == 0? "#CCCC99" : "F2D0F2") + ">" +
                                    "<p align=center><font face=Arial>" +
                                    r.responses[id][k] + "</font></p></td></tr>");
		    }
		    info.append("</table>\n");
		    dos.writeBytes(info.toString());
		    dos.write(0);
		    dos.flush();
		    //Thread.currentThread().sleep(500);
		    br.close();
		    dos.close();
		    s.close();

		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}

    }
}


//------------------------------------------------------------------
// Classes to talk to IrisNet and and gather responses
//------------------------------------------------------------------
class QueryHandler extends Thread{

    private static boolean DebugON = false;
    private final String logFileName = "cqaccess.log";
    private static BufferedWriter logbw = null;
    private static long qId = 0;

    public QueryHandler() {
	try {
	    logbw = new BufferedWriter(new FileWriter(logFileName, true));
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    public static synchronized void writeLog(String st) {
	try {
	    java.util.Date d = new java.util.Date();
	    String s = d.toString() + " " + st;
	    logbw.write(s, 0, s.length());
	    logbw.newLine();
	    logbw.flush();
	} catch (Exception e) {};
    }

    public static ServerSocket getListenSocket() {
        ServerSocket sock;
        try {
            sock = new ServerSocket(0);
            sock.setSoTimeout(60000); // 30 secs timeout
        } catch (Exception e) {
            e.printStackTrace();
            //System.exit(1);
            return null;
        }

        return sock;
    }

    public static String listenToAndReceiveAMessage(ServerSocket listenServersocket) {

        try {
            Socket s = listenServersocket.accept();
            DataInputStream inStream = new DataInputStream(s.getInputStream());
            System.out.println("Waiting for response..");
            //Thread.sleep(300);
            while (inStream.available() == 0) ;
            String result = null;

            if(inStream.available() != 0) {
                result = Packet.receive(inStream);
                System.out.println("Response received");
            } else {
                result = "<noresults/>";
                System.out.println("No response received... giving up.");
            }
            inStream.close();
            s.close();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return "<error> Operation Time Out </error>";
        }
        //return null;
    }

    
    // used for one shot queries
    public String getResponse(String query, String lca)
    {
	try {
	    //1.  create a socket to listen from irisnet
	    ServerSocket listenSock = getListenSocket();
	    
	    
	    // 2. send the query to IrisNet
	    Protocol.sendQuery2MessageWithPort(qId++, 4, "irisnet5ROOT", null,
					       query, lca, 6788,
					       listenSock.getLocalPort(), false);
	    
	    // 3. receive the response from irisnet
	    String response = listenToAndReceiveAMessage(listenSock);
	    System.out.println("Received response: " + response);
	    return response;
	} catch (Exception e) {
	    e.printStackTrace();
	    return "";
	}
    }

    public void run() {
	CQueryManager CQM = CQueryManager.instance();
	
	for(;;) {
	    try {
		QueryEntry qe = (QueryEntry) CQM.bqueue.dequeue();
		writeLog(qe.query);
		String response = getResponse(qe.query, qe.LCA);
		Responses.instance().addResponse(response);
		Thread.currentThread().sleep(qe.sleepTime);

	    } catch (Exception e) {
		e.printStackTrace();
	    }
	    
	}
    }

    //static QueryHandler INSTANCE = new QueryHandler();
    //public static QueryHandler instance() {
    //    return INSTANCE;
    //}
} 


//------------------------------------------------------------------
// Classes to represent all the CQueries running in this server
//------------------------------------------------------------------
class QueryEntry {
    String query;
    String LCA;
    long sleepTime;

    public QueryEntry(String _query, String _LCA, long _sleepTime)
    {
	query = _query;
	LCA = _LCA;
	sleepTime = _sleepTime;
    }
}

class CQueryManager {
    static BQueue bqueue = new BQueue(100);

    public synchronized void scheduleQuery(String query, 
				      String LCA, long period, 
				      long duration)
    {
	try {
	    if (bqueue.size() <= 0)
		bqueue.enqueue(new QueryEntry(query, LCA, period));
	    
	    //long queryCount = duration/period - bqueue.size();
	    //for (int i = 0; i < queryCount; i++){
	    //	bqueue.enqueue(new QueryEntry(query, LCA, period));
	    //}
	} catch (Exception e) {
	}
    }
    
    static CQueryManager INSTANCE = new CQueryManager();
    public static CQueryManager instance() {
	return INSTANCE;
    }
}


// this class represents an active continuous query
class CQuery {
    public String  query, rootAtNode, lca; // query string
    public String queryId;
    public long period,  duration;
    public String responseDescription;
    Object lock = new Object();
    public String  valid_r, valid_g, valid_b, invalid_r, 
	invalid_g, invalid_b, imageName;
    public double imageLat_min, imageLat_max, imageLong_min, 
	imageLong_max, radius_max, radius_min;
    public int imageWidth, imageHeight, resultType;
    public LinkedList vQuery = null; 


    public CQuery(String queryFile, long p, long d)
    {
	String line, bigLine, attr;
	StringTokenizer tokens;

	period = p;
	duration = d;
	queryId = queryFile;
	
	// read the queryFile and parse
	try {
	    FileReader fr = new FileReader(queryFile);
	    BufferedReader br = new BufferedReader(fr);
	    while ( (line = br.readLine()) != null) {
		line= line.trim();
		if (line.startsWith("#")) continue; // comment line
		if (line.length() == 0 ) continue; // empty line
		if (line.startsWith("<")) {
		    attr = line.substring(line.indexOf('<') + 1, line.indexOf('>'));
		    bigLine = "";
		    while ( ((line =br.readLine()) != null) && !line.startsWith("</")) 
			bigLine = bigLine + line;
		    System.out.println(bigLine);
		    tokens = new StringTokenizer(bigLine, ""); 
		} else {
		    tokens = new StringTokenizer(line, " :,=");
		    attr = tokens.nextToken();
		    System.out.println(line);
		}

		if (attr.equalsIgnoreCase("DESCRIPTION")) {
		    responseDescription = tokens.nextToken("");
		} else if (attr.equalsIgnoreCase("QUERY")) {
		    query = tokens.nextToken("");
		} else if (attr.equalsIgnoreCase("VQUERY")) {
		    vQuery = new LinkedList();
		    while (tokens.hasMoreTokens())
		    	vQuery.add(tokens.nextToken(" "));
		} else if (attr.equalsIgnoreCase("LCA")) {
		    lca = tokens.nextToken();
		} else if (attr.equalsIgnoreCase("ROOT_AT_NODE")) {
		    rootAtNode = tokens.nextToken();
		} else if (attr.equalsIgnoreCase("RESULT_TYPE")) {
		    resultType = Integer.parseInt(tokens.nextToken(":"));
		} else if (attr.equalsIgnoreCase("IMAGE_NAME")) {
		    imageName = tokens.nextToken(":");
		} else if (attr.equalsIgnoreCase("IMAGE_SIZE")) {
		    imageWidth = Integer.parseInt(tokens.nextToken(":, "));
		    imageHeight = Integer.parseInt(tokens.nextToken(":, "));
		} else if (attr.equalsIgnoreCase("LATITUDE_RANGE")) {
		    imageLat_min = Double.parseDouble(tokens.nextToken(": ,"));
		    imageLat_max = Double.parseDouble(tokens.nextToken(": ,"));
		} else if (attr.equalsIgnoreCase("LONGITUDE_RANGE")) {
		    imageLong_min = Double.parseDouble(tokens.nextToken(": ,"));
                    imageLong_max = Double.parseDouble(tokens.nextToken(": ,"));
		} else if (attr.equalsIgnoreCase("RADIUS_RANGE")) {
                    radius_min = Double.parseDouble(tokens.nextToken(": ,"));
                    radius_max = Double.parseDouble(tokens.nextToken(": ,"));
                } else if (attr.equalsIgnoreCase("VALID")) {
		    valid_r = tokens.nextToken(": ,");
		    valid_g = tokens.nextToken(": ,");
		    valid_b = tokens.nextToken(": ,");
		} else if (attr.equalsIgnoreCase("INVALID")) {
                    invalid_r = tokens.nextToken(": ,");
                    invalid_g = tokens.nextToken(": ,");
                    invalid_b = tokens.nextToken(": ,");
                } else {
		    System.out.println("Invalid attribute " + attr);
		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}

	printParameters();
    }

    public void dispatch()
    {
	CQueryManager CQM = CQueryManager.instance();
	CQM.scheduleQuery(query, lca, period, duration);
    }

    public void printParameters()
    {
	System.out.println("Query: " + query + "\nLCA: " + lca + 
			   "\nRootAtNode: " + 
			   rootAtNode + "\nImageName: " + imageName);
	if (vQuery!= null) {
	    for (ListIterator li = vQuery.listIterator(); li.hasNext(); ) 
		System.out.println("VQuery: " + (String)li.next());
	}
    }

    public static String getLCA(String q)
    {
	// the query is supposed to be in this format:
        //    for <var> in <xpath>
        // so we just get the LCA of the 4th token

	StringTokenizer tokens = new StringTokenizer(q, " ");
	tokens.nextToken();tokens.nextToken();tokens.nextToken();
	String xpath = tokens.nextToken();
	try {
	    return QueryAnalysis.getLongestNonbrachingPrefix(xpath) + ".dsan.net";
	} catch (Exception e) {
	    e.printStackTrace();
	    return "INVALID_LCA";
	}
    }


    public String getLatestResponse(String metric) {
		
	StringBuffer ret_val = new StringBuffer(1024);
	

	Responses r = Responses.instance();	
	Integer m = (Integer)r.metricToIndex.get(metric);
	if (m == null) {
	    System.out.println("Unknown metric: " + metric);
	    return "";
	}
	
	double x, y;
	double radius;
	String color;

	int m_index = m.intValue();
	if (responseDescription != null) {
	    int ii = responseDescription.indexOf("@XXXXX");
	    if (ii > 0)
		ret_val.append("Success\n" + responseDescription.substring(0, ii) +
			       r.metrics[m_index].description + 
			       responseDescription.substring(ii + 6) + 
			       "\n" + imageName + "\n");
	}

	System.out.println("Metric:" + metric + " index: " + m_index); 
	for (int i = 0; i< r.siteCount; i++) {
	    if (r.sites[i].name.indexOf(lca) >=0) {
		x = (r.sites[i].longitude - imageLong_min) * imageWidth / (imageLong_max - imageLong_min);
		y = imageHeight - (r.sites[i].latitude - imageLat_min) * imageHeight /(imageLat_max - imageLat_min);
		
		if (x < 0 || x > imageWidth || y < 0 || y > imageHeight) 
		    continue; // point outside the image
		if (r.responses[i][m_index] < 0) {
		    color = invalid_r + ":" + invalid_g + ":" + invalid_b;
		    radius = radius_min + 0.3 * (radius_max - radius_min);
		}
		else {
		    color = valid_r + ":" + valid_g + ":" + valid_b;
		    radius = (r.responses[i][m_index] - r.metrics[m_index].min) 
			/ (r.metrics[m_index].max - r.metrics[m_index].min);
		    //System.out.println("Radius Ratio:" + radius);
		    if (radius > 1) radius = 1;
		    radius = radius_min + radius * (radius_max - radius_min);
		}

		ret_val.append(r.sites[i].niceName + ":" + i + ":" +  
			       //"(" + r.responses[i][m_index] + " "+r.metrics[m_index].min + "," + r.metrics[m_index].max + ")" +  
			       (int)x + ":" + (int)y + ":" + (int) radius + 
			       ":" + color + "\n");
	    }
	}
	
	return ret_val.toString();
	
    }

}


class PLNode {
    public String niceName, name;
    public String xpath; // XPATH representing the site
    public double latitude, longitude;

    public PLNode(String _niceName, String _name, String _xpath, double _lat, double _lng)
    {
	niceName = _niceName;
	xpath = _xpath;
	name = _name;;
	latitude = _lat;
	longitude = _lng;
    }

    public PLNode(String _niceName, String _name, String _xpath, String lat, String lng)
    {
	this(_niceName, _name, _xpath, Double.parseDouble(lat), Double.parseDouble(lng));
    }

}

class Metric {
    public String name, description; // name of the metric
    public double max, min; // approximate max and min values
    
    public Metric(String _name, double _min, double _max, String desc) {
	name = _name;
	max = _max;
	min = _min;
	description = desc;
    }

    public Metric (String _name, String _min, String _max, String desc) {
	this(_name, Double.parseDouble(_min), Double.parseDouble(_max), desc);
    }
}

class Responses {
    static final PLNode[] sites = new PLNode[100];
    public int siteCount = 0;
    final static Metric metrics[] = new Metric[30];
    public int metricCount;

    Hashtable siteToIndex = new Hashtable();
    Hashtable metricToIndex = new Hashtable();

    public Responses() {
	int i;
	String line;
	try {

	    // load the site description file
	    FileReader fr = new FileReader("CQUERY/sites.desc");
	    BufferedReader br = new BufferedReader(fr);
	    i = 0;
	    while ( (line = br.readLine()) != null) {
		if (line.startsWith("#")) continue;
		StringTokenizer tokens = new StringTokenizer(line, ":");
		sites[i++] = new PLNode (tokens.nextToken(), tokens.nextToken(), tokens.nextToken(), tokens.nextToken(), tokens.nextToken());
	    };			     
	    fr.close();
	    siteCount = i;

	    // load the metric description file
	    fr =  new FileReader("CQUERY/metrics.desc");
            br = new BufferedReader(fr);
            i = 0;
            while ( (line = br.readLine()) != null) {
                if (line.startsWith("#")) continue;
                StringTokenizer tokens = new StringTokenizer(line, " ");
                metrics[i++] = new Metric (tokens.nextToken(), tokens.nextToken(), tokens.nextToken(), tokens.nextToken(""));
            };
	    fr.close();
	    metricCount = i;
	} catch (Exception e) {
	    e.printStackTrace();
	}

	for (i = 0; i< siteCount; i++)
	    siteToIndex.put(sites[i].xpath, new Integer(i));

	for (i = 0; i < metricCount; i++)
	    metricToIndex.put(metrics[i].name, new Integer(i));
	
	for (i = 0; i < sites.length; i++)
	    for (int j = 0; j < metrics.length; j++)
		responses[i][j] = -1;
    }

    public static double responses[][] = new double[sites.length][metrics.length];

    public void addResponse(String response) {
	StringTokenizer tokens = new StringTokenizer(response, " ");
	tokens.nextToken();tokens.nextToken();tokens.nextToken();tokens.nextToken();
	int numSites = Integer.parseInt(tokens.nextToken());
	int s_index, m_index;

	for (int i = 0; i< numSites; i++) {
	    String length = tokens.nextToken();
	    String siteName = tokens.nextToken();
	    if (siteName.indexOf("/country") < 0)
		System.out.println("?????" + siteName + ", i = " + i);
	    siteName = siteName.substring(siteName.indexOf("/country"));
	    
	    Integer index_i = (Integer)siteToIndex.get(siteName);
	    if (index_i == null) { 
		System.out.println("Unknown site: " + siteName);
		continue;
	    }
	    // get the site index
	    s_index = index_i.intValue(); 
	    
	    String tuple = tokens.nextToken();
	    StringTokenizer tokens2 = new StringTokenizer(tuple, "=|");
	    tokens2.nextToken(); // skip the group name
	    for (int j = 0; j < metrics.length && tokens2.hasMoreTokens(); j++) {
		String val = tokens2.nextToken();
		if (!val.equalsIgnoreCase("NULL"))
		    responses[s_index][j] = Double.parseDouble(val);
		else
		    responses[s_index][j] = -1;
	    }
	}
    }
    
    public String getResponse(String lca, String metric) {
	StringBuffer ret_val = new StringBuffer(1024);

	Integer m = (Integer)metricToIndex.get(metric);
	if (m == null) {
	    System.out.println("Unknown metric: " + metric);
	    return "";
	}

	int m_index = m.intValue();

	for (int i = 0; i< siteCount; i++) {
	    if (sites[i].name.indexOf(lca) >=0) {
		ret_val.append(sites[i].niceName + " " + sites[i].latitude + " " + sites[i].longitude + " " + responses[i][m_index] + "\n");
	    }
	}

	return ret_val.toString();
    }

    static Responses INSTANCE = new Responses();
    public static Responses instance() {
	return INSTANCE;
    }
}

//   R2 128.2.206.1 0 4 23 232 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='asia']/site[@id='cuhk'] $=0.575|0.9500000000000001|NULL|5.55|234.5|72078.0|66.15|1.95|930.0|NULL|NULL|90.5|0.9550000000000001|NULL|NULL|514704.0 241 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='asia']/site[@id='huji'] $=0.45|1.145|105.45500000000001|4.1|254.5|39154.0|72.80000000000001|3.8|930.0|4471.155|33.015|93.4|1.265|153.851|111.513|256336.0 217 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='asia']/site[@id='nthu'] $=1.22|2.16|1.38547328E8|3.4|1134.0|35996.0|80.6|2.1|999.0|9305.77|43.16|94.5|3.29|56.796|14.378|256648.0 254 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='asia']/site[@id='sinica'] $=1.9849999999999999|1.015|170.065|43.2|371.5|112144.0|0.8|56.300000000000004|2392.0|0.0|130.465|0.0|1.49|67.488|28.662499999999998|905012.0 195 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='asia']/site[@id='testcn'] $=NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL 204 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='australia']/site[@id='canterbury'] $=NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL 239 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='australia']/site[@id='equiash'] $=60.205|71.015|6.3161309095E7|50.15|402.0|356604.0|46.1|1.3|1263.0|11785.115|62.285|48.05|1.81|101.856|60.042|905012.0 201 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='australia']/site[@id='equisan'] $=NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL|NULL 262 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='australia']/site[@id='uts'] $=15.75|12.325000000000001|272.8|35.95|740.0|268926.0|16.0|40.25|1794.0|12772.970000000001|80.80000000000001|46.35|23.58|236.661|175.1415|905012.0 216 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='canada']/site[@id='mcgill'] $=0.02|0.22|35.23|0.4|281.0|79096.0|35.3|0.7|2394.0|1049.23|10.45|97.2|0.32|153.851|113.016|905008.0 236 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='canada']/site[@id='toronto'] $=1.03|0.7849999999999999|NULL|0.8999999999999999|155.5|48572.0|84.85|2.8|736.0|NULL|NULL|48.65|0.78|NULL|NULL|580788.0 217 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='canada']/site[@id='ubc'] $=4.74|7.09|167.86|24.2|432.0|424608.0|27.7|3.0|1794.0|12732.26|81.95|85.8|11.6|236.661|178.332|905012.0 364 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='europe']/site[@id='cam'] $=5.036666666666666|1.0999999999999999|4.473925285333333E7|21.166666666666668|856.0|470069.3333333333|50.46666666666667|19.26666666666667|1263.0|9714.563333333334|76.94666666666667|58.53333333333333|4.903333333333333|67.968|20.591333333333335|905012.0 267 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='europe']/site[@id='diku'] $=401.96000000000004|1.635|215.385|27.8|4448.5|110342.0|43.050000000000004|23.3|1794.0|18232.68|114.755|50.099999999999994|1.495|236.661|176.662|905012.0 203 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='europe']/site[@id='inria'] $=3.35|6.46|NULL|3.7|331.0|180672.0|7.3|5.4|2192.0|NULL|NULL|0.0|7.71|NULL|NULL|515908.0 236 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='europe']/site[@id='interxion'] $=19.685|158.405|5.368701454E7|7.5|368.5|535476.0|74.15|2.8|1258.0|8973.03|62.55|89.85|13.055|67.968|25.9775|905012.0 339 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region[@id='europe']/site[@id='irc'] $=0.3666666666666667|0.48|1.2907390666666667E8|9.0|301.6666666666667|309406.6666666667|61.300000000000004|3.1333333333333333|1390.0|4230.573333333334|38.22666666666667|96.3|0.8266666666666667|140.08|55.779666666666664|515264.0 ENDMESSAGE




// response R2 128.2.77.231 1 4 8 137 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='accretive']7135.454545454545 132 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='hp1']10955.741935483871 117 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='hp2']0.0 132 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='irb']11620.695652173914 132 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='irs']10932.363636363636 121 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='lbl']10200.0 135 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='nbgisp']15076.117647058823 135 irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region[@id='usa-west3']/site[@id='postel']13086.105263157895


// Continuous Query Server class
public class CQServer {

 
    static int port = 3457; // port to listen client requests


    String queryUSA = "query2 4 irisnet5ROOT usa.irislog.irisnet5ROOT " + 
	"for $i in irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='usa']/region/site " +
	"return multiCall2($i/node/sensor[@id='gangaggr'], 'avg:load_one', 'avg:load_fifteen', 'avg:pkts_out', " + 
	"'avg:cpu_user, 'avg:proc_total', 'avg:mem_free', 'avg:cpu_aidle', 'avg:cpu_system', 'avg:cpu_speed', " +
	" 'avg:bytes_in', 'avg:bytes_out', 'avg:cpu_idle', 'avg:load_five', 'avg:disk_total', 'avg:disk_free', " +
	"'avg:mem_total'" ;

    String queryRest = "query2 4 irisnet5ROOT rest.irislog.irisnet5ROOT " +
        "for $i in irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country[@id='rest']/region/site " +
        "return multiCall2($i/node/sensor[@id='gangaggr'], 'avg:load_one', 'avg:load_fifteen', 'avg:pkts_out', " +
        "'avg:cpu_user, 'avg:proc_total', 'avg:mem_free', 'avg:cpu_aidle', 'avg:cpu_system', 'avg:cpu_speed', " +
        " 'avg:bytes_in', 'avg:bytes_out', 'avg:cpu_idle', 'avg:load_five', 'avg:disk_total', 'avg:disk_free', " +
        "'avg:mem_total'" ;

    String queryGlobal = "query2 4 irisnet5ROOT irislog.irisnet5ROOT " +
        "for $i in irisnet5ROOT[@id='irisnet5ROOT']/service[@id='irislog']/country/region/site " +
        "return multiCall2($i/node/sensor[@id='gangaggr'], 'avg:load_one', 'avg:load_fifteen', 'avg:pkts_out', " +
        "'avg:cpu_user, 'avg:proc_total', 'avg:mem_free', 'avg:cpu_aidle', 'avg:cpu_system', 'avg:cpu_speed', " +
        " 'avg:bytes_in', 'avg:bytes_out', 'avg:cpu_idle', 'avg:load_five', 'avg:disk_total', 'avg:disk_free', " +
        "'avg:mem_total'" ;


 
    public static void main(String args[])
    {
	CQueryManager CQM = CQueryManager.instance();

	QueryHandler qh = new QueryHandler();
	qh.start();

	RequestHandler rh = new RequestHandler(port);	
	rh.run_server();

	ConfigurationManager CM = ConfigurationManager.instance();
	CM.loadConfiguration(args[0]);
	CM.printConfiguration();

	// start the heartbeat server
        if (!CM.getHBIP().equals("0.0.0.0")) {
	    HeartBeat hb = new HeartBeat(CM.getHBIP(), CM.getHBPort(), CM.getHBPeriod());
	    Thread t1 = new Thread(hb);
	    t1.start();
        }
	
    }
}
