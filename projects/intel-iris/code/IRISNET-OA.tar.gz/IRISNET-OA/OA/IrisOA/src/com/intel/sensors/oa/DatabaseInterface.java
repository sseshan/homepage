/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/** Specifies the functionality required by a database. */
public interface DatabaseInterface {

    /** Given an Xpath query, return the Document that corresponds to that query.
     *  Basically, it does a getDocumentWithID on the first tag in the query. */
    public Document getDocumentContainingAnswer(String xpathQuery);

    public Document getDocumentContainingAnswer(de.fzi.XPath.Expr expr);

    public Document getDocumentWithID(String id);

    public void deleteDocumentWithID(String id);

    /** Store document... overwrites an original document with the same id.*/
    public void storeDocument(Document document);

    /** Given a document, find the document in the collection with same root. */
    public Document getCorrespondingDocument(Document doc);

    /** Execute query normally and return all answers */
    public String executeQuery(String xpathQuery);

    /** Apply Xupdate */
    public void applyXUpdate(String xupdateQuery);

    /** Check if an document with this ID is already present in the document */
    public boolean existsDocumentWithName(String name);

    /** Replace an element identified by this query with this node */
    public void replaceElement(String xpathQuery, Element e);

    /** Apply XSLT to the document given by the ID */
    public Document applyXSLT(String documentID, String xsltQuery);

    /** Break document at the point specified by the xpathQuery. The xpathQuery should result in exactly 
     *  one result. The original document is updated so that this node is doesn't own that part any more.
     *
     *  Returns the breakAway document as a DOM which can be sent directly to the other node. */
    public Document breakDocument(String xpathQuery);
	public String[] listDocuments();
};
