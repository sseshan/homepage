/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
package com.intel.sensors.oa;

import java.util.Vector;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.FileReader;

import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xpath.XPathAPI;
import org.apache.xml.utils.TreeWalker;
import org.apache.xml.utils.DOMBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Attr;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.traversal.*;

import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;

// Imported JAVA API for XML Parsing 1.0 classes
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException; 

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

// DocumentImpl
import org.apache.xindice.xml.dom.DocumentImpl;

// From Xalan 
import org.apache.xalan.templates.*;
import org.apache.xalan.transformer.*;
import org.apache.xpath.XPath;
import org.apache.xml.utils.QName;

// Parser
import de.fzi.XPath.*;

class FirstTemplateInformation 
{
    public ElemTemplate et;

    FirstTemplateInformation(ElemTemplate _et) {
        et = _et;
    }
};

class LastTemplateInformation 
{
    public ElemTemplate et;
    
    public ElemApplyTemplates eat_set_mode;

    LastTemplateInformation(ElemTemplate _et) {
        et = _et;

        eat_set_mode = (ElemApplyTemplates) et.getChildNodes().item(0).getChildNodes().item(1).
                                                                getChildNodes().item(0).getChildNodes().item(1);
    }

    public void setMode(int i) {
        QName templatename = new QName("usetemplate" + QueryAnalysis.literalNumbers[i]);
        et.setMode(templatename);
        eat_set_mode.setMode(templatename);
    }
};

class FetchallTemplateInformation 
{
    public ElemTemplate et;
    
    FetchallTemplateInformation(ElemTemplate _et) {
        et = _et;
    }

    public void setPredicatesAndTemplate(int templateNumber, String nodeName) {
        try {
            QName templatename = new QName("usetemplate" + QueryAnalysis.literalNumbers[templateNumber]);
            et.setMode(templatename);
            et.setMatch(new XPath(nodeName + "[@status]", null, null, XPath.MATCH));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};


class CommonTemplateInformation 
{
    CommonTemplateInformation(ElemTemplate _et) {
        try {
            et = _et;

            // traverse the template to find points of interest...
            ElemWhen topLevelIncomplete = null, topLevelIDComplete = null, topLevelComplete = null, topLevelOwned = null;
            NodeList nl = ((ElemChoose) et.getChildNodes().item(0)).getChildNodes();
            Utils.myassert(nl.getLength() == 4);
            for(int i = 0; i < nl.getLength(); i++) 
            {
                String test = ((ElemWhen) nl.item(i)).getTest().getPatternString();
                if(test.indexOf("incomplete") != -1) {
                    topLevelIncomplete = (ElemWhen) nl.item(i);
                } else if(test.indexOf("id-complete") != -1) {
                    topLevelIDComplete = (ElemWhen) nl.item(i);
                } else if(test.indexOf("complete") != -1) {
                    topLevelComplete = (ElemWhen) nl.item(i);
                } else {
                    topLevelOwned = (ElemWhen) nl.item(i);
                }
            }

            // System.out.println("\n\nComes here" + topLevelIncomplete.getTest().getPatternString());
            // System.out.println("\n\nComes here" + topLevelIDComplete.getTest().getPatternString());
            // System.out.println("\n\nComes here" + topLevelComplete.getTest().getPatternString());
            // System.out.println("\n\nComes here" + topLevelOwned.getTest().getPatternString());

            ew_incomplete_predicates_id = (ElemWhen) topLevelIncomplete.getChildNodes().item(0).getChildNodes().item(0);

            ew_idcomplete_predicates_id = (ElemWhen) topLevelIDComplete.getChildNodes().item(0).getChildNodes().item(0);
            ew_idcomplete_applyall_or_not = (ElemWhen) ew_idcomplete_predicates_id.getChildNodes().item(0).getChildNodes().item(0);

            ew_complete_predicates_id_static = (ElemWhen) topLevelComplete.getChildNodes().item(0).getChildNodes().item(0);
            ew_complete_predicates_consistency = (ElemWhen) ew_complete_predicates_id_static.getChildNodes().item(0).getChildNodes().item(0);

            ew_owned_predicates_id_static = (ElemWhen) topLevelOwned.getChildNodes().item(0).getChildNodes().item(0);

            // XPath xpath = new XPath("self::node[@status='id-complete']", null, null, XPath.SELECT);
            // Utils.printClassName(topLevelIncomplete.getTest().getExpression());
            // Utils.printClassName(xpath);
            // topLevelIncomplete.setTest(xpath);

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    // instance of the template itself
    public ElemTemplate et;

    // incomplete
    public ElemWhen ew_incomplete_predicates_id;

    // id-complete
    public ElemWhen ew_idcomplete_predicates_id;
    public ElemWhen ew_idcomplete_applyall_or_not;

    // complete
    public ElemWhen ew_complete_predicates_id_static;
    public ElemWhen ew_complete_predicates_consistency;
    
    // owned
    public ElemWhen ew_owned_predicates_id_static;

    /** Print the current information about the "tests" */
    public void print() {
        System.out.println(et.getMatch().getPatternString());

        System.out.println(ew_incomplete_predicates_id.getTest().getPatternString());

        System.out.println(ew_idcomplete_predicates_id.getTest().getPatternString());
        System.out.println(ew_idcomplete_applyall_or_not.getTest().getPatternString());

        System.out.println(ew_complete_predicates_id_static.getTest().getPatternString());
        System.out.println(ew_complete_predicates_consistency.getTest().getPatternString());

        System.out.println(ew_owned_predicates_id_static.getTest().getPatternString());
    }

    /** Use these new predicates instead of the old ones. */
    public void setPredicates(String nodeName, String predicates_id, String predicates_consistency, String predicates_static, boolean static_consistency_predicates_exist) {
        try {
            XPath xpath_id = new XPath("self::node()" + predicates_id, null, null, XPath.SELECT);
            XPath xpath_consistency = new XPath("self::node()" + predicates_consistency, null, null, XPath.SELECT);
            XPath xpath_static = new XPath("self::node()" + predicates_static, null, null, XPath.SELECT);
            XPath xpath_id_static = new XPath("self::node()" + predicates_id + predicates_static, null, null, XPath.SELECT);
            XPath xpath_true = new XPath("true", null, null, XPath.SELECT);
            XPath xpath_false = new XPath("false", null, null, XPath.SELECT);

            // As opposed to others, this one has to be a MATCH
            XPath xpath_nodeName = new XPath(nodeName + "[@status]", null, null, XPath.MATCH); 

            ew_incomplete_predicates_id.setTest(xpath_id);

            ew_idcomplete_predicates_id.setTest(xpath_id);
            ew_idcomplete_applyall_or_not.setTest(static_consistency_predicates_exist ? xpath_false : xpath_true);

            ew_complete_predicates_id_static.setTest(xpath_id_static);
            ew_complete_predicates_consistency.setTest(xpath_consistency);

            ew_owned_predicates_id_static.setTest(xpath_id_static);

            et.setMatch(xpath_nodeName);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};

public class FastXSLTCreation {

    public static Transformer serializer = null;
    public static DocumentBuilderFactory dfactory = null;
    public static TransformerFactory tFactory = null;

    public static void init() 
    {
        try 
        {
            tFactory = TransformerFactory.newInstance();
            serializer = tFactory.newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            dfactory = DocumentBuilderFactory.newInstance();
            dfactory.setAttribute("http://apache.org/xml/features/dom/defer-node-expansion", new Boolean(false));
            dfactory.setNamespaceAware(false);
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static ElemTemplate getTemplateCorrespondingToStepForFetchAll(int currentNumber, Step st, String newquery) throws Exception 
    {
        fati.setPredicatesAndTemplate(currentNumber, ((NameTest) st.getNodeTest()).toString());
        return fati.et;
    }

    public static ElemTemplate getTemplateCorrespondingToStep(int current_template_number, 
            Step st, Step nextStep, boolean do_not_apply_consistency) throws Exception 
    {
        boolean isFinal = (nextStep == null);

        String childNodeName = null;

        int thisAxis = st.getAxis();

        if(!isFinal) 
        {
            NodeTest nt = nextStep.getNodeTest();
            if(nt instanceof NameTest) 
                childNodeName = ((NameTest) nt).toString();
            else if(nt instanceof NodeType)
                childNodeName = "*";
            else 
            {
                // Utils.printClassName(nextStep.getNodeTest());
                // System.out.println(nextStep);
                System.exit(1);
            }
        }

        if(thisAxis == Axis.DESCENDANT_OR_SELF)
        {
            System.out.println("The fast XSLT creation code can not handle \"//\" yet.");
            java.lang.Thread.dumpStack();
            System.exit(1);
            // return getTemplateCorrespondingToStepForSlashSlash(current_template_number).toString();
        }

        StringBuffer predicates_consistency_checking = new StringBuffer();
        StringBuffer predicates_static = new StringBuffer();
        StringBuffer predicates_id = new StringBuffer();
        int num_static_predicates = 0, num_id_predicates = 0, num_consistency_checking_predicates = 0;
        for(int i  = 0; i < st.getPredicatesCount(); i++) 
        {
            if(!do_not_apply_consistency && QueryAnalysis.isConsistencyPredicate(st.getPredicate(i))) 
            {
                predicates_consistency_checking.append("[" + st.getPredicate(i) + "]");
                num_consistency_checking_predicates++;
            }
            else if(QueryAnalysis.isIdPredicate(st.getPredicate(i)) || QueryAnalysis.isORedIdPredicate(st.getPredicate(i))) 
            {
                predicates_id.append("[" + st.getPredicate(i).toString() + "]");
                num_id_predicates++;
            }
            else 
            {
                predicates_static.append("[" + st.getPredicate(i).toString() + "]");
                num_static_predicates++;
            }
        }

        ctis[current_template_number].setPredicates(((NameTest) st.getNodeTest()).toString(), predicates_id.toString(), 
                predicates_consistency_checking.toString(), predicates_static.toString(), 
                (num_static_predicates != 0) || (num_consistency_checking_predicates != 0));

        return ctis[current_template_number].et;
    }

    public static Transformer getFastXSLTTransformer(String query)
    {
        try {
            Expr expr = QueryAnalysis.parse(query);
            return getFastXSLTTransformer(expr);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    public static Transformer getFastXSLTTransformer(Expr expr)
    {
        try {
            // initTemplates();

            if(false) {
                return ti;
            }

            TemplateList tl = new TemplateList();

            /** First template. */
            tl.setTemplate(fti.et);

            /** Now use the query to set other templates */
            LocationPath lp = (LocationPath) expr;
            // System.out.println("Parsed Expression ==> " + lp);

            /* First find out if we need to use fetch-all. If yes, then only create an XSLT query till that point. */
            int fetchallstepnumber = QueryAnalysis.findFetchAllStepNumber(lp);
            int iteratetill = (fetchallstepnumber == -1) ? lp.getStepsCount() : fetchallstepnumber + 1;


            /* this is just identity transform right now... add the templates corresponding to the query. */
            int current_template_number = 0;
            LocationPath newquery = null;
            for(int i = 0; i < iteratetill; i++) 
            {
                if(i < iteratetill - 1)
                {
                    tl.setTemplate(getTemplateCorrespondingToStep(current_template_number, lp.getStep(i), lp.getStep(i+1), false));
                } 
                else 
                {
                    if(fetchallstepnumber == -1)
                    {
                        tl.setTemplate(getTemplateCorrespondingToStep(current_template_number, lp.getStep(i), null, false));
                    }
                    else
                    {
                        newquery = new LocationPath();
                        for(int j = iteratetill - 1; j < lp.getStepsCount(); j++) 
                        {
                            newquery.addStep(lp.getStep(j));
                        }
                        tl.setTemplate(getTemplateCorrespondingToStepForFetchAll(current_template_number, lp.getStep(i), newquery.toString()));
                    }
                }

                // only upgrade the template number if this step doesn't not involve "//"
                if(lp.getStep(i).getAxis() != Axis.DESCENDANT_OR_SELF)
                {
                    current_template_number++;
                }
            }


            /** Last template */
            lti.setMode(current_template_number);
            tl.setTemplate(lti.et);

            /** Get the stylesheet root of the compiled XSLT */
            StylesheetRoot sr = ti.getStylesheet(); 

            /** Compose teh template list */
            tl.compose(sr); // XALAN 2.4.1 only
            // tl.compose();    // XALAN 2.0.1 only

            /** Recomppose the stylesheetroot -- I don't know exactly why this is needed */
            sr.recompose();  // XALAN 2.0.1 only

            /** Set the template list from above */
            sr.setTemplateListComposed(tl);

            /** Recompose templates -- if this is not done, weird errors abound. */
            sr.recomposeTemplates(true);

            return ti;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
            return null;
        }
    }

    static FirstTemplateInformation fti = null;
    static LastTemplateInformation lti = null;
    static CommonTemplateInformation[] ctis = null;
    static FetchallTemplateInformation fati = null;
    static TransformerImpl ti = null;

    public static void initTemplates() throws Exception 
    {
        if(serializer == null) 
            init();

        try 
        {
            String query = "/test0/test1/test2/test3/test4/test5/test6/test7/test8/test9/fetchall[./fetchall]";

            String xsltQuery = (String) QueryAnalysis.findXSLTQuery(query, true)[0];

            Transformer transformer = tFactory.newTransformer(new StreamSource(new StringReader(xsltQuery)));

            ti = (TransformerImpl) transformer;

            StylesheetRoot sr = ti.getStylesheet();

            TemplateList tl = sr.getTemplateListComposed();

            TemplateList.TemplateWalker tw = tl.getWalker();

            ElemTemplate et;

            ElemTemplate first = null, common_templates[] = new ElemTemplate[10], last = null, fetchall = null;

            while((et = tw.next()) != null) 
            {
                // System.out.println(et.getMode());
                if((et.getMode() != null) && et.getMode().toString().equals("usetemplateeleven")) {
                    last = et;
                } else if((et.getMode() != null) && et.getMode().toString().equals("usetemplateten")) {
                    fetchall = et;
                } else if((et.getMode() == null) && (et.getChildNodes().item(0) instanceof ElemCopy)) {
                    first = et;
                } else {
                    // use the pattern string to decide
                    for(int i = 0; i < 10; i++) {
                        if(et.getMatch().getPatternString().indexOf("test" + i) != -1) {
                            common_templates[i] = et;
                        }
                    }
                }

                NodeList nl = et.getChildNodes();

                for(int i = 0; i < nl.getLength(); i++)
                {
                    // Utils.printClassName(nl.item(i));
                }

                // Utils.printClassName(et);
                // System.out.println("*****************************************\n");
            }

            /** The first template remains unchanged in all the queries.
              * Only the mode name changes for the last template.
              * Common template, on the other hand, has quite a few changes for every query, not
              * to mention it repeats as many times as there are steps in the query. */
            fti = new FirstTemplateInformation(first);
            lti = new LastTemplateInformation(last);
            ctis = new CommonTemplateInformation[10];
            fati = new FetchallTemplateInformation(fetchall);

            for(int i = 0; i < 10; i++) {
                ctis[i] = new CommonTemplateInformation(common_templates[i]);
                // ctis[i].print();
                // System.out.println("**************");
            }

            // System.exit(1);

            // TemplateList newTL = new TemplateList();
            // first.setMode(new org.apache.xml.utils.QName("help"));
            // common.setMode(new org.apache.xml.utils.QName("help"));
            // last.setMode(new org.apache.xml.utils.QName("help"));

            // newTL.setTemplate(first);
            // newTL.setTemplate(common);
            // newTL.setTemplate(last);

            // StylesheetRoot newSR = new StylesheetRoot(null);
            // sr.setTemplateListComposed(newTL);

            // Document doc = DOMProcessing.fileToDOM("testing.xml");

            // Document ret_val = new org.apache.xindice.xml.dom.DocumentImpl();

            // transformer.transform(new DOMSource(doc), new DOMResult(ret_val));

            // DOMProcessing.prettyPrint(ret_val);

            // System.exit(1);

        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) 
    {
        try {
            initTemplates();

            String q = "/parkingone"; 
            q = "/test0/test1/test2/test3/test4/test5/test6/test7/test8/test9/fetchall[./test11]";
            q = "/parkingone/usRegion/state/county/city/neighborhood/block/parkingSpace/dummy/dummy";

            if(serializer == null) 
                init();

            Transformer transformer = tFactory.newTransformer(new StreamSource(new StringReader((String)
                            QueryAnalysis.findXSLTQuery(q, true)[0])));

            Document dd = DOMProcessing.fileToDOM("testing.xml");

            ctis[0].et.setMatch(new XPath("parkingone[@status]", null, null, XPath.MATCH));
            System.out.println(ctis[0].et.getMatch().getPatternString());
            ElemWhen ew = (ElemWhen) ctis[0].et.getChildNodes().item(0).getChildNodes().item(3);
            System.out.println(ew.getTest().getPatternString());
            ew.setTest(new XPath("self::node()[@status='ownsthis']", null, null, XPath.SELECT));
            System.out.println(ew.getTest().getPatternString());

            TemplateList.TemplateWalker tw = ti.getStylesheet().getTemplateListComposed().getWalker();

            ElemTemplate et;

            TemplateList newTL = new TemplateList();

            System.out.println("******************************\n");
            while((et = tw.next()) != null) 
            {
                newTL.setTemplate(et);
                System.out.println(et.getMatch().getPatternString());
            }
            newTL.setTemplate(fti.et);
            newTL.setTemplate(lti.et);
            for(int i = 0; i < 10; i++)
                newTL.setTemplate(ctis[i].et);

            StylesheetRoot newSR = ti.getStylesheet(); // new StylesheetRoot(null);
            newTL.compose(newSR); // XALAN 2.4.1 only
            // newTL.compose(); // XALAN 2.0.1 only
            newSR.recompose();
            newSR.setTemplateListComposed(newTL);
            newSR.recomposeTemplates(true);

            TransformerImpl newTI = ti; // new TransformerImpl(newSR);

            // TransformerImpl newTI = (TransformerImpl) newSR.newTransformer();

            tw = newTI.getStylesheet().getTemplateListComposed().getWalker();

            System.out.println("*****************\n");
            while((et = tw.next()) != null) 
            {
                System.out.println(et.getMatch().getPatternString());
            }

            Node answer = DOMProcessing.applyXSLTtoDOM(dd, newTI);

            System.out.println(DOMProcessing.DOMtoXML(answer));

            System.exit(1);

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
