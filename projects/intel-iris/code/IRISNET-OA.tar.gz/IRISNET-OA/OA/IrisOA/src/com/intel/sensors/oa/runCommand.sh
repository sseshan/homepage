#! /bin/sh

make

IRIS=/home/amol/cvs/IRIS
echo IRIS $IRIS
CLASSPATH=/usr/java/jdk1.3.1_03/lib:$IRIS/src/:$IRIS/lib-java/xmldb.jar:$IRIS/lib-java/xindice.jar:$IRIS/lib-java/openorb-1.2.0.jar:$IRIS/lib-java/xerces-1.4.3.jar:$IRIS/lib-java/xalan-2.0.1.jar:$IRIS/lib-java/sixpath.jar:$IRIS/lib-java/libreadline-java.jar:$IRIS/lib-java/patbinfree153.jar:$IRIS/lib-java/commons-httpclient.jar:$IRIS/lib-java/xercesImpl.jar:$IRIS/lib-java/xml-apis.jar

java -classpath ../../../..:$CLASSPATH com.intel.sensors.oa.CommandLine DUMMY $1

