/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.util.*;

// sixpath
import de.fzi.XPath.*;

// dom
import org.w3c.dom.*;

/** ContinuousQuery class records information about a continuous query.
 *  It is also a TimerTask subclass and is scheduled to run periodically.
 *  
 *  @author Shimin
 */
public class ContinuousQuery {

  // ---
  // static members
  // ---
  static final boolean ContinuousQuery_debugging = false;

  static Object mutex;

  static Hashtable    continuous_query_table;
  static Timer        continuous_query_timer;

  static Hashtable    update_monitoring_table;

  static Expr         force_expire;

  static void init ()
  {
	mutex = new Object ();

	continuous_query_table = new Hashtable ();
	continuous_query_timer = new Timer (true);	// running as Daemon

	update_monitoring_table = new Hashtable ();

	try {
	  force_expire = XPathQueryParser.parsequery ("@expiry='0'");
	} catch (Exception e) {
	  System.out.println ("can't parse a simple query?");
	  System.exit (1);
	}
  }

  // ContinuousQuery hash table
  static String keyCQuery (String root_at, String query, int mode)
  {
	return root_at + '~' + query +'~' + mode;
  }

  static void putCQuery (String root_at, String query, int mode, 
			 ContinuousQuery c_query)
  {
	
	continuous_query_table.put (keyCQuery(root_at, query, mode), c_query);
  }

  static ContinuousQuery getCQuery (String root_at, String query, int mode)
  {
	return (ContinuousQuery) 
		continuous_query_table.get (keyCQuery(root_at, query, mode));
  }

  static void removeCQuery (String root_at, String query, int mode)
  {
	continuous_query_table.remove (keyCQuery(root_at, query, mode));
  }

  // update_monitoring_table
  static void registerNode (String node_signature, NodeInterested ni)
  {
if (ContinuousQuery_debugging){
  System.out.println ("registerNode: " + node_signature);
}

	NodeInterestedList list = (NodeInterestedList) 
				  update_monitoring_table.get (node_signature);
	if (list == null) {
	  list = new NodeInterestedList ();
	  update_monitoring_table.put (node_signature, list);
	}

	list.add (ni);
  }

  static void unregisterNode (String node_signature, Element n)
  {
if (ContinuousQuery_debugging){
  System.out.println ("unregisterNode: " + node_signature);
}
	NodeInterestedList list = (NodeInterestedList) 
				  update_monitoring_table.get (node_signature);
	if (list != null) {
	  list.remove (n);
	  if (list.getList().size() == 0)
	    update_monitoring_table.remove (node_signature);
	}
  }

  static NodeInterestedList getNodesInterested (String node_signature)
  {
	return (NodeInterestedList)
		update_monitoring_table.get (node_signature);
  }

  static void monitorUpdates (String[] queries, String[] new_values)
  {
     try {

	// use this ArrayList to combine multiple updates to the same query
	ArrayList local_op_list = new ArrayList ();

	int num_queries = queries.length;
	for (int ii=0; ii<num_queries; ii++) {
	   Expr expr = XPathQueryParser.parsequery(queries[ii]);
	   if (expr instanceof LocationPath) {
	     String owner_agent = QueryUtils.getOwnerAgentForUpdateSelection (
							(LocationPath) expr);
	     if (owner_agent != null) {
		// good!  /st1[@id='id1']/st2[@id='id2']/.../@attr
		NodeInterestedList nlist = getNodesInterested (owner_agent);
		if (nlist != null) {
		  LocationPath lp = (LocationPath) expr;
		  String attr = 
		     lp.getStep(lp.getStepsCount()-1).getNodeTest().toString();
		  ArrayList list = nlist.getList ();
		  for (int jj=list.size()-1; jj>=0; jj--) {
		     NodeInterested ni = (NodeInterested) list.get(jj);

		     ni.local_op.updateNode (ni.node_interested,
					     attr,
					     new_values[ii]);		     

		     local_op_list.add (ni.local_op);

		  } // end of inner loop
		} // nlist != null
	     } // good format
	   } // expr instanceof LocationPath
	} // end of outer loop

	// send resultReady up the operator tree
	for (int ii=0; ii<local_op_list.size(); ii++) {
	   LocalResultOperator local_op = (LocalResultOperator)
					   local_op_list.get (ii);
	   if (local_op.update_pending)
	     local_op.resultReady (0);
	}

     } catch (Exception e) {
        Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  // parsing params in the continuous query call
  static void parseParams (String[] params, QueryInfo qinfo)
  {
	qinfo.mode   = 0;	// top-down query
	qinfo.period = 1000;	// 1 second
	qinfo.lease  = 600000;	// 10 minutes

	for (int ii=0; ii<params.length; ii++) {
	   String arg = params[ii];
	   int length = arg.length();
	   if (((arg.charAt(0) == '\'') && (arg.charAt(length-1) == '\''))
	     ||((arg.charAt(0) == '\"') && (arg.charAt(length-1) == '\"'))) {
	     arg = arg.substring (1, length-1);
	     length -= 2;
	   }
	   int index = arg.indexOf ('=');
	   if (index != -1) {
	     String key = arg.substring (0, index);
	     String value = arg.substring (index+1, length);
          try {
	     if (key.compareToIgnoreCase("mode") == 0) {
		try {
		  qinfo.mode = Integer.parseInt (value);
		}
		catch (NumberFormatException e) {
		  if (value.compareToIgnoreCase ("pulling") == 0)
		    qinfo.mode = 0;
		  else if (value.compareToIgnoreCase ("triggered") == 0)
		    qinfo.mode = 1;
		  else {
		    Utils.error ("Continous Query param error:" + arg);
		  }
		}
	     } // end of processing for parameter "mode"
	     else if (key.compareToIgnoreCase("period") == 0) {
		qinfo.period = Long.parseLong (value);
	     } 
	     else if (key.compareToIgnoreCase("lease") == 0) {
		qinfo.lease = Long.parseLong (value);
	     }
	     else {
		Utils.error ("Continous Query param error:" + arg);
	     }
          } catch (Exception e) {
	     Utils.error ("Continous Query param error:" + arg);
          }
	   }
	   else {
		Utils.error ("Continous Query param error:" + arg);
	   }
	}

	if (qinfo.lease < qinfo.period)
	  qinfo.lease = 0;

	if (qinfo.period < 50)	// if required to run too often,
	  qinfo.period = 0;	// make it fully event-based
  }

  // time
  static long currentTime ()
  {
	return System.currentTimeMillis();
  }

  // Create and initiate an instance of continuous query
  static ContinuousQuery create (RootOperator rop, Expr expr)
  {
	ContinuousQuery c_query = new ContinuousQuery ();

	// build a client info
	ClientInfo cinfo = new ClientInfo ();
	cinfo.client_ip       = rop.client_ip;
	cinfo.client_port     = rop.client_port;
	cinfo.client_query_id = rop.query_id;
	cinfo.client_lease_expire = currentTime() + rop.query_info.lease;
	cinfo.period          = rop.query_info.period;
	cinfo.lease           = rop.query_info.lease;

	// set up the c_query fields
	c_query.clients = new ArrayList (1);
	c_query.clients.add (cinfo);

	c_query.timer_period = rop.query_info.period;
	long child_period = c_query.timer_period;	// pipelining effect

	c_query.query_info = rop.query_info;
	c_query.query_info.period = child_period;

	if (c_query.query_info.lease < 4 * c_query.timer_period + 4000)
	  c_query.query_info.lease = 4*c_query.timer_period + 4000;
	c_query.quarter_lease_time = c_query.query_info.lease / 4;

	c_query.root_op    = rop;
	c_query.xpath      = expr;

	// dealing with caching
	c_query.xpath_no_caching = QueryUtils.addExpirePredicate (expr);

	c_query.new_result_ready = false;
	c_query.immediate_send   = true;	//imm send the first result

	c_query.next_client_lease_expire = cinfo.client_lease_expire;

	// sanity check
	if ((c_query.query_info.mode == 0) && (c_query.timer_period == 0)) {
	  Utils.error ("Continuous query error: period is 0 in mode 0!");
	}

	// put c_query into the continuous_query_table
	putCQuery (c_query.query_info.queryForRoot(), 
		   c_query.xpath.toString(), 
		   c_query.query_info.mode, 
		   c_query);

	// add the task into Timer task queue
	c_query.startTimer ();

if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": create continuous query");
  c_query.print ();
}

	return c_query;
  }

  // get the query for a defined stored query
  // query_for_element:		the path from root to the element
  // n:				the element node
  // st_name:			the stored query name
  // Either query_for_element or n is not null.
  // return the query for the stored query, or null if it does not exist.
  static String getStoredQuery (String query_for_element, Element n, 
				String st_name)
  {
	// get the element where the stored query is defined
	if (n == null) {
	  try {
            Node node =  QueryUtils.getContextNode (query_for_element);
	    n = (node instanceof Document) ?
		((Document) node).getDocumentElement() :
		(Element) node;
	  } catch (Exception e) {return null;}
	}

	// get the stored query elements
	NodeList nl = n.getElementsByTagName (QueryOperator.stored_query);

	// select by the st_name and return the query content
	for (int ii=nl.getLength()-1; ii>=0; ii--) {
	   Element st_node = (Element) nl.item (ii);
	   if (st_name.equals(st_node.getAttribute ("name"))) {
	     String query = st_node.getAttribute ("query");
	     if ((query != null) && (query.length() != 0))
		return query;
	     else
		return null;
	   }
	}

	return null;
  }

  // create an entry for the continuous stored query in the continuous
  // query table.  Some of the codes are taken from processQuery2Request()
  // in Servant.java.
  // query_for_element:		the path from root to the element
  // n:				the element node (may be null)
  // st_name:			the stored query name
  static void addContinuousStoredQuery (String query_for_element, 
					Element n,
					String st_name)
  {
if (ContinuousQuery_debugging) {
  System.out.println ("addContinuousStoredQuery: "+ query_for_element 
  + ", " + st_name);
}
	// get stored query content
	String query = getStoredQuery (query_for_element, n, st_name);
	if (query == null)
	  Utils.error ("Stored query " + st_name + 
		       " is not defined for the element: "
		       + query_for_element);

	// create root operator, which will automatically register the query
	RootOperator  r = new RootOperator ();
        boolean answered_locally = r.setup (
                               -1,
                               QueryOperator.RESULT_STRING,
                               query_for_element,
                               query,
                               Protocol.getLocalIP (),
                               Protocol.getLocalPort ());

	if (r.continuous_query.st_name != null) {
	  removeContinuousStoredQuery (query_for_element, n, 
				       r.continuous_query.st_name);
	}
	r.continuous_query.st_name = st_name;
	r.continuous_query.csq_sponsor = new CStoredQueryLeaseSponsor(
			continuous_query_timer,	
			query_for_element, query, r.query_info.lease);

        if (answered_locally) {
          // send query result to client
	  r.continuous_query.sendResults ();
        } else {
          r.expandRemotely ();
        }

	// start lease sponsor
  }

  // remove the entry for the continuous stored query from the continuous
  // query table.  We simply set lease=0 and use the existing mechanism
  // to do it.
  // query_for_element:		the path from root to the element
  // n:				the element node (may be null)
  // st_name:			the stored query name
  static void removeContinuousStoredQuery (String query_for_element,
					   Element n,
                                           String st_name)
  {
if (ContinuousQuery_debugging) {
  System.out.println ("removeContinuousStoredQuery: "+ query_for_element 
  + ", " + st_name);
}
        // get stored query content
        String query = getStoredQuery (query_for_element, n, st_name);
	if ((query == null) || !query.startsWith ("continuous"))
	  return;

	// add lease=0 to the end of the query
	int pos = query.lastIndexOf (')');
	if (pos == -1) return;
	query = query.substring (0, pos) + ",'lease=0')";

        // create root operator, which will automatically 
	// remove the continuous query
        RootOperator  r = new RootOperator ();
        r.setup (-1,
                 QueryOperator.RESULT_STRING,
                 query_for_element,
                 query,
                 Protocol.getLocalIP (),
                 Protocol.getLocalPort ());

	if ((r.continuous_query != null) && (r.continuous_query.st_name!=null)){
	  r.continuous_query.csq_sponsor.cancel ();
	  r.continuous_query.st_name = null;
	}
  }

  // This is a short-cut for COMMAND_LOAD_DATA_FROM_SA
  // some of the codes are copied from Servant.java
  static void updateStoredQueryValue (String query_for_element,
				      String st_name,
				      String value)
  {
	// update the xindice database
	if (query_for_element.charAt (0) != '/')
	  query_for_element = '/' + query_for_element;

	String query = query_for_element + "/@" + st_name;
	String xupdate_query = 
      "<xu:modifications version='1.0' xmlns:xu='http://www.xmldb.org/xupdate'>"
    + "<xu:update select=\"" + query + "\">"  + value
    + "</xu:update></xu:modifications>";
	Globals.getDatabase().applyXUpdate(xupdate_query);

	// update any continuous queries interested in this element
	String[] queries = new String[1];  queries[0] = query;
	String[] values = new String[1];   values[0] = value;
	monitorUpdates (queries, values);
  }

  // This should be called at the start of the OA
  // initiate all continuous stored queries in the db
  static void initAllOwnedContinuousStoredQuery ()
  {
        DatabaseInterface db = Globals.getDatabase();
        String docs[] = db.listDocuments();
                
        for (int i = 0; i< docs.length; i++) {
	   initOwnedContinuousStoredQuery (docs[i]);
        }
  }

  static void initOwnedContinuousStoredQuery (String db_name)
  {
           System.out.println("Document: " + db_name);
	   DatabaseInterface db = Globals.getDatabase();
           Document doc = db.getDocumentWithID(db_name);

	   if (doc == null) return;

           try {
             NodeList nl = org.apache.xpath.XPathAPI.selectNodeList (doc,
                           "//*[@status='ownsthis'][./stored_query]");
             for (int ii = 0; ii < nl.getLength(); ii++) {
                Element ele = (Element) nl.item (ii);
                NodeList st_nl = ele.getElementsByTagName ("stored_query");
                String query_for_element =
                        QueryUtils.findQueryForThisElement (ele);
                for (int jj=st_nl.getLength()-1; jj>=0; jj--) {
                   Element st_ele = (Element) st_nl.item (jj);
                   String query = st_ele.getAttribute ("query");
                   if ((query!=null) && (query.startsWith ("continuous"))) {
		     try {
                     addContinuousStoredQuery (query_for_element, ele,
                                               st_ele.getAttribute ("name"));
		     }
		     catch (Throwable e) {
		       System.out.println ("Error starting stored query:"
			+ "element=" + query_for_element
			+ ", stored_query=" + st_ele.getAttribute ("name"));
		     }
		   }
                }
             }
           } catch (Exception e) {
             System.out.println (e.getClass() + ":" + e.getMessage ());
           }
  }

  // This method is used to renew all the continuous queries related to a
  // particular database
  static void renewContinuousQuery (String db_name)
  {
	// 1. go through all the continuous queries
	//    put the queries in the db in an ArrayList
	ArrayList cq_list = getRelatedContinuousQuery (db_name);

if (ContinuousQuery_debugging)
System.out.println ("terminateAllCQueriesLocally");

	// 2. terminate all the selected queries locally
	terminateAllCQueriesLocally (cq_list);

if (ContinuousQuery_debugging)
System.out.println ("initOwnedContinuousStoredQuery");

	// 3. renew all the continuous stored queries
	initOwnedContinuousStoredQuery (db_name);

if (ContinuousQuery_debugging)
System.out.println ("renew other continuous queries");

	// 4. renew other continuous queries
	Document doc = Globals.getDatabase().getDocumentWithID(db_name);
	if (doc != null)
	  renewContinuousNonStoredQuery (cq_list, doc);

if (ContinuousQuery_debugging)
System.out.println ("good");
  }

  static void terminateContinuousQuery (String db_name)
  {
        // 1. go through all the continuous queries
        //    put the queries in the db in an ArrayList
        ArrayList cq_list = getRelatedContinuousQuery (db_name);

        // 2. terminate all the selected queries
        terminateAllCQueries (cq_list);
  }

  private static ArrayList getRelatedContinuousQuery (String db_name)
  {
	ArrayList my_list = new ArrayList ();

    try {
	Iterator it = continuous_query_table.values().iterator();
	while (it.hasNext ()) {
	  ContinuousQuery c_query = (ContinuousQuery) it.next ();
	  String root_id = QueryAnalysis.getRoot (
			   c_query.query_info.queryForRoot ());

	  if (db_name.equals (root_id)) {
	    my_list.add (c_query);
	  }
	}
     } catch (Exception e) {
	Utils.error (e.getClass().toString() + ":" + e.getMessage());
     }

	return my_list;
  }

  private static void terminateAllCQueries (ArrayList cq_list)
  {
	for (int ii=cq_list.size()-1; ii>=0; ii--) {
	   ContinuousQuery c_query = (ContinuousQuery) cq_list.get (ii);

	   if (c_query.st_name != null) {
		c_query.csq_sponsor.cancel ();
		c_query.st_name = null;
	   }
	   c_query.terminate ();
	}
  }

  private static void terminateAllCQueriesLocally (ArrayList cq_list)
  {
	for (int ii=cq_list.size()-1; ii>=0; ii--) {
	   ContinuousQuery c_query = (ContinuousQuery) cq_list.get (ii);

	   if (c_query.st_name != null) {
		c_query.csq_sponsor.cancel ();
		c_query.st_name = null;
	   }
	   c_query.terminateLocally ();
	}
  }

  private static void renewContinuousNonStoredQuery (ArrayList cq_list,
					     Document doc)
  {
        for (int ii=cq_list.size()-1; ii>=0; ii--) {
           ContinuousQuery c_query = (ContinuousQuery) cq_list.get (ii);
	   renewContinuousNonStoredQuery (c_query, doc);
        }
  }

  private static void renewContinuousNonStoredQuery (ContinuousQuery c_query,
					     Document doc)
  {
	// check if the root at node is still on this machine
	// do nothing if the node is not found
	String root_at_query = c_query.query_info.queryForRoot ();
	Node n = null;
     try {
	n = org.apache.xpath.XPathAPI.selectSingleNode (doc, root_at_query);
     } catch (Exception e) {}

	if (n == null) return;

	Element en = (n instanceof Document)?
	             ((Document)n).getDocumentElement ():
		     (Element) n;

	if (!(en.hasAttribute ("status") && 
	      en.getAttribute("status").equals("ownsthis")))
	  return;

	// renew continuous queries
	String local_ip = Protocol.getLocalIP ();
	int    local_port = Protocol.getLocalPort ();

        int num_clients = c_query.clients.size ();
        for (int ii=0; ii<num_clients; ii++) {
           ClientInfo cinfo = (ClientInfo) c_query.clients.get (ii);
           if (local_ip.equals (cinfo.client_ip) &&
               (local_port == cinfo.client_port)) {
             // self: this must be a continuous stored query
	     // do nothing
           }
           else {

	     String query = "continuous(" + c_query.xpath.toString()
			  + ",'mode="     + c_query.query_info.mode
			  + "','period="  + cinfo.period
			  + "','lease="   + cinfo.lease
			  + "')";

             // create root operator, automatically register the query
             RootOperator  r = new RootOperator ();
             boolean answered_locally = r.setup (
                               cinfo.client_query_id,
			       c_query.root_op.getResultType(),
			       root_at_query,
                               query,
			       cinfo.client_ip,
			       cinfo.client_port);

            if (answered_locally) {
              // r.continuous_query.sendResults ();
            } else {
              r.expandRemotely ();
            }
	  }
        }
  }

  // ---
  // instance members
  // ---
  ContinuousQueryTask  task;

  ArrayList       clients;	// all clients interested in this query
  QueryInfo       query_info;	// params for sub queries
  RootOperator    root_op;	// the root operator
  Expr            xpath;	// xpath query

  private boolean new_result_ready;
  private boolean immediate_send;
  private long    next_client_lease_expire;// the next estimated expiration time

  long    timer_period;
  long    quarter_lease_time;

  // sub leases management
  private long    next_lease_action_time;
  private int     next_lease_action;	// 0. send  1. flush

  Object          current_result = null;

  // for continuous stored query
  String	  st_name = null;
  CStoredQueryLeaseSponsor  csq_sponsor;

  // for dealing with caching
  Expr             xpath_no_caching;

  void startTimer ()
  {
	next_lease_action_time = currentTime() + quarter_lease_time;
	next_lease_action = 1;

	long run_period = (timer_period>0)?timer_period:quarter_lease_time;
	task = new ContinuousQueryTask (this);
	continuous_query_timer.schedule (task, run_period, run_period);
  }

  void stopTimer ()
  {
	task.cancel ();
	task = null;
  }

  void manageSubLeases ()
  {
	long now = currentTime();
	while (now >= next_lease_action_time) {
	  if (next_lease_action == 0) {
	    renewLeaseForRemoteQuery ();
	  }
	  else {
	    flushLeaseForRemoteQuery ();
	  }
	  next_lease_action_time += quarter_lease_time;
	  next_lease_action = 1 - next_lease_action;
	}
  }

  private ArrayList last_renew_flush_list = null;

  void renewLeaseForRemoteQuery ()
  {
	root_op.expandRemotely ();

	last_renew_flush_list = Protocol.getFlushList ();

if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": renewLeaseForRemoteQuery");
}
  }

  void flushLeaseForRemoteQuery ()
  {
	// call flush of package
	try {
	Protocol.flushFlushList (last_renew_flush_list);
	}
	catch (Exception e) {
	  Utils.error (e.getClass ().toString() + ':' + e.getMessage());
	}
	last_renew_flush_list = null;

if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": flushLeaseForRemoteQuery");
}
  }

  // after inserting or deleting clients, the timer period and lease
  // need to change accordingly.  checkPeriodLease checks and makes the
  // changes.
  void checkPeriodLease ()
  {
	// timer period = min (client period)
	// sub period = timer period / 2
	// sub lease = min (client lease)

	// 1. compute the min period and min lease
        int num_clients = clients.size ();
        long min_period = Long.MAX_VALUE;
        long min_lease = Long.MAX_VALUE;
                                                                                
        for (int ii=0; ii<num_clients; ii++) {
           ClientInfo cinfo = (ClientInfo) clients.get (ii);
           if (cinfo.period < min_period)
             min_period = cinfo.period;
           if (cinfo.lease < min_lease)
             min_lease = cinfo.lease;
        }
                                                                                
	// 2. adjust min_lease
        if (min_lease < 4 * min_period + 4000)
          min_lease = 4 * min_period + 4000;
                                                                                
	// 3. do nothing if there is no change
        if ((min_period == timer_period) && (min_lease == query_info.lease))
          return;
                                                                                
	// 4. remember the period and lease
        query_info.period = min_period;  // pipelining effect
        query_info.lease = min_lease;
        timer_period = min_period;
        quarter_lease_time = min_lease / 4;
                                                                                
        // 5. restart the timer
        stopTimer (); 
	startTimer ();
                                                                                
        // 6. renew the lease
        renewLeaseForRemoteQuery (); flushLeaseForRemoteQuery ();
  }

  // the continuous query already exists. Three cases:
  // 1) a lease renewal
  // 2) an existing client wants to change period and lease time
  // 3) a new client subscribes to the same query
  void insertClient (RootOperator rop)
  {
	// 1. look for the client in the clients
	int find_index = -1;
	int num_clients = clients.size ();
	for (int ii=0; ii<num_clients; ii++) {
	   ClientInfo cinfo = (ClientInfo) clients.get (ii);
	   if ((cinfo.client_ip.equals (rop.client_ip)) &&
	       (cinfo.client_query_id == rop.query_id)  &&
	       (cinfo.client_port     == rop.client_port)) {
		    find_index = ii;
		    break;
	       }
	}

	// 2. existing client
	if (find_index >= 0) {
	   // 1) when input lease == 0, we delete the client
	  if (rop.query_info.lease == 0) {
	    deleteClient (find_index);
	    return;
	  }
	    
	  // 2) renew lease
	  ClientInfo cinfo = (ClientInfo) clients.get (find_index);
	  cinfo.client_lease_expire = currentTime() + rop.query_info.lease;

	  // 3) check if period and lease time have changed?
	  if ((rop.query_info.period != cinfo.period) ||
	      (rop.query_info.lease != cinfo.lease)) {

	     // sanity check
	     if ((query_info.mode == 0) && (rop.query_info.period == 0)) {
	       Utils.error ("Continuous query error: period is 0 in mode 0!");
	     }

	     cinfo.period = rop.query_info.period;
	     cinfo.lease = rop.query_info.lease;

	     checkPeriodLease ();

	    if (next_client_lease_expire > cinfo.client_lease_expire)
	      next_client_lease_expire = cinfo.client_lease_expire;
	  }
	}

	// 3. new client
	else {

	  // sanity check
	  if ((query_info.mode == 0) && (rop.query_info.period == 0)) {
	    Utils.error ("Continuous query error: period is 0 in mode 0!");
	  }

	  // 1) initiate ClientInfo
	  ClientInfo cinfo = new ClientInfo ();
	  cinfo.client_ip       = rop.client_ip;
	  cinfo.client_port     = rop.client_port;
	  cinfo.client_query_id = rop.query_id;
	  cinfo.client_lease_expire = currentTime() + rop.query_info.lease;
	  cinfo.period          = rop.query_info.period;
	  cinfo.lease           = rop.query_info.lease;

	  clients.add (cinfo);

	  // 2) change period and lease?
	  checkPeriodLease ();

	  // 3) send result to the client
	  if (current_result != null)
	    sendResults (clients.size ()-1);

	  if (next_client_lease_expire > cinfo.client_lease_expire)
	    next_client_lease_expire = cinfo.client_lease_expire;
	}

if (ContinuousQuery_debugging) {
  System.out.println (currentTime() + ": insertClient");
  print ();
}

  }

  // remove the specific client
  void deleteClient (int client_index)
  {
	clients.remove (client_index);

	if (clients.size () > 0) {
	  checkPeriodLease ();
	}
	else {
	  // destroy this Continuous Query
	  terminate ();
	}

if (ContinuousQuery_debugging) {
  System.out.println ("deleteClient (" + client_index + ")");
}
  }

  // destroy this continuous query
  void terminate ()
  {
	// send termination requests to sub OAs
	root_op.terminate ();

	// stop timer
	stopTimer ();

	// remove it from the continuous_query_table
	removeCQuery (query_info.queryForRoot(),
		      xpath.toString(), 
		      query_info.mode);

	// remove all the clients
	if (clients.size () > 0)
	  clients.clear ();

if (ContinuousQuery_debugging) {
  System.out.println (currentTime() + ": terminate");
}
  }

  void terminateLocally ()
  {
	// do not send termination requests to sub OAs
	// otherwise do the same things as terminate
	root_op.terminateLocally ();

	// stop timer
	stopTimer ();

	// remove it from the continuous_query_table
	removeCQuery (query_info.queryForRoot(),
		      xpath.toString(), 
		      query_info.mode);

	// remove all the clients
	if (clients.size () > 0)
	  clients.clear ();

if (ContinuousQuery_debugging) {
  System.out.println (currentTime() + ": terminateLocally");
}
  }

  public void run ()
  {
  try{
   synchronized (mutex) {
	if (clients.size () == 0) return;

	// 1. check client leases
	long now = currentTime ();
	if (now >= next_client_lease_expire) {
	  next_client_lease_expire = Long.MAX_VALUE;
	  for (int ii=clients.size ()-1; ii>=0; ii--) {
	     ClientInfo cinfo = (ClientInfo) clients.get (ii);
	     if (cinfo.client_lease_expire <= now) {
	       deleteClient (ii);
	     }
	     else if (next_client_lease_expire > cinfo.client_lease_expire)
		next_client_lease_expire = cinfo.client_lease_expire;
	  }

	  Protocol.flushPackets ();

	  if (clients.size () == 0) return;
	}

	// 2. check if we should renew child lease
	if (query_info.mode > 0)
	  manageSubLeases ();

	// 3. check new results
	if (new_result_ready) {
	  sendResults ();
	  new_result_ready = false;
	}
	else if (query_info.mode == 0) {
	  immediate_send = true;

	  // ask a snapshot query
	  // 1) prepare a snapshot query info
	  query_info.resetRoot ();
	  QueryInfo qinfo = new QueryInfo ();
          qinfo.root = query_info.root;
	  qinfo.subtree_consistency_checking = "[expiry='0']";

	  // 2) build sub xpath operator
	  root_op.removeAllChildren ();
          SubXpathOperator sub = new SubXpathOperator (root_op);
          sub.setup (qinfo, xpath_no_caching, root_op.getResultType());

          // 3) return
          boolean ret = sub.expandLocally ();

	  if (ret) {
	    resultReady (root_op.getChild(0).getResult ());
	  }
	  else {
	    root_op.expandRemotely ();
	  }
	}
	else if ((query_info.mode == 1)&&(timer_period > 0)) {
	  // There is no activity in this period
	  immediate_send = true;
	}

	Protocol.flushPackets ();

if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": run ()");
  print ();
}
    } // mutex
   } catch (Throwable e) {
	System.out.println (e.getClass().toString() + ':' + e.getMessage());
	e.printStackTrace ();
   }
  }

  // We have set immediate_send == true
  void firstResultAlreadySent (Object result)
  {
	current_result = result;
	new_result_ready = false;

	if (timer_period > 0)
	  immediate_send = false;

	// this is the end of this invokation
	query_info.clearRoot ();
  }

  void resultReady (Object result)
  {
	current_result = result;
	new_result_ready = true;

	if (immediate_send) {
	  sendResults ();
	  new_result_ready = false;

	  if (timer_period > 0)
	    immediate_send = false;
	}

	// this is the end of this invokation
	query_info.clearRoot ();
  }

  void sendResults ()
  {
if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": sendResults");
}
	// 1. preparation
	String response = null;
	int rtype = root_op.getResultType ();
	String local_ip = Protocol.getLocalIP ();
	int    local_port = Protocol.getLocalPort ();

     try {
	// 2. iterate through all clients and send results
        int num_clients = clients.size ();
        for (int ii=0; ii<num_clients; ii++) {
           ClientInfo cinfo = (ClientInfo) clients.get (ii);
	   if (local_ip.equals (cinfo.client_ip) && 
	       (local_port == cinfo.client_port)) {
	     // self: this must be a continuous stored query
	     if ((current_result != null) && 
		 (current_result instanceof String[])) {
	        updateStoredQueryValue (query_info.queryForRoot(), st_name, 
		   QueryOperator.getResultString ((String[])current_result));
	     }
	   }
	   else {
	     if (response == null)
		response = root_op.generateResponse (current_result);
	     Protocol.enqueueReply2Message (cinfo.client_query_id, 
				       rtype, 
				       response,
				       cinfo.client_ip,
                                       cinfo.client_port,
				       false);
	   }
        }

	// 3. call flush
     } catch (Exception e) {
	System.out.println (e.getClass().toString() + ':' + e.getMessage());
     }

	// 4. for mode 0, remove children
	if (query_info.mode == 0) {
	  root_op.removeAllChildren ();
	}
  }

  void sendResults (int client_index)
  {
if (ContinuousQuery_debugging) {
  System.out.println (currentTime () + ": sendResults (" + client_index + ")");
}

	// 1. preparation
	int rtype = root_op.getResultType ();
	String local_ip = Protocol.getLocalIP ();
	int    local_port = Protocol.getLocalPort ();

     try {
	// 2. send result
	ClientInfo cinfo = (ClientInfo) clients.get (client_index);
        if (local_ip.equals (cinfo.client_ip) &&
            (local_port == cinfo.client_port)) {
	     // self: this must be a continuous stored query
	     if ((current_result != null) && 
		 (current_result instanceof String[])) {
	        updateStoredQueryValue (query_info.queryForRoot(), st_name, 
		   QueryOperator.getResultString ((String[])current_result));
	     }
        }
        else {
          String response = root_op.generateResponse (current_result);
          Protocol.enqueueReply2Message (cinfo.client_query_id,
                                    rtype,
                                    response,
                                    cinfo.client_ip,
                                    cinfo.client_port,
				    false);
	}
        // 3. call flush
     } catch (Exception e) {
        System.out.println (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  void print ()
  {
	System.out.print ("ContinuousQuery:");
	System.out.print (xpath.toString());
	System.out.print (",mode=" + query_info.mode);
	System.out.print (",period=" + timer_period);
	System.out.println (",quarter_lease_time=" + quarter_lease_time);

	int num_clients = clients.size();
	System.out.println (num_clients + " clients:");
	for (int ii=0; ii<num_clients; ii++) {
	   ClientInfo cinfo = (ClientInfo) clients.get (ii);
	   System.out.print (ii + ") " + cinfo.client_ip);
	   System.out.print (",port=" + cinfo.client_port);
	   System.out.print (",query_id=" + cinfo.client_query_id);
	   System.out.print (",period=" + cinfo.period);
	   System.out.print (",lease=" + cinfo.lease);
	   System.out.println (",lease_expire=" + cinfo.client_lease_expire);
	}

	System.out.println ("sub query: " + "period=" + query_info.period
			+ ",lease=" + query_info.lease);

	System.out.print ("has_result=" + (current_result!=null));
	System.out.print (",new_result_ready=" + new_result_ready);
	System.out.print (",immediate_send=" + immediate_send);
	System.out.println (",next_client_lease_expire=" 
			    + next_client_lease_expire);

	System.out.print ("next_lease_action_time=" + next_lease_action_time);
	System.out.println (",next_lease_action=" + next_lease_action);
	System.out.println ("----------------------------------------------");
  }

  // --------------------------------------------------------------------------
  // test
  public static void main (String[] args)
  {
	init ();
	QueryInfo qinfo = new QueryInfo();
	parseParams (args, qinfo);
	System.out.println ("mode:" + qinfo.mode);
	System.out.println ("period:" + qinfo.period);
	System.out.println ("lease:" + qinfo.lease);

/*
	debugCQuery one = new debugCQuery ("/aaa", "127.0.0.1", 1, 1000, 8000);

	try {
	  //one.set_stop ();
	  Thread.sleep (9*1000);
	  debugCQuery two = new debugCQuery (one, "127.0.0.2", 500, 8000);
	  // one.set_param (1000, 0); one.set_stop (); one.run ();
	  //Thread.sleep (15*1000);
	  //Thread.sleep (300);
	  //for (int ii=0; ii<10; ii++) {
	  //   one.c_query.resultReady ("");
	  //   Thread.sleep (500);
	  //}
	  Thread.sleep (5000);
	} catch (Exception e) {
	}
	System.exit (0);
*/
  }
} // ContinuousQuery

// ----------------------------------------------------------------------------
//                class ClientInfo
// ----------------------------------------------------------------------------
class ClientInfo {
  String   client_ip;
  int      client_port;
  long     client_query_id;
  long     client_lease_expire;	// next lease expiration time in ms
  long     period;
  long     lease;
} // ClientInfo

// ----------------------------------------------------------------------------
//                class ContinuousQueryTask
// ----------------------------------------------------------------------------
class ContinuousQueryTask extends TimerTask {
  private ContinuousQuery  c_query;

  ContinuousQueryTask (ContinuousQuery cquery)
  {
	super ();
	c_query = cquery;
  }

  public void run ()
  {
	c_query.run ();
  }
} // ContinuousQueryTask

// ----------------------------------------------------------------------------
//                class NodeInterested
// ----------------------------------------------------------------------------
class NodeInterested {
  LocalResultOperator  local_op;
  Element              node_interested;
} // NodeInterested

class NodeInterestedList {
  private ArrayList  list;

  NodeInterestedList ()
  { list = new ArrayList (1); }

  void add (NodeInterested ni)
  {
	list.add (ni);
  }

  void remove (Element n)
  {
	int num = list.size();
	for (int ii=0; ii<num; ii++) {
	   if (((NodeInterested) list.get (ii)).node_interested == n) {
	     list.set (ii, list.get(num-1));
	     list.remove (num-1); 
	     break;
	   }
	}
  }

  ArrayList getList ()
  {
	return list;
  }
} // NodeInterestedList

// ----------------------------------------------------------------------------
//                class CStoredQueryLeaseSponsor
// ----------------------------------------------------------------------------
class CStoredQueryLeaseSponsor extends TimerTask {

  String query_for_element;
  String query;

  CStoredQueryLeaseSponsor (Timer timer, 
	String queryForElement, String Query, long lease_ms)
  {
	query_for_element = queryForElement;
	query = Query;

        long period = lease_ms - 1000;
        timer.schedule (this, period, period);
  }

  public void run ()
  {
    try {
     synchronized (ContinuousQuery.mutex) {
	RootOperator  r = new RootOperator ();
        r.setup (
                 -1,
                 QueryOperator.RESULT_STRING,
                 query_for_element,
                 query,
                 Protocol.getLocalIP (),
                 Protocol.getLocalPort ());
	// lease sponsor should not generate any packets
	// but in case lease expired because the jre is too busy
	// we may restart the query
	Protocol.flushPackets ();
     }
   } catch (Exception e) {
	System.out.println (e.getClass().toString() + ':' + e.getMessage());
	e.printStackTrace ();
   }
  }
} // CStoredQueryLeaseSponsor

// ----------------------------------------------------------------------------
//                class debugCQuery
// ----------------------------------------------------------------------------
class debugCQuery extends TimerTask {

  RootOperator rop;
  ContinuousQuery c_query;
  boolean  stop_in_next_run;

  debugCQuery (String query, String client_ip, 
	       int mode, long period, long lease)
  {
	rop = new RootOperator ();
	rop.query_id = 123;
	rop.client_ip = client_ip;
	rop.client_port = 2000;

	QueryInfo qinfo = new QueryInfo ();
	qinfo.mode = mode;
	qinfo.period = period;
	qinfo.lease = lease;
	rop.query_info = qinfo;
	
	Expr expr = null;
        try {
          expr = XPathQueryParser.parsequery (query);
        } catch (Exception e) {
          Utils.error (e.getClass().toString() + ':' + e.getMessage());
        }

	c_query = ContinuousQuery.create (rop, expr);

	// get a new qinfo, the old is overwritten by ContinuousQuery
        qinfo = new QueryInfo ();
        qinfo.mode = mode;
        qinfo.period = period;
        qinfo.lease = lease;
        rop.query_info = qinfo;

	stop_in_next_run = false;

	// periodically update lease
	long my_lease = lease - 1000;
	ContinuousQuery.continuous_query_timer.schedule (this, my_lease, 
						         my_lease);
  }

  debugCQuery (debugCQuery orig, String client_ip,
               long period, long lease)
  {
        rop = new RootOperator ();
        rop.query_id = 123;
        rop.client_ip = client_ip;
        rop.client_port = 2000;

        QueryInfo qinfo = new QueryInfo ();
        qinfo.mode = orig.rop.query_info.mode;
        qinfo.period = period;
        qinfo.lease = lease;
        rop.query_info = qinfo;

	c_query = orig.c_query;

        stop_in_next_run = false;

        // periodically update lease
        long my_lease = lease - 1000;
        ContinuousQuery.continuous_query_timer.schedule (this, 0,
                                                         my_lease);
  }

  void set_param (long period, long lease)
  {
        QueryInfo qinfo = new QueryInfo ();
        qinfo.mode = rop.query_info.mode;
        qinfo.period = period;
        qinfo.lease = lease;
        rop.query_info = qinfo;

	//if (lease > 0) {
	//  cancel ();
	//  long my_lease = lease - 1000;
        //  ContinuousQuery.continuous_query_timer.schedule (this, 0,
        //                                                 my_lease);
	//}
  }

  void set_stop ()
  {
	stop_in_next_run = true;
  }

  public void run ()
  {
	System.out.println ("debug renew lease:" + rop.client_ip);
	c_query.insertClient (rop);

	if (stop_in_next_run) {
	  cancel ();
	}
  }
} // debugCQuery
