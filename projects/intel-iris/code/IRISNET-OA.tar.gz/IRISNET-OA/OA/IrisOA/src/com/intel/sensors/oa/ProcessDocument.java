/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.w3c.dom.*;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xpath.XPathAPI;
import org.apache.xml.utils.TreeWalker;
import org.apache.xml.utils.DOMBuilder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException; 

/** 
 *   Docment processing using the DOM model.
 *   Things like : finding hanging children etc.
 *   XXX Functionality of this class has been encompassed in DOMProcessing.
 *
 *   @author Amol */
public class ProcessDocument {

    Document doc = null;

    /** The sub-queries and owner-agents and stuff after finding hangingChildren */
    Vector owneragents = new Vector();
    Vector hangingNodes = new Vector();
    
    /** Query Entry corresponding to tihs.. if ever generated */
    QueryEntry qEntry = null;

    ProcessDocument(Document _doc) {
        doc = _doc;
    }

    /** A hanging node is one that has `leaf' tag, but doesn't have `final' tag inside it */
    private boolean isHangingNode(Node n) {
        boolean isleaf = false, isfinal = false;
        if(n.hasChildNodes()) {
            NodeList nl = n.getChildNodes();
            if(nl != null) {
                for(int i = 0; i < nl.getLength(); i++) {
                    if(nl.item(i) instanceof Element) {
                        String tagname = ((Element)nl.item(i)).getTagName();
                        if(tagname.equals("leaf")) 
                            isleaf = true;
                        if(tagname.equals("final")) 
                            isfinal = true;
                    }
                }
            }
        }
        return (isleaf) && (!isfinal);
    }

    public void findHangingDescedentsRecursively(Node n) {
        if(isHangingNode(n)) {
            // extract owner-agent
            Element elm = (Element) n; // has to be
            NamedNodeMap nnm = elm.getAttributes();
            String owneragent = ((Attr) nnm.getNamedItem("owner-agent")).getValue();

            hangingNodes.add(n);
            owneragents.add(owneragent);
        } else { // note this is an else... a hangingNode can not have descendent hangingNodes, by definition
            // recursively call the children
            if(n.hasChildNodes()) {
                NodeList nl = n.getChildNodes();
                if(nl != null) {
                    for(int i = 0; i < nl.getLength(); i++) {
                        findHangingDescedentsRecursively(nl.item(i));
                    }
                }
            }
        }
    }

    /** Find out if there are any hanging nodes and if yes, create a query entry and add
     *  the rendeveousNodes, toBeReplacedNodes etc to it. */
    public boolean areThereHangingDescendents() {
        findHangingDescedentsRecursively(doc);
        return hangingNodes.size() != 0;
    }

    /** Convert to an array of nodes */
    public Node[] getHangingNodes() {
        Node[] ret_val = new Node[hangingNodes.size()];
        for(int i = 0; i < hangingNodes.size(); i++) {
            ret_val[i] = (Node) hangingNodes.get(i);
        }
        return ret_val;
    }

    public RemoteSourceInfo[] getOwneragents() {
        RemoteSourceInfo[] ret_val = new RemoteSourceInfo[owneragents.size()];
        for(int i = 0; i < owneragents.size(); i++) {
            try {
                ret_val[i] = new RemoteSourceInfo((String)owneragents.get(i));
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        return ret_val;
    }

    public static void printRandomStuff(Node n) {
        if(n instanceof Element) {
            System.out.println("*** " + ((Element) n).getTagName() + " ***");
        }
        if(n instanceof CharacterData) {
            System.out.println("*** " + ((CharacterData) n).getData() + " ***");
        }
        if(n instanceof Attr) {
            System.out.println("*** " + ((Attr) n).getValue() + " ***");
            System.out.println("*** " + ((Attr) n).getName() + " ***");
        }
    }

    public static void main(String[] args) {
        try {
            InputSource in = new InputSource(new FileInputStream("test.xml"));
            DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
            dfactory.setNamespaceAware(true);
            Document doc = dfactory.newDocumentBuilder().parse(in);

            System.out.println(doc.toString());

            ProcessDocument pd = new ProcessDocument(doc);
            pd.areThereHangingDescendents();
            for(int i = 0; i < pd.hangingNodes.size(); i++) {
                printRandomStuff((Node) pd.hangingNodes.get(i));
                System.out.println(pd.owneragents.get(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
};
