/*========================================================================*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License.
 *
 * You may obtain a copy of the License at http://www.mozilla.org/MPL/
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * See the License for the specific language governing rights and
 * limitations under the License.
 *
 * The Original Code is all this file.
 *
 * The Initial Developer of the Original Code is
 * Aleksei Valikov, Forchungszentrum Informatik (valikov@fzi.de).
 *
 * Contributor(s): none.
 *========================================================================*/

package de.fzi.XPath;

/**
 * Class <code>ForExpr</code> represents a for expression.
 * @author Shimin
 */
public class ForExpr extends Expr
{
  // for $i in expr1 return expr2
  Expr     in_expr;	// expr1
  Expr     return_expr;	// expr2
  Variable loop_index;	// $i

  public void setInExpr (Expr expr)
  {
	in_expr = expr;
  }

  public Expr getInExpr ()
  {
	return in_expr;
  }

  public void setReturnExpr (Expr expr)
  {
	return_expr = expr;
  }

  public Expr getReturnExpr ()
  {
	return return_expr;
  }

  public void setLoopVariable (Variable v)
  {
	loop_index = v;
  }

  public Variable getLoopVariable ()
  {
	return loop_index;
  }

  /**
   * Returns string representation of for expression.
   * @return Returns string representation of for expression.
   */
  public String toString()
  {
    return "for " + loop_index.toString() 
           + " in " + in_expr.toString()
           + " return " + return_expr.toString();
  }
}
