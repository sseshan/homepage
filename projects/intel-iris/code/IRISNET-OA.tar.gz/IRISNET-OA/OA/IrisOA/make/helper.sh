#!/bin/tcsh
set CP = `pwd`

cd ../../../packages/lib-java/

foreach sourcefile (`ls *.jar`)
    echo "(XML_LIB)/${sourcefile}(SEP)"
end

cd CP
