/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <math.h>
#include <sys/resource.h>
#include <ctype.h>
#include <assert.h>
	
// SA Application includes
#include <filter.h>
#include "pl.h"

// need to fold this into make file
#undef NDEBUG

#define SA      struct sockaddr

#define THR 20
#define PS_FULL 1
#define PS_EMPTY 0

#define DELETE
#define ADD
#define LOOP
#define USE_SLICESTAT 1
#define USE_GANGLIA 1
#define USE_HISTORY 0

#define SLICESTAT_FILE "/home/cmu5/sknath/slicestat.out"

char *dynamic_metrcis[] = {
	"load_fifteen",
	"cpu_nice",
	"pkts_out",
	"cpu_user",
	"proc_total",
	"mem_free",
	"proc_run",
	"cpu_aidle",
	"bytes_in",
	"bytes_out",
	"mem_shared",
	"mem_cached",
	"cpu_idle",
	"swap_free",
	"load_five",
	"pkts_in",
	"disk_free",
	"mem_buffers",
	"load_one"
};
#define METRIC_COUNT 19

// name of the comma seperated values in each slicestat line
char *slicestat_attrs[] = {
	"slice",
	"ctx",
	"cpu",
	"mem",
	"pmem",
	"vmem",
	"ntasks",
	"send_bw1",
	"send_bw5",
	"send_bw15",
	"recv_bw1",
	"recv_bw5",
	"recv_bw15"
};
#define SSTAT_COUNT 13

#define HACSIZE 30
#define DACSIZE 12
#define WACSIZE 4
#define MACSIZE 7
#define YACSIZE 0
#define MAXACC 30

#define HSAMPLES 60*1
#define DSAMPLES 23*2
#define WSAMPLES 6*4 
#define MSAMPLES 3*7 
#define YSAMPLES  51
#define MAXSAMPLES 60

#define STAGES 5

#define HOUR 0
#define DAY 1
#define WEEK 2
#define MONTH 3
#define YEAR 4

typedef struct {
	// sampling times: 1 min, 30 mins, 6 hours, 1 day, 7 days 
	int sampleSize[STAGES], accSize[STAGES], curr[STAGES], total[STAGES], accumulated[STAGES];
	float queue[STAGES][MAXSAMPLES+MAXACC];
	
	// accumulation buffer is placed between two successive queues
	// accumulation buffer sizes

	//float hour[HSIZE], day[DSIZE], week[WSIZE], month[MSIZE], year[YSIZE];
	// 'curr' is the next slot to insert item, 'total' is the queue size 
	//int h_curr, h_total, d_curr, d_total, w_curr, w_total, m_curr, m_total, y_curr, y_total;
	// intermediate buffer sizes
	//int h_accumulated, d_accumulated, w_accumulated, m_accumulated;
} HistoricalQueue;

#define MAXDYNAMICMETRIC 20
HistoricalQueue history[MAXDYNAMICMETRIC];

char hb_ip[32];
int hb_port = -1;
int sleepTime = 10;
int displayFlag = 1; // verbose or quiet mode?

#define BUFSIZE 1024
int fileCopy(char *src, char *dst)
{
	
	FILE *srcf, *dstf;
	char buff[BUFSIZE];
	int nRead;

	if ( (srcf = fopen(src, "r")) == NULL) {
		printf("File %s cannot be open to read\n", src);
		return -1;
	}

	if ( (dstf = fopen(dst, "w")) == NULL) {
		printf("File %s cannot be open for writing\n", dst);
		return -1;
	}

	while ( (nRead = fread(buff, sizeof(char), BUFSIZE,  srcf)) != 0) {
		fwrite(buff, sizeof(char), nRead, dstf);
	}

	fclose(srcf);
	fclose(dstf);
	return 0;
}


int metricIndex(char *name)
{
	int i;
	for (i = 0; i <METRIC_COUNT; i++)
		if (!strcmp(dynamic_metrcis[i], name)) return i;

	return -1;
}


void initHistoricalQueue()
{
	int index, i;

	for (index = 0; index <MAXDYNAMICMETRIC; index++) { 
		for (i = 0; i<STAGES; i++) {
			history[index].curr[i] = 0;
			history[index].total[i] = 0;
			history[index].accumulated[i] = 0;
	}
		
		history[index].sampleSize[HOUR]=HSAMPLES;
		history[index].sampleSize[DAY]=DSAMPLES;
		history[index].sampleSize[WEEK]=WSAMPLES;
		history[index].sampleSize[MONTH]=MSAMPLES;
		history[index].sampleSize[YEAR]=YSAMPLES;
		
		history[index].accSize[HOUR]=HACSIZE;
		history[index].accSize[DAY]=DACSIZE;
		history[index].accSize[WEEK]=WACSIZE;
		history[index].accSize[MONTH]=MACSIZE;
		history[index].accSize[YEAR]=YACSIZE;
	}
}

void addToHistoricalQueue(int qIndex, float item);

int updateHistoricalQueue(unsigned long delta)
{
	unsigned long i;
	int j;


	for (i =0; i<delta; i++) {
		for (j = 0; j < METRIC_COUNT; j++) {
			addToHistoricalQueue(j, -1); // insert dummy element
		}
	}

	return 0;
}

int writeHistoricalQueue(char *fName)
{
	FILE *fp;
	char command[256];
	unsigned long header[2];
	char backupFile[256];

	sprintf(backupFile, "%s.back", fName);
	
	if (fileCopy(fName, backupFile) < 0) {
		printf("Trying system command to create backup file\n");
		sprintf(command , "cp -f %s %s", fName, backupFile);
		system(command);
		sleep(2);
	}
	
	if ( (fp = fopen(fName, "w")) == NULL) {
		printf("Error in creating file %s to write historical queue\n", fName);
		return -1;
	}

	header[0] = 0xABCD; // magic number
	header[1] = time(NULL);
	
	fwrite(header, sizeof(header), 1, fp);
	fwrite(history, sizeof(history), 1, fp);
	fclose(fp);

	return 0;
}

int loadHistoricalQueue(char *fName)
{
	FILE *fp;
	char backup[256];
	unsigned long header[2];
	unsigned long timestamp = 0;

	// load from the file
	if ( (fp = fopen(fName, "r")) != NULL) {
		if (fread(header, sizeof(header), 1, fp) == 1) {
			if (header[0] == 0xABCD) {
				timestamp = header[1];
				if (fread(history, sizeof(history), 1, fp) == 1) {
					updateHistoricalQueue((time(NULL) - timestamp)/sleepTime);
					fclose(fp);
					return 0;
				}
			}
		}
	}
	
	// try the backup file
	sprintf(backup, "%s.backup", fName);
	if ( (fp = fopen(backup, "r")) != NULL) {
		if (fread(header, sizeof(header), 1, fp) == 1) {
			if (header[0] == 0xABCD) {
				timestamp = header[1];
				if (fread(history, sizeof(history), 1, fp) == 1) {
					updateHistoricalQueue(time(NULL) - timestamp);
					fclose(fp);
					return 0;
				}
			}
		}
	}
	
	// nothing to do.. bad luck :(
	return -1;
}

// returns the overflowed item
float addToSubQueue(int qIndex, int stage, float item)
{
	float sum = 0, curritem = 0, valid = 0;
	int i;
	int maxSize = history[qIndex].sampleSize[stage] + history[qIndex].accSize[stage];
	history[qIndex].queue[stage][history[qIndex].curr[stage]] = item;
	history[qIndex].curr[stage]= (history[qIndex].curr[stage] + 1) % maxSize;
        history[qIndex].total[stage]++;
        if (history[qIndex].total[stage] > maxSize) history[qIndex].total[stage] = maxSize;

        if (history[qIndex].total[stage] > history[qIndex].sampleSize[stage] )
                history[qIndex].accumulated[stage] ++;
        if (history[qIndex].accumulated[stage] == history[qIndex].accSize[stage]) {
		for (i = 0; i< history[qIndex].accSize[stage]; i++) {			
			curritem = history[qIndex].queue[stage][(history[qIndex].curr[stage] + i) % maxSize];
			if (item >= 0) {
				sum += curritem;
				valid ++; 
			}
		}
		history[qIndex].accumulated[stage] = 0;
		if (valid > 0 ) return -1;
			else return sum / valid;
        }

	return -2;
}

void printSubQueue(int qIndex, int stage, char* outBuffer)
{
	int maxSize = history[qIndex].sampleSize[stage] + history[qIndex].accSize[stage];
	int i, j;
	char temp[256];
	float value;

	strcpy(outBuffer, "");

	for (i = 0, j = history[qIndex].curr[stage]-1; i <  history[qIndex].sampleSize[stage]; i++, j--) {
		if (j < 0) j = maxSize-1;
		value  =  history[qIndex].queue[stage][j];

		if (value - (int)(value) >0)
			sprintf(temp, "%.1f ", value);
		else
			sprintf(temp, "%.0f ", value);
		strcat(outBuffer, temp);
	}

}


void addToHistoricalQueue(int qIndex, float item)
{
	int i;
	float slided;
	
	//printf("INSERTING: %f\n", item);
	slided = item;
	for (i = 0; i< STAGES; i++) {
		slided = addToSubQueue(qIndex, i, slided);
		if (slided < -1) break;
	}
}

void printHistoricalQueue(int qIndex, char* outBuffer)
{
	char tmp[1024*128];

	strcpy(outBuffer, "");
	strcat(outBuffer, "<VALUE NAME='HOUR'>");
	printSubQueue(qIndex, HOUR, tmp);
	strcat(outBuffer, tmp);
	strcat(outBuffer, "</VALUE>\n");
	
	strcat(outBuffer, "<VALUE NAME='DAY'>");
        printSubQueue(qIndex, DAY, tmp);
        strcat(outBuffer, tmp);
        strcat(outBuffer, "</VALUE>\n");

	strcat(outBuffer, "<VALUE NAME='WEEK'>");
        printSubQueue(qIndex, WEEK, tmp);
        strcat(outBuffer, tmp);
        strcat(outBuffer, "</VALUE>\n");

	strcat(outBuffer, "<VALUE NAME='MONTH'>");
        printSubQueue(qIndex, MONTH, tmp);
        strcat(outBuffer, tmp);
        strcat(outBuffer, "</VALUE>\n");

	strcat(outBuffer, "<VALUE NAME='YEAR'>");
        printSubQueue(qIndex, YEAR, tmp);
        strcat(outBuffer, tmp);
        strcat(outBuffer, "</VALUE>\n");
}

//strstr(), ignoring case 
char *strstrcase(char *haystack, char *needle)
{
	char haystack_orig[MAXBUFLEN], needle_orig[MAXBUFLEN], *p, *ret;

	strcpy(haystack_orig, haystack);
	strcpy(needle_orig, needle);
	
	for (p = haystack; *p; p++) 
		*p = toupper(*p);
	for (p = needle; *p; p++)
                *p = toupper(*p);

	ret = strstr(haystack, needle);
	strcpy(haystack, haystack_orig);
	strcpy(needle, needle_orig);
	return ret;
}

// send 'message' to a tcp port, and terminates the connection
int sendTCPPacket(char *address, int port, char *message)
{
        int sockfd;
        struct sockaddr_in servaddr;

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd <0) return -1;

        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(port);
        inet_pton(AF_INET, address, &servaddr.sin_addr);

        if (connect(sockfd, (SA *) &servaddr, sizeof(servaddr)) < 0) {
		close(sockfd);
		return -1;
	}

	write(sockfd, message, sizeof(message));
	close (sockfd);

        return 0;
}

int httpGET(char *address, int port, char *get, char* outFileName)
{
	char* Buffer[] = {
		"GET ",
		get,
		" HTTP/1.0\n", "\n\n",
		"Connection: Keep-Alive\n",
		"User-Agent: Moxilla/2.0 (WinNT; I)\n",
		"Host: chilly:2512\n", "Accept: image/gif\n", "\n\n",
		/* "POST /cgi-bin/getset.exe HTTP/1.0\n",
		   "Connection: Keep-Alive\n",
		   "User-Agent: Mozilla/2.0\n",
		   "Accept: text/plain\n",
		   "Accept: text/html\n",
		   "Content-type: application/x-www-form-urlencoded\n",
		   "Content-length: 11\n", "\n",
		   "name=nobody\n\n", */
		NULL };
	char endOfHeader1[] = {0xD, 0xA, 0xD, 0xA, 0x0};
	char endOfHeader2[] = {0xA, 0xA, 0x0};

	int sockfd, i;
        struct sockaddr_in servaddr;
	FILE *fp;
	char buffer[1024*8] = "", tmpBuf[1024*8], *c;
	int nRead;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd <0) return -1;

        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(port);
        inet_pton(AF_INET, address, &servaddr.sin_addr);

        if (connect(sockfd, (SA *) &servaddr, sizeof(servaddr)) < 0) {
                close(sockfd);
                return -1;
        }

	for (i = 0; Buffer[i] != NULL; i++) {
		if (write(sockfd, Buffer[i], strlen(Buffer[i])) < 0) break;
	}
	sleep(1);
	for (;;) {
		if ( (nRead = read(sockfd, tmpBuf, 1024 * 8-1)) <= 0) break;
		tmpBuf[nRead] = '\0';
		printf(tmpBuf);
		strcat(buffer, tmpBuf);
	}
	close(sockfd);

	// write it to the file
	if ( (fp = fopen (outFileName, "wt")) == NULL) {
                printf("httpGET: Error in opening file to write\n");
                return -1;
        }

	c = strstr(buffer, endOfHeader1); // ommit the header
	if (c != NULL)
		c += strlen(endOfHeader1);
	else {
		c = strstr(buffer, endOfHeader2);
		if (c != NULL)
			c += strlen(endOfHeader2);
		else
			c = buffer;
	}

	//printf("***************%s*************", c);
	fwrite(c, strlen(c), 1, fp);
	fclose(fp);

	sleep(1);
	return 0;
}

int CollectSliceStat(char *fName)
{
	return httpGET("127.0.0.1", 2840, "/slicestat", fName);
}

int ConnectToOA(OrgAgent *oa)
{
	int  sockfd;
	struct sockaddr_in saaddr;
	char buffer[MAXBUFLEN];

	assert (oa != NULL);

	// debug
	inet_ntop(AF_INET, &(oa->addr.s_addr), buffer, MAXBUFLEN);
	printf("Connecting to host %s, port %d\n", buffer, oa->port);
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		return sockfd;
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(oa->port);
	//Inet_pton(AF_INET, sa->addr.s_addr, &saaddr.sin_addr);
	saaddr.sin_addr = oa->addr;  
	if (connect(sockfd, (SA *) &saaddr, sizeof(saaddr)) < 0) {
		close(sockfd);
		return -1;
	}

	return sockfd;
}


// write the string "st" to the socket 
// prepends length of string to "st"
// returns 1 on success, 0 on error
int SendToOA(int sockfd, char *st)
{
	unsigned long len = 0;
	char lenSt[7];

	if (sockfd < 0) 
		return -1;
	assert (st != NULL);

	// calculate length of packet
	// must be able to fit in a 3 byte signed int
	len = strlen(st) + 7;

	lenSt[0] = len / (128 * 128) ; //(len & 0xff0000) >> 16;
	lenSt[1] = (len % (128 * 128)) / 128; //(len & 0x00ff00) >> 8;
	lenSt[2] = (len % (128 * 128)) % 128; // (len & 0x0000ff);

	// not sure what these bytes are used for
        //   lenSt[3] = (len & 0x000000ff);
	lenSt[3] = ' ';
	lenSt[4] = '-';
	lenSt[5] = '1';
	lenSt[6] = ' ';

	if (displayFlag)
		printf("Parking.SendToOA(): Sending message:\n%s\n\n", st);

	// write total length of message
	if (write (sockfd, lenSt, 7) != 7) return -1;
	
	// write message
	if (write (sockfd, st, len - 7) != (len-7)) return -1;

	return 1;
}

// initializes pconf from configuration file
// returns 1 on success, 0 on error
int InitConfiguration(char * confFileName, PLConfType * pconf)
{
	FILE * fp; // file pointer to configuration file
	char line[MAXBUFLEN], *attr, *value, *last;

	assert(confFileName != NULL);
	assert(pconf != NULL);

	// Open configuration file
	if ( (fp = fopen(confFileName, "rt")) == NULL) {
		printf("PL.InitConfiguration(): Error opening %s configuration file.\n", confFileName);
		return 0;
	}


	// Read the values from the configuration file
	printf("Loading configuration\n");
	while (fgets(line, MAXBUFLEN, fp) != NULL) {
		attr = strtok_r(line, "=\n", &last);
		value = strtok_r(NULL, "\n", &last);

		if (!strcasecmp(attr, "HOSTNAME")) { 
			strcpy(pconf->hostName, value);
			printf("HOSTNAME: %s\n", pconf->hostName);
		} else if (!strcasecmp(attr, "GANGLIA")) {
			strcpy(pconf->gangFile, value);
			printf("GANGLIA: %s\n", pconf->gangFile);
		} else if (!strcasecmp(attr, "XPATH")) {
			strcpy(pconf->xpath, value);
		        printf("XPATH: %s\n", pconf->xpath);
		} else if (!strcasecmp(attr, "SLEEPTIME")) {
			sscanf(value, "%d", &pconf->sleepTime);
			sleepTime = pconf->sleepTime;
			printf("SLEEPTIME: %d\n", pconf->sleepTime);
		} else if (!strcasecmp(attr, "NODENAME")) {
			strcpy(pconf->nodeName, value);
			printf("NODENAME: %s\n", pconf->nodeName);
		}
	}

	return 1;
}

// simple hacks to collect ganglia and slicestat output through 
// "system" call
int CollectGanglia(char *fName)
{
	char command1[MAXBUFLEN], command2[MAXBUFLEN];
	sprintf(command1, "telnet localhost 8649 > %s.tmp", fName);
	sprintf(command2, "mv -f %s.tmp %s", fName, fName);

	if (system(command1) <0) {
		printf("Error in executing.. %s\n", command1);
		return -1;
	}
	//sleep(2); // wait for the command to finish

	if (system(command2) < 0) {
		printf("Error in executing.. %s\n", command2);
		return -1;
	}

	return 1;
}

int CollectSliceStat2(char *fName)
{
	char command1[MAXBUFLEN], command2[MAXBUFLEN];
	sprintf(command1, "curl --connect-timeout 5 http://127.0.0.1:2840/slicestat > %s.tmp", fName);
	sprintf(command2, "mv -f %s.tmp %s", fName, fName);

	if (system(command1) <0) {
		printf("Error in executing.. %s\n", command1);
		return -1;
	}
	//sleep(2); // wait for the command to finish
	//printf("Done\n");
	if (system(command2) < 0) {
		printf("Error in executing.. %s\n", command2);
		return -1;
	}

	//printf("Done\n");
	return 1;
}


// We collect the measurement statistics from the ganglia measurement 
// daemon runing on each PlanetLab node
// Ganglia daemon listens on TCP port 8649, and outputs all the current measurement 
// in XML to any connection on that port 
// This function collects the XML output from ganglia and stores in in a file
int CollectGangliaOutput2(char *fName)
{
        char command1[MAXBUFLEN], command2[MAXBUFLEN];
        sprintf(command1, "rm -f %s", fName);
        sprintf(command2, "telnet localhost 8649 > %s", fName);
	if (system(command1) <0) {
		printf("Error in executing.. %s\n", command1);
		return -1;
	}
	if (system(command2) < 0) {
		printf("Error in executing.. %s\n", command2);
		return -1;
	}

	return 1;

}

/*
int CollectGangliaOutput3(char *fName)
{
	int sockfd, n;
	struct sockaddr_in servaddr;
	char buffer[1024*32];
	FILE *fp;

	sockfd =  socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		return -1;
	bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(8649); // ganglia port
        inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr);
	if (connect(sockfd, (SA *) &servaddr, sizeof(servaddr)) < 0)
		return -1;

	if ( (fp = fopen(fName, "wt")) == NULL) {
		printf("Error in opening file: %s to write\n", fName);
		return -1;
	}

	for (;;) {
		if ( (n = Readline(sockfd, buffer, 1024*32))  ==0)
			break;
		fprintf(fp, "%s", buffer);
	}
	fclose(fp);

	close(sockfd);
	return 0;
}
*/

// This function connects to a server using a stream socket
// The data read from the server is writen into a file
int clientRead(char *sName, int sPort, char *outFile)
{
	int sockfd, numbytes;  
	char buf[MAXBUFLEN];
	struct hostent *he;
	struct sockaddr_in their_addr; // connector's address information 
	int port = sPort;
	FILE *fp;
	
	if ((he=gethostbyname(sName)) == NULL) {  // get the host info 
		perror("gethostbyname");
		return -1;
	}
	
	// if ( sscanf(sPort, "%d", &port) != 1) {
	//  perror("port number");
	//  return -1;
	//}
	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		return -1;
	}
	
	
	their_addr.sin_family = AF_INET;    // host byte order 
	their_addr.sin_port = htons(port);  // short, network byte order 
	their_addr.sin_addr = *((struct in_addr *)he->h_addr);
	memset(&(their_addr.sin_zero), '\0', 8);  // zero the rest of the struct 
	
	if (connect(sockfd, (SA *)&their_addr,
		    sizeof(struct sockaddr)) == -1) {
		perror("connect");
		close(sockfd);
		return -1;
	}
	
	if ( (fp = fopen(outFile, "wt")) == NULL) {
                perror("error in opening output file\n");
                return -1;
        }

	while ((numbytes=recv(sockfd, buf, MAXBUFLEN-1, 0)) != 0) {
		//buf[numbytes] = 0;
		//printf("%s", buf);
		fwrite(buf, 1, numbytes, fp);
	}
	
	fclose(fp);
	close(sockfd);
	
	return 0;
} 


int CollectGangliaOutput(char *fName) {
	return clientRead("127.0.0.1", 8649, fName);
}


// generate XML update to be sent to the OA
// return 1 on success, 0 on error
int GenXMLUpdate(PLConfType * pconf, char * xupdate)
{
	char line[MAXBUFLEN], *c, currentTime[MAXBUFLEN], attr[MAXBUFLEN], value[MAXBUFLEN], temp[MAXBUFLEN * 128], *p, *last;
	char gangliaAggr[MAXBUFLEN * 128] = "";
	FILE *fp = NULL, *slice_fp = NULL;
	int index, i;
	float fvalue;
	struct timeval tv;

	printf("Generating XUPDATE\n");

	assert (pconf != NULL);
	assert (xupdate != NULL);

	// initialize the xupdate command string
	strcpy(xupdate, "b 127.0.0.1 ");

	//----------- xupdate header
	strcat(xupdate, "<xupdate:modifications version=\"1.0\" xmlns:xupdate=\"http://www.xmldb.org/xupdate\">\n");

#ifdef DELETE	
	//-------- "remove" old element
	strcat(xupdate, "<xupdate:remove select=\"");
	strcat(xupdate, pconf->xpath);
	strcat(xupdate, "/node[@id='");
	strcat(xupdate, pconf->nodeName);
	strcat(xupdate, "']\"/>\n");
#endif
#ifdef ADD
	//--------- "add" the new element
	gettimeofday(&tv, NULL);
	sprintf(currentTime, "%.0lf", tv.tv_sec * 1000.0 + tv.tv_usec/1000);

	strcat(xupdate, "<xupdate:append select=\"");
	strcat(xupdate, pconf->xpath);
	strcat(xupdate, "\" >	 <xupdate:element name=\"node\"><xupdate:attribute name=\"id\">");
	strcat(xupdate, pconf->nodeName);
	strcat(xupdate, "</xupdate:attribute><xupdate:attribute name=\"status\">ownsthis</xupdate:attribute>");

	strcat(xupdate, "<xupdate:attribute name=\"expiry\">");
        strcat(xupdate, currentTime);
        strcat(xupdate, "</xupdate:attribute>\n");
	
	strcat(xupdate, "<xupdate:attribute name=\"name\">");
	strcat(xupdate, pconf->hostName);
	strcat(xupdate, "</xupdate:attribute>\n");
	
	slice_fp = fopen (SLICESTAT_FILE, "rt");
	if (USE_SLICESTAT && (slice_fp != NULL)) {
		strcat(xupdate, "<sensor id=\"SLICESTAT\" status=\"ownsthis\">\n");
		while (fgets(line, MAXBUFLEN, slice_fp) != NULL) {
			if (strlen(line) < 40) continue; // invalid line
			c = strtok_r(line, " ,\n", &last);
			if (c == NULL) break;
			sprintf(temp, "<SLICE status=\"ownsthis\" id=\"%s\"", c);
			strcat(xupdate, temp);
			i = 1; 
			c = strtok_r(NULL, " ,\n", &last);
			while ( (i < SSTAT_COUNT) && (c != NULL)) {
				sprintf(temp, " %s=\"%s\"", slicestat_attrs[i], c);
				strcat(xupdate, temp);
				c = strtok_r(NULL, " ,\n", &last);
				i++;
			}
								    
			strcat(xupdate, "/>\n");
		}
		strcat(xupdate, "</sensor>");
		       
	};

	if (slice_fp != NULL) {
		fclose(slice_fp);
		slice_fp = NULL;
	} // if (USE_SLICESTAT)

	fp = fopen(pconf->gangFile, "rt");
	if (USE_GANGLIA && (fp != NULL)) {
		strcpy(gangliaAggr, "<sensor id=\"gangaggr\" status=\"ownsthis\"");
		// parse the ganglia output file, and add relevant part to the xupdate command
		// find the first line containing pconf->hostName
		while (fgets(line, MAXBUFLEN, fp) != NULL)
			if (strstrcase(line, pconf->hostName)) break;
		
		// add the <GANGLIA> tag
		strcat(xupdate, "<sensor id=\"ganglia\" status=\"ownsthis\"");
		c = strstr(line, "HOST");
		strcat(xupdate, c+4);
		
		// add all the <METRIC> element
		while (fgets(line, MAXBUFLEN, fp) != NULL) {
			if (strstr(line, "METRIC")) {
				c = strstr(line, "NAME");
				// copy the attribute
				while (*c != '\"') c++; c++;
				p = attr;
				while (*c != '\"')
					*p++ = *c++;
				*p = '\0';
				
				// copy the value
				c = strstr(line, "VAL");
				while (*c != '\"') c++; c++;
				p = value;
				while (*c != '\"')
					*p++ = *c++;
				*p = '\0';
				
				sprintf(temp, "<METRIC id=\"%s\" status=\"ownsthis\" NAME=\"%s\" VAL=\"%s\">", attr, attr, value);
				strcat(xupdate, temp);
				sprintf(temp, " %s=\"%s\"", attr, value);
                                strcat(gangliaAggr, temp);

				if (USE_HISTORY) {
					sprintf(temp, "<VALUE NAME=\"LATEST\">%s</VALUE>", value);
					strcat(xupdate, temp);
				}
				if ((index=metricIndex(attr)) >= 0) {
					sscanf(value, "%f", &fvalue);
					addToHistoricalQueue(index, fvalue);
					if (USE_HISTORY) {
						printHistoricalQueue(index, temp);
						strcat(xupdate, temp);
					}
				}
				strcat(xupdate, "</METRIC>\n");
			}
			else {
				// add the closing </HOST> tag
				// strcat(xupdate, line); // already closed the tag, see (*** 1 ***)
				//strcat(xupdate, "</sensor>\n");
				break;
			}
		}
		strcat(xupdate, "</sensor>\n");
		strcat(gangliaAggr, " />");
		strcat(xupdate, gangliaAggr);
	};

	if (fp != NULL) {
		fclose(fp);
		fp = NULL;
	}// if (USE_GANGLIA)

	strcat(xupdate, "</xupdate:element> </xupdate:append>");
#endif
	//----------- xupdate footer
	strcat(xupdate, "</xupdate:modifications>");

	strcat(xupdate, " ENDMESSAGE");

	if (fp!= NULL ) fclose(fp);
	if (slice_fp != NULL) fclose(slice_fp);

	return 1;

}

//extern "C" {

// return 1 if no error
// return 0 on error
int Start(FilterParameter param)
{
#define BACKUPTIME 10
	PLConfType pconf;
	char xupdate[128 * 1024];
	int sockfd;
	int lastBackup = 0;
	int hbLoop = 0;

	printf("PlanetLab Monitoring Application starting...\n");

	if (InitConfiguration("pl.conf", &pconf) == 0) {
		printf("PL(): Configuration initialization error.\n");
		return 0;
	}
	
	initHistoricalQueue();
	if (loadHistoricalQueue("ganglia.history") == 0) { // see if there is any backup
		printf("Historical Queue loaded\n");
	}

	for (;;){

	        CollectGangliaOutput(pconf.gangFile);
		//CollectGanglia(pconf.gangFile);
		CollectSliceStat(SLICESTAT_FILE);
		GenXMLUpdate(&pconf, xupdate);
		if (displayFlag)
			printf("%s\n==========================================\n", xupdate);
		
		// send XML Update to OA
		sockfd = ConnectToOA(param.oa);
  		if (sockfd >= 0) {
			SendToOA(sockfd, xupdate);
			close(sockfd);
#ifndef LOOP
			exit(1); 
#endif
			lastBackup++;
			if (lastBackup >= BACKUPTIME) {
				writeHistoricalQueue("ganglia.history");
				lastBackup = 0;
			}
		}	
		
		
		if (hbLoop == 0 && hb_port >0) {
			sendTCPPacket(hb_ip, hb_port, "ALIVE");
		}
		
		hbLoop ++;
		if (hbLoop >= 3) // send hearbeat every 3rd time
			hbLoop = 0;
		sleep(pconf.sleepTime);
	}
	
	printf("PL(): Exiting application...\n");
	return 1;
}

//} // end extern c


int main(int argc, char* argv[])
{
	FilterParameter param;
	OrgAgent oa;

	if (argc < 3) {
		printf("Usage: %s <OA_IP> <OA_PORT> [DISPLAY_FLAG] [<HEARTBEAT_IP> <HEARTBEAT_PORT>]\n", argv[0]);
		return -1;
	}
	oa.port = atoi(argv[2]);
	if ( (inet_pton(AF_INET, argv[1], & (oa.addr))) <= 0) {
		printf("Error in parsing IP address\n");
		return -1;
	}

	if (argc >= 4) {
		sscanf(argv[3], "%d", &displayFlag);
	}
	
	if (argc == 6) {
		strcpy(hb_ip, argv[4]);
		hb_port = atoi(argv[5]);
	}
	
	//initHistoricalQueue();
	param.oa = &oa;
	//param.shmKey = IMAGE_SHM_KEY;
	strcpy(param.confFile, "pl.conf");
	Start(param);

	return 0;
}


