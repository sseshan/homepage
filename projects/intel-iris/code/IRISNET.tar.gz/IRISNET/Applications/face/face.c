/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
//
// The full "Square Detector" program.
// It loads several images subsequentally and tries to find squares in
// each image
//
#include "unp.h"
#include "cv.h"
#include "highgui.h"
#include "ipp.h"
#include "SACommon.h"
#include "filter.h"
#include <sys/shm.h>
#include <math.h>

int thresh = 50;
IplImage* img = 0;
IplImage* img0 = 0;
CvMemStorage* storage = 0;
CvPoint pt[4];





// finds the index of the image in the "imagelist" that is the closest
// 1-neighbor of "image". "imagelist" is the list previously loaded
// images. "listLen" is the length of the image;
int FindBestMatch(IplImage *image, IplImage **imageList, int listLen)
{
  int i, bestMatch;
  double diff, minDiff;

  for (i = 0; i<listLen; i++)
    {
      diff = MyAbsImageDiff_8u_C1R(image, imageList[i]);
      //printf("%lf ", diff);
      if ( (i == 0) || (diff < minDiff)){ 
	bestMatch = i;
	minDiff = diff;
      }
    }
  //printf("\n");
  return bestMatch;
}



// The function loadImage loads all the images in the database. 
// These are the images that will be compared to the test image.
// confFile is the configuration file that lists the image files
// the images will be converted to gray image before being loaded
IplImage** LoadImages(char *confFile, int *listLen)
{
  FILE *fp;
  char st[256], fname[256];
  int num, i;
  IplImage **imageList, *tmpImage;
  
  if ( (fp = fopen(confFile, "rt")) == NULL) {
    printf("Can't open the configuration file in loadImage()\n");
    return NULL;
  }

  fgets(st, 256, fp);
  if (sscanf(st, "%d", &num) != 1) {
    printf("Invalid format of the configuration file in loadImage()\n");
    return NULL;
  }

  imageList = (IplImage **) calloc(num, sizeof(IplImage*));

  for (i = 0; i<num; i++)
    {
      fgets(st, 256, fp);
      sscanf(st, "%s", fname);
      tmpImage = cvvLoadImage(fname);
      if (!tmpImage) break;
      imageList[i] = MyColorToGray(tmpImage, 0);
      cvReleaseImage(&tmpImage);
    }

  *listLen = num;
  return imageList;
      
}

// all the images should be in gray scale
void RecognizeFaces(IplImage *image, IplImage **imageList, int listLen, IplImage *colorImage, char** desc)
{
  CvSeq *squares;
  CvRect roi;
  CvPoint pt[4],  pt1[4], *ptList = pt1;
  IplImage *part;
  int bestMatch, i;
  CvSeqReader  reader; 
  IplImage *tmp;
  int count = 4;	
  int x1, y1, x2, y2;

  if (image == NULL || imageList == NULL)
    {
      printf("Null image\n");
      return ;
    }
  // initialize reader of the sequence  

  squares = FindUniqueSquares4(image, 50);
  cvStartReadSeq( squares, &reader, 0 );

  cvvNamedWindow("faces", 1);
  ptList = pt1;

  for( i = 0; i < squares->total; i += 4 )
    {
             
        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );

	x1 = max(pt[0].x, pt[1].x);
	y1= max(pt[0].y, pt[3].y);
	x2 = min(pt[2].x, pt[3].x);
	y2 = min(pt[1].y, pt[2].y);
	pt1[0].x = x1; pt1[0].y = y1;
	pt1[1].x = x1; pt1[1].y = y2;
	pt1[2].x = x2; pt1[2].y = y2;
	pt1[3].x = x2; pt1[3].y = y1;
	roi.x = x1;
	roi.y = y1;
	roi.height = y2 - y1; if (roi.height < 0) roi.height = -roi.height;
	roi.width = x2 - x1; if (roi.width < 0) roi.width = -roi.width;

	part = GetImagePart(image, roi);
	bestMatch = FindBestMatch(part, imageList, listLen);

	printf("[%s: (%d %d) (%d %d)] ", desc[bestMatch], pt[0].x, pt[0].y, 
pt[1].y-pt[0].y, pt[2].x-pt[1].x);

	//printf("Image recognized as : %s\n", desc[bestMatch]);
	tmp = cvCloneImage(colorImage);
	cvPolyLine( tmp, &ptList, &count, 1, 1, CV_RGB(255, 0, 0), 8, 8 );
	cvvShowImage("faces", tmp);
	//cvvWaitKey(0);
	//cvReleaseImage(&tmp);
	//cvReleaseImage(&part);
    }
    printf("\n");
}


int Start(FilterParameter param)
{
  //int i;
  //  FILE *fp;
  //  int num_img;
  //  char tmp[1024], fname[1024];
    IplImage *image0 = 0, *image1 = 0;
    //CvSeq *squares;  *uniqueSquares;
    //CvMemStorage *storage1, *storage2;
    IplImage **imageList;
    int listLen, step, shmid;
    char *imageDesc[] = {"Suman", "Phil", "Srini"};
    CvSize size;
    shmHeaderType *shmHeader;
    uchar *shm;

/*		
	image0 = cvvLoadImage("snapshot.bmp");
	printf("Depth: %d, nchann: %d, alphachan: %d\n", image0->depth, image0->nChannels, 
image0->alphaChannel);
	return 1;
*/
    imageList = LoadImages("face_list", &listLen);
    //printf("%d Images loaded\n", listLen);
      	//image0 = cvvLoadImage(argv[2]);
    shmid = shmget(param.shmKey, 1228860, 0777);
    if (shmid < 0) {
      printf( "Error in opening shared segment");
      return 0;
    }
    shm = (uchar*) shmat(shmid, 0,  0);
    shmHeader = (shmHeaderType*)shm;

cvvNamedWindow("test", 1);
    
    step = shmHeader->bytesPerPixel;
    size.width = shmHeader->width;
    size.height = shmHeader->height;
    image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
    for (;;) 
  {
      image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
      cvSetImageData(image0, (uchar*) (shm + shmHeader->offsets[shmHeader->buffHead]), step * shmHeader->width);

      image1 = MyColorToGray(image0, 1);
      cvvShowImage("test", image1);

      RecognizeFaces( image1, imageList, listLen, image0, imageDesc);
      cvReleaseImage(&image1);
      sleep(2);
    }	
    shmdt(shm);
    return 0;
}

