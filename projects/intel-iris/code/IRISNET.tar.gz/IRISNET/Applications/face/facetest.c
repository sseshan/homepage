/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
//
// The full "Square Detector" program.
// It loads several images subsequentally and tries to find squares in
// each image
//
#include "unp.h"
#include "cv.h"
#include "highgui.h"
#include "ipp.h"
#include "SA.h"
#include "filter.h"
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>

int thresh = 50;
IplImage* img = 0;
IplImage* img0 = 0;
CvMemStorage* storage = 0;
CvPoint pt[4];
CvMemStorage *storage1, *storage2;
struct rusage r1, r2;

void pr_rusage(FILE *fp, char *pre, struct rusage r)
{
  fprintf(fp, "%s: user: %7.3f , sys: %7.3f , maxrss: %ld , ixrss: %ld , idrss: %ld , isrss: %ld , minflt: %ld , majflt: %ld , nswap: %ld , inblock: %ld , oublock: %ld , msgsnd: %ld , msgrcv: %ld , nsignals: %ld , nvcsw: %ld , nivcsw: %ld\n", pre, r.ru_utime.tv_sec + r.ru_utime.tv_usec/1000000.0, r.ru_stime.tv_sec + r.ru_stime.tv_usec/1000000.0, r.ru_maxrss, r.ru_ixrss, r.ru_idrss, r.ru_isrss, r.ru_minflt, r.ru_majflt, r.ru_nswap, r.ru_inblock, r.ru_oublock, r.ru_msgsnd, r.ru_msgrcv, r.ru_nsignals, r.ru_nvcsw, r.ru_nivcsw);   
}

void pr_times(FILE *fp, char *pre, clock_t real, struct tms *tmsstart, struct tms *tmsend)
{
  static double clktck = 0;

  if (clktck == 0)
    if ( (clktck = sysconf(_SC_CLK_TCK)) < 0) {
      printf("Error in detecting _SC_CLK_TCK_); time will be reported in clock ticks\n");
      clktck = 1;
    }

  fprintf(fp, "%s real: %7.2f , user: %7.2f , sys: %7.2f , child_user: %7.2f , child_sys: %7.2f\n", pre,  real/clktck, (tmsend->tms_utime - tmsstart->tms_utime)/clktck, (tmsend->tms_stime - tmsstart->tms_stime)/clktck, (tmsend->tms_cutime - tmsstart->tms_cutime)/clktck, (tmsend->tms_cstime - tmsstart->tms_cstime)/clktck);  
}

#define dot(a,b) (a.x*b.x + a.y*b.y)
#define abs(x) ((x) > 0 ? (x) : (-(x)))

// helper function:
// finds a cosine of angle between vectors
// from pt0->pt1 and from pt0->pt2 
double angle( CvPoint pt1, CvPoint pt2, CvPoint pt0 )
{
  double a;
  pt1.x -= pt0.x;
  pt2.x -= pt0.x;
  pt1.y -= pt0.y;
  pt2.y -= pt0.y;
  a = dot(pt1,pt2)/sqrt((double)dot(pt1,pt1)*dot(pt2,pt2) + 1e-10);
  return a;
}

// returns sequence of squares detected on the image.
// the sequence is stored in the specified memory storage
CvSeq* FindSquares4( IplImage* img, CvMemStorage* storage )
{
  CvSeq* contours;
  int i, c, l, N = 11;
  int thresh = 50; 
  CvPoint pt[4];

  clock_t start, end;
  struct tms tmsstart, tmsend;

  CvSize sz = cvSize( img->width & -2, img->height & -2 );
  IplImage* timg = cvCloneImage( img ); // make a copy of input image
  IplImage* gray = cvCreateImage( sz, 8, 1 ); 
  IplImage* tgray;
  
  // create empty sequence that will contain points -
  // 4 points per square (the square's vertices)
  CvSeq* squares = cvCreateSeq( 0, sizeof(CvSeq), sizeof(CvPoint), storage );


  start = times(&tmsstart);
  
  // select the maximum ROI in the image
  // with the width and height divisible by 2
  cvSetImageROI( timg, cvRect( 0, 0, sz.width, sz.height )); 
  tgray = cvCreateImage( sz, 8, 1 );
  
  // find squares in every color plane of the image
  for( c = 0; c < 1; c++ )
    {
      // extract the c-th color plane
      //cvSetImageCOI( timg, c+1 );
      cvCopy( timg, tgray, 0 );
      
      // try several threshold levels
        for( l = 0; l < N; l++ )
	  {
            // hack: use Canny instead of zero threshold level.
            // Canny helps to catch squares with gradient shading 	
            if( l == 0 )
	      {
                // apply Canny. Take the upper threshold from slider
                // and set the lower to 0 (which forces edges merging) 
                cvCanny( tgray, gray, 0, thresh, 5 );
                // dilate canny output to remove potential
                // holes between edge segments 
                cvDilate( gray, gray, 0, 1 );
	      }
            else
	      {
                // apply threshold if l!=0:
                //     tgray(x,y) = gray(x,y) < (l+1)*255/N ? 255 : 0
                cvThreshold( tgray, gray, (l+1)*255/N, 255, CV_THRESH_BINARY );
	      }
            
            // find contours and store them all as a list
            cvFindContours( gray, storage, &contours, sizeof(CvContour),
			    CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );
            
	    //end = times(&tmsend);
	    //pr_times(stdout, "findContour: ", end-start, &tmsstart, &tmsend);

            // test each contour
            while( contours )
            {
	      // approximate contour with accuracy proportional
	      // to the contour perimeter
	      CvSeq* result = cvApproxPoly( contours, sizeof(CvContour), storage,
					    CV_POLY_APPROX_DP, cvContourPerimeter(contours,CV_WHOLE_SEQ)*0.02, 0 );
	      //end = times(&tmsend);
	      //pr_times(stdout, "approxPoly: ", end-start, &tmsstart, &tmsend);
	      // square contours should have 4 vertices after approximation
	      // relatively large area (to filter out noisy contours)
	      // and be convex.
	      // Note: absolute value of an area is used because
	      // area may be positive or negative - in accordance with the
	      // contour orientation
	      if( result->total == 4 &&
		  fabs(cvContourArea(result,CV_WHOLE_SEQ)) > 1000 &&
		  cvCheckContourConvexity(result) )
                {
		  double s = 0, t;
		  
		  for( i = 0; i < 5; i++ )
                    {
		      // store all the contour vertices in the buffer
		      pt[i&3] = *(CvPoint*)cvGetSeqElem( result, i, 0 );
		      // and find minimum angle between joint
		      // edges (maximum of cosine)
		      if( i >= 2 )
				 {
					 t = fabs(angle( pt[i&3], pt[(i-2)&3], pt[(i-1)&3]));
					 s = MAX( s, t );
				 }
                    }
		  
		  // if cosines of all angles are small
		  // (all angles are ~90 degree) then write quandrange
		  // vertices to resultant sequence 
		  if( s < 0.3 ) {
			  for( i = 0; i < 4; i++ )
				  cvSeqPush( squares, pt + i );
		  }
                }
	      
	      // take the next contour
	      contours = contours->h_next;
            }
	  }
    }
  
  // release all the temporary images
  cvReleaseImage( &gray );
  //cvReleaseImage( &pyr );
  cvReleaseImage( &tgray );
  cvReleaseImage( &timg );
  
  return squares;
}


int Equal(CvPoint a, CvPoint b, int THR)
{
  return ( (abs(a.x - b.x) <= THR) && (abs(a.y - b.y) <= THR));
}

// sort the list of points clockwise
void SortPoints(CvPoint *a)
{
	CvPoint center = {0, 0}, pt[4];
	int i;

	for (i = 0; i<4; i++) {
		pt[i] = a[i];
		center.x += a[i].x;
		center.y += a[i].y;
	}

	center.x /= 4;
	center.y /= 4;

	for (i = 0; i<4; i++)
		{
			if (pt[i].x < center.x && pt[i].y <center.y) a[0] = pt[i];
			else if (pt[i].x < center.x && pt[i].y >= center.y) a[1] = pt[i];
			else if (pt[i].x >= center.x && pt[i].y >= center.y) a[2] = pt[i];
			else a[3] = pt[i];
		}
	
}

// sort the list of points. This helps to decide if two recatngles are unique
void SortPoints1(CvPoint* a)
{
  int i, j;
  CvPoint tmp;
  
  for (i = 0; i<4; i++)
    for (j = i+1; j<4; j++)
      {
	if ( (a[i].x > a[j].x) || ((a[i].x == a[j].x) && (a[i].y > a[j].y)))
	  {
	    tmp = a[i];
	    a[i] =a[j];
	    a[j] = tmp;
	  }
      }
}

// this function counts the unique squeares in the contour; the OpenCV 
// routines find multiple contours around each rectangles. The coutours 
// for one particular rectangle are close to each other - may be 2/3 pixels 
// apart from each other. This functions considers those coutours as one, 
// and count such "unique" countours

CvSeq* ListUniqueSquares (CvSeq* squares, int THR, CvMemStorage *storage)
{
  // allocate memory for the maximum number of unique coordinates
  CvPoint *points = (CvPoint *) calloc(squares->total, sizeof (CvPoint));
  int numUnique = 0, isUnique, i, j, k;
  CvPoint pt[4]; 
  CvSeqReader  reader;	
  

  CvSeq* uniqueSquares = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvPoint), storage);

  
  // initialize reader of the sequence  
  cvStartReadSeq( squares, &reader, 0 );
  
  for (i = 0; i<squares->total; i+= 4)
    {
      isUnique = 1;
      
      // read 4 vertices
      CV_READ_SEQ_ELEM( pt[0], reader );
      CV_READ_SEQ_ELEM( pt[1], reader );
      CV_READ_SEQ_ELEM( pt[2], reader );
      CV_READ_SEQ_ELEM( pt[3], reader ); 
      // printf("(%d %d) (%d %d) (%d %d) (%d %d)\n", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y, pt[3].x, pt[3].y);
      SortPoints(pt);
      // check if the currect rectangles appeared before
      for (j = 0; j< numUnique; j++)
   	{
	  SortPoints(points+j*4);
	  if ( 	(Equal(pt[0], points[j*4], THR)) &&
		(Equal(pt[1], points[j*4 + 1], THR)) &&
		(Equal(pt[2], points[j*4 + 2], THR)) &&
		(Equal(pt[3], points[j*4 + 3], THR)) ) {
	    isUnique = 0;
	    break;
	  }			
   	}	
	
	// get rid of duplicates
	// ignore the outer border, which is basically the border of the whole image
      if ( (isUnique) 
	&& (pt[0].x>2 && pt[0].y > 2) 
	// && (abs(pt[1].x - pt[0].x) > 20) 
	// && (abs(pt[2].y - pt[1].y) > 20)
	) {
		 for (k = 0; k<4; k++) {
			 points[numUnique*4 + k] = pt[k];
			 cvSeqPush(uniqueSquares, pt + k);
		 }
		 numUnique ++;
	 }
    }
  
  free(points);
  return uniqueSquares;
}


// finds unique square in an image. 
CvSeq* FindUniqueSquares4(IplImage* image, int threshold)
{

  clock_t start, end;
  struct tms tmsstart, tmsend;

	CvSeq *list, *list1;
	//sk: CvMemStorage *storage1, *storage2;
	//sk:storage1 = cvCreateMemStorage(0);
	//sk: storage2 = cvCreateMemStorage(0);
	start = times(&tmsstart);
	list = FindSquares4(image, storage1);
	end = times(&tmsend);

	//pr_times(stdout, "findsq: ", end-start, &tmsstart, &tmsend);
	return  ListUniqueSquares(list, threshold, storage2);
}

// the function draws all the squares in the image
void DrawSquares( IplImage* img, CvSeq* squares )
{
    CvSeqReader reader;
    IplImage* cpy = cvCloneImage( img );
    int i;
    CvPoint pt[4];

    // initialize reader of the sequence
    cvStartReadSeq( squares, &reader, 0 );
    
    // read 4 sequence elements at a time (all vertices of a square)
    for( i = 0; i < squares->total; i += 4 )
    {
        CvPoint* rect = pt;
        int count = 4;
        
        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );
        
        // draw the square as a closed polyline 
        cvPolyLine( cpy, &rect, &count, 1, 1, 100, 1, 2 );
    }
    
    // show the resultant image
    cvvShowImage("image",cpy);
    cvReleaseImage( &cpy );
}


void NormalizeIntensity(IplImage* ipl_image, int level)
{
  CvSize roi;
  int step, width, height, i, j, mean, newval;
  uchar *img;

  if (level < 1 || level > 255) return ;

  cvGetImageRawData(ipl_image, &img, &step, &roi);
  
  width = roi.width;
  height = roi.height;
  
  mean = (int)cvMean(ipl_image, 0);
  
  // normalize to 128
  for (i = 0; i<height; i++, img += step)
    {
      for (j = 0; j<width*3; j++) 
	{
	  newval = img[j] + level - mean;
	  newval = (newval < 0) ? 0 : newval;
	  newval = (newval > 255) ? 255 : newval;
	  img[j] = newval;
	}
    }
}


IplImage* GetImagePart( IplImage* img, CvRect roi )
{
  IplImage* part = cvCreateImageHeader( cvGetSize(img), img->depth, img->nChannels );
  cvSetImageData( part, img->imageData, img->widthStep );
  cvSetImageROI( part, roi );
  return part;
}


IplImage *MyColorToGray(IplImage *src, int flag)
{
  int srcStep, dstStep;
  CvSize roi;
  uchar *srcData, *dstData;
  IppiSize srcROI;


  IplImage *dst;

  cvGetImageRawData(src, &srcData, &srcStep, &roi);
  srcROI.width = roi.width;
  srcROI.height = roi.height;

  dst = cvCreateImage(roi, 8, 1); // create a 8-bit, 1-channel gray image
  cvGetImageRawData(dst, &dstData, &dstStep, &roi);

  if (!flag) ippiRGBToGray_8u_C3C1R(srcData, srcStep, dstData, dstStep,  
srcROI);
	else ippiRGBToGray_8u_AC4C1R(srcData, srcStep, dstData, dstStep,  srcROI);
  return dst;
}

IplImage *MyScaleImage_8u_C1R(IplImage* srcImg, int dstWidth, int dstHeight)
{
  int srcStep, dstStep;
  uchar *srcData, *dstData;
  CvSize srcRoi, dstRoi;
  double xScale, yScale;
  IppiRect rect;
  IplImage *dstImg;
  IppiSize srcROI, dstROI;
  


  cvGetImageRawData(srcImg, &srcData, &srcStep, &srcRoi);
  srcROI.width = srcRoi.width;
  srcROI.height = srcRoi.height;

  xScale = dstWidth / (srcRoi.width * 1.0);
  yScale = dstHeight / (srcRoi.height * 1.0);

  dstRoi.width = dstROI.width = dstWidth;
  dstRoi.height = dstROI.height = dstHeight;

 
  dstImg = cvCreateImage(dstRoi, srcImg->depth, srcImg->nChannels);
  cvGetImageRawData(dstImg, &dstData, &dstStep, &dstRoi); 
  rect.x = 0; rect.y = 0; rect.width = srcRoi.width; rect.height = srcRoi.height;
  ippiResize_8u_C1R(srcData, srcROI, srcStep, rect, dstData, dstStep, dstROI,xScale, yScale, IPPI_INTER_LINEAR);

  return dstImg;
  
}

double MyAbsImageDiff_8u_C1R(IplImage* img1, IplImage* img2)
{
  IplImage *image1, *image2, *image;
  CvSize roi1, roi2, roi;
  int step1, step2;
  uchar *data1, *data2;
  double result;
  int flag = 0;

  cvGetImageRawData(img1, &data1, &step1, &roi1);
  cvGetImageRawData(img2, &data2, &step2, &roi2);
  

  // scale both the images to the same size
  if (roi1.width > roi2.width) {
    roi = roi2;
    image1 = MyScaleImage_8u_C1R(img1, roi.width, roi.height);
    flag = 1;
    image2 = img2;
  }
  else {
    roi = roi1;
    image1 = img1;
    image2 = MyScaleImage_8u_C1R(img2, roi.width, roi.height);
    flag = 2;
  }

 
  image = cvCreateImage(roi, image1->depth, image1->nChannels);
  //cvGetImageRawData(image, &data, &step, &roi);

  //ROI.width = roi.width; ROI.height = roi.height;
  cvAbsDiff(image1, image2, image);
  result = cvMean(image, 0);
  cvReleaseImage(&image);
  if (flag == 1) cvReleaseImage(&image1);
  if (flag == 2) cvReleaseImage(&image2); 
  return result;
  //ippiAbsDiff_8u_C1R(data1, step1, data2, step2, data, step, ROI);


}

// finds the index of the image in the "imagelist" that is the closest
// 1-neighbor of "image". "imagelist" is the list previously loaded
// images. "listLen" is the length of the image;
int FindBestMatch(IplImage *image, IplImage **imageList, int listLen)
{
  int i, bestMatch;
  double diff, minDiff;

  for (i = 0; i<listLen; i++)
    {
      diff = MyAbsImageDiff_8u_C1R(image, imageList[i]);
      //printf("%lf ", diff);
      if ( (i == 0) || (diff < minDiff)){ 
	bestMatch = i;
	minDiff = diff;
      }
    }
  //printf("\n");
  return bestMatch;
}



// The function loadImage loads all the images in the database. 
// These are the images that will be compared to the test image.
// confFile is the configuration file that lists the image files
// the images will be converted to gray image before being loaded
IplImage** LoadImages(char *confFile, int *listLen)
{
  FILE *fp;
  char st[256], fname[256];
  int num, i;
  IplImage **imageList, *tmpImage;
  
  if ( (fp = fopen(confFile, "rt")) == NULL) {
    printf("Can't open the configuration file in loadImage()\n");
    return NULL;
  }

  fgets(st, 256, fp);
  if (sscanf(st, "%d", &num) != 1) {
    printf("Invalid format of the configuration file in loadImage()\n");
    return NULL;
  }

  imageList = (IplImage **) calloc(num, sizeof(IplImage*));

  for (i = 0; i<num; i++)
    {
      fgets(st, 256, fp);
      sscanf(st, "%s", fname);
      tmpImage = cvvLoadImage(fname);
      if (!tmpImage) break;
      imageList[i] = MyColorToGray(tmpImage, 0);
      cvReleaseImage(&tmpImage);
    }

  *listLen = num;
  return imageList;
      
}

// all the images should be in gray scale
void RecognizeFaces(IplImage *image, IplImage **imageList, int listLen, IplImage *colorImage, char** desc)
{
  CvSeq *squares;
  CvRect roi;
  CvPoint pt[4],  pt1[4], *ptList = pt1;
  IplImage *part;
  int bestMatch, i;
  CvSeqReader  reader; 
  IplImage *tmp;
  int count = 4;	
  int x1, y1, x2, y2;

  if (image == NULL || imageList == NULL)
    {
      printf("Null image\n");
      return ;
    }
  // initialize reader of the sequence  

  squares = FindUniqueSquares4(image, 50); 
  cvStartReadSeq( squares, &reader, 0 );
  
  cvvNamedWindow("faces", 1);
  ptList = pt1;

  for( i = 0; i < squares->total; i += 4 )
    {
             
        // read 4 vertices
        CV_READ_SEQ_ELEM( pt[0], reader );
        CV_READ_SEQ_ELEM( pt[1], reader );
        CV_READ_SEQ_ELEM( pt[2], reader );
        CV_READ_SEQ_ELEM( pt[3], reader );

	x1 = max(pt[0].x, pt[1].x);
	y1= max(pt[0].y, pt[3].y);
	x2 = min(pt[2].x, pt[3].x);
	y2 = min(pt[1].y, pt[2].y);
	pt1[0].x = x1; pt1[0].y = y1;
	pt1[1].x = x1; pt1[1].y = y2;
	pt1[2].x = x2; pt1[2].y = y2;
	pt1[3].x = x2; pt1[3].y = y1;
	roi.x = x1;
	roi.y = y1;
	roi.height = y2 - y1; if (roi.height < 0) roi.height = -roi.height;
	roi.width = x2 - x1; if (roi.width < 0) roi.width = -roi.width;

	part = GetImagePart(image, roi);
	bestMatch = FindBestMatch(part, imageList, listLen);

	printf("[%s: (%d %d) (%d %d)] ", desc[bestMatch], pt[0].x, pt[0].y, 
pt[1].y-pt[0].y, pt[2].x-pt[1].x);

	cvReleaseImageHeader(&part);
	//printf("Image recognized as : %s\n", desc[bestMatch]);
	tmp = cvCloneImage(colorImage);
	cvPolyLine( tmp, &ptList, &count, 1, 1, CV_RGB(255, 0, 0), 8, 8 );
	cvvShowImage("faces", tmp);
	//cvvWaitKey(0);
	cvReleaseImage(&tmp);
	//cvReleaseImage(&part);
    }
    printf("\n");
}


int Start(FilterParameter param)
{
  int i;
  //  FILE *fp;
  //  int num_img;
  //  char tmp[1024], fname[1024];
    IplImage *image0 = 0, *image1 = 0;
    //CvSeq *squares;  *uniqueSquares;
    //CvMemStorage *storage1, *storage2;
    IplImage **imageList;
    int listLen, step, shmid;
    char *imageDesc[] = {"Suman", "Phil", "Srini"};
    CvSize size;
    shmHeaderType *shmHeader;
    uchar *shm;
    clock_t start, end;
    struct tms tmsstart, tmsend;


    storage1 = cvCreateMemStorage(0);
    storage2 = cvCreateMemStorage(0);

    imageList = LoadImages("face_list", &listLen);
    shmid = shmget(param.shmKey, 1228860, 0777);
    if (shmid < 0) {
      printf( "Error in opening shared segment");
      return 0;
    }
    shm = (uchar*) shmat(shmid, 0,  0);
    shmHeader = (shmHeaderType*)shm;

    //sk: cvvNamedWindow("test", 1);
    
    step = shmHeader->bytesPerPixel;
    size.width = shmHeader->width;
    size.height = shmHeader->height;
    //image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
    for (i = 0; i< 200; i++) {
      start  = times(&tmsstart);
      image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
      cvSetImageData(image0, (uchar*) (shm + shmHeader->offsets[shmHeader->buffHead]), step * shmHeader->width);

      image1 = MyColorToGray(image0, 1);
      //sk: cvvShowImage("test", image1);

      RecognizeFaces( image1, imageList, listLen, image0, imageDesc);
      cvReleaseImage(&image1);
      cvReleaseImageHeader(&image0);
      end = times (&tmsend);
      //pr_times(stdout, "face: ", end-start, &tmsstart, &tmsend);
      sleep(1);
      cvClearMemStorage(storage1);
      cvClearMemStorage(storage2);
    }	
    shmdt(shm);
    return 0;
}


int main()
{
 FilterParameter param;
 //struct timeval tvp1, tvp2;
 struct tms tmsstart, tmsend;
 clock_t start, end;

 
  start = times(&tmsstart);
 //gettimeofday(&tvp1, NULL);
 param.shmKey = IMAGE_SHM_KEY;
 Start(param);
 //gettimeofday(&tvp2, NULL);
 end = times(&tmsend);
  
 //pr_times(stdout, "time: ", end-start, &tmsstart, &tmsend);

 getrusage(RUSAGE_SELF, &r1);
 pr_rusage(stdout, "self usage", r1);
 return 0;
}
