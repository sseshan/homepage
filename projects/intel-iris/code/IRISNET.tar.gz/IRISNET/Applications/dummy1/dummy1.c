/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include "filter.h"
#include <stdio.h>
#include <unistd.h>

#include <sys/shm.h>

int Start(FilterParameter param)
{
	int i = 0;

	int key = 74;
	void * addr = 0;

	int shmid = shmget(key, 1, 0);
	if (shmid < 0) {
		fprintf(stderr, " Error getting shared memory id\n");
		perror("\n\n");
	}
	else
		printf("Successfully opened shared memory key %d\n", key);

	addr = shmat(shmid, NULL, 0);
	if ((int) addr == -1) {
		fprintf(stderr, "Error attaching shared memory\n");
		perror("\n\n");
	}
	else
		printf("Successfully attached shared memory to address %x\n", (unsigned int) addr);
	
	printf("My uid is %d, gid is %d\n", getuid(), getgid());
	
	
	while (1) {
		printf("Dummy1 running iteration %d.\n", i++);
		sleep(10);	
	}
}
