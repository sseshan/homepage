/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

//
// Common image processing functions
//
// Some more useful (top of file) than others (bottom of file)


/* Parts of FindSquares routines adapted from squares.c in OpenCV Samples */

// OpenCV
#include <cv.h>
#include <highgui.h>

// Our shared libraries
#include "imgproc.h"
#include "shmman.h"

// System includes
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

// generate debug code - need to fold into makefile.
#undef NDEBUG
#include <assert.h>

#define dot(a,b) (a.x*b.x + a.y*b.y)
#define max(a,b) ( ((a) > (b)) ? (a) : (b))
#define min(a,b) ( ((a) < (b)) ? (a) : (b))

//-------------------------------------------------------
// Co-occurance texture related functions
//-------------------------------------------------------

#define GRAY_QUANTIZED 16
#define GETGRAYPIXEL(i, j) (((uchar *)(image->imageData))[(i) + ((j)*image->widthStep)])
#define GETGRAYINDEX(i, j) ((i) + ((j)*image->widthStep))

// Displays IplImage on the screen
// Waits for key press
void DisplayIplImage(IplImage * image, const char * title)
{
	assert (image != NULL);
	assert (title != NULL);

	cvNamedWindow(title, 1);
	cvShowImage(title, image);
	cvResizeWindow(title, image->width + 1, image->height + 1);
}
	
// Creates IplImage, caller must release
// Gets the source image from shared memory
// Returned image is in 3 channels
// Returns NULL on error
IplImage * GetSrcImage()
{
	return GetSrcImageKey(IMAGE_SHM_KEY);
}

IplImage * GetSrcImageKey(int key)
{
	CvSize size;
	shmHeaderType *shmHeader = NULL;
	uchar *shm = NULL;
	int step = 0;

	// raw image straight from the shared mem
	IplImage *rawImage = NULL;
		
	// processed raw image - 3 channels only
	IplImage *srcImage = NULL;


	shm = (uchar *) OpenSharedMemoryKey(key);
		if (shm == NULL) {
		fprintf(stderr, "GetSrcImage(): Error opening shared memory.\n");
		return NULL;
	}


	shmHeader = (shmHeaderType *) shm;

	fprintf(stderr, "GetSrcImage(): Shared memory of size %d mapped to 0x%x\n",
		shmHeader->bufsize, (unsigned int) shm);

	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;

	rawImage = cvCreateImageHeader(size, IPL_DEPTH_8U, step);

	if (rawImage == NULL) {
		fprintf(stderr, "GetSrcImage(): Error creating image header\n");
		return NULL;
	}

	cvSetImageData(rawImage,
		(uchar *) (shm + shmHeader->offsets[shmHeader->buffHead]),
		step * shmHeader->width);

	// Converts 4 channels to 3 channels
	if (rawImage->nChannels == 4)
		srcImage = Cvt4to3(rawImage);
	else
		srcImage = cvCloneImage(rawImage);
	

	cvReleaseImageHeader(&rawImage);
	
	shmdt(shm);

	return srcImage;
}

IplImage * GetSrcImage(void * mem) {
	CvSize size;
	shmHeaderType *shmHeader = NULL;
	uchar *shm = (uchar *) mem;
	int step = 0;

	// raw image straight from the shared mem
	IplImage *rawImage = NULL;
		
	// processed raw image - 3 channels only
	IplImage *srcImage = NULL;

	shmHeader = (shmHeaderType *) shm;

	fprintf(stderr, "GetSrcImage(): Shared memory of size %d mapped to 0x%x\n",
		shmHeader->bufsize, (unsigned int) shm);

	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;

	rawImage = cvCreateImageHeader(size, IPL_DEPTH_8U, step);

	if (rawImage == NULL) {
		fprintf(stderr, "GetSrcImage(): Error creating image header\n");
		return NULL;
	}

	cvSetImageData(rawImage,
		(uchar *) (shm + shmHeader->offsets[shmHeader->buffHead]),
		step * shmHeader->width);

	// Converts 4 channels to 3 channels
	if (rawImage->nChannels == 4)
		srcImage = Cvt4to3(rawImage);
	else
		srcImage = cvCloneImage(rawImage);
	

	cvReleaseImageHeader(&rawImage);

	return srcImage;
}


// Creates and returns IplImage, caller must release
// convert a 4 channel image to 3 channel image, discarding the 4th channel
// returns NULL on error
IplImage * Cvt4to3(IplImage * image4)
{
	IplImage *plane0 = NULL,
		*plane1 = NULL,
		*plane2 = NULL,
		*plane3 = NULL;

	IplImage *image3 = NULL;

	int depth = 0;

	assert(image4 != NULL);

	depth = image4->depth;

	// create individual image planes
	CvSize size = cvSize(image4->width, image4->height);

	// create individual image planes
	plane0 = cvCreateImage(size, depth, 1);
	plane1 = cvCreateImage(size, depth, 1);
	plane2 = cvCreateImage(size, depth, 1);
	plane3 = cvCreateImage(size, depth, 1);


	// create destination image
	image3 = cvCreateImage(size, depth, 3);

	cvCvtPixToPlane(image4, plane0, plane1, plane2, plane3);
	cvCvtPlaneToPix(plane0, plane1, plane2, 0, image3);

	cvReleaseImage(&plane0);
	cvReleaseImage(&plane1);
	cvReleaseImage(&plane2);
	cvReleaseImage(&plane3);	

	return image3;
}

// converts 3 planes to 4 planes, with 4th plane equal 1st plane
IplImage *Cvt3to4(IplImage* image3) {
	IplImage *plane0 = NULL,
		*plane1 = NULL,
		*plane2 = NULL,
		*plane3 = NULL;

	IplImage *image4 = NULL;

	int depth = 0;

	assert(image3 != NULL);

	depth = image3->depth;

	CvSize size = cvSize(image3->width, image3->height);

	// create individual image planes
	plane0 = cvCreateImage(size, depth, 1);
	plane1 = cvCreateImage(size, depth, 1);
	plane2 = cvCreateImage(size, depth, 1);
	plane3 = cvCreateImage(size, depth, 1);

	// create destination image
	image4 = cvCreateImage(size, depth, 4);

	cvCvtPixToPlane(image3, plane0, plane1, plane2, plane3);
	cvCvtPlaneToPix(plane0, plane1, plane2, plane0, image4);

	cvReleaseImage(&plane0);
	cvReleaseImage(&plane1);
	cvReleaseImage(&plane2);
	cvReleaseImage(&plane3);

	return image4;	

}

// helper function:
// finds a cosine of angle between vectors
// from pt0->pt1 and from pt0->pt2 
double angle( CvPoint pt1, CvPoint pt2, CvPoint pt0 )
{
	double a;

	pt1.x -= pt0.x;
	pt2.x -= pt0.x;
	pt1.y -= pt0.y;
	pt2.y -= pt0.y;
	a = dot(pt1,pt2) / sqrt((double)dot(pt1,pt1) * dot(pt2,pt2) + 1e-10);

	return a;
}


// helper for FindSquares4
// If contour is a square, add it to square sequence
// squares are represented as sequences of 4 CvPoint per square
// *squares must be intialized
// *storage is a temporary storage that must be intialized by the caller
// return 0 on success, 1 on error
int ContourToSquare(CvSeq * contours, CvSeq * squares, CvMemStorage * storage)
{
	// result of cvApproxPoly
	CvSeq * result = NULL;
	int i = 0;
        CvPoint pt[4];

	assert(contours != NULL);
	assert(squares != NULL);
	assert(storage != NULL);

	// approximate contour with accuracy proportional
	// to the contour perimeter
	result = cvApproxPoly( contours, sizeof(CvContour),
			       storage, CV_POLY_APPROX_DP,
			       cvContourPerimeter(contours)*0.02,
			       0 );

	if (result == NULL)
		return 0;

	// square contours should have 4 vertices after
	// approximation relatively large area (to filter out
	// noisy contours) and be convex.
	// Note: absolute value of an area is used because
	// area may be positive or negative - in accordance
	// with the contour orientation
	if( result->total == 4 &&
	    fabs(cvContourArea(result,CV_WHOLE_SEQ)) > 1000 &&
	    cvCheckContourConvexity(result) ) {
		double s = 0, t;
		
		for( i = 0; i < 5; i++ ) {
			// store all the contour vertices in the buffer
			pt[i&3] = *(CvPoint*)cvGetSeqElem( result, i, 0 );
			// and find minimum angle between joint
			// edges (maximum of cosine)
			if( i >= 2 ) {
				t = fabs(angle( pt[i&3], pt[(i-2)&3], pt[(i-1)&3]));
				s = MAX( s, t );
			}
		}
		
		// if cosines of all angles are small
		// (all angles are ~90 degree) then write quandrange
		// vertices to resultant sequence 
		if( s < 0.3 ) {
			for( i = 0; i < 4; i++ )
				cvSeqPush( squares, pt + i );
		}
	}

	return 1;
}

// helper function for FindSquares4()
// Given a gray image, and a pixel intensity level,
// level must be between 0 and 255
// outputs any squares in founds in *squares
void FindSquaresInContourLevelN (IplImage * grayImage, int level,
				CvSeq * squares)
{
	CvSeq * contours = NULL;
        IplImage * tmpImage = NULL;
	CvSize size;
	CvMemStorage * tmpStorage = NULL;
	CvMemStorage * storage = NULL;
	
	int cannyHighThresh = 50;
	int cannyAperatureSize = 5;

	assert (grayImage != NULL);
	assert (squares != NULL);

	// tmpStorage created outside the inner loop to optimize
	// against excessive creation and deletion
	tmpStorage = cvCreateMemStorage(0);
	
	storage = cvCreateMemStorage(0);

        // set LSB to 0 so that width and height is even.
        size = cvSize( grayImage->width & -2, grayImage->height & -2 );
  
        // create temp image buffer
        tmpImage = cvCreateImage( size, IPL_DEPTH_8U, 1 );

	// hack: use Canny instead of zero threshold level.
	// Canny helps to catch squares with gradient shading         
	if( level == 0 ) {
		// apply Canny. Take the upper threshold from slider
		// and set the lower to 0 (which forces edges merging) 
		cvCanny( grayImage, tmpImage, 0, cannyHighThresh, cannyAperatureSize );
		
		// dilate canny output to remove potential
		// holes between edge segments 
		cvDilate( tmpImage, tmpImage, NULL, 1 );
	}
	else {
		// apply threshold if l!=0:
		cvThreshold( grayImage, tmpImage, level, 255, CV_THRESH_BINARY );
	}
	
	// find contours and store them all as a list
	cvFindContours( tmpImage, storage, &contours, sizeof(CvContour),
			CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );
	
	// test each contour
	while( contours ) {
		ContourToSquare(contours, squares, tmpStorage);
		
		// take the next contour
		contours = contours->h_next;
	}
	
	cvReleaseMemStorage(&tmpStorage);
	cvReleaseMemStorage(&storage);
        cvReleaseImage( &tmpImage );
}

// scales down and up the image to remove noise
// gets input from srcImage and writes output to dstImage
void RemoveNoiseFromImage(IplImage *srcImage, IplImage *dstImage)
{
        IplImage *smallImage = NULL;
        CvSize size;

	//set LSB to 0 so that width and height is even (round down)
	size = cvSize( srcImage->width & -2, srcImage->height & -2 );

	// down-scale and upscale the image to filter out the noise
	smallImage = cvCreateImage( cvSize(size.width/2, size.height/2),
				    srcImage->depth, srcImage->nChannels );

	cvPyrDown( srcImage, smallImage, IPL_GAUSSIAN_5x5 );
	cvPyrUp( smallImage, dstImage, IPL_GAUSSIAN_5x5 );

	cvReleaseImage(&smallImage);
}

// scales down and up the image to remove noise
// gets input from srcImage and writes output to dstImage
IplImage * HalfImage(IplImage *srcImage)
{
        IplImage *smallImage = NULL;
        CvSize size;
                                                                                
        //set LSB to 0 so that width and height is even (round down)
        size = cvSize( srcImage->width & -2, srcImage->height & -2 );
                                                                                
        // down-scale and upscale the image to filter out the noise
        smallImage = cvCreateImage( cvSize(size.width/2, size.height/2),
                                    srcImage->depth, srcImage->nChannels 
);
                                                                                
        cvPyrDown( srcImage, smallImage, IPL_GAUSSIAN_5x5 );
	
	return smallImage;
}


// CvSeq memory are never released back to storage.
// Caller must release storage memory to reclaim memory.
//
// returns sequence of squares detected on the image.
// the sequence is stored in the specified memory storage
// Each "real" square may be represented by lots of overlapping squares
// Caller will need to clean this up
//
// Returns sequence of CvPoint
// Every 4 points make up a square
// In a Top Origin coordinate system, the points are organized as follows:
// PT0--PT3
//  |    |
// PT1--PT2
//
// return NULL on error
CvSeq* FindSquares4( IplImage* srcImage, CvMemStorage* storage )
{
        int c, level, NLEVELS = 11;

        CvSize size;
        IplImage *timg = NULL;

        IplImage *grayImage = NULL;
        CvSeq * squares = NULL;

        assert (srcImage != NULL);
        assert (storage != NULL);

        // create empty sequence that will contain points -
        // 4 points per square (the square's vertices)
        squares = cvCreateSeq( CV_SEQ_ELTYPE_POINT, sizeof(CvSeq),
			       sizeof(CvPoint), storage );

	size = cvSize(srcImage->width, srcImage->height);

	timg = cvCreateImage(size, srcImage->depth, srcImage->nChannels);

	if (timg == NULL)
		return NULL;

	RemoveNoiseFromImage(srcImage, timg);

        grayImage = cvCreateImage( size, srcImage->depth, 1 );

	if (grayImage == NULL)
		return NULL;

	// try several threshold levels
	// a level represents a pixel intensity level from 0 to 255 
	for (level = 0; level < NLEVELS; level++) {
		int threshold = level * 255 / NLEVELS;

		if (timg->nChannels == 1) {
			// gray image
			FindSquaresInContourLevelN(timg, threshold, squares);
		} else {			
			// loop through every color plane of the image
			for (c = 0; c < timg->nChannels; c++) {
				// COI=0 means all channels
				cvSetImageCOI(timg, c+1);
				cvCopy( timg, grayImage, 0 );		
				FindSquaresInContourLevelN(grayImage,
							  threshold, squares);
			}
		}
	}

        cvReleaseImage( &grayImage );
        cvReleaseImage( &timg );
        
        return squares;
}


// See if two points are equal to a given threshold
int PtEqual(CvPoint a, CvPoint b, int THR)
{
	return ( (abs(a.x - b.x) <= THR) && (abs(a.y - b.y) <= THR) );
}

// sort the list of 4 points. This helps to decide if two rectangles are unique
// 
// Every 4 points make up a square
// In a Top Origin coordinate system, the points are organized as follows:
// PT0--PT3
//  |    |
// PT1--PT2
void SortPointsInRect(CvPoint *a)
{
	CvPoint center = cvPoint(0, 0);
	CvPoint pt[4];
	int i;

	assert (a != NULL);

	// copy the 4 points
	// and calculate the center of the rectangle
	for (i = 0; i < 4; i++) {
		pt[i] = a[i];
		center.x += a[i].x;
		center.y += a[i].y;
	}

	center.x /= 4;
	center.y /= 4;

	for (i = 0; i < 4; i++) {
		if (pt[i].x < center.x && pt[i].y <center.y)
			a[0] = pt[i];
		else if (pt[i].x < center.x && pt[i].y >= center.y)
			a[1] = pt[i];
		else if (pt[i].x >= center.x && pt[i].y >= center.y)
			a[2] = pt[i];
		else a[3] = pt[i];
	}
}

// CvSeq memory are never released back to storage.
// Caller must release storage memory to reclaim memory.
//
// helper routine, called from FindUniqueSquares
// squares is a CvSeq of CvPoint (4 points per square)
// creates a new CvSeq of unique squares, with a given Threshold
// *squares will be stored in *storage
//
// Returns NULL on error
CvSeq* ListUniqueSquares (CvSeq* squares, int THR, CvMemStorage *storage)
{

	CvPoint *points = NULL;
	int numUnique = 0;
	int i, j, k;
	CvSeqReader reader;	
	CvSeq * uniqueSquares = NULL;
	
	assert (squares != NULL);
	assert (storage != NULL);
	
	// allocate memory for the maximum number of unique coordinates
	points = (CvPoint *) calloc(squares->total, sizeof (CvPoint));
  
	if (points == NULL) {
		fprintf(stderr, "ListUniqueSquares(): Error allocating memory.\n");
		return NULL;
	}
 
        uniqueSquares = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvPoint), storage);

	if (uniqueSquares == NULL) {
		fprintf(stderr, "ListUniqueSquares(): Error creating sequence.\n");
		free (points);
		return NULL;
	}
	// initialize reader of the sequence  
	cvStartReadSeq( squares, &reader, 0 );
 
	// loop through all of the squares
	for (i = 0; i <squares->total; i += 4) {
		int isUnique = 1;
		CvPoint pt[4];

		// read 4 vertices
		CV_READ_SEQ_ELEM( pt[0], reader );
		CV_READ_SEQ_ELEM( pt[1], reader );
		CV_READ_SEQ_ELEM( pt[2], reader );
		CV_READ_SEQ_ELEM( pt[3], reader ); 
		// printf("(%d %d) (%d %d) (%d %d) (%d %d)\n", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y, pt[3].x, pt[3].y);

		SortPointsInRect(pt);
		// check if the currect rectangle appeared before
		for (j = 0; j < numUnique; j++) {
			//SortPointsInRect(points + j*4);
			if ((PtEqual(pt[0], points[j*4], THR)) &&
			    (PtEqual(pt[1], points[j*4 + 1], THR)) &&
			    (PtEqual(pt[2], points[j*4 + 2], THR)) &&
			    (PtEqual(pt[3], points[j*4 + 3], THR)) ) {
				isUnique = 0;
				break;
			}
		}
		
		// get rid of duplicates
		// ignore the outer border, which is basically the border of the whole image
		if ( (isUnique) 
		     && (pt[0].x > 2 && pt[0].y > 2) 
		     // && (abs(pt[1].x - pt[0].x) > 20) 
		     // && (abs(pt[2].y - pt[1].y) > 20)
		     ) {
			// printf("Unique found (%d %d) (%d %d) (%d %d) (%d %d)\n", pt[0].x, pt[0].y, pt[1].x, pt[1].y, pt[2].x, pt[2].y, pt[3].x, pt[3].y);

			// Add points to list of unique rectangles
			for (k = 0; k < 4; k++) {
				points[numUnique*4 + k] = pt[k];
				cvSeqPush(uniqueSquares, pt + k);
			}
			numUnique ++;
		}
	}
	
	//  for (i = 0; i<numUnique; i++)
	//    printf("U: (%d %d) (%d %d) (%d %d) (%d %d)\n", points[i*4].x, points[i*4].y, points[i*4+1].x, points[i*4+1].y, points[i*4+2].x, points[i*4+2].y, points[i*4+3].x, points[i*4+3].y);
	//printf("Total unique square: %d\n", numUnique);

	free (points);
	return uniqueSquares;
}


// CvSeq memory are never released back to storage.
// Caller must release storage memory to reclaim memory.
//
// this function counts the unique squares in the contour; the OpenCV 
// routines find multiple contours around each rectangles. The coutours 
// for one particular rectangle are close to each other - may be 2/3 pixels 
// apart from each other. This functions considers those coutours as one, 
// and count such "unique" countours

// Returns sequence of CvPoint
// Every 4 points make up a square
// In a Top Origin coordinate system, the points are organized as follows:
// PT0--PT3
//  |    |
// PT1--PT2
//
// Returns NULL on error
CvSeq* FindUniqueSquares4(IplImage* image, int threshold, CvMemStorage* storage)
{
	CvSeq * squares = NULL;
	CvSeq * uniqueSquares = NULL;
	CvMemStorage * storage2;

	assert(image != NULL);
	assert(storage != NULL);

	storage2 = cvCreateMemStorage(0);
	if (storage2 == NULL) {
		fprintf(stderr, "FindUniqueSquares4(): Error creating mem storage.\n");
		return NULL;
	}

	squares = FindSquares4(image, storage2);

	if (squares == NULL) {
		fprintf(stderr, "FindUniqueSquares4(): Error finding squares.\n");
		cvReleaseMemStorage(&storage2);
		return NULL;
	}

	uniqueSquares = ListUniqueSquares(squares, threshold, storage);

	cvReleaseMemStorage(&storage2);

	return uniqueSquares;
}

// Creates IplImageHeader.  Caller must release.
// Returns an IplImage * that points to a part of the original image
// Image Data points to original image
// New image ROI set to roi
// Returns NULL on error
IplImage* GetImagePart( IplImage* img, CvRect roi )
{
	IplImage* part = NULL;

	assert (img != NULL);

	part = cvCreateImageHeader( cvGetSize(img), img->depth, img->nChannels );

	if (part == NULL) {
		fprintf(stderr, "GetImagePart(): Error creating IPL image header.\n");
		return NULL;
	}

	//printf("GetImagePart(): depth: %d, nChannels: %d, widthStep: %d\n", img->depth, img->nChannels,  img->widthStep);
	cvSetImageData( part, img->imageData, img->widthStep );
	cvSetImageROI( part, roi );

	return part;
}

// allocates IplImage.  Caller must release.
// converts a color image to gray (1 channel)
IplImage *MyColorToGray(IplImage *src)
{
	IplImage *dst = NULL;
	int srcStep = 0;
	CvSize srcROI;
	uchar *srcData = NULL;
 
	assert(src != NULL);

	cvGetImageRawData(src, &srcData, &srcStep, &srcROI);

	dst = cvCreateImage(srcROI, IPL_DEPTH_8U, 1); // create a 8-bit, 1-channel gray image

	if (dst == NULL) {
		printf("MyColorToGray(): Error creating new gray image\n");
		return NULL;
	}

	//  printf("MyColorToGray(): Src img: %dx%d %d bytes per line\n", srcROI.width, srcROI.height, srcStep);
	cvCvtColor(src, dst, CV_RGB2GRAY);

	return dst;
}

// creates IplImage, caller must release
// Resizes an image and returns the resized image
// Returns NULL on error
IplImage *MyResize(IplImage *src, int dstWidth, int dstHeight)
{
	CvSize dstRoi;
	IplImage *dst = NULL;

	assert (src != NULL);
	assert (dstWidth >= 0);
	assert (dstHeight >= 0);

	dstRoi.width = dstWidth;
	dstRoi.height = dstHeight;
	dst = cvCreateImage(dstRoi, src->depth, src->nChannels);

	if (dst == NULL) {
		fprintf(stderr, "MyResize(): Error creating image.\n");
		return NULL;
	}

	cvResize(src, dst, CV_INTER_NN);

	return dst;
}

// Returns the difference of two images
// implements cvMean of cvAbsDiff
// automatically scale both input images to the same size before diffing
// returns 1 on success, 0 on error
int MyAbsImageDiff(IplImage* srcImg1, IplImage* srcImg2, double * diff)
{
	IplImage *image1 = NULL, *image2 = NULL, *diffImage = NULL;
	CvSize roi1, roi2, roi;
	int step1, step2;
	uchar *data1 = NULL, *data2 = NULL;
	int flag = 0;

	assert (srcImg1 != NULL);
	assert (srcImg2 != NULL);

	cvGetImageRawData(srcImg1, &data1, &step1, &roi1);
	cvGetImageRawData(srcImg2, &data2, &step2, &roi2);
	*diff = 0;

	//	printf("roi1: %d %d, roi2: %d %d\n", roi1.width, roi1.height, roi2.width, roi2.height);

	// scale both the images to the same size
	if (roi1.width > roi2.width) {
		roi = roi2;
		image1 = MyResize(srcImg1, roi.width, roi.height);
		flag = 1;
		image2 = srcImg2;
	}
	else {
		roi = roi1;
		image1 = srcImg1;
		image2 = MyResize(srcImg2, roi.width, roi.height);
		flag = 2;
	}

	if (image1 == NULL || image2 == NULL) {
		fprintf(stderr, "AbsImageDiff_8u_C1(): Error resizing images.\n"); 
		return 0;
	}

	diffImage = cvCreateImage(roi, image1->depth, image1->nChannels);
	
	if (diffImage == NULL) {
		fprintf(stderr, "AbsImageDiff_8u_C1(): Error creating diff image.\n"); 
		return 0;
	}

	cvAbsDiff(image1, image2, diffImage);
	*diff = cvMean(diffImage, 0);

	cvReleaseImage(&diffImage);

	if (flag == 1)
		cvReleaseImage(&image1);
	if (flag == 2)
		cvReleaseImage(&image2); 

	return 1;
}

// Returns the difference of two images
// implements cvMean of cvAbsDiff
// automatically scale both input images to the same size before diffing
// returns 1 on success, 0 on error
int MyAbsImageDiff2(IplImage* srcImg1, IplImage* srcImg2, double * diff)
{
	IplImage *image1 = NULL, *image2 = NULL, *diffImage = NULL;
	CvSize roi1, roi2, roi;
	int step1, step2;
	uchar *data1 = NULL, *data2 = NULL;
	int flag = 0;

	assert (srcImg1 != NULL);
	assert (srcImg2 != NULL);

	//printf("Using ABSDIFF 2\n");

	cvGetImageRawData(srcImg1, &data1, &step1, &roi1);
	cvGetImageRawData(srcImg2, &data2, &step2, &roi2);
	*diff = 0;

	//	printf("roi1: %d %d, roi2: %d %d\n", roi1.width, roi1.height, roi2.width, roi2.height);

	// scale both the images to the same size
	if (roi1.width > roi2.width) {
		roi = roi2;
		image1 = MyResize(srcImg1, roi.width, roi.height);
		flag = 1;
		image2 = srcImg2;
	}
	else {
		roi = roi1;
		image1 = srcImg1;
		image2 = MyResize(srcImg2, roi.width, roi.height);
		flag = 2;
	}

	if (image1 == NULL || image2 == NULL) {
		fprintf(stderr, "AbsImageDiff_8u_C1(): Error resizing images.\n"); 
		return 0;
	}


	diffImage = cvCreateImage(roi, image1->depth, image1->nChannels);
	
	if (diffImage == NULL) {
		fprintf(stderr, "AbsImageDiff_8u_C1(): Error creating diff image.\n"); 
		return 0;
	}

	cvAbsDiff(image1, image2, diffImage);

	cvThreshold(diffImage, diffImage, 75, 255, CV_THRESH_BINARY);

	IplImage * threshold = MyColorToGray(diffImage);

	cvThreshold(threshold, threshold, 10, 255, CV_THRESH_BINARY);

	cvErode(threshold, threshold, 0, 1);
	cvDilate(threshold, threshold, 0, 4);
	
	*diff = cvMean(threshold, 0);

	cvReleaseImage(&diffImage);
	cvReleaseImage(&threshold);
	

	if (flag == 1)
		cvReleaseImage(&image1);
	if (flag == 2)
		cvReleaseImage(&image2); 

	return 1;
}

// finds the index of the image in the "imagelist" that is the closest
// 1-neighbor of "image". "imagelist" is the list previously loaded
// images. "listLen" is the length of the image;
// returns -1 on error
int FindBestMatch(IplImage *image, IplImage **imageList, int listLen)
{
	int i, bestMatch;
	double diff, minDiff;
	
	for (i = 0; i<listLen; i++) {
		if (MyAbsImageDiff(image, imageList[i], &diff) == 0)
			return -1;

		//printf("%lf ", diff);
		if ( (i == 0) || (diff < minDiff)){ 
			bestMatch = i;
			minDiff = diff;
		}
	}
	//printf("\n");
	return bestMatch;
}



// The function loadImage loads all the images in the database. 
// These are the images that will be compared to the test image.
// confFile is the configuration file that lists the image files
// the images will be converted to gray image before being loaded
IplImage** LoadImages(char *confFile, int *listLen)
{
	FILE *fp;
	char st[256], fname[256];
	int num, i;
	IplImage **imageList, *tmpImage;
  
	printf("LoadImages()\n");
	if ( (fp = fopen(confFile, "rt")) == NULL) {
		printf("Can't open the configuration file in loadImage()\n");
		return NULL;
	}

	fgets(st, 256, fp);
	if (sscanf(st, "%d", &num) != 1) {
		printf("Invalid format of the configuration file in loadImage()\n");
		return NULL;
	}

	imageList = (IplImage **) calloc(num, sizeof(IplImage*));
	
	for (i = 0; i<num; i++) {
		fgets(st, 256, fp);
		sscanf(st, "%s", fname);
		printf("Loading %s\n", fname);
		tmpImage = cvvLoadImage(fname);
		if (!tmpImage) break;
		imageList[i] = MyColorToGray(tmpImage);
		cvReleaseImage(&tmpImage);
	}
	
	*listLen = num;
	return imageList;
	
}

// all the images should be in gray scale
void RecognizeFaces(IplImage *image, IplImage **imageList, int listLen,
		    IplImage *colorImage, char** desc)
{
	CvSeq *squares;
	CvRect roi;
	CvPoint pt[4],  pt1[4], *ptList = pt1;
	IplImage *part;
	int bestMatch, i;
	CvSeqReader  reader; 
	IplImage *tmp;
	int count = 4;	
	int x1, y1, x2, y2;
	CvMemStorage *storage;
	
	storage = cvCreateMemStorage(0);
	
	if (image == NULL || imageList == NULL) {
		printf("Null image\n");
		return ;
	}

	// initialize reader of the sequence  	
	squares = FindUniqueSquares4(image, 50, storage);
	cvStartReadSeq( squares, &reader, 0 );
	
	cvvNamedWindow("faces", 1);
	ptList = pt1;
	
	for( i = 0; i < squares->total; i += 4 ) {
		
		// read 4 vertices
		CV_READ_SEQ_ELEM( pt[0], reader );
		CV_READ_SEQ_ELEM( pt[1], reader );
		CV_READ_SEQ_ELEM( pt[2], reader );
		CV_READ_SEQ_ELEM( pt[3], reader );
		
		x1 = max(pt[0].x, pt[1].x);
		y1= max(pt[0].y, pt[3].y);
		x2 = min(pt[2].x, pt[3].x);
		y2 = min(pt[1].y, pt[2].y);
		pt1[0].x = x1; pt1[0].y = y1;
		pt1[1].x = x1; pt1[1].y = y2;
		pt1[2].x = x2; pt1[2].y = y2;
		pt1[3].x = x2; pt1[3].y = y1;
		roi.x = x1;
		roi.y = y1;
		roi.height = y2 - y1; if (roi.height < 0) roi.height = -roi.height;
		roi.width = x2 - x1; if (roi.width < 0) roi.width = -roi.width;
		
		part = GetImagePart(image, roi);
		bestMatch = FindBestMatch(part, imageList, listLen);
		
		printf("[%s: (%d %d)] ", desc[bestMatch], pt[0].x, pt[0].y);
		
		//printf("Image recognized as : %s\n", desc[bestMatch]);
		tmp = cvCloneImage(colorImage);
		cvPolyLine( tmp, &ptList, &count, 1, 1, CV_RGB(255, 0, 0), 8, 8 );
		cvvShowImage("faces", tmp);
		//cvvWaitKey(0);
		//cvReleaseImage(&tmp);
		//cvReleaseImage(&part);
	}

	cvReleaseMemStorage(&storage);
	
	printf("\n");
}



void MyRunningAvg(IplImage *srcImage, IplImage *dstImage, float alpha) {
	cvAddWeighted(srcImage, alpha, dstImage, 1 - alpha, 0, dstImage);

}

// match each color plane separately, then combine
void MyMatchTemplate(IplImage *img, IplImage *templ, IplImage *result, CvTemplMatchMethod method) {

	
	int i;
	int nchan = img->nChannels;

	IplImage* imgplane[4];
	IplImage* templplane[4];

	IplImage* tempresult = cvCloneImage(result);

	int depth = img->depth;

	CvSize imgsize = cvSize(img->width, img->height);
	CvSize templsize = cvSize(templ->width, templ->height);
	// create individual image planes
	for (i = 0; i < nchan; i++) {
		imgplane[i] = cvCreateImage(imgsize, depth, 1);
		templplane[i] = cvCreateImage(templsize, depth, 1);
	}

	cvCvtPixToPlane(img, imgplane[0], imgplane[1], imgplane[2], NULL);

	cvCvtPixToPlane(templ, templplane[0], templplane[1], templplane[2], NULL);


	cvMatchTemplate(imgplane[0], templplane[0], result, method);

	
	for (i = 1; i < nchan; i++) {
		cvMatchTemplate(imgplane[i], templplane[i], tempresult, method);
		cvAdd(tempresult, result, result);
		//cvScaleAdd(tempresult, cvScalar(0.5), result, result);
	}

	for (i = 0; i < nchan; i++) {
		cvReleaseImage(&(imgplane[i]));
		cvReleaseImage(&(templplane[i]));
	}

	cvReleaseImage(&tempresult);

}

// converts to grayscale - match once
void MyMatchTemplate2(IplImage *img, IplImage *templ, IplImage *result, CvTemplMatchMethod method) {


	IplImage * grayImg = MyColorToGray(img);
	IplImage * grayTempl = MyColorToGray(templ);

	cvMatchTemplate(grayImg, grayTempl, result, method);


	cvReleaseImage(&grayImg);
	cvReleaseImage(&grayTempl);

}
