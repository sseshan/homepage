/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <math.h>
#include "vector.h"


Vector::Vector(CvPoint p) {
	x = p.x;
	y = p.y;
	z = 0;
}

Vector::Vector(CvPoint2D64d p) {
	x = p.x;
	y = p.y;
	z = 0;
}

Vector::Vector(CvPoint2D32f p) {
	x = p.x;
	y = p.y;
	z = 0;
}


Vector::Vector(double x1, double y1, double z1) {
	x = x1;
	y = y1;
	z = z1;
}

Vector::Vector(CvPoint p1, CvPoint p2) {
	x = p2.x - p1.x;
	y = p2.y - p1.y;
	z = 0;
}

Vector Vector::cross(Vector v) {
	return Vector(y*v.z - z*v.y, z*v.x - x*v.z, x*v.y - y*v.x);
}

void Vector::normalize() {
	double s= size();

	x /= s;
	y /= s;
	z /= s;
}

double Vector::size() {
	return sqrt(x*x + y*y + z*z);
}

void Vector::scale(double s) {
	x *= s;
	y *= s;
	z *= s;
}

Vector Vector::subtract(Vector v) {
	return Vector(x - v.x, y - v.y, z - v.z);
}

