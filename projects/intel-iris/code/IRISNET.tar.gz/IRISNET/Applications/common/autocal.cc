/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


// Reads from video frame in shared memory and tries to find
// where the parking spaces are.

// Our common libraries for SA's
#include <imgproc.h>
#include <shmman.h>

// OpenCV
#include <cv.h>
#include <highgui.h>

// Unix system includes
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>
#include <stdio.h>

// generate debug code - need to fold into makefile
#undef NDEBUG
#include <assert.h>


#include "vector.h"

// returns CvSeq of CvBox2D of circles

CvSeq * FindCircles(IplImage * input_img, CvMemStorage * circle_storage)
{
	// DO SOME DECLARARTIONS
	// FOR ALL TYPES "Cv.." LOOK AT OPENCV-DOC !!
	
        CvMemStorage *storage;
        int header_size, i, count,length, width;
        CvSeq *contour;
        CvBox2D * myBox;
        CvPoint *PointArray;
        CvPoint2D32f *PointArray32f;
        CvPoint myCenter;
	CvSeq * circles;


	circles = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvBox2D), circle_storage);

	
	// ALLOCATE SOME MEMORY        
        myBox= (CvBox2D *) malloc(sizeof(CvBox2D));
        header_size = sizeof(CvContour);
        storage = cvCreateMemStorage (1000); // For FindContours.

	// ECTRACT WIDTH AND HEIGHT OF THE INPUT-IMAGE

        int w = input_img->width;
        int h = input_img->height;

	// CREATE TEMPORARY IMAGES
	// ONE FOR THE "CANNY" AND ONE FOR PREPROCESSING

	//THIS IS FOR CANNY - 1 CHANNEL (GRAY)
	//SAME SIZE AS INPUT
        IplImage* m_tmp8uC1= cvCreateImage(
					   cvSize(w ,h ),   
					   IPL_DEPTH_8U,1); //GRAY
	
        //PREPROCESSING OF YOUR CHOICE
        //HERE WE DO A SIMPLE BLUR TO REMOE NOISE
	//        iplBlur(input_img,m_tmp8uC1, 2,2,1,1);

	RemoveNoiseFromImage(input_img, m_tmp8uC1);

        // NOW THE 1ST "ESSENTIAL" FUNCTION
        // CANNY IS A KIND OF EDGE-DETECTION
        // THE RESULT IS BLACK/WHITE WITH ONLY THE CONTOURS (WHITE)
        cvCanny(m_tmp8uC1, m_tmp8uC1, 0, 255, 5 );

	//       	DisplayIplImage(m_tmp8uC1, "canny");
	//cvWaitKey(0);

 /*    
   // SAVE THE RESULT FOR DEBUGGING AS BITMAP ONE CHANNEL
        gr_fmt_write_image(m_tmp8uC1->imageData,
                                    m_tmp8uC1->widthStep,
                                        m_tmp8uC1->width,
                                        m_tmp8uC1->height,
                                        0,
                                        "c:\\canny.bmp"
                                        ,"BMP");
 */    

	// NOW THE 2ND "ESSENTIAL" FUNCTION
	//THIS FUNCTION SEPARATES ALL CONTOURS
	// LOOK AT THE DOC !!!! AGAIN
	cvFindContours (m_tmp8uC1 , storage, &contour,
			header_size, CV_RETR_EXTERNAL,
			CV_CHAIN_APPROX_SIMPLE);
	
	// GO THROUGH ALL CONTOURS
	while(contour!=NULL) {
		if(CV_IS_SEQ_CURVE(contour)) {
                        // HOW MANY POITS HAS THE CONTOUR ??
                        count = contour ->total;
                       
                        //ALLOC MEM
                        PointArray = (CvPoint *)malloc(count * sizeof(CvPoint));
                       
                        //COPY THE POINTS TO A ARRAY
                        cvCvtSeqToArray(contour, PointArray, CV_WHOLE_SEQ);

                        // ALLOC MEM
                        PointArray32f = (CvPoint2D32f *)
				malloc((count + 1) * sizeof(CvPoint2D32f));

                        //CONVERT THE ARRAY TO A 2ND (32FLOAT)
                        // THIS WE NEED FOR cvFitELLIPSE

                        for (i=0; i<count-1; i++)
                        {                              
                                PointArray32f[i].x = (float)(PointArray[i].x);
                                PointArray32f[i].y = (float)(PointArray[i].y);
                        }

			PointArray32f[i].x = (float)(PointArray[0].x);
			PointArray32f[i].y = (float)(PointArray[0].y);        
			
			//FOR DEBUGGING YOU CAN DRAW THECONTOUR
			//cvDrawContours(input_img, contour,RGB(0,0,255), RGB(0,255,0),0);

                        //cvFITELLIPSE NEEDS MIN. 6 POINTS
                        // IS IT ?

                        if (count>=7)
                        {
				
                                //FIND THE BEST FITTING ELLIPSE INTHIS CONTOUR
                                cvFitEllipse(PointArray32f, count,myBox);
                               
                                //ECTRACT THE RESULTS FROM "myBox"
                                //CENTER
                                myCenter.x = (int) myBox->center.x;
                                myCenter.y = (int) myBox->center.y;
                               
                                //HEIGHT AND WITH (THE 2 AXES OF THE ELLIPSE)
                                length  =(int)myBox->size.height;
                                width = (int)myBox->size.width;
                               
                                // IS THE ELLIPSE INSIDE THE IMAGE ??
                                if ((myCenter.x > 0) && (myCenter.y >0) &&
				    (width > 3 && length > 3) &&
				    (((float)width / length) < 1.8)
				    && width < 50
				    )
                                {      
                                        //DRAW A CIRCLE
                                        cvCircle(input_img,myCenter,
								(int)length/2, CV_RGB(0,0,255));
                               
                                        //DRAW THE ELLIPSE
                                        cvEllipse(input_img,
						  myCenter,
						  cvSize((int)width/2,
							 (int)length/2),
						  -myBox->angle,
						  0,360, CV_RGB(0,255,0),1);
					
					//printf("Circle found at (%d, %d) w=%d c=%d\n", myCenter.x, myCenter.y, width, count);

					cvSeqPush(circles, myBox);
                                }

			

                        }
                        free(PointArray32f );
                        free(PointArray );
                }
                // GOT TO THE NEXT CONTOUR (IF ANY)
                contour = contour->h_next;
                
        }
        free (contour);
	free (myBox);            
        cvReleaseImage(&m_tmp8uC1);
        cvReleaseMemStorage(&storage);

	return circles;
}


double GetCircleBrightness(CvBox2D * circle, IplImage * image)
{
	CvSize size = cvSize(image->width, image->height);
        IplImage* mask = cvCreateImage(size, IPL_DEPTH_8U, 1); //GRAY
	CvPoint myCenter;
	int radius;
	
	
	myCenter.x = (int) circle->center.x;
	myCenter.y = (int) circle->center.y;
	radius = (int) circle->size.height/2;
	
	cvCircle(mask, myCenter, radius, CV_RGB(255, 255, 255), -1);
	
	//	DisplayIplImage(mask, "mask");
	//cvWaitKey(0);
	
	return cvMean(image, mask); 
}


int GetLargestIndex(double *array, int start, int n)
{
	int max = start;

	for (int i = start+1; i < n; i++) {
		if (array[i] > array[max])
			max = i;
	}

	return max;

}

void SortDoubleArray(double * array, int n)
{
	for (int i = 0; i < n; i++) {
		int max = GetLargestIndex(array, i, n);
		double tmp = array[max];
		array[max] = array[i];
		array[i] = tmp;
	}

}

// input CvSeq of CvBox2D of circles
// output CvSeq of CvBox2D of circles
// get n brightest circles
CvSeq * GetBrightestCircles(CvSeq * circles, CvMemStorage * storage, IplImage * image, int n = 1)
{
	CvSeq * brightest;
	CvBox2D circle;
	int i;

	double * means;

	double topn;

	brightest = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvBox2D), storage);

	if (circles->total == 0)
		return brightest;

	printf("GetBrightestCircles(): Total circles %d\n", circles->total);

	means = (double *) malloc(circles->total * sizeof(double));

	for (i = 0; i < circles->total; i++) {
		circle = *((CvBox2D *) cvGetSeqElem(circles, i));
		means[i] = GetCircleBrightness(&circle, image);
		//printf("GetBrightestCircle(): Mean of circle %d is %f\n", i, means[i]);
	}

	SortDoubleArray(means, circles->total);

	if (n > circles->total)
		n = circles->total;

	topn = means[n - 1];

	for (int i = 0; i < circles->total; i++) {
		circle = *((CvBox2D *) cvGetSeqElem(circles, i));
		if (GetCircleBrightness(&circle, image) >= topn) {
			cvSeqPush(brightest, &circle);
			//printf("GetBrightestCircles(): Pushing (%f, %f), r=%f\n",
			//       circle.center.x, circle.center.y, circle.size.height/2);
		}
	}

	free(means);

	return brightest;
}

void GetBrightestCircle(CvSeq * circles, IplImage * image, CvBox2D * box)
{
	CvSeq * brightest;
	CvMemStorage * storage;
	CvBox2D * tmpbox;
	
	storage = cvCreateMemStorage();

	brightest = GetBrightestCircles(circles, storage, image, 1);

	printf("GetBrightestCircle(): Total circles %d\n", brightest->total);

	if (brightest->total == 0)
		return;

	tmpbox = (CvBox2D *) cvGetSeqElem(brightest, 0);
	
	memcpy(box, tmpbox, sizeof(CvBox2D));
	
	printf("GetBrightestCircle(): (%f, %f), r=%f\n", box->center.x, box->center.y, box->size.height/2);
	
	cvReleaseMemStorage(&storage);

}

// draw brightest circle on image
void DrawBrightestCircle(CvSeq * circles, IplImage * in_image, IplImage * out_image, double color)
{
	CvBox2D brightest;
	CvPoint myCenter;
	int radius;
	
	
	GetBrightestCircle(circles, in_image, &brightest);

	myCenter.x = (int) brightest.center.x;
	myCenter.y = (int) brightest.center.y;
	radius = (int) brightest.size.height/2;
	
	cvCircle(out_image, myCenter, radius, color, 5);
	
	
	printf("DrawBrightestCircle(): Brightest (%d, %d) r=%d\n", myCenter.x, myCenter.y, radius);

}

void CompositeImage(IplImage * image)
{
	IplImage *plane0 = NULL,
		*plane1 = NULL,
		*plane2 = NULL;

	IplImage *blue, *red, *green;

	IplImage *redonly, *blueonly, *greenonly;
	IplImage *tmpImage;

	CvMemStorage * storage = cvCreateMemStorage();
	CvSeq * redcircles, * bluecircles, * greencircles;
	
	int depth = 0;

	depth = image->depth;
	
	CvSize size = cvSize(image->width, image->height);
	
	
	redonly = cvCreateImage(size, depth, 1);
	greenonly = cvCreateImage(size, depth, 1);
	blueonly = cvCreateImage(size, depth, 1);

	tmpImage = cvCreateImage(size, depth, 1);

	// create individual image planes
	plane0 = cvCreateImage(size, depth, 1);
	plane1 = cvCreateImage(size, depth, 1);
	plane2 = cvCreateImage(size, depth, 1);

	cvCvtPixToPlane(image, plane0, plane1, plane2, NULL);


	//DisplayIplImage(plane0, "blue");
	//DisplayIplImage(plane1, "green");
	//DisplayIplImage(plane2, "red");
	
	blue = plane0;
	green = plane1;
	red = plane2;

	int C_MULT = 2, C_SUB=-60;

	cvAddWeighted(green, 0.5, blue, 0.5, 0, tmpImage);
	cvSub(red, tmpImage, redonly);
	cvAddWeighted(redonly, C_MULT, redonly, 0, C_SUB, redonly);
	redcircles = FindCircles(redonly, storage);
	DrawBrightestCircle(redcircles, redonly, image, CV_RGB(255, 0, 0));
	DisplayIplImage(redonly, "redonly");

	cvAddWeighted(red, 0.5, blue, 0.5, 0, tmpImage);
	cvSub(green, tmpImage, greenonly);
	cvAddWeighted(greenonly, C_MULT, greenonly, 0, C_SUB, greenonly);
	greencircles = FindCircles(greenonly, storage);
	DrawBrightestCircle(greencircles, greenonly, image, CV_RGB(0, 255, 0));
	DisplayIplImage(greenonly, "greenonly");

	cvAddWeighted(green, 0.5, red, 0.5, 0, tmpImage);
	cvSub(blue, tmpImage, blueonly);
	cvAddWeighted(blueonly, C_MULT, blueonly, 0, C_SUB, blueonly);
	bluecircles = FindCircles(blueonly, storage);
	DrawBrightestCircle(bluecircles, blueonly, image, CV_RGB(0, 0, 255));
	DisplayIplImage(blueonly, "blueonly");

	DisplayIplImage(image, "composite");

	cvReleaseImage(&tmpImage);
	cvReleaseImage(&redonly);
	cvReleaseImage(&greenonly);
	cvReleaseImage(&blueonly);

	cvReleaseImage(&plane0);
	cvReleaseImage(&plane1);
	cvReleaseImage(&plane2);

	cvReleaseMemStorage(&storage);

}

double CircleDist(CvBox2D * c1, CvBox2D * c2)
{
	double x = c1->center.x - c2->center.x;
	double y = c1->center.y - c2->center.y;

	x *= x;
	y *= y;


	return sqrt(x + y);
	
}

CvPoint CircleCenter3(CvBox2D * c1, CvBox2D * c2, CvBox2D * c3)
{

	CvPoint p;

	p.x = (int) (c1->center.x + c2->center.x + c3->center.x) / 3;
	p.y = (int) (c1->center.y + c2->center.y + c3->center.y) / 3;

	
	return p;

}

CvPoint FindCenter3(CvSeq * circles, int maxdist)
{
	const int MIN_DIST = 10;
	const double SKEW = 1.5;

	CvPoint center = cvPoint(0, 0);

	int i, j, k;

	if (circles->total < 3)
		return center;
	
	for (i = 0; i < circles->total - 2; i++) {
		for (j = i+1; j < circles->total - 1; j++) {
			for (k = j+1; k < circles->total; k++) {
				CvBox2D c1, c2, c3;
				double dist12, dist13, dist23;

				c1 = * (CvBox2D *) cvGetSeqElem(circles, i);
				c2 = * (CvBox2D *) cvGetSeqElem(circles, j);
				c3 = * (CvBox2D *) cvGetSeqElem(circles, k);

				dist12 = CircleDist(&c1, &c2);
				dist13 = CircleDist(&c1, &c3);
				dist23 = CircleDist(&c2, &c3);

				if (dist12 > MIN_DIST
				    && dist13 > MIN_DIST
				    && dist23 > MIN_DIST
				    && dist12 < maxdist
				    && dist13 < maxdist
				    && dist23 < maxdist

				    && dist13/dist12 < SKEW
				    && dist12/dist13 < SKEW
				    && dist13/dist23 < SKEW
				    && dist23/dist13 < SKEW
				    && dist12/dist23 < SKEW
				    && dist23/dist12 < SKEW
				    ) {
					//printf("12=%f, 23=%f, 13=%f\n", dist12, dist23, dist13);
					cvSeqRemove(circles, k);
					cvSeqRemove(circles, j);
					cvSeqRemove(circles, i);
					return CircleCenter3(&c1, &c2, &c3);
				}
			}
		}
	}

	return center;
	
}

// return CvSeq of n CvPoint
CvSeq *  GetBlueCenters(IplImage * image, CvMemStorage * retstorage, int nCenters)
{
	IplImage *plane0 = NULL,
		*plane1 = NULL,
		*plane2 = NULL;

	IplImage *blue, *red, *green;

	IplImage *blueonly;
	IplImage *tmpImage;

	CvSeq * centers = cvCreateSeq(0, sizeof(CvSeq), sizeof(CvPoint), retstorage);

	CvMemStorage * storage = cvCreateMemStorage();

	CvSeq * bluecircles;
	
	int depth = 0;

	depth = image->depth;
	
	CvSize size = cvSize(image->width, image->height);
       	
	blueonly = cvCreateImage(size, depth, 1);

	tmpImage = cvCreateImage(size, depth, 1);

	// create individual image planes
	plane0 = cvCreateImage(size, depth, 1);
	plane1 = cvCreateImage(size, depth, 1);
	plane2 = cvCreateImage(size, depth, 1);

	cvCvtPixToPlane(image, plane0, plane1, plane2, NULL);


	//DisplayIplImage(plane0, "blue");
	//DisplayIplImage(plane1, "green");
	//DisplayIplImage(plane2, "red");
	
	blue = plane0;
	green = plane1;
	red = plane2;

	int C_MULT = 2, C_SUB=-50;

	cvAddWeighted(green, 0.5, red, 0.5, 0, tmpImage);
	cvSub(blue, tmpImage, blueonly);
	cvAddWeighted(blueonly, C_MULT, blueonly, 0, C_SUB, blueonly);
	bluecircles = FindCircles(blueonly, storage);

	for (int i = 0; i < nCenters; i++) {
		CvPoint center = FindCenter3(bluecircles, 100);
		cvSeqPush(centers, &center);
		if (center.x != 0 && center.y != 0) {			
			cvCircle(image, center, 5, CV_RGB(255, 255, 0), 5);
		}
	}


	//DisplayIplImage(blueonly, "blueonly");

	//DisplayIplImage(image, "composite");

	cvReleaseImage(&tmpImage);;
	cvReleaseImage(&blueonly);

	cvReleaseImage(&plane0);
	cvReleaseImage(&plane1);
	cvReleaseImage(&plane2);

	cvReleaseMemStorage(&storage);

	return centers;
}


/* from = landmark detected on image
   to   = landmark on reference image
*/

void CopyPixel(IplImage * fromImage, int fromx, int fromy,
	       IplImage * toImage, int tox, int toy)
{
	int topos = toImage->widthStep * toy + tox*toImage->nChannels;
	int frompos = fromImage->widthStep * fromy + fromx*fromImage->nChannels;
	
	for (int c = 0; c < toImage->nChannels; c++) {
		toImage->imageData[topos + c] = fromImage->imageData[frompos + c];

	}
}


/* from = landmark detected on image
   to   = landmark on reference image
*/

void CopyPixel(IplImage * image, int fromx, int fromy, int tox, int toy)
{
	CopyPixel(image, fromx, fromy, image, tox, toy);
}

void TranslateImageY(int from, int to, IplImage * image)
{
	int y;

	printf("TranslateImageY(): Translating Y %d to %d\n",
	       from, to);
	
	if (from > to) {
		int diff = from - to;

		for (y = 0; y < image->height - diff; y++) {
			for (int x = 0; x < image->width; x++) {
				CopyPixel(image, x, y+diff, x, y);
			}
		}

		cvRectangle(image,
			    cvPoint(0, image->height - diff),
			    cvPoint(image->width - 1, image->height - 1),
			    CV_RGB(0, 0, 0), -1);
	}
	else if (to > from) {
		int diff = to - from;

		for (y = image->height - 1; y > diff; y--) {
			for (int x = 0; x < image->width; x++) {
				CopyPixel(image, x, y-diff, x, y);
			}
		}

		cvRectangle(image,
			    cvPoint(0, 0),
			    cvPoint(image->width - 1, diff),
			    CV_RGB(0, 0, 0), -1);
	}
	
}

void TranslateImageX(int from, int to, IplImage * image)
{
	int x;

	printf("TranslateImageX(): Translating X %d to %d\n",
	       from, to);
	
	if (from > to) {
		int diff = from - to;

		for (x = 0; x < image->width - diff; x++) {
			for (int y = 0; y < image->height; y++) {
				//printf("TranslateImageX(): Copying pixel (%d, %d) to (%d, %d)\n", x+diff, y, x, y);
				CopyPixel(image, x+diff, y, x, y);
			}
		}

		cvRectangle(image,
			    cvPoint(image->width - diff, 0),
			    cvPoint(image->width - 1, image->height - 1),
			    CV_RGB(0, 0, 0), -1);
	}
	else if (to > from) {
		int diff = to - from;

		for (x = image->width - 1; x > diff; x--) {
			for (int y = 0; y < image->height; y++) {
				//printf("TranslateImageX(): Copying pixel (%d, %d) to (%d, %d)\n", x+diff, y, x, y);
				CopyPixel(image, x-diff, y, x, y);
			}
		}

		cvRectangle(image,
			    cvPoint(0, 0),
			    cvPoint(diff, image->height - 1),
			    CV_RGB(0, 0, 0), -1);
	}
}


void TranslateImage(CvPoint from, CvPoint to, IplImage * image)
{

	if (from.x == 0 && from.y == 0)
		return;

	printf("TranslateImage(): Translating point (%d, %d) to (%d, %d)\n",
	       from.x, from.y, to.x, to.y);
	
	TranslateImageX(from.x, to.x, image);
	TranslateImageY(from.y, to.y, image);
}

void Cal1Point(IplImage * srcImage)
{
	CvMemStorage * storage = cvCreateMemStorage();

	static CvPoint oldlandmark = cvPoint(0, 0);

	CvSeq * landmarks = GetBlueCenters(srcImage, storage, 1);

	if (landmarks->total == 0)
		return;

	CvPoint landmark = * (CvPoint *) cvGetSeqElem(landmarks, 0);

	if (landmark.x == 0 && landmark.y == 0)
		landmark = oldlandmark;
	
	oldlandmark = landmark;
	CvPoint ref = cvPoint(320, 240);
	TranslateImage(landmark, ref, srcImage);
	
	cvReleaseMemStorage(&storage);

}


// returns (v1 x v2) x (v3 x v4)
Vector HVector(Vector v1, Vector v2, Vector v3, Vector v4)
{
	Vector t1 = v1.cross(v2);
	Vector t2 = v3.cross(v4);

	return t1.cross(t2);
}


Vector HomoPoint(CvPoint p) {
	return Vector(p.x, p.y, 1);
}

Vector HomoPoint(CvPoint2D64d p) {
	return Vector(p.x, p.y, 1);
}

Vector HomoPoint(CvPoint2D32f p) {
	return Vector(p.x, p.y, 1);
}


void HMat(CvMat * H, Vector H1, Vector H2, Vector H3)
{
	cvmSet(H, 0, 0, H1.x);
	cvmSet(H, 0, 1, H2.x);
	cvmSet(H, 0, 2, H3.x);
	cvmSet(H, 1, 0, H1.y);
	cvmSet(H, 1, 1, H2.y);
	cvmSet(H, 1, 2, H3.y);
	cvmSet(H, 2, 0, H1.z);
	cvmSet(H, 2, 1, H2.z);
	cvmSet(H, 2, 2, H3.z);
/*
	H->data.db[0] = H1.x;
	H->data.db[1] = H2.x;
	H->data.db[2] = H3.x;
	H->data.db[3] = H1.y;
	H->data.db[4] = H2.y;
	H->data.db[5] = H3.y;
	H->data.db[6] = H1.z;
	H->data.db[7] = H2.z;
	H->data.db[8] = H3.z;
*/
}

CvPoint ApplyM(CvMat * M, CvPoint in)
{
	CvMat * inm = cvCreateMat(3, 1, CV_64FC1);
	CvMat * outm = cvCreateMat(3, 1, CV_64FC1);
	cvmSet(inm, 0, 0, in.x);
	cvmSet(inm, 1, 0, in.y);
	cvmSet(inm, 2, 0, 1);

	/*
	inm->data.db[0] = in.x;
	inm->data.db[1] = in.y;
	inm->data.db[2] = 1;
	*/


	cvMatMul(M, inm, outm);

	CvPoint p;

	p.x = cvmGet(outm, 0, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[0] / outm->data.db[2];
	p.y = cvmGet(outm, 1, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[1] / outm->data.db[2];

	cvReleaseMat(&inm);
	cvReleaseMat(&outm);

	return p;

}

CvPoint2D64d ApplyM64d(CvMat * M, CvPoint2D64d in)
{
	CvMat * inm = cvCreateMat(3, 1, CV_64FC1);
	CvMat * outm = cvCreateMat(3, 1, CV_64FC1);

	cvmSet(inm, 0, 0, in.x);
	cvmSet(inm, 1, 0, in.y);
	cvmSet(inm, 2, 0, 1);

	/*
	inm->data.db[0] = in.x;
	inm->data.db[1] = in.y;
	inm->data.db[2] = 1;
	*/

	cvMatMul(M, inm, outm);

	CvPoint2D64d p;

	p.x = cvmGet(outm, 0, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[0] / outm->data.db[2];
	p.y = cvmGet(outm, 1, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[1] / outm->data.db[2];

	cvReleaseMat(&inm);
	cvReleaseMat(&outm);

	return p;
}

CvPoint2D32f ApplyM32f(CvMat * M, CvPoint2D32f in)
{
	CvMat * inm = cvCreateMat(3, 1, CV_32F);
	CvMat * outm = cvCreateMat(3, 1, CV_32F);

	cvmSet(inm, 0, 0, in.x);
	cvmSet(inm, 1, 0, in.y);
	cvmSet(inm, 2, 0, 1);

	/*
	inm->data.db[0] = in.x;
	inm->data.db[1] = in.y;
	inm->data.db[2] = 1;
	*/

	cvMatMul(M, inm, outm);

	CvPoint2D32f p;

	p.x = cvmGet(outm, 0, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[0] / outm->data.db[2];
	p.y = cvmGet(outm, 1, 0) / cvmGet(outm, 0, 2);
	//outm->data.db[1] / outm->data.db[2];

	cvReleaseMat(&inm);
	cvReleaseMat(&outm);

	return p;
}


CvMat * FindProjTransform(CvPoint2D32f fromP1, CvPoint2D32f fromP2, CvPoint2D32f fromP3, CvPoint2D32f fromP4,
			  CvPoint2D32f toP1, CvPoint2D32f toP2, CvPoint2D32f toP3, CvPoint2D32f toP4)
{
	Vector A = HomoPoint(fromP1);
	Vector B = HomoPoint(fromP2);
	Vector C = HomoPoint(fromP3);
	Vector D = HomoPoint(fromP4);


	Vector H1 = HVector(B, A, C, D);
	Vector H2 = HVector(A, D, B, C);
	Vector H3 = HVector(A, C, B, D);



	Vector a = HomoPoint(toP1);
	Vector b = HomoPoint(toP2);
	Vector c = HomoPoint(toP3);
	Vector d = HomoPoint(toP4);


	Vector h1 = HVector(b, a, c, d);
	Vector h2 = HVector(a, d, b, c);
	Vector h3 = HVector(a, c, b, d);



	CvMat * H = cvCreateMat(3, 3, CV_32F);
	CvMat * h = cvCreateMat(3, 3, CV_32F);

	HMat(H, H1, H2, H3);
	HMat(h, h1, h2, h3);

	CvMat * HInv = cvCreateMat(3, 3, CV_32F);
	cvInvert(H, HInv);

	CvMat * M = cvCreateMat(3, 3, CV_32F);

	cvMatMul(h, HInv, M);

	cvReleaseMat(&H);
	cvReleaseMat(&h);
	cvReleaseMat(&HInv);

	return M;

}

IplImage * ProjectiveTransform(CvPoint fromP1, CvPoint fromP2, CvPoint fromP3, CvPoint fromP4,
		 CvPoint toP1, CvPoint toP2, CvPoint toP3, CvPoint toP4,
		 IplImage * image)
{
	Vector A = HomoPoint(fromP1);
	Vector B = HomoPoint(fromP2);
	Vector C = HomoPoint(fromP3);
	Vector D = HomoPoint(fromP4);


	Vector H1 = HVector(B, A, C, D);
	Vector H2 = HVector(A, D, B, C);
	Vector H3 = HVector(A, C, B, D);

	Vector a = HomoPoint(toP1);
	Vector b = HomoPoint(toP2);
	Vector c = HomoPoint(toP3);
	Vector d = HomoPoint(toP4);


	Vector h1 = HVector(b, a, c, d);
	Vector h2 = HVector(a, d, b, c);
	Vector h3 = HVector(a, c, b, d);

	CvMat * H = cvCreateMat(3, 3, CV_64FC1);
	CvMat * h = cvCreateMat(3, 3, CV_64FC1);


	HMat(H, H1, H2, H3);
	HMat(h, h1, h2, h3);

	CvMat * HInv = cvCreateMat(3, 3, CV_64FC1);
	
	cvInvert(H, HInv);

	CvMat * M = cvCreateMat(3, 3, CV_64FC1);

	cvMatMul(h, HInv, M);

	CvMat *MInv = cvCreateMat(3, 3, CV_64FC1);

	cvInvert(M, MInv);

	// now we have matrix MInv

	IplImage * dst = cvCreateImage(cvSize(image->width, image->height), image->depth, image->nChannels);
		
	for (int x = 0; x < image->width; x++) {
		for (int y = 0; y < image->height; y++) {
			CvPoint v = ApplyM(MInv, cvPoint(x, y));
			
			if (v.x >= 0 && v.y >= 0 &&
			    v.x < image->width && v.y < image->height) {
				//printf("T: (%d, %d) -> (%f, %f)\n", x, y, v.x, v.y); 
				CopyPixel(image, v.x, v.y, dst, x, y);
			}
		}
	}
	

	cvReleaseMat(&H);
	cvReleaseMat(&h);
	cvReleaseMat(&HInv);
	cvReleaseMat(&M);
	cvReleaseMat(&MInv);

	return dst;
}

CvMat * ProjectiveTransform64d(CvPoint2D64d fromP1, CvPoint2D64d fromP2,
			       CvPoint2D64d fromP3, CvPoint2D64d fromP4,
			       CvPoint2D64d toP1, CvPoint2D64d toP2,
			       CvPoint2D64d toP3, CvPoint2D64d toP4)
{
	Vector A = HomoPoint(fromP1);
	Vector B = HomoPoint(fromP2);
	Vector C = HomoPoint(fromP3);
	Vector D = HomoPoint(fromP4);


	Vector H1 = HVector(B, A, C, D);
	Vector H2 = HVector(A, D, B, C);
	Vector H3 = HVector(A, C, B, D);

	Vector a = HomoPoint(toP1);
	Vector b = HomoPoint(toP2);
	Vector c = HomoPoint(toP3);
	Vector d = HomoPoint(toP4);


	Vector h1 = HVector(b, a, c, d);
	Vector h2 = HVector(a, d, b, c);
	Vector h3 = HVector(a, c, b, d);

	CvMat * H = cvCreateMat(3, 3, CV_64FC1);
	CvMat * h = cvCreateMat(3, 3, CV_64FC1);


	HMat(H, H1, H2, H3);
	HMat(h, h1, h2, h3);

	CvMat * HInv = cvCreateMat(3, 3, CV_64FC1);
	
	cvInvert(H, HInv);

	CvMat * M = cvCreateMat(3, 3, CV_64FC1);

	cvMatMul(h, HInv, M);

	cvReleaseMat(&H);
	cvReleaseMat(&h);
	cvReleaseMat(&HInv);

	return M;

}



void P3ToP4(CvPoint in1, CvPoint in2, CvPoint in3, CvPoint * out4) {
	out4->x = in3.x + (in1.x - in2.x);
	out4->y = in3.y + (in1.y - in2.y);
}


void P2ToP3(CvPoint in1, CvPoint in2, CvPoint * out3) {
	Vector v1 = Vector(in1, in2);
	Vector v2 = Vector(0, 0, 1);
	Vector v3 = v1.cross(v2);
	
	v3.normalize();
	v3.scale(v1.size());

	out3->x = in2.x + (int) v3.x;
	out3->y = in2.y + (int) v3.y;

}


/*

 points arranged as follows:

(0, 0)

L4   L3

L1   L2

*/

void Cal2Point(IplImage * srcImage, CvPoint ref1, CvPoint ref2, int maxdist)
{

	CvMemStorage * storage = cvCreateMemStorage();

	CvSeq * landmarks = GetBlueCenters(srcImage, storage, 2);

	if (landmarks->total < 2)
		return;

	CvPoint landmark1 = * (CvPoint *) cvGetSeqElem(landmarks, 0);
	CvPoint landmark2 = * (CvPoint *) cvGetSeqElem(landmarks, 1);

	CvPoint landmark3, landmark4;

	if (landmark1.x > landmark2.x) {
		CvPoint tmp = landmark2;
		landmark2 = landmark1;
		landmark1 = tmp;
	}

	if (landmark1.x == 0 && landmark1.y == 0) {
		printf("Cal2Point(): Insufficient landmarks.\n");
		return;
	}

	// too far away

	Vector v1 = Vector(landmark1).subtract(Vector(ref1));
	Vector v2 = Vector(landmark2).subtract(Vector(ref2));

	if (v1.size() > maxdist || v2.size() > maxdist) {
		printf("Cal2Point(): Landmark distances: %f, %f\n", v1.size(), v2.size());
		return;
	}

	P2ToP3(landmark1, landmark2, &landmark3);
	P3ToP4(landmark1, landmark2, landmark3, &landmark4);

	printf("Cal2Point(): L1: (%d, %d)   L2: (%d, %d)  L3:(%d, %d)  L4:(%d, %d)\n",
	       landmark1.x, landmark1.y,
	       landmark2.x, landmark2.y,
	       landmark3.x, landmark3.y,
	       landmark4.x, landmark4.y);

	cvCircle(srcImage, landmark3, 5, CV_RGB(200, 200, 0), 5);
	cvCircle(srcImage, landmark4, 5, CV_RGB(200, 200, 0), 5);

	CvPoint ref3;
	CvPoint ref4;

	P2ToP3(ref1, ref2, &ref3);
	P3ToP4(ref1, ref2, ref3, &ref4);


	IplImage * transformed = ProjectiveTransform(landmark1, landmark2, landmark3, landmark4, ref1, ref2, ref3, ref4, srcImage);
	
	cvCopy(transformed, srcImage);
	
	cvReleaseImage(&transformed);

	cvReleaseMemStorage(&storage);

}


void InitLandmarks( LandmarkFinder * lf, CvSize imgSize, IplImage * templateImage) {

	lf->templateImage = templateImage;

	lf->matchresult32f = cvCreateImage(cvSize(imgSize.width - lf->templateImage->width + 1,
						  imgSize.height - lf->templateImage->height + 1),
					   IPL_DEPTH_32F, 1);
	
	lf->matchresult = cvCreateImage(cvSize(imgSize.width - lf->templateImage->width + 1,
					       imgSize.height - lf->templateImage->height + 1),
					IPL_DEPTH_8U, 1);
	
	lf->lmstorage = cvCreateMemStorage(0);

        lf->landmarks = cvCreateSeq( CV_SEQ_ELTYPE_POINT, sizeof(CvSeq),
				     sizeof(CvPoint), lf->lmstorage );



	//DisplayIplImage(templateImage, "template");
}

int NumContours(CvSeq * contours) {
	int num = 0;

	while (contours != NULL) {
		num++;
		contours = contours->h_next;
	}

	return num;
}

int NumContours(CvSeq * contours, int minsize) {
	int num = 0;

	while (contours != NULL) {
		CvMoments moments;
		
		cvContourMoments(contours, &moments);
	
		double area = cvGetSpatialMoment(&moments, 0, 0);

		if (area >= minsize)
			num++;

		contours = contours->h_next;
	}

	return num;

}


//
int FindLandmarks(LandmarkFinder * lf, IplImage * rawImage) {
	MyMatchTemplate2(rawImage, lf->templateImage, lf->matchresult32f, CV_TM_CCOEFF_NORMED); 

	//double tmean = cvMean(matchresult, 0);
	//printf("Template match mean = %f\n", tmean);
	
	//cvAddWeighted(matchresult, 0.1, matchresult, 0, 0, matchresult);
	cvConvertScale(lf->matchresult32f, lf->matchresult, 256, 0);

	DisplayIplImage(lf->matchresult, "raw template");

	CvMemStorage * storage = cvCreateMemStorage(0);

	bool done = false;

	int pixthreshold = 254;

	IplImage * tmpresult = cvCloneImage(lf->matchresult);
	CvSeq * contours = NULL;

	do {
		fprintf(stderr, "Trying match threshold %d\n", pixthreshold);
		cvThreshold(tmpresult, lf->matchresult, pixthreshold, 255, CV_THRESH_BINARY);	
		// find contours and store them all as a list
		cvFindContours( lf->matchresult, storage, &contours, sizeof(CvContour),
				CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );
		
		pixthreshold -= 20;

		if (pixthreshold < 50 || NumContours(contours) >= 4) {
			done = true;
			
			

		}

	} while (!done);

	cvReleaseImage(&tmpresult);
	
	done = false;

	int numerode = 0;
	
	while (NumContours(contours) > 4 && numerode < 10) {
		fprintf(stderr, "Eroding match\n");
		numerode++;
		cvErode(lf->matchresult, lf->matchresult, NULL, 1);
		cvFindContours( lf->matchresult, storage, &contours, sizeof(CvContour),
				CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );
	}

	cvDilate(lf->matchresult, lf->matchresult, NULL, 5);

	DisplayIplImage(lf->matchresult, "processed template");		

	//cvDrawContours(rawImage, contours, CV_RGB(0, 200, 200), CV_RGB(0, 0, 0), 2, 0);

	cvClearSeq(lf->landmarks);
	
	int i = 0;

	while (contours != NULL) {
		CvMoments moments;
		
		cvContourMoments(contours, &moments);
	
		double area = cvGetSpatialMoment(&moments, 0, 0);
		double xc = cvGetSpatialMoment(&moments, 1, 0) / area;
		double yc = cvGetSpatialMoment(&moments, 0, 1) / area;

		//printf("iteration %d  xc %f  yc %f area %f\n", i, xc, yc, area);

		CvPoint centroid = cvPoint((int) (xc + lf->templateImage->width / 2),
					   (int) (yc + lf->templateImage->height / 2));

		if (centroid.x < 0 || centroid.y < 0) {
			contours = contours->h_next;
			i++;
			continue;
		}

		cvSeqPush(lf->landmarks, &centroid);

		//printf("Landmark %d = (%d, %d)\n", i, centroid.x, centroid.y); 
		//printf("Landmark (%d, %d)\n",  centroid.x, centroid.y); 
		
		contours = contours->h_next;
		i++;
	}

	//printf("Done finding landmarks.\n");

	//printf("\n");

	cvReleaseMemStorage(&storage);

	return lf->landmarks->total;
}


void DrawLandmarks(IplImage * rawImage, CvSeq * landmarks) {

	assert(rawImage);
	assert(landmarks);

	if (landmarks->total == 0)
		return;

	CvSeqReader reader;
	cvStartReadSeq( landmarks, &reader, 0 );
 
	for (int i = 0; i < landmarks->total; i++) {
		CvPoint landmark;
		CV_READ_SEQ_ELEM( landmark, reader );

		cvCircle(rawImage, landmark, 5, CV_RGB(220, 220, 0), 5);
	}

}


void SwapPt(CvPoint * pt1, CvPoint * pt2) {
	CvPoint pt = *pt1;
	*pt1 = *pt2;
	*pt2 = pt;
}

/* Sorted into

L1  L2

L3  L4
*/

void SortLandmarks ( CvPoint * landmark1, CvPoint * landmark2,
		     CvPoint * landmark3, CvPoint * landmark4) {

	if (landmark3->y < landmark1->y)
		SwapPt(landmark3, landmark1);
	if (landmark3->y < landmark2->y)
		SwapPt(landmark3, landmark2);
	if (landmark4->y < landmark1->y)
		SwapPt(landmark4, landmark1);
	if (landmark4->y < landmark2->y)
		SwapPt(landmark4, landmark2);

	if (landmark2->x < landmark1->x)
		SwapPt(landmark2, landmark1);
	if (landmark4->x < landmark3->x)
		SwapPt(landmark4, landmark3);
			

	fprintf(stderr, "Done sorting landmarks\n");
}

int Cal4Point(LandmarkFinder * lf, IplImage * srcImage,
	      CvPoint ref1, CvPoint ref2, CvPoint ref3, CvPoint ref4,
	      CvPoint * refb1, CvPoint * refb2, CvPoint * refb3, CvPoint * refb4,
	      int *lostcount)
{

	static int findskip = 0;

	CvPoint landmark1, landmark2, landmark3, landmark4;

	if (findskip++ % 1 == 0)
		FindLandmarks(lf, srcImage);

	CvSeq *landmarks = lf->landmarks;

	fprintf(stderr, "Number of landmarks found: %d\n", landmarks->total);

	if (landmarks->total != 4) {
		if (*lostcount == -1 || *lostcount > 10)
			return 0;
		*lostcount++;
		landmark1 = *refb1;
		landmark2 = *refb2;
		landmark3 = *refb3;
		landmark4 = *refb4;
	} else {
		landmark1 = * (CvPoint *) cvGetSeqElem(landmarks, 0);
		landmark2 = * (CvPoint *) cvGetSeqElem(landmarks, 1);
		landmark3 = * (CvPoint *) cvGetSeqElem(landmarks, 2);
		landmark4 = * (CvPoint *) cvGetSeqElem(landmarks, 3);
		
		DrawLandmarks(srcImage, landmarks);
		*lostcount = 0;
		*refb1 = landmark1;
		*refb2 = landmark2;
		*refb3 = landmark3;
		*refb4 = landmark4;
	}
	
	SortLandmarks(&landmark1, &landmark2, &landmark3, &landmark4);

	printf("Cal4Point(): L1: (%d, %d)   L2: (%d, %d)  L3:(%d, %d)  L4:(%d, %d)\n",
	       landmark1.x, landmark1.y,
	       landmark2.x, landmark2.y,
	       landmark3.x, landmark3.y,
	       landmark4.x, landmark4.y);

	int width = (landmark2.x - landmark1.x + landmark4.x - landmark3.x) / 2;
	int height = (landmark3.y - landmark1.y + landmark4.y - landmark1.y) / 2;

	if (width * height < 100000) {
		printf("Landmarks not the right shape.");
		return 0;
	}
	
	IplImage * transformed = ProjectiveTransform(landmark1, landmark2, landmark3, landmark4, ref1, ref2, ref3, ref4, srcImage);
	
	cvCopy(transformed, srcImage);
	
	cvReleaseImage(&transformed);

	return 1;
}

