/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef MVECTOR_H
#define MVECTOR_H

#include <cv.h>

class Vector {
 public:
	
	double x;
	double y;
	double z;
	
	Vector(CvPoint p);
	Vector(CvPoint2D64d p);
	Vector(CvPoint2D32f p);
	Vector(CvPoint p1, CvPoint p2);
	
	Vector(double x1, double y1, double z1);
	
	Vector cross(Vector v);

	void normalize();
	double size();
	void scale(double s);
	Vector subtract(Vector v);
};

#endif
