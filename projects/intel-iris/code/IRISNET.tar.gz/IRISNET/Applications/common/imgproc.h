/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
// Image processing functions that wrap around OpenCV.
//

#ifndef IMGPROC__H
#define IMGPROC__H

// OpenCV
#include <cv.h>
#include <highgui.h>

// Some general functions
float DistanceL2(float *fv1, float *fv2, int len);
double angle( CvPoint pt1, CvPoint pt2, CvPoint pt0 );

void DisplayIplImage(IplImage * image, const char * title );
IplImage * GetSrcImage();
IplImage * GetSrcImageKey(int key);
IplImage * GetSrcImage(void * mem);
IplImage *Cvt4to3(IplImage* image4);
IplImage *Cvt3to4(IplImage* image3);
IplImage* GetImagePart( IplImage* img, CvRect roi );
IplImage *MyColorToGray(IplImage *src);

IplImage *MyResize(IplImage* srcImg, int dstWidth, int dstHeight);
int MyAbsImageDiff(IplImage* img1, IplImage* img2, double * diff);
int MyAbsImageDiff2(IplImage* img1, IplImage* img2, double * diff);

void RemoveNoiseFromImage(IplImage *srcImage, IplImage *dstImage);
void MyRunningAvg(IplImage *srcImage, IplImage *dstImage, float alpha);

// Following 5 functions used for parking space finder
CvSeq* FindSquares4( IplImage* img, CvMemStorage* storage );
int PtEqual(CvPoint a, CvPoint b, int THR);
void SortPointsInRect(CvPoint *a);
CvSeq* ListUniqueSquares (CvSeq* squares, int THR, CvMemStorage *storage);
CvSeq* FindUniqueSquares4(IplImage* image, int threshold,
			  CvMemStorage* storage);


// following 3 functions are specific to face recognition application
int FindBestMatch(IplImage *image, IplImage **imageList, int listLen);
IplImage** LoadImages(char *confFile, int *listLen);

void RecognizeFaces(IplImage *image, IplImage **imageList, int listLen,
		    IplImage *colorImage, char** desc);

int ExtractCotext(IplImage *grayimage, float *feature_vector,
		  int *feature_len);


void Cal2Point(IplImage * srcImage, CvPoint ref1, CvPoint ref2, int maxdist);
CvSeq *  GetBlueCenters(IplImage * image, CvMemStorage * retstorage, int nCenters);

void MyMatchTemplate(IplImage *img, IplImage *templ, IplImage *result, CvTemplMatchMethod method);
void MyMatchTemplate2(IplImage *img, IplImage *templ, IplImage *result, CvTemplMatchMethod method);

typedef struct {
	IplImage * templateImage;
	IplImage * matchresult32f;
	IplImage * matchresult;
	CvSeq * landmarks;
	CvMemStorage * lmstorage;
} LandmarkFinder;

int FindLandmarks(LandmarkFinder * lf, IplImage * rawImage);
void InitLandmarks(LandmarkFinder * lf, CvSize srcImageSize, IplImage * templateImage);
void DrawLandmarks(IplImage * rawImage, CvSeq * landmarks);
void SortLandmarks ( CvPoint * landmark1, CvPoint * landmark2,
		     CvPoint * landmark3, CvPoint * landmark4);
//int Cal4Point(LandmarkFinder *lf, IplImage * srcImage, CvPoint ref1, CvPoint ref2, CvPoint ref3, CvPoint ref4);
int Cal4Point(LandmarkFinder * lf, IplImage * srcImage,
	      CvPoint ref1, CvPoint ref2, CvPoint ref3, CvPoint ref4,
	      CvPoint * refb1, CvPoint * refb2, CvPoint * refb3, CvPoint * refb4,
	      int *lostcount);
int NumContours(CvSeq * contours);
int NumContours(CvSeq * contours, int minsize);

CvMat * ProjectiveTransform64d(CvPoint2D64d fromP1, CvPoint2D64d fromP2,
			       CvPoint2D64d fromP3, CvPoint2D64d fromP4,
			       CvPoint2D64d toP1, CvPoint2D64d toP2,
			       CvPoint2D64d toP3, CvPoint2D64d toP4);

CvMat * FindProjTransform(CvPoint2D32f fromP1, CvPoint2D32f fromP2, CvPoint2D32f fromP3, CvPoint2D32f fromP4,
			  CvPoint2D32f toP1, CvPoint2D32f toP2, CvPoint2D32f toP3, CvPoint2D32f toP4);

CvPoint2D64d ApplyM64d(CvMat * M, CvPoint2D64d in);
CvPoint2D32f ApplyM32f(CvMat * M, CvPoint2D32f in);

CvPoint ApplyM(CvMat * M, CvPoint in);

void CopyPixel(IplImage * fromImage, int fromx, int fromy,
               IplImage * toImage, int tox, int toy);

IplImage * HalfImage(IplImage *srcImage);

#endif
