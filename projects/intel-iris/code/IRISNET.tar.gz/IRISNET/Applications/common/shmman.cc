/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

// This file implements helper functions for shared memory management.

// SA Application includes
#include <shmman.h>

// Unix includes
#include <sys/shm.h>
#include <stdio.h>
#include <sys/time.h>

// Creates shared memory to dump the frames from the webcam.
// The shared memory segment must be initialized with this function
// before it can be used.
// We write a header block to the beginning of the shared memory, and then
// mark the rest of the memory for the frames.
//
// the frames are assumed to be of 4-byte color
// the frames are used as a circular buffer 
// 
// The first int in the shared buffer indocates the head of the circular queue
// The rest of the buffer is the circular buffer
//
// returns 0 if failure, 1 if successful
int CreateSharedMemory(int numFrames, int width, int height, int bytesPerPixel, int key, int flags)
{
	int size = width * height * bytesPerPixel;
	int shmid; // shared memory id
	int i;
	shmHeaderType *shmHeader;

	// check frames range
	if (numFrames > MAX_SHM_FRAMES) {
		printf("Num frames of %d too high.  Adjusted to %d frames\n",
		       numFrames, MAX_SHM_FRAMES);
		numFrames = MAX_SHM_FRAMES;
	}

	if (numFrames <= 0) {
		printf("%d frames is invalid.  Setting to 1.\n", numFrames);
		numFrames = 1;
	}
	
	printf("Creating %d bytes shared memory for %d webcam frames\n",
		sizeof(shmHeaderType) + size * numFrames, numFrames);

	// createss shared memory segment with proper size and id
	if ((shmid =
	     shmget(key,
		    sizeof(shmHeaderType) + size * numFrames,
		    flags | IPC_CREAT)) < 0) {
		perror("Failed to create shared memory");
		printf("This may happen when another application previously\n");
		printf("allocated shared memory that was too small.\n");
		printf("You may also get this error when using 'loadImage' to\n");
		printf("load images with smaller size or depth into shared memory.\n");
		printf("When upgrading to a new version of this program, you may get this error.\n");
		printf("Please reboot your machine and try again.\n");
		return 0;
	}

	// put header at the beginning of shared memory
	shmHeader = (shmHeaderType *) shmat(shmid, 0, 0);
	shmHeader->isInit = SHM_NOTINIT;
	shmHeader->width = width;
	shmHeader->height = height;
	shmHeader->numFrames = numFrames;
	shmHeader->bytesPerPixel = bytesPerPixel;
	shmHeader->bufsize = sizeof(shmHeaderType) + numFrames * size;
	shmHeader->buffHead = 0;
	shmHeader->lastUpdateTime = 0;

	/*
	shmInfo->numFrames = numFrames;
	shmInfo->shmKey = IMAGE_SHM_KEY;
	shmInfo->size = shmHeader->bufsize;
	*/
	// mark frames in shared memory
	for (i = 0; i < numFrames; i++) {
		shmHeader->offsets[i] = sizeof(shmHeaderType) + i * size;
		//shmInfo->offsets[i] = shmHeader->offsets[i];
		printf("CreateSharedMemory(): Setting offset %d to %x\n", i, shmHeader->offsets[i]);
		shmHeader->timestamps[i] = 0;
	}


       	shmHeader->isInit = SHM_INITIALIZED;

	shmdt((void *) shmHeader);

	return 1;
}


void * OpenSharedMemory() {
	return OpenSharedMemoryKey(IMAGE_SHM_KEY);
}

// Opens shared memory segment
// Returns address of memory segment on success, NULL on error
void * OpenSharedMemoryKey(int key)
{
        int shmid = 0;
	shmHeaderType * shmHeader = NULL;
	int shmsize = 0;
	void * mem = NULL;
	
	// open the shared memory to dump the frames
	shmid = shmget(key, sizeof(shmHeaderType), 0);
	if (shmid < 0) {
		fprintf(stderr, "OpenSharedMemory(): Error getting shared memory id of key %d\n", key);
		perror("OpenSharedMemory()");
		return NULL;
	}
	
	shmHeader = (shmHeaderType *) shmat(shmid, 0, 0);
	
	if ((int) shmHeader == -1) {
		fprintf(stderr, "OpenSharedMemory(): Error attaching shared memory\n");
		perror("OpenSharedMemory()");
		return NULL;
	}
	
	if (shmHeader->isInit != SHM_INITIALIZED) {
		fprintf(stderr, "OpenSharedMemory(): Shared memory not initialized\n");
		return NULL;
	}
	
	shmsize = shmHeader->bufsize;
	
	if (shmdt((void *) shmHeader) != 0) {
		fprintf(stderr, "OpenSharedMemory(): Error detaching shared memory\n");
		perror("OpenSharedMemory()");
		return NULL;
	}
	
	// fprintf(stderr, "OpenSharedMemory(): Attaching shared memory of size %d\n", shmsize);
	
	shmid = shmget(key, shmsize, 0);
	if (shmid < 0) {
		printf("OpenSharedMemory(): Error getting shared memory id\n");
		perror("OpenSharedMemory()");
		return NULL;
	}
	
	mem = shmat(shmid, 0, 0);
	
	if ((int) mem == -1) {
		fprintf(stderr, "OpenSharedMemory(): Error attaching final shared memory\n");
		perror("OpenSharedMemory()");
		return NULL;
	}
	
	return mem;
}

shmHeaderType * OpenSharedMemoryHeader() {
	return OpenSharedMemoryHeaderKey(IMAGE_SHM_KEY);
}

// Opens shared memory for reading
// returns NULL on error
shmHeaderType * OpenSharedMemoryHeaderKey(int key)
{
        int shmid = 0;
	shmHeaderType * shmHeader = NULL;
       
	// open the shared memory to dump the frames
	shmid = shmget(key, sizeof(shmHeaderType), 0);
	if (shmid < 0) {
		perror("OpenSharedMemoryHeader(): Error in opening shared segment");
		return NULL;
	}

	shmHeader = (shmHeaderType *) shmat(shmid, 0, 0);

	if ((int) shmHeader == -1) {
		perror("OpenSharedMemoryHeader()");
		return NULL;
	}


	return shmHeader;
}

long GetTime() {
	struct timeval t;

	gettimeofday(&t ,NULL);

	return t.tv_sec * 1000 + t.tv_usec / 1000;

}
