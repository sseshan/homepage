#include "filter.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>


pid_t pid = 0;

void Dum2LogPid()
{
    char buf[80];
    FILE * outf;

    pid = getpid();
    printf("dummy2 got pid as %d.\n", pid);

    sprintf(buf, "/tmp/IRISSA.dummy2.pid.%d", pid);

    outf = fopen(buf, "w");

    if (outf == NULL)
        printf("Error opening pid file %s\n", buf);

    sprintf(buf, "%d\n", pid);
    fwrite(buf, 1, strlen(buf), outf);
    fflush(outf);
    fclose(outf);
}

int Start(FilterParameter param)
{
	int i = 0;

	Dum2LogPid();

	while (1) {
		printf("Dummy2 on pid %d running iteration %d.\n", pid, i++);

		sleep(10);	
	}
}
