/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*

Parking lot demo for Oceanographer's workshop


                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

/* Parking Space Finder senselet code */

// Stevens library
#include <unp.h>


// SA Application includes
#include <shmman.h>
#include <filter.h>

#include <imgproc.h>
#include "parking.h"

// OpenCV
#include <cv.h>
#include <highgui.h>


// Unix includes
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>

#define THR 60
#define PS_FULL 1
#define PS_EMPTY 0

int ConnectToOA(OrgAgent *oa)
{
	int  sockfd = -1;
	struct sockaddr_in saaddr;
	char buffer[MAXBUFLEN];

	assert (oa != NULL);

	// debug
	inet_ntop(AF_INET, &(oa->addr.s_addr), buffer, MAXBUFLEN);
	printf("Connecting to host %s, port %d\n", buffer, oa->port);
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(oa->port);
	//Inet_pton(AF_INET, sa->addr.s_addr, &saaddr.sin_addr);
	saaddr.sin_addr = oa->addr;  

	
	if (connect(sockfd, (SA *) &saaddr, sizeof(saaddr)) < 0)
		return -1;

	return sockfd;
}


// write the string "st" to the socket 
// prepends length of string to "st"
// returns 1 on success, 0 on error
int SendToOA(int sockfd, char *st)
{
	unsigned long len = 0;
	char lenSt[7];

	assert (st != NULL);

	// calculate length of packet
	// must be able to fit in a 3 byte signed int
	len = strlen(st) + 7;

	lenSt[0] = len / (128 * 128) ; //(len & 0xff0000) >> 16;
	lenSt[1] = (len % (128 * 128)) / 128; //(len & 0x00ff00) >> 8;
	lenSt[2] = (len % (128 * 128)) % 128; // (len & 0x0000ff);

	// not sure what these bytes are used for
        //   lenSt[3] = (len & 0x000000ff);
	lenSt[3] = ' ';
	lenSt[4] = '-';
	lenSt[5] = '1';
	lenSt[6] = ' ';

	printf("Parking.SendToOA(): Sending message:\n%s\n\n", st);

	// write total length of message
	Write (sockfd, lenSt, 7);
	
	// write message
	Write (sockfd, st, len - 7);

	return 1;
}

// initializes pconf from configuration file
// returns 1 on success, 0 on error
int InitConfiguration(char * confFileName, ParkingConfType * pconf)
{
	FILE * fp; // file pointer to configuration file
	char fname[MAXBUFLEN]; // file name of reference image of a pspot
	int i;

	assert(confFileName != NULL);
	assert(pconf != NULL);

	// Open configuration file
	if ( (fp = fopen(confFileName, "rt")) == NULL) {
		printf("Parking.InitConfiguration(): Error opening %s configuration file.\n", confFileName);
		return 0;
	}

	printf("Parking.InitConfiguration(): Reading in %d XML Update header lines.\n", NUM_XML_LINES);
	// Load header information
	for (i = 0 ; i < NUM_XML_LINES; i++) {
		int len;

		fgets(pconf->XMLLine[i], MAXBUFLEN, fp); // gets the header of the packet
		len  = strlen(pconf->XMLLine[i]); 
		if (pconf->XMLLine[i][len-1] == '\n')
			pconf->XMLLine[i][len-1] = 0;

		printf("%s\n", pconf->XMLLine[i]);
	}

	fscanf(fp, "%d %d %d", &(pconf->sleepTime), &(pconf->displayFlag), &(pconf->numSpaces));

	printf("Parking.InitConfiguration(): Time interval between updates is %d seconds.\n", pconf->sleepTime);
	
	printf("Parking.InitConfiguration(): Number of spaces in this lot: %d\n", pconf->numSpaces);

	// allocate memory for all spaces
	pconf->parkingDesc = (ParkingDescType *) calloc(pconf->numSpaces,
							sizeof(ParkingDescType));

	int ret;

	// read in each individual space
	for (i = 0; i < pconf->numSpaces; i++) {
	       

		ret = fscanf(fp, "%d %d %d %d %s %s",
			     &(pconf->parkingDesc[i].roi.x),
			     &(pconf->parkingDesc[i].roi.y),
			     &(pconf->parkingDesc[i].roi.width),
			     &(pconf->parkingDesc[i].roi.height),
			     (pconf->parkingDesc[i].desc), fname);

		if (ret != 6) {
			printf("Parking.InitConfiguration(): Parking spot description error.\n");
			return 0;
		}

		printf("Parking.InitConfiguration(): Loading image: %s\n", fname);
		printf("Parking.InitConfiguration():   ROI at (%dx%d) of size (%dx%d)\n",
			pconf->parkingDesc[i].roi.x,
                        pconf->parkingDesc[i].roi.y,
                        pconf->parkingDesc[i].roi.width,
                        pconf->parkingDesc[i].roi.height);

		pconf->parkingDesc[i].image = cvvLoadImage(fname);
	}

	ret = fscanf(fp, "%d", &(pconf->numrefs));

	if (ret != 1) {
		printf("Parking.InitConfiguration(): Number of reference points error.\n");
		return 0;	
	}

	printf("Parking.InitConfiguration(): Number of landmarks in calibration file: %d\n", pconf->numrefs);

	if (pconf->numrefs != 0) {
		ret = fscanf(fp, "%d %d %d %d %d %d %d %d",
			     &(pconf->ref1.x),
			     &(pconf->ref1.y),
			     &(pconf->ref2.x),
			     &(pconf->ref2.y),
			     &(pconf->ref3.x),
			     &(pconf->ref3.y),
			     &(pconf->ref4.x),
			     &(pconf->ref4.y));
		
		if (ret != 8) {
			printf("Parking.InitConfiguration(): Reference points error.\n");
			return 0;
		}
		
		printf("Parking.InitConfiguration(): Landmarks: (%d, %d), (%d, %d), (%d, %d), (%d, %d)\n",
		       pconf->ref1.x, pconf->ref1.y, pconf->ref2.x, pconf->ref2.y,
		       pconf->ref3.x, pconf->ref3.y, pconf->ref4.x, pconf->ref4.y);
	}

	return 1;
}


// Analyzes the status of the parking spots
// puts PS_FULL or PS_EMPTY in status[]
// puts the number of PS_FULL spots in occupied
// return 1 on success, 0 on error
int GetPSpotStatus(ParkingConfType * pconf,
	IplImage * srcImg, char * status, int * occupied)
{
	IplImage * partImg = NULL;

	int i;

	double mean;

	assert (pconf != NULL);
	assert (srcImg != NULL);
	assert (status != NULL);

	*occupied = 0;

	//printf("Parking.GetPSpotStatus(): Looping through %d spots\n", pconf->numSpaces);

	// Loop through all parking spaces and analyze each one
	for (i = 0; i < pconf->numSpaces; i++) {
		partImg = GetImagePart(srcImg, pconf->parkingDesc[i].roi);
		MyAbsImageDiff2(partImg, pconf->parkingDesc[i].image, &mean);

		
		printf("Parking.GetPSpotStatus(): Mean for parking spot %d is %f\n", i, mean); 
		
		if (mean > THR) {
			//printf("\tParking spot \"%s\" is full\n", pconf->parkingDesc[i].desc);
			(*occupied)++;
			status[i] = PS_FULL;
		}
		else {
			//printf("\tParking spot \"%s\" is empty\n", pconf->parkingDesc[i].desc);
			status[i] = PS_EMPTY;
		}

		cvReleaseImageHeader(&partImg);

	}

	return 1;
}

// Initialize X11 Window for display parking spots
int InitDisplay()
{

	cvvNamedWindow("live", 1);

	return 0;
}

// Display status of parking spots on the screen
// return 1 on success, 0 on error
int DisplayPSpotStatus(ParkingConfType * pconf, IplImage * srcImg,
	char * status)
{
	int VERTEX_COUNT = 4;
	IplImage *displayImage = NULL;
	CvFont font;	
	int i;

	assert (pconf != NULL);
	assert (srcImg != NULL);
	assert (status != NULL);
	
	cvInitFont(&font, CV_FONT_VECTOR0, 1.0, 1.0, 0, 4);	

	// creates image for display
	displayImage = cvCloneImage(srcImg);
	
	// Loop through all parking spots
	for (i = 0; i < pconf->numSpaces; i++) {
		int PS_FULL_COLOR = CV_RGB(255, 0 , 0); // red
		int PS_EMPTY_COLOR = CV_RGB(0, 255, 0); // green
		int PS_TEXT_COLOR = CV_RGB(0, 0, 255); // blue
		CvPoint pt[4], *ptList = pt;
		int ps_color = 0; // parking space color
		CvRect roi;

		roi = pconf->parkingDesc[i].roi;
		
		// Calculate box to draw around parking spot
		pt[0].x = roi.x;
		pt[0].y = roi.y;
                
		pt[1].x = pt[0].x + roi.width;
		pt[1].y = pt[0].y;
                
		pt[2].x = pt[1].x;
		pt[2].y = pt[1].y + roi.height;

                pt[3].x = pt[0].x;
		pt[3].y = pt[2].y;

		// determine box color
		if (status[i] == PS_FULL)
			ps_color = PS_FULL_COLOR;
		else
			ps_color = PS_EMPTY_COLOR;

		// draw box
		cvPolyLine( displayImage, &ptList, &VERTEX_COUNT, 1, 1, ps_color, 6, 6 );

		// draw parking spot description
		cvPutText(displayImage, pconf->parkingDesc[i].desc,
			  cvPoint(roi.x + roi.width / 4, roi.y + roi.height / 2),
			  &font, PS_TEXT_COLOR);

	}


	DisplayIplImage(displayImage, "Parking Spot App");

	cvReleaseImage(&displayImage);
			 
	return 1;
}

// generate XML update to be sent to the OA
// return 1 on success, 0 on error
int GenXMLUpdate(ParkingConfType * pconf, char * status,
	int occupied, char * xupdate)
{
	int i;
	char buffer[MAXBUFLEN], result[MAXBUFLEN];

	struct timeval tv;

	assert (pconf != NULL);
	assert (status != NULL);
	assert (xupdate != NULL);
	
	result[0] = 0;

	strcat(xupdate, pconf->XMLLine[0]);
	strcat(xupdate, "\n");

	for (i = 0; i < pconf->numSpaces; i++) {
		strcat(xupdate, pconf->XMLLine[1]);
		sprintf(buffer, "/parkingSpace[@id='%d']/usage/in-use", i + 1);
		strcat(xupdate, buffer);
			
		if (status[i] == PS_FULL) {
			// make the message here
			// printf("Parking spot %s is full\n", pconf->parkingDesc[i].desc);
			strcat(result, " yes");
			strcat(xupdate, " yes ");
		}
		else {
			// printf("Parking spot %s is empty\n", pconf->parkingDesc[i].desc);
			strcat(result, " no");
			strcat(xupdate, " no ");
		}

		strcat(xupdate, "\n"); 

	}
			
	strcat(xupdate, pconf->XMLLine[2]); // update the count
	sprintf(buffer, " %d ", occupied);
	strcat(xupdate, buffer);
	strcat(xupdate, "\n");

	gettimeofday(&tv, NULL);
		
	strcat(xupdate, pconf->XMLLine[3]); // update the time
	sprintf(buffer, " %.0lf ", tv.tv_sec * 1000.0 + tv.tv_usec/1000);
	strcat(xupdate, buffer);
	strcat(xupdate, "ENDMESSAGE");

	sprintf(buffer, "%d %s\n", occupied, result);
	printf("%s\n", buffer);

	return 1;

}

extern "C" {

// return 1 if no error
// return 0 on error
int Start(FilterParameter param)
{
	int step;
	CvSize size;
	shmHeaderType *shmHeader = NULL;
	uchar *shm = NULL;
	ParkingConfType pconf;

//	CvMemStorage *storage1, *storage2;

	printf("Parking Spot Finder Application starting...\n");

	if (InitConfiguration("parking.conf", &pconf) == 0) {
		printf("Parking(): Configuration initialization error.\n");
		return 0;
	}
		

//	storage1 = cvCreateMemStorage(0);
//	storage2 = cvCreateMemStorage(0);
	
	//shm = (uchar *) OpenSharedMemoryKey(IMAGE_RAW_SHM_KEY);
	shm = (uchar *) OpenSharedMemoryKey(IMAGE_SHM_KEY);

	shmHeader = (shmHeaderType *) shm;

	if (shm == NULL) {
	        printf("Parking(): Error initializing shared memory.\n");
		return 0;
        }
	else
		printf("Parking(): Shared memory of size %d initialized\n", shmHeader->bufsize);

	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;

	//InitDisplay();
	
	long lasttime = GetTime();
	int count = 0;
	int interval = 1;

	printf("Parking(): Threshold for difference image is %d\n", THR);

	LandmarkFinder lf;
	IplImage * templateImage = cvLoadImage("template.png");
	if (templateImage == NULL) {
		fprintf(stderr, "Error opening template image.\n");
		return 1;
	}
 
	InitLandmarks(&lf, size, templateImage);

	int lostcount = -1;
	CvPoint refb1, refb2, refb3, refb4;

	for (;;){
		char xupdate[MAXBUFLEN * 8] = "";
		char status[pconf.numSpaces];
		int sockfd;
		int occupied;
		int cal = 0;

		IplImage *srcImg = GetSrcImage(shm);
		// PSF specific steps
		if (pconf.numrefs == 4)
			cal = Cal4Point(&lf, srcImg, pconf.ref1, pconf.ref2, pconf.ref3, pconf.ref4,
					&refb1, &refb2, &refb3, &refb4, &lostcount);
		GetPSpotStatus(&pconf, srcImg, status, &occupied);
		if (cal == 0) {
			CvFont font;
			cvInitFont(&font, CV_FONT_VECTOR0, 1.0, 1.0, 0, 4);	

			// draw parking spot description
			cvPutText(srcImg, "NO LANDMARKS FOUND!!!",
				  cvPoint(30, 30),
				  &font, CV_RGB(255, 0, 0));
		}

		if (pconf.displayFlag == 1)
			DisplayPSpotStatus(&pconf, srcImg, status);
		GenXMLUpdate(&pconf, status, occupied, xupdate);
		// end of PSF specific steps
	
		//squares = FindUniqueSquares4(image1, 50, 1, storage1, storage2);
		
		// send XML Update to OA
		
		// normal
		
		sockfd = ConnectToOA(param.oa);
		if (sockfd >= 0) {
  		        SendToOA(sockfd, xupdate);
		        Close(sockfd);
		}
		
		/*
		//demo only
		inet_pton(AF_INET, "128.2.209.220", & (param.oa->addr));
		sockfd = ConnectToOA(param.oa);
		if (sockfd >= 0) {
			SendToOA(sockfd, xupdate);
			Close(sockfd);
		}
		inet_pton(AF_INET, "128.2.206.13", & (param.oa->addr));
		sockfd = ConnectToOA(param.oa);
		if (sockfd >= 0) {
			SendToOA(sockfd, xupdate);
			Close(sockfd);
		}
		*/
		
		cvReleaseImage(&srcImg);

//		cvClearMemStorage(storage1);
//		cvClearMemStorage(storage2);

		count++;

		if (count % interval == 0) {
			float msperframe = (float) (GetTime() - lasttime) / interval;
			printf("Perf: %f ms per frame.\n", msperframe);
			lasttime = GetTime();
		}

		if (pconf.sleepTime < 100)
			sleep(pconf.sleepTime);
		else
			usleep(pconf.sleepTime);

	}
	
	shmdt(shm);

	printf("Parking(): Exiting application...\n");
	return 1;
}

} // end extern c

/*
int main()
{
	FilterParameter param;
	printf("here I am\n");	
	param.shmKey = IMAGE_SHM_KEY;
	//strcpy(param.confFile, "parking.conf");
	Start(param);

	return 0;
}
*/
