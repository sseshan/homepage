/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:5; tab-width:5; indent-tabs-mode:t -*- */
#include "unp.h"
#include "cv.h"
#include "highgui.h"
#include "ipp.h"
#include "SA.h"
#include "filter.h"
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>
#include "imgproc.h"

#define THR 15
#define SLEEP 2

CvMemStorage *storage1, *storage2;


int Start(FilterParameter param)
{
     IplImage *image0 = 0, *image1 = 0, *part, *diff;
	parkingDescType *parkingDesc;
	int sockfd;
	int listLen, step, shmid, i, parkingCount, occupied;
	CvSize size;
	shmHeaderType *shmHeader;
	uchar *shm;
	CvSeq* squares;
	char buffer[1024], fname[64], result[256];
	FILE *fp;
	double mean;
	
	//----- read the configuration file
	if ( (fp = fopen(param.confFile,"rt")) == NULL)
		return 1; // erro rin opening conf file

	fscanf(fp, "%d", &parkingCount);
	parkingDesc = (parkingDescType*) calloc(parkingCount, sizeof(parkingDescType));
	for (i = 0; i<parkingCount; i++) {
		fscanf(fp, "%d %d %d %d %s %s", &(parkingDesc[i].roi.x), &(parkingDesc[i].roi.y), &(parkingDesc[i].roi.width),&(parkingDesc[i].roi.height), (parkingDesc[i].desc), fname);
		printf("Loading image: %s\n", fname);
		parkingDesc[i].image = MyColorToGray(cvvLoadImage(fname), 0);
	}
		

	storage1 = cvCreateMemStorage(0);
	storage2 = cvCreateMemStorage(0);
	
     	// sockfd = ConnectToOA(param.oa);
	shmid = shmget(param.shmKey, 1228860, 0777);
	if (shmid < 0) {
		printf( "Error in opening shared segment");
		return 0;
	}
	shm = (uchar*) shmat(shmid, 0,  0);
	shmHeader = (shmHeaderType*)shm;
	
	//cvvNamedWindow("test", 1);
	
	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;
	
	for (;;){
		image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
		cvSetImageData(image0, (uchar*) (shm + shmHeader->offsets[shmHeader->buffHead]), step * shmHeader->width);
		
		image1 = MyColorToGray(image0, 1);

		//---- analyze spots
		result[0] = 0;
		occupied = 0;
		for (i =0 ; i < parkingCount; i++) {
			part = GetImagePart(image1, parkingDesc[i].roi);
			mean = MyAbsImageDiff_8u_C1R(part, parkingDesc[i].image);
			//printf("diff..\n");
			//diff = cvCreateImage(parkingDesc[i].roi, part->depth, part->nChannels);
			//cvAbsDiff(part, parkingDesc[i].image, diff);
			//printf("mean\n");
			//mean = cvMean(diff, 0);
			if (mean > THR) {
				// maMyAbsImageDiff_8u_C1Rke the message here
				printf("Parking spot %s is full %f\n", parkingDesc[i].desc, (float)mean);
				//strcat(result, " yes");
				occupied ++;
			}
			else {
				printf("Parking spot %s is empty %f\n", parkingDesc[i].desc, (float)mean);
				//strcat(result, " no");
			}
			
			//cvReleaseImage(&diff);
			cvReleaseImageHeader(&image0);
		}
		printf("--------------------------\n");	
		
		sprintf(buffer, "%d %s\n", occupied, result);
		//cvvShowImage("test", image1);
		
		//squares = FindUniqueSquares4(image1, 50, 1, storage1, storage2);
		
		// process the squares and make a string to send to OA
  		//if (SendToOA(sockfd, buffer) < 0)
		//	return 0;
		cvReleaseImage(&image1);
		sleep(SLEEP);
		cvClearMemStorage(storage1);
		cvClearMemStorage(storage2);


	}	
	shmdt(shm);
	return 0;
}



int main()
{
	FilterParameter param;
	printf("here I am\n");	
	param.shmKey = IMAGE_SHM_KEY;
	strcpy(param.confFile, "parking.conf");
	Start(param);

	return 0;
}

