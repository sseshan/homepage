/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* Currently not updated and not used */

/* -*-  Mode:C; c-basic-offset:5; tab-width:5; indent-tabs-mode:t -*- */
#include "unp.h"
#include "cv.h"
#include "highgui.h"
#include "SA.h"
#include "filter.h"
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>
#include "common.h"

CvMemStorage *storage1, *storage2;

int Start(FilterParameter param)
{
     IplImage *image0 = 0, *tmp;
	parkingDescType *parkingDesc;
	int listLen, step, shmid, i, parkingCount, occupied;
	CvSize size;
	shmHeaderType *shmHeader;
	uchar *shm;
	CvSeq* squares;
	char buffer[1024], fname[64], result[256];
	FILE *fp;
	double mean;
	int count = 4;
	CvPoint pt[4], *ptList = pt;

	//----- read the configuration file
	if ( (fp = fopen(param.confFile,"rt")) == NULL)
		return 1; // error in opening conf file

	storage1 = cvCreateMemStorage(0);
	storage2 = cvCreateMemStorage(0);

	shmid = shmget(param.shmKey, 1228860, 0777);
	if (shmid < 0) {
		printf( "Error in opening shared segment");
		return 0;
	}
	shm = (uchar*) shmat(shmid, 0,  0);
	shmHeader = (shmHeaderType*)shm;
	

	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;

	// read the parking conf file
	fscanf(fp, "%d", &parkingCount);
	parkingDesc = (parkingDescType*) calloc(parkingCount, sizeof(parkingDescType));
	for (i = 0; i<parkingCount; i++) {
		fscanf(fp, "%d %d %d %d %s %s", &(parkingDesc[i].roi.x), &(parkingDesc[i].roi.y), &(parkingDesc[i].roi.width),&(parkingDesc[i].roi.height), (parkingDesc[i].desc), fname);
	}

	cvvNamedWindow("parking", 1);
	for (;;) {
		image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
		cvSetImageData(image0, (uchar*) (shm + shmHeader->offsets[shmHeader->buffHead]), step * shmHeader->width);

		tmp = cvCloneImage(image0);

		for (i = 0; i<parkingCount; i++) {
			pt[0].x = parkingDesc[i].roi.x;  pt[0].y = parkingDesc[i].roi.y;
			pt[1].x = pt[0].x + parkingDesc[i].roi.width; pt[1].y = pt[0].y;
			pt[2].x = pt[1].x; pt[2].y = pt[1].y + parkingDesc[i].roi.height;
			pt[3].x = pt[0].x ;pt[3].y = pt[2].y;
			
			cvPolyLine( tmp, &ptList, &count, 1, 1, CV_RGB(255, 0, 0), 8, 8 );
		//parkingDesc[i].image = MyColorToGray(cvvLoadImage(fname), 0);
		}
		cvvShowImage("parking", tmp);
		cvReleaseImage(&tmp);
		cvReleaseImageHeader(&image0);
		sleep(1);
	}
		
	cvClearMemStorage(storage1);
	cvClearMemStorage(storage2);
		
	shmdt(shm);
	return 0;
}



int main(int argc, char *argv[])
{
	FilterParameter param;

	if (argc != 2) {
		printf("parameters: <parking_conf file>\n");
		return 1;
	}
   
	param.shmKey = IMAGE_SHM_KEY;
	strcpy(param.confFile, argv[1]);
	Start(param);

	return 0;
}

