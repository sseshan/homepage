#!/bin/sh

SADIR=../../../SA/IrisSA/src

echo "Installing parking app to SA/IrisSA/src directory"
rm parkingWS.so

make
cp parking.so $SADIR/code
cp parkingWS.so $SADIR/code
cp calibrate $SADIR/parking
cp updateconf $SADIR/parking
