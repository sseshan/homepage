/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


// Reads from video frame in shared memory and tries to find
// where the parking spaces are.

// Our common libraries for SA's
#include <imgproc.h>
#include <shmman.h>
#include <filter.h>

// OpenCV
#include <cv.h>
#include <highgui.h>

// Stevens unix library
#include <unp.h>

// Unix system includes
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>

// generate debug code - need to fold into makefile
#undef NDEBUG
#include <assert.h>

// Finds and returns CvSeq of parking spots
// CvSeq of CvRect, stored in storage
// Each CvRect represents a part of the original image
// corresponding to a parking spot
// returns NULL on error
CvSeq * FindPSpots(CvMemStorage * storage, IplImage *srcImage)
{
	CvSeq *squares = NULL;
	CvSeqReader reader;
	CvSeqWriter writer;
	CvSeq *pspots = NULL;
	int i;
	IplImage * grayImage = NULL;

	assert (storage != NULL);
	assert (srcImage != NULL);

	grayImage = MyColorToGray(srcImage);

	if (grayImage == NULL) {
		fprintf(stderr, "FindPSpots(): Error converting image to gray\n");
		return NULL;
	}

	fprintf(stderr, "Gray Image: %dx%d x%d\n", grayImage->width,
		grayImage->height, grayImage->nChannels);

	storage = cvCreateMemStorage(0);

	squares = FindUniqueSquares4(grayImage, 50, storage);

	if (squares == NULL) {
		fprintf(stderr, "FindPSpots(): Error finding squares\n");
		return NULL;
	}

	fprintf(stderr, "Total squares found: %d\n", squares->total / 4);

	cvStartReadSeq(squares, &reader, 0);

	cvStartWriteSeq(0, sizeof(CvSeq), sizeof(CvRect), storage, &writer);

	// loop through the parking spots (4 points per spot)
	for (i = 0; i < squares->total / 4; i++) {	
		int minX, minY, maxX, maxY;
		CvPoint pt[4];
		CvRect roi;

		// read 4 vertices
		CV_READ_SEQ_ELEM(pt[0], reader);
		CV_READ_SEQ_ELEM(pt[1], reader);
		CV_READ_SEQ_ELEM(pt[2], reader);
		CV_READ_SEQ_ELEM(pt[3], reader);

		int BTHR = 3;

		// calculate the smallest bounding box
		// so minX = maximum of smaller X's
		minX = max(pt[0].x, pt[1].x) + BTHR;
		minY = max(pt[0].y, pt[3].y) + BTHR;
		maxX = min(pt[2].x, pt[3].x) - BTHR;
		maxY = min(pt[1].y, pt[2].y) - BTHR;

		// Set bounding box of image
		roi.x = minX;
		roi.y = minY;
		roi.height = abs(maxY - minY);
		roi.width = abs(maxX - minX);

		int area = abs(maxY - minY) * abs(maxX - minX);
		
		if (area < 30000 && area > 2000)
			CV_WRITE_SEQ_ELEM(roi, writer);

		/*
		fprintf(stderr,
			"Square %d: ROI: origin (%d, %d), width: %d, height: %d\n",
			i, roi.x, roi.y, roi.width, roi.height);
		*/
	}

	pspots = cvEndWriteSeq(&writer);

	cvReleaseImage(&grayImage);

	return pspots;
}


// Generate conforming configuration file output.
// Output is printed on stdout so that it can be
// piped to the configuration file.
// return 1 on success, 0 on error
int GenOutput(IplImage * srcImage, CvSeq * pspots, int numlm, CvPoint landmark1, CvPoint landmark2,
	      CvPoint landmark3, CvPoint landmark4)
{
	CvSeqReader reader;
	IplImage * part;
	char fname[128];	
	int i;

	assert (srcImage != NULL);
	assert (pspots != NULL);

	printf("%d\n", pspots->total);

	cvStartReadSeq(pspots, &reader, 0);

	for (i = 0; i < pspots->total; i++) {
		CvRect roi;
		int pspotnum = i+1;

		CV_READ_SEQ_ELEM(roi, reader);

		// print the region
		printf("%d %d %d %d ", roi.x, roi.y, roi.width, roi.height);

                // print the lot number
		printf("%d ", pspotnum);

		// print the file name
		sprintf(fname, "pspot%d.jpg", pspotnum);
		printf("%s\n", fname);

		fprintf(stderr, "Saving parking spot %d to to %s\n", pspotnum, fname);

		part = GetImagePart(srcImage, roi);
		if (part == NULL) {
			fprintf(stderr, "Calibrate(): Error extracting pspot image %d\n", pspotnum);
			return 0;
		}

		cvSaveImage(fname, part);

		cvReleaseImageHeader(&part);

	}

	printf("%d\n", numlm);
	
	if (numlm != 0)
		printf("%d %d %d %d %d %d %d %d\n", landmark1.x, landmark1.y, landmark2.x, landmark2.y,
		       landmark3.x, landmark3.y, landmark4.x, landmark4.y);

	return 1;
	
}

// Displays the original image and highlights parking spots
// graphically.
void DisplayPSpots(IplImage * srcImage, CvSeq * pspots)
{
	CvFont font;
	CvSeqReader reader;
	IplImage * displayImage = NULL;
	int i;
	int count = 4;
	char desc[32];

	assert (srcImage != NULL);
	assert (pspots != NULL);

	cvvNamedWindow("calibrate", 1);

	cvInitFont(&font, CV_FONT_VECTOR0, 1.0, 1.0, 0, 1);
	displayImage = cvCloneImage(srcImage);
	
	cvStartReadSeq(pspots, &reader, 0);

	for (i = 0; i < pspots->total; i++) {
      		CvPoint ptList[4];
		CvPoint *dispPtList = ptList;
		CvRect roi;

		// read 4 vertices
		CV_READ_SEQ_ELEM(roi, reader);

		// Sets the vertices to be drawn around the parking spot
		ptList[0].x = roi.x;
		ptList[0].y = roi.y;
		ptList[1].x = roi.x;
		ptList[1].y = roi.y + roi.height;
		ptList[2].x = roi.x + roi.width;
		ptList[2].y = roi.y + roi.height;
		ptList[3].x = roi.x + roi.width;
		ptList[3].y = roi.y;
		
		cvPolyLine(displayImage, &dispPtList, &count, 1, 1,
			   CV_RGB(255, 0, 0), 8, 8);
		sprintf(desc, "#%d", i + 1);
		cvPutText(displayImage, desc,
			  cvPoint(roi.x + roi.width / 4, roi.y + roi.height / 2),
			  &font, CV_RGB(0, 0, 255));
	}

       	cvShowImage("calibrate", displayImage);

	fprintf(stderr, "Press any key on the image to continue...\n");
	cvvWaitKey(0);

	cvReleaseImage(&displayImage);
	
}


// Prints parking spot information to stderr
void PrintPSpots(CvSeq * pspots)
{
	CvSeqReader reader;	
	int i;

	assert(pspots != NULL);

	fprintf(stderr, "Total spots %d\n", pspots->total);

	if (pspots->total > 0)
		cvStartReadSeq(pspots, &reader, 0);

	for (i = 0; i < pspots->total; i++) {
		CvRect roi;

		CV_READ_SEQ_ELEM(roi, reader);

		fprintf(stderr,
			"Square %d ROI: origin (%d, %d), width: %d, height: %d\n",
			i+1, roi.x, roi.y, roi.width, roi.height);
	}

} 

int GetLandmarks( LandmarkFinder * lf, IplImage * srcImage, CvPoint * landmark1, CvPoint * landmark2,
		 CvPoint * landmark3, CvPoint * landmark4) {

	FindLandmarks(lf, srcImage);

	CvSeq *landmarks = lf->landmarks;

	if (landmarks->total != 4)
		return 0 ;

	DrawLandmarks(srcImage, landmarks);

	*landmark1 = * (CvPoint *) cvGetSeqElem(landmarks, 0);
	*landmark2 = * (CvPoint *) cvGetSeqElem(landmarks, 1);
	*landmark3 = * (CvPoint *) cvGetSeqElem(landmarks, 2);
	*landmark4 = * (CvPoint *) cvGetSeqElem(landmarks, 3);
	
	SortLandmarks(landmark1, landmark2, landmark3, landmark4);
	
	fprintf(stderr, "Landmarks: (%d, %d)  (%d, %d)\n\n",
		landmark1->x, landmark1->y,
		landmark2->x, landmark2->y);
	fprintf(stderr, "           (%d, %d)  (%d, %d)\n",
		landmark3->x, landmark3->y,
		landmark4->x, landmark4->y);

	return 4;
}

int main(int argc, char *argv[])
{
	CvMemStorage * storage = NULL;

	CvSeq * pspots = NULL; // of CvRect

	int numlm = 0;
	CvPoint landmark1, landmark2, landmark3, landmark4;
	
	// processed image - 3 channels only
	IplImage *srcImage = NULL;
	int dlandmarks = 0;

	if (argc != 1 && argc != 2) {
		fprintf(stderr, "This program looks at the video stream in shared\n");
		fprintf(stderr, "memory and tries to see where the parking spaces are.\n");
		fprintf(stderr, "Outputs reference images of empty parking spots as\n");
		fprintf(stderr, "pspot*.jpg and configuration information to stdout\n\n");

		fprintf(stderr, "usage: %s [detect_landmarks] > pspots.conf", argv[0]);

		return 1;
	}

	storage = cvCreateMemStorage(0);

	if (argc == 2)
		dlandmarks = atoi(argv[1]);

	fprintf(stderr, "Detecting landmarks: %d\n", dlandmarks);

	fprintf(stderr, "Getting source image.\n");
	if ((srcImage = GetSrcImageKey(IMAGE_RAW_SHM_KEY)) == NULL)
		return 1;

	fprintf(stderr, "Finding parking spots.\n");
	if ((pspots = FindPSpots(storage, srcImage)) == NULL)
		return 1;

	PrintPSpots(pspots);

	LandmarkFinder lm;
	IplImage * templateImage = cvLoadImage("template.png");
	if (templateImage == NULL) {
		fprintf(stderr, "Error opening template image.\n");
		return 1;
	}
	InitLandmarks(&lm, cvSize(srcImage->width, srcImage->height), templateImage);

	numlm = GetLandmarks(&lm, srcImage, &landmark1, &landmark2,
			     &landmark3, &landmark4);

	if (dlandmarks == 0)
		numlm = 0;

	fprintf(stderr, "Generating configuration file output.\n");
	GenOutput(srcImage, pspots, numlm, landmark1, landmark2, landmark3, landmark4);

	fprintf(stderr, "Displaying final results.\n");
	DisplayPSpots(srcImage, pspots);

	fprintf(stderr, "Cleaning up.\n");
	cvReleaseImage(&srcImage);
	cvReleaseMemStorage(&storage);

	return 0;
}
