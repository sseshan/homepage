/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


/* Gets reference parking spot images from video frame and
   configuration file */

#include "parking.h"

// our own common headers
#include <imgproc.h>
#include <shmman.h>

// Stevens unix library
#include <unp.h>

// OpenCV
#include <cv.h>
#include <highgui.h>

// System libraries
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>


int main(int argc, char *argv[])
{
	char * confFile = NULL;

	IplImage *srcImage = NULL;
	ParkingDescType *parkingDesc = NULL;
	
	int i, numSpaces;

	char fname[128];
	FILE *fp;
	
	if (argc != 2) {
		printf("usage: %s <parking_conf file>\n", argv[0]);
		return 1;
	}
   
	confFile = argv[1];

	srcImage = GetSrcImage();

	if (srcImage == NULL) {
		fprintf(stderr, "Error getting source image.\n");
		return 1;
	}

	if ( (fp = fopen(confFile, "rt")) == NULL) {
		fprintf(stderr, "Error opening configuration file.\n");
		return 1;
	}

	fscanf(fp, "%d", &numSpaces);
	parkingDesc = (ParkingDescType*) calloc(numSpaces,
						sizeof(ParkingDescType));

	for (i = 0; i < numSpaces; i++) {
		IplImage * part = NULL;

		fscanf(fp, "%d %d %d %d %s %s",
		       &(parkingDesc[i].roi.x),
		       &(parkingDesc[i].roi.y),
		       &(parkingDesc[i].roi.width),
		       &(parkingDesc[i].roi.height),
		       (parkingDesc[i].desc), fname);

		printf("Saving image to: %s\n", fname);
		part = GetImagePart(srcImage, parkingDesc[i].roi);
		cvvSaveImage(fname, part);

		cvReleaseImageHeader(&part);
	}

	cvReleaseImage(&srcImage);

	return 0;

}

