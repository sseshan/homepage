/* -*-  Mode:Java; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.stevesoft.pat.*;

import com.intel.sensors.oa.Log;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;

import com.intel.sensors.oa.*;
import org.w3c.dom.Document;

/** Job of this is to listen on a port ... can't think of any other way 
 *  to see if any data is being received by the client aksing a query.
 *
 *  @author Amol
 *  */
public class CannedQueries {
	public static ServerSocket httpServersocket;
	
	public static String cannedQueries[] = new String[] {
		"/psfROOT",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland']/block[@id='3']",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland']/block/parkingSpace[usage/in-use = 'no']",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood/block/parkingSpace[usage/in-use = 'no']",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland' or @id='Shadyside']/block/parkingSpace[usage/in-use = 'no']",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland' or @id='Shadyside']/block[@expiry > 'TENSECONDSOLD']/parkingSpace[usage/in-use = 'no']",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland']/block/parkingSpace",
		"/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='Oakland' or @id='Shadyside']/block/parkingSpace",
		"/psfROOT"
	};
	
	private static ServerSocket listenServersocket = null;
	
	public static void startListener(int port) {
		try {
			listenServersocket = new ServerSocket(port);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public static String listenToAndReceiveAMessage() {
		try {
			Socket s = listenServersocket.accept();
			DataInputStream inStream = new DataInputStream(s.getInputStream());
			Thread.sleep(300);
			String result = null;
			if(inStream.available() != 0) {
				result = Packet.Receive(inStream);
			} else {
				result = "<noresults/>";
			}
			s.close();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/** This accepts the initial request from the form */
	public static void run_http_server(int port) {
		httpServersocket = null;
		try {
			httpServersocket = new ServerSocket(port);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		while(true) {
			Socket s = null;
			try {
				String requestString = null;
				s = httpServersocket.accept();
				System.out.println("Got a new connection... listening");
				InputStreamReader isr = new InputStreamReader(s.getInputStream());
				DataOutputStream dos = new DataOutputStream(s.getOutputStream());
				try {
					String str;
					BufferedReader br = new BufferedReader(isr);
					str = br.readLine();
					while(!str.equals("")) {
						if(str.indexOf("GET") != -1) {
							requestString = str;
						}
						System.out.println("*" + str + "*");
						str = br.readLine();
					}
				} catch (Exception e) {
				}
				
				System.out.println(requestString);
				int index = requestString.indexOf("/");
				char query = requestString.charAt(index+1);
				System.out.println("Query No. " + query);
				int queryIndex = Integer.parseInt((new Character(query)).toString());
				
				String xpath = cannedQueries[queryIndex];
				
				// do a string replace if there is an expirty attribute involved
				if(xpath.indexOf("TENSECONDSOLD") != -1) {
					xpath = new StringBuffer(xpath).replace(xpath.indexOf("TENSECONDSOLD"), xpath.indexOf("TENSECONDSOLD") + 13, String.valueOf(System.currentTimeMillis())).toString();
				}
				System.out.println(xpath);
				
				Protocol.sendQueryMessage(0, QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath), 6789, xpath, -1, QueryAnalysis.getRoot(xpath));
				ParsedMessage pm = Protocol.parseIncomingMessage(listenToAndReceiveAMessage());
				System.out.println("********** RESPONSE ************");
				System.out.println(pm.response);
				Document doc = DOMProcessing.XMLtoDOM(pm.response);
				// doc = DOMProcessing.fileToDOM("demodata.xml");
				System.out.println(DOMProcessing.DOMtoXML(doc));
				DOMProcessing.myNormalize(doc);
				DOMProcessing.orderByIDs(doc);
				String next_to_final_response = DOMProcessing.DOMtoXML(DOMProcessing.applyFileXSLTtoDOM(doc, "my2html-1.xsl"));
				System.out.println("after XSLT: \n" + next_to_final_response);
				
				StringBuffer final_response = new StringBuffer(next_to_final_response);
				int insert_at = next_to_final_response.indexOf("<font");
				
				// must insert in reverse order; otherwise need to keep on updating insert_at
				final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query Answer :</b> </font>" + "<br>");
				
				// insert the query starting point; modified
				
				String startingpoint = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath);
				startingpoint = startingpoint.substring(0, startingpoint.indexOf("psfROOT"));
				startingpoint = startingpoint + "psf.intel-iris.net";
				final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Starting Point :</b> </font>" + startingpoint + "<br><br>");
				
				
				final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query : </b></font> /parking" + xpath.substring(11, xpath.length()) + "<br><br>");
				
				System.out.println("XSLT RESPONSE");
				System.out.println(final_response);
				
				// dos.writeBytes("<html><head><body>Error processing the directive</body>");
				dos.writeBytes(final_response.toString());
				dos.write(0);
				dos.flush();
				Thread.sleep(100);
				dos.close();
				s.close();
				
				Log.shutdownlogger();
				
			} catch (Exception e) {
				e.printStackTrace();
				try { 
					DataOutputStream dos = new DataOutputStream(s.getOutputStream());
					dos.writeBytes("<html><head><body>Error processing the directive</body>");
					dos.write(0);
					dos.flush();
					Thread.sleep(100);
					dos.close();
					s.close();
				} catch (Exception ee) {
				}
				System.out.println("Continueing");
			}
		}
	}
	
	
	public static void main(String[] args) {
		try {
			//Log.setReplayLog("10.212.3.211", "5678");
			
			com.intel.sensors.oa.Protocol.myPortNumber = Integer.parseInt(args[1]);
			
			startListener(com.intel.sensors.oa.Protocol.getLocalPort());
			
			run_http_server(Integer.parseInt(args[0]));
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
};
