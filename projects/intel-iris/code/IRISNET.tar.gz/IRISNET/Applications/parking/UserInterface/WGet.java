/*
 * This is a simply wget.
 * You can test your URL
 *
 * $Log: WGet.java,v $
 * Revision 1.1  2004/03/03 20:05:52  sknath
 * First addition by Suman
 *
 * Revision 1.1  2003/05/16 21:52:26  sknath
 * Moved a few files from the OA directory to the app directory
 *
 */

//package com.intel.utils;

import java.io.IOException;
import java.io.EOFException;
import java.io.DataInputStream;
import java.io.PrintStream;
 
import java.net.URL;
import java.net.URLConnection;
import java.net.HttpURLConnection;
 
/**
 * @version $Revision: 1.1 $
 */
public class WGet {
    final PrintStream out = System.out;
    boolean verb;
    boolean output = true;
    int count = 0;
    
    WGet (boolean _verb) {
	verb = _verb;
    }

    public String getPage(String _url) throws IOException {
	String _out = "";

	URLConnection url = (new URL(_url)).openConnection();
	
	if (url instanceof HttpURLConnection) {
	    _out = readHttpURL((HttpURLConnection) url);
	} else {
	    _out = readURL(url);
	}

	return _out;
    }
    
  public String readURL(URLConnection url) throws IOException {
      StringBuffer _out = new StringBuffer(1024*16);

      DataInputStream in = new DataInputStream(url.getInputStream());
      printHeader(url);
      
      try {
	  while (true) {
	      _out.append((char) in.readUnsignedByte());
	      count++;
	  }
      } catch (EOFException e) {
	  if (output) verbose("\n");
	  verbose("wget" +
		  ": Read " + count +
		  " bytes from " + url.getURL());
      } catch (IOException e) {
	  out.println( e + ": " + e.getMessage());
	  if (output) verbose("\n");
	  verbose("wget" +
		  ": Read " + count +
		  " bytes from " + url.getURL());
      }
      // System.exit(0);
      return _out.toString();
  }
 
  public String readHttpURL(HttpURLConnection url) 
      throws IOException {
      
      StringBuffer _out = new StringBuffer(1024 * 16);
      long before, after;
      
      url.setAllowUserInteraction (true);
      verbose("wget" + ": Contacting the URL ...");
      url.connect();
      verbose("wget" + ": Connect. Waiting for reply ...");
      before = System.currentTimeMillis();
      DataInputStream in = new DataInputStream(url.getInputStream());
      after = System.currentTimeMillis();
      verbose("wget" + ": The reply takes " + 
	      ((int) (after - before) / 1000) + " seconds");
      
      before = System.currentTimeMillis();
      
      
      try {
	  if (url.getResponseCode() != HttpURLConnection.HTTP_OK) {
	      out.println("wget" + ": " + url.getResponseMessage());
	  } else {
	      printHeader(url);
	      while (true) {
		  _out.append((char) in.readUnsignedByte());
		  count++;
	      }
	  }
      } catch (EOFException e) {
	  after = System.currentTimeMillis();
	  int milliSeconds = (int) (after-before);
	  if (output) verbose("\n");
	  verbose("wget" +
		  ": Read " + count +
		  " bytes from " + url.getURL());
	  verbose("wget" + ": HTTP/1.0 " + url.getResponseCode() +
		  " " + url.getResponseMessage());
	  url.disconnect();
	  
	  verbose("wget" + ": It takes " + (milliSeconds/1000) + 
		  " seconds" + " (at " + round(count/(float) milliSeconds) + 
		  " K/sec).");
	  if (url.usingProxy()) {
	      verbose("wget" + ": This URL uses a proxy");
	  }
      } catch (IOException e) {
	  out.println( e + ": " + e.getMessage());
	  if (output) verbose("\n");
	  verbose("wget" +
		  ": I/O Error : Read " + count +
		  " bytes from " + url.getURL());
	  out.println("wget" + ": I/O Error " + url.getResponseMessage());
      }
      //System.exit(0);
      
      return _out.toString();
  }
  
    public void printHeader(URLConnection url) {
	verbose(WGet.class.getName() + ": Content-Length   : " + 
		url.getContentLength() );
	verbose(WGet.class.getName() + ": Content-Type     : " + 
		url.getContentType() );
	if (url.getContentEncoding() != null)
	    verbose(WGet.class.getName() + ": Content-Encoding : " + 
		    url.getContentEncoding() );
	if (output) verbose("");
    }
    
    public void  writeChar(char c) {
	if (output) out.print(c);
	//count++;
    }
    
    public void verbose(String s) {
	if (verb) out.println( s );
    }
    
    public  float round(float f) {
	return Math.round(f * 100) / (float) 100;
    }
}

      
