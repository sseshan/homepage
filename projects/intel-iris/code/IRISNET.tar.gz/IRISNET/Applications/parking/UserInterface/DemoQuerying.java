/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
//package com.intel.sensors.oa;

import com.intel.sensors.oa.*;
import com.intel.utils.*;
import java.lang.Exception;
import java.lang.Integer;
import java.lang.String;
import java.util.Hashtable;
import java.util.Vector;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.DataInputStream;

/** Contains some functions for the Demo. No need for this after the demo.
 *
 *  @author Amol */
public class DemoQuerying {

    private static ServerSocket serversocket = null;

    public static void startListener(int port) {
        try {
            serversocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static void gatherResponses(String[] responses) {
        try {
            int num_responses = 0;
            while(true) {
                Socket s = serversocket.accept();
                DataInputStream inStream = new DataInputStream(s.getInputStream());

                String packet = Packet.Receive(inStream);
                System.out.println("Received command: " + packet);

                ParsedMessage pm = Protocol.parseIncomingMessage(packet);

                Utils.myassert(pm.opCode.equals(Globals.COMMAND_REPLY));
                responses[Integer.parseInt(pm.queryID)] = pm.response;
                num_responses++;

                s.close();

                if(num_responses == responses.length)
                    return;
            } 
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static boolean firstSearchFailed = false;

    /** Main function : Given the destination street address, find the closest parking spot that is available */
    public static String findAddressOfClosestAvailableParkingSpot(String destinationAddress, String covered, String handicapped, String price) throws Exception {
	ConfigurationManager CM = ConfigurationManager.instance();

        // first find the queries using query convert
        String queriesToAsk[] = QueryConvert.findQueriesForClosestParkingSpaces(destinationAddress, firstSearchFailed);

        // these above queries already check for availability.. just add the other conditions
        for(int i = 0; i < queriesToAsk.length; i++) {
            if(covered.equals("yes")) {
                queriesToAsk[i] = queriesToAsk[i] + "[covered='yes']";
            } else if(covered.equals("no")) {
                queriesToAsk[i] = queriesToAsk[i] + "[covered='no']";
            }

            if(handicapped.equals("no")) {
                queriesToAsk[i] = queriesToAsk[i] + "[handicapped='no']";
            } else {
                queriesToAsk[i] = queriesToAsk[i] + "[handicapped='yes']";
            }

            if(price.equals("fifty")) {
                queriesToAsk[i] = queriesToAsk[i] + "[./meter/cost/price-in-dollars = '0.25']";
            } else if(price.equals("hundred")) {
                queriesToAsk[i] = queriesToAsk[i] + "[./meter/cost/price-in-dollars = '0.50']";
            }
        }

        for(int i = 0; i < queriesToAsk.length; i++) {
            System.out.println(queriesToAsk[i]);
        }

        // start listener
        // startListener(Protocol.getLocalPort());

        // currently ask each one separately
        for(int i = 0; i < queriesToAsk.length; i++) {
            String toberoutedOA = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(queriesToAsk[i]);
            Protocol.sendQueryMessage(Integer.toString(i), toberoutedOA, CM.getOAPort(), queriesToAsk[i], -1, QueryAnalysis.getRoot(queriesToAsk[i]));
        }

        // gather responses
        String responses[] = new String[queriesToAsk.length];
        gatherResponses(responses);

        // now need to find street addresses in the responses
        Vector streetAddresses = new Vector();
        for(int i = 0; i < responses.length; i++) {
            if(responses[i].indexOf("<in-use>no</in-use>") != -1) {
                String addresshere = ApplyXPathToString.applyXPath(responses[i], "//streetaddress/text()").toString();
                if(addresshere.length() > 0) {
                    streetAddresses.add(addresshere);
                }
            }
        }

        for(int i = 0; i < streetAddresses.size(); i++) {
            System.out.println(streetAddresses.get(i));
        }


        if(streetAddresses.size() == 0) {
            if(firstSearchFailed) {
                // return destinationAddress;
                firstSearchFailed = false;
                return null;
            } else {
                firstSearchFailed = true;
                // recursively call self
                return findAddressOfClosestAvailableParkingSpot(destinationAddress, covered, handicapped, price);
            }
        } else {
            // return streetAddresses.get(0).toString();
            String[] streetaddressarray = new String[streetAddresses.size()];
            for(int i = 0; i < streetAddresses.size(); i++) {
                streetaddressarray[i] = (String) streetAddresses.get(i);
            }
            return QueryConvert.findClosestAddress(destinationAddress, streetaddressarray);
        }
    }

    public static void main(String[] args) {
        try {

            Protocol.myPortNumber = Integer.parseInt(args[0]);

            // System.out.println(findAddressOfClosestAvailableParkingSpot("409 Forbes Ave"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
