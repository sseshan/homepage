/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
//package com.intel.sensors.oa;

import com.intel.utils.*;
import com.intel.sensors.oa.*;
import java.lang.Exception;
import java.lang.Integer;
import java.lang.String;
import java.lang.Math;
import java.util.Hashtable;

class GPS {
    public double longitude;
    public double latitude;
    public double computeDistance(GPS other) {
        double horiz = (other.longitude - this.longitude) * 11000; // approximately in meters i believe
        double vert = (other.latitude - this.latitude) * 11000; // ditto -- but only on equator
        return Math.sqrt(horiz * horiz + vert * vert);
    }
    GPS (double lo, double la) {
        longitude = lo;
        latitude = la;
    }
}

class ParkingspotDescription {
    public GPS gps;
    public String query;
    public String streetAddress;

    ParkingspotDescription(double lo, double la, String q, String sa)  {
        gps = new GPS(lo, la);
        query = q;
        streetAddress = sa;
    }
};

class BlockDescription {
    public GPS gps;
    public String query;
    public String streetAddress;

    BlockDescription(double lo, double la, String nghhood, String blockID, String sa)  {
        gps = new GPS(lo, la);
        query = "/psfROOT/usRegion[@id='NE']/state[@id='PA']/county[@id='Allegheny']/city[@id='Pittsburgh']/neighborhood[@id='" + nghhood + "']/block[@id='" + blockID + "']/parkingSpace[./usage/in-use/text()='no']";
        streetAddress = sa;
    }
};

class LongLatStreetAddressMapping {
    public GPS gps;
    public String streetAddress;
    LongLatStreetAddressMapping(double lo, double la, String sa)  {
        gps = new GPS(lo, la);
        streetAddress = sa;
    }
};

/** Only used for Demo.
 *
 *  @author Amol */
public class QueryConvert {

    /** outdated --- shoulnd't use this */
    private static ParkingspotDescription[] parkingSpots = new ParkingspotDescription[] { 
        new ParkingspotDescription(1, 1, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='100']/parkingSpace[@id='10000'][./usage/in-use/text()='no']", "405 South Craig"),
        new ParkingspotDescription(1, 2, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='100']/parkingSpace[@id='10001'][./usage/in-use/text()='no']", "409 South Craig"),
        new ParkingspotDescription(1, 3, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='100']/parkingSpace[@id='10002'][./usage/in-use/text()='no']", "413 South Craig"),
        new ParkingspotDescription(2, 1, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='101']/parkingSpace[@id='10000'][./usage/in-use/text()='no']", "405 Forbes Ave"),
        new ParkingspotDescription(2, 2, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='101']/parkingSpace[@id='10001'][./usage/in-use/text()='no']", "409 Forbes Ave"),
        new ParkingspotDescription(2, 3, "/psfROOT/usRegion/state/county/city/block[@id='Oakland']/neighborhood[@id='Oakland']/block[@id='101']/parkingSpace[@id='10002'][./usage/in-use/text()='no']", "413 Forbes Ave"),
    };

    private static LongLatStreetAddressMapping[] streetAddresses = new LongLatStreetAddressMapping[] { 
        new LongLatStreetAddressMapping(40.445028, -079.948749, "417 South Craig"),
        new LongLatStreetAddressMapping(40.447069, -079.945471, "4802 Fifth Ave"),
        new LongLatStreetAddressMapping(40.444388, -079.945530, "4800 Forbes"),
        new LongLatStreetAddressMapping(40.444360, -079.942746, "5010 Forbes"),
        new LongLatStreetAddressMapping(40.444276, -079.948763, "4600 Forbes"),
        new LongLatStreetAddressMapping(40.447403, -079.942549, "5th at Morewood "), 
        new LongLatStreetAddressMapping(40.445642, -079.950623, "Dithridge at Winthrop "), 
        new LongLatStreetAddressMapping(40.444384, -079.948838, "Forbes at Craig "),
        new LongLatStreetAddressMapping(40.444533, -079.943091, "Forbes at Morewood ")
    };

    public static LongLatStreetAddressMapping getMapping(String streetAddress) {
        for(int i = 0; i < streetAddresses.length; i++) {
            System.out.println("Comparing *" + streetAddresses[i].streetAddress + "*" + streetAddress + "*");
            if(streetAddresses[i].streetAddress.equals(streetAddress)) {
                return streetAddresses[i];
            }
        }
        Utils.shouldnthappen();
        return null;
    }

    private static BlockDescription[] blocks = new BlockDescription[] { 
        new BlockDescription(40.447403, -079.942549, "Shadyside", "1", "5th at Morewood"), 
        new BlockDescription(40.445642, -079.950623, "Oakland",   "2", "Dithridge at Winthrop"), 
        new BlockDescription(40.444384, -079.948838, "Oakland",   "3", "Forbes at Craig"),
        new BlockDescription(40.444533, -079.943091, "Oakland",   "1", "Forbes at Morewood")
    };

    /** Find k-median */
    public static int findKthSmallest(double[] data, int k) {
        // assuming no equal number, this is one that has exactly k-1 smaller than it
        for(int i = 0; i < data.length; i++) {
            int count = 0;
            for(int j = 0; j < data.length; j++) {
                if(i != j) {
                    if(data[i] > data[j])
                        count++;
                }
            }
            if(count == (k - 1)) {
                return i;
            }
        }
        Utils.shouldnthappen();
        return -1;
    }

    /** Find 2 closest or furthest parking spots and generate queries that can find out if there are parking spaces there
     *  are empty. */
    public static String[] findQueriesForClosestParkingSpaces(String streetAddress, boolean searchFurthestTwo) {
        System.out.println("########" + streetAddress);
        // first find the latitude/longitude
        double longitude = -1, latitude = -1;
        for(int i = 0; i < streetAddresses.length; i++) {
            if(streetAddresses[i].streetAddress.equals(streetAddress)) {
                longitude = streetAddresses[i].gps.longitude;
                latitude = streetAddresses[i].gps.latitude;
            }
        }
        GPS saGPS = new GPS(longitude, latitude);

        // got it; now find the closest 2 blocks
        double distances[] = new double[blocks.length];
        for(int i = 0; i < blocks.length; i++) {
            distances[i] = saGPS.computeDistance(blocks[i].gps);
            System.out.println(blocks[i].query + " " + distances[i]);
        }

        System.out.println("Closest two parking spots");

        String[] _queries = new String[2];
        if(! searchFurthestTwo) {
            _queries[0] = blocks[findKthSmallest(distances, 1)].query;
            _queries[1] = blocks[findKthSmallest(distances, 2)].query;
        } else {
            _queries[0] = blocks[findKthSmallest(distances, 3)].query;
            _queries[1] = blocks[findKthSmallest(distances, 4)].query;
        }

        System.out.println(_queries[0]);
        System.out.println(_queries[1]);

        // merge the two queries to get a single query

        return _queries;
    }

    public static String findClosestAddress(String destAddress, String[] addresses) {
        GPS daGPS = getMapping(destAddress).gps;

        int minindex = -1;
        double mindistance = 1000000;
        for(int i = 0; i < addresses.length; i++) {
            GPS gps = getMapping(addresses[i]).gps;
            double dist = daGPS.computeDistance(gps);
            if(dist < mindistance) {
                minindex = i;
                mindistance = dist;
            }
        }
        if(minindex == -1) {
            return null;
        } else {
            return addresses[minindex];
        }
    }


    public static void main(String args[]) {
        String[] queries = findQueriesForClosestParkingSpaces(args[0], false);
        for(int i = 0; i < queries.length; i++) 
            System.out.println(queries[i]);
    }
}
