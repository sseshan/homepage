#! /bin/sh
IRIS=~/IRISNET

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$IRIS/packages/opencv-0.9.3/cv/src/.libs/:$IRIS/packages/opencv-0.9.3/otherlibs/highgui/.libs/
export DISPLAY=10.212.3.37:0.0

if [ -d $IRIS/SA/IrisWebcam/ ]
then 
	cd $IRIS/SA/IrisWebcam/
	killall loadImages
	./loadImages &
else
	echo "Webcam is not installed"
fi

if [ -d $IRIS/SA/IrisSA/ ]
then
	echo ................... Running SA ...........................
        cd $IRIS/SA/IrisSA/src
        killall SA
	killall runsa
        ./runsa &
else
        echo "SA is not installed"
fi

