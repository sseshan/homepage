#!/bin/sh

NAME=~/IRISNET/SA/IrisWebcam/static/Cars$1.png

~/IRISNET/SA/IrisWebcam/loadImage $NAME 74

echo Done loading $NAME
