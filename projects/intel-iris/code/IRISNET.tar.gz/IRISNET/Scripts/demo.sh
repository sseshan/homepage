#! /bin/sh
HOSTS=$1
SCHEMA=$2

#ssh-agent $SHELL
#ssh-add

echo Using $HOSTS to configure the hosts, and $SCHEMA to build the XML hierarchy

# set up the SAs

for line in `cat $HOSTS`
do
	# we here use the simple rule: if there is a ':' character in the $line,
	# it might be a un-commented line and we should parse it
	
	# get the position of ':' in the $line
	pos=`echo $line | awk '{print index($0, ":")}'`
	if [ $pos -gt 0 ]
	then  
		echo LINE: $line
		node=`echo $line | awk '{split($0, list, ":"); print list[1]}'`
		host=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
		dir=`echo $line | awk '{split($0, list, ":"); print list[3]}'`
		if [ $node = "SA" ]
		then
			sensor=`echo $line | awk '{split($0, list, ":"); print list[4]}'`
		fi

		xhost + $host

		if [ $node = "SA" ]
		then
			echo Configuring the SA at $host:$dir	
			if [ $sensor = "fake" ] 
			then
				scp sasetup_fs.sh $host:$dir
				xterm -e ssh $host "cd $dir;./sasetup_fs.sh " &
			else
				scp sasetup_rs.sh $host:$dir
				ssh $host "cd $dir; ./sasetup_rs.sh &"
			fi
		fi
		
		if [ $node = "OA" ]
		then
			scp oasetup.sh $host:$dir
			xterm -e ssh $host "cd $dir; ./oasetup.sh" & 			
		fi

		if [ $node = "Yahoo" ]
                then
                        scp yahoosetup.sh $host:$dir
                        xterm -e ssh $host "cd $dir; ./yahoosetup.sh" &
                fi

		if [ $node = "Canned" ]
                then
                        scp cannedsetup.sh $host:$dir
                        xterm -e ssh $host "cd $dir; ./cannedsetup.sh" &
                fi

		if [ $node = "Log" ]
		then
			scp logsetup.sh $host:$dir
                        xterm -e ssh $host "cd $dir; ./logsetup.sh" &	
		fi
	fi
done

#exit

