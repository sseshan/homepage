#! /bin/sh

IRIS= `pwd`

cd $IRIS/Logger/nam-1.0a11a_iris/
./nam &

cd $IRIS/Logger/IrisLogger/src
./runnam.sh &

