#! /bin/sh
CONFFILE=$1

#ssh-agent $SHELL
#ssh-add

echo Using $CONFFILE to configure the demo

# initialize the temporary file
rm -f break.tmp oas.tmp populate.tmp
touch break.tmp oas.tmp populate.tmp

first_oa=""
first_oadir=""

OA_PORT=6789

for line in `cat $CONFFILE`
do
	# we here use the simple rule: if there is a ':' character in the $line,
	# it might be a un-commented line and we should parse it
	
	# get the position of ':' in the $line
	pos=`echo $line | awk '{print index($0, ":")}'`
	if [ $pos -gt 0 ]
	then  
		# echo LINE: $line

		# parse the line and get the first token 
		opcode=`echo $line | awk '{split($0, list, ":"); print list[1]}'`
		
		if [ $opcode = "DOCUMENT" ]
		then
			document=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
		fi
		
		if [ $opcode = "SCHEMA" ]
		then
			schema=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
			if [ -f $schema ]
			then
				echo XML schema: $schema
			else
				echo File $schema not found. Exiting ...
				exit 1
			fi
				
		fi

		if [ $opcode = "BREAK" ]
		then
			echo $line | awk '{split($0, list, ":"); print list[2]}' >> break.tmp
		fi		

		if [ $opcode = "SA" ]
		then
			host=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
                        dir=`echo $line | awk '{split($0, list, ":"); print list[3]}'`
			sensor=`echo $line | awk '{split($0, list, ":"); print list[4]}'`
                        xhost + $host
			echo Configuring the SA at $host:$dir	

			#if [ $sensor = "fake" ] 
			#then
			#	scp sasetup_fs.sh $host:$dir
			#	xterm -e ssh $host "cd $dir;./sasetup_fs.sh " &
			#else
			#	scp sasetup_rs.sh $host:$dir
			#	ssh $host "cd $dir; ./sasetup_rs.sh &"
			#fi
		fi
		
		if [ $opcode = "OA" ]
		then
			host=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
                        dir=`echo $line | awk '{split($0, list, ":"); print list[3]}'`
			
			echo delete $host $document >> populate.tmp	
			if [ "X$first_oa" = "X" ]
			then
				first_oa=`echo $host`
				first_oadir=`echo $dir`
	
				echo addfile $first_oa $OA_PORT $schema >> populate.tmp
			else
				echo breakfile $first_oa $OA_PORT $host $OA_PORT >> oas.tmp
			fi
			 
			#scp oasetup.sh $host:$dir
			#xterm -e ssh $host "cd $dir; ./oasetup.sh" & 			
		fi

		if [ $opcode = "Yahoo" ]
                then
			host=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
                        dir=`echo $line | awk '{split($0, list, ":"); print list[3]}'`

                        #scp yahoosetup.sh $host:$dir
                        #xterm -e ssh $host "cd $dir; ./yahoosetup.sh" &
                fi

		if [ $opcode = "Canned" ]
                then
			host=`echo $line | awk '{split($0, list, ":"); print list[2]}'`
                        dir=`echo $line | awk '{split($0, list, ":"); print list[3]}'`

                        #scp cannedsetup.sh $host:$dir
                        #xterm -e ssh $host "cd $dir; ./cannedsetup.sh" &
                fi

		if [ $opcode = "Log" ]
		then
			#scp logsetup.sh $host:$dir
                        #xterm -e ssh $host "cd $dir; ./logsetup.sh" &	
			echo Log
		fi
	fi
done

# generate the populate script 'populate.cl'
rm -f populate.cl
touch populate.cl

oas_len=`wc -l oas.tmp | awk '{split($0, list, " "); print list[1]}'`
break_len=`wc -l break.tmp | awk '{split($0, list, " "); print list[1]}'`

if [ $oas_len -lt $break_len ]
then
	paste --delimiters=' ' oas.tmp break.tmp | head -$oas_len >> populate.tmp 	
else
	paste --delimiters=' ' oas.tmp break.tmp | head -$break_len >> populate.tmp
fi

rm -f break.tmp oas.tmp 

# Copy the populate script to the $first_oa and execute it remotely
#scp populate.tmp $first_oa:$first_oadir/OA/IrisOA/script.cl
#scp $schema $first_oa:$first_oadir/OA/IrisOA/
#ssh $first_oa "cd $first_oadir/OA/IrisOA/; make runscript"


#exit

