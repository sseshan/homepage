#! /bin/sh

IRIS=`pwd`
export JAVA_HOME=$IRIS/packages/jdk1.3.1_06
export PATH=$PATH:$JAVA_HOME/bin

if [ -d $IRIS/packages/xml-xindice-1.0 ]
then
	# run the xindice database engine

	cd $IRIS/packages/xml-xindice-1.0
	export XINDICE_HOME=`pwd`
	./xindice.server start

	# setup the frontend. Xindice has a HTTP server on port 4080.
        # we will use that server to server our frontend webpages
        # to do that, we copy the frontend web pages to $XINDICE-HOME/docs directory
	if [ -d $IRIS/Applications/parking/FrontEnd ]
	then
		cp  --remove-destination $IRIS/Applications/parking/FrontEnd/* $XINDICE_HOME/docs
	else
		echo FrontEnd web pages was not found
	fi

else
	echo Xindice not installed!!
	exit 1
fi

sleep 1

if [ -d  $IRIS/OA/IrisOA ]
then
	cd $IRIS/OA/IrisOA
	killall make
	make run
else
	echo IRISNET OA is not installed
	exit 1
fi


