#! /bin/sh

sleep 2

IRIS=~/IRISNET
export JAVA_HOME=$IRIS/packages/jdk1.3.1_06
export PATH=$PATH:$JAVA_HOME/bin

if [ -d  $IRIS/OA/IrisOA ]
then
	cd $IRIS/OA/IrisOA
	make runcanned
else
	echo IRISNET YahooMaps is not installed
	exit 1
fi


