#! /bin/sh
IRIS=~/IRISNET

if [ -d $IRIS/SA/IrisWebcam/ ]
then 
	cd $IRIS/SA/IrisWebcam/
	killall loadImages
	./loadImages &
else
	echo "Webcam is not installed"
fi

if [ -d $IRIS/SA/IrisSA/ ]
then
        cd $IRIS/SA/IrisSA/src
        killall SA
	killall runsa
        ./runsa &
else
        echo "SA is not installed"
fi

