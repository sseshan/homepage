#ifndef LMDIF_H
#define LMDIF_H

#include "OptProb.h"

#include <vector>
using namespace std;


void lm(OptProb & optprob, vector<double> & x);

void lmdif(OptProb & optprob, vector<double> & x, vector<double> &fvec,
	   double ftol,
	   double xtol, double gtol, int maxfev, double epsfcn,
	   vector<double> & diag, int mode, double factor, int nprint, int *info,
	   int *nfev, vector<double> & fjac, int ldfjac, vector<int> & ipvt, vector<double> & qtf,
	   vector<double> & wa1, vector<double> & wa2, vector<double> & wa3, vector<double> & wa4);


void pmat(int m, int n, vector<double> & y);
double enorm(int n, vector<double> x);

extern char *infmsg[];


#endif
