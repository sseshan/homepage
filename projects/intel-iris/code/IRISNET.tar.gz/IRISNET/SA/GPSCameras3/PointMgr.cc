/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <iostream>

#include "imgproc.h"

#include "PointMgr.h"
#include "Ransac.h"
#include "Dlt.h"
#include "Lm.h"

PointMgr::PointMgr(vector<FakeCam *> fakecams, FakeGPS * fakegps) {
	this->fakecams = fakecams;
	this->fakegps = fakegps;
	count = 0;
	useransac = false;
	numcams = fakecams.size();

	c2cpts = 25;
}

PointMgr::~PointMgr() {


}
void initHV(vector <CvMat *> * Hs, int size) {
	
	for (unsigned int i = 0; i < Hs->size(); i++) {
		cvReleaseMat(&(*Hs)[i]);
	}
	
	Hs->clear();
	Hs->resize(size, 0);
	
}

void PointMgr::add(GPSCoord & gps, vector<CvPoint2D64d> & pts, vector<bool> & inViews) {
	Corres corres;
	corres.hasGPS = true;
	corres.gps = gps;
	corres.pts = pts;
	corres.inViews = inViews;
	
	corrlist.push_back(corres);

	count++;

	cout << "PointMgr.add(): Adding point " << count << " correspondence" << endl << endl;

	if (count % (20 + c2cpts) == 0) {
		for (int i = 0; i < c2cpts; i++)
			corrlist[i].hasGPS = false;

		updateCorres();
		corrlist.clear();
	}

}

void PointMgr::computeHDlt(vector <Corres> & cs, vector <CvMat *> & Hs) {
	//cout << " Computing H via DLT " << endl;

	for (unsigned int i = 0; i < Hs.size(); i++) {
		vector<CvPoint2D64d> list;
		
		for (vector<Corres>::iterator iter = cs.begin(); iter != cs.end(); iter++) {
			if (iter->inViews[i] && iter->hasGPS) {
				list.push_back(iter->gps.toCvPoint2D64d());
				list.push_back(iter->pts[i]);
			}
		}

		Hs[i] = dlt(list);
		cout << "Camera " << fakecams[i]->id << ":" << endl;
		printH(Hs[i]);
	}	

	printf("Done initial H computation using DLT\n");
}


void PointMgr::goldWrap(vector<Corres> & csps, vector <CvMat *> * Hs, vector<double> & v) {
        v.clear();

        for (unsigned int k = 0; k < Hs->size(); k++) {
                //printf("H size = %d\n", H->rows * H->cols);
                for (int j = 0; j < (*Hs)[k]->rows; j++) {
                        for (int i = 0; i < (*Hs)[k]->cols; i++) {
                                v.push_back(cvmGet((*Hs)[k], j, i));
                        }
                }
        }


        for (vector<Corres>::iterator iter = csps.begin(); iter != csps.end(); iter++) {
                v.push_back(iter->gps.latN);
                v.push_back(iter->gps.longW);
        }


}


void PointMgr::goldUnwrap(vector<Corres> & csps, vector <CvMat *> * Hs, vector<double> & v) {
	vector<double>::iterator iter = v.begin();
 
	int Hsize = numcams;
       
	Hs->resize(Hsize);
       
	for (int k = 0; k < Hsize; k++) {
		(*Hs)[k] = cvCreateMat(3, 3, CV_64FC1);
		
		for (int j = 0; j < (*Hs)[k]->rows; j++) {
			for (int i = 0; i < (*Hs)[k]->cols; i++) {
				cvmSet((*Hs)[k], j, i, *iter++);
			}
		}
	}
	

	csps.clear();

	while (iter != v.end()) {
		Corres cs;
		
		cs.gps.latN = *iter++;
		cs.gps.longW = *iter++;
		cs.applyHCToP(Hs);
		
		csps.push_back(cs);
	}

	
}


double dist(CvPoint2D64d a, CvPoint2D64d b) {
	//printf("dist(): Calculating distance between (%f, %f) and (%f, %f)\n", a.x, a.y, b.x, b.y);
	double x = b.x - a.x;
	double y = b.y - a.y;
	return sqrt(x*x + y*y);
}



void PointMgr::computeHGold(vector <Corres> &csps, vector <CvMat *> & Hs) {
	vector <CvMat *> initHs;

	vector<double> initState;

	vector<double> fvec;

	printf("Computing initial H's (%d total)\n", Hs.size());

	initHV(&initHs, numcams);

	computeHDlt(csps, initHs);

	printf("Gold wrapping initial state\n");
	
	goldWrap(csps, &initHs, initState);

	printf("x size = %d    fvec size = %d\n", initState.size(), fvec.size());
	lm(*this, initState);

	printf("LM Done.\n");

	vector<Corres> finalCsps(csps.size());

	goldUnwrap(finalCsps, &initHs, initState);
	
	double totalmeasured = 0;
	double totaladjusted = 0;
	//for (unsigned int i = 0; i < csps.size(); i++) {
	for (unsigned int i = c2cpts; i < csps.size(); i++) {
		printf("Corres %d:  ", i);
		double measured = csps[i].gps.distToTrue(csps[i].gps);
		printf("Meas. Err: %.8f   ", measured);
		double adjusted = csps[i].gps.distToTrue(finalCsps[i].gps);
		printf("Adj Err: %.8f\n", adjusted);
		totalmeasured += measured;
		totaladjusted += adjusted;
	}

	 
	for (unsigned int j = 0; j < csps[0].pts.size(); j++) {
		printf("Camera %d\n", j + 1);
		for (unsigned int i = c2cpts; i < csps.size(); i++) {
			CvPoint2D64d p = ApplyM64d(initHs[j], finalCsps[i].gps.toCvPoint2D64d());
			//CvPoint2D64d p = ApplyM64d(goldH, c[i].gps.trueToCvPoint2D64d());
			//CvPoint2D64d p = c[i].p;
		
			CvPoint2D64d truep = ApplyM64d(fakecams[j]->H, csps[i].gps.trueToCvPoint2D64d());

			printf("Adj P - True P: (%.2f, %.2f) - (%.2f, %.2f)\n", p.x, p.y, truep.x, truep.y);
		}
	}

	printf("Total             Measured  %.8f     Adjusted  %.8f\n", totalmeasured, totaladjusted);
	printf("Percent better = %f%%\n", 100 * (totalmeasured - totaladjusted) / totalmeasured);
	Hs = initHs;
}

void PointMgr::computeH(vector <Corres> & cs, vector <CvMat *> & Hs) {

	cout << "PointMgr.computeH(): Computing H" << endl;

	computeHGold(cs, Hs);
	//computeHDlt(cs, Hs);
	
}



void PointMgr::printH(CvMat * H) {
	cout << "H Matrix:" << endl;

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
	}

	cout << endl;
}


void PointMgr::computeError(vector <Corres> & csps, vector <CvMat *> & Hs) {

	for (unsigned int i = 0; i < Hs.size(); i++) {
		double error = 0;
		int count = 0;

		for (vector<Corres>::iterator iter = csps.begin(); iter != csps.end(); iter++) {
			if (!iter->inViews[i] || !iter->hasGPS)
				continue;

			CvPoint2D64d p = ApplyM64d(Hs[i], iter->gps.trueToCvPoint2D64d());
			CvPoint2D64d q = ApplyM64d(fakecams[i]->H, iter->gps.trueToCvPoint2D64d());
			
			error += dist(p, q);
			count++;

			//error += abs(p.x - iter->p.x) + abs(p.y - iter->p.y);
			//cout << iter->c.longW << " " << iter->c.latN << " -> "
			//     << iter->p.x << " " << iter->p.y << endl;
			//cout << "                  " << p.x << " " << p.y << endl;
		}
		cout << "Camera " << fakecams[i]->id << ":" << endl;
		cout << "Total pixel error per point: " << error / count << endl; 
	}
	


}


void PointMgr::printCorres() {
	for (vector<Corres>::iterator iter = corrlist.begin(); iter != corrlist.end(); iter++) {
		cout << iter->gps.longW << " " << iter->gps.latN << endl;
	}

}

void PointMgr::updateCorres() {

	cout << "Iteration " << count << endl;
 
	initHV(&camH, numcams);
	
        if (!useransac) {
                cout << "Without RANSAC" << endl;
                computeH(corrlist, camH);
                computeError(corrlist, camH);

                cout << endl;
        } else {
                cout << "With RANSAC" << endl;
                //Ransac ransac(&corrlist, 100);
                //vector <Corres> inliers = ransac.getInliers();
                //computeH(inliers, camH);
                //computeError(inliers, camH);
      
                cout << endl;
        }

	
}



void PointMgr::evalState(vector<double> & state, vector<double> & fvec, int * iflag) {


	vector<Corres> guess;

	vector <CvMat *> Hs;

	goldUnwrap(guess, &Hs, state);

	unsigned int n = (1 + Hs.size()) * corrlist.size() + 9;

	if (fvec.size() != n)
		fvec.resize(n);


	//printf("fcn(): state.size = %d   x.size = %d   guess.size = %d   init.size = %d\n",
	//       state.size(), x.size(), guess.size(), init.size());

	for (unsigned int i = 0; i < fvec.size(); i++) {
		fvec[i] = 0;
	}

	for (unsigned int i = 0; i < guess.size(); i++) {
		// gps error
		double gpsstddev = fakegps->gpserror;
		if (gpsstddev == 0)
			gpsstddev = 10e-10;

		if (corrlist[i].hasGPS)
			fvec[(numcams + 1) * i] = (1.0 / gpsstddev) * guess[i].gps.dist(corrlist[i].gps);

		for (int j = 0; j < numcams; j++) {
			// camera error
			double camstddev = fakecams[j]->camerror;
			if (camstddev == 0)
				camstddev = 10e-10;
			if (corrlist[i].inViews[j])
				fvec[(numcams + 1) * i + (j + 1)] = (1 / camstddev) * dist(guess[i].pts[j], corrlist[i].pts[j]);
		}
	}

	for (unsigned int i = 0; i < Hs.size(); i++) 
		cvReleaseMat(&Hs[i]);

	
}


void PointMgr::estimateC2C(vector <Corres> & csps, vector <CvMat *> &  Hs) {

	// loop through correspondences to find a camera only one
	for (unsigned int i = 0; i < csps.size(); i++) {
		if (csps[i].hasGPS)
			continue;
		
		unsigned int j = 0;

		// loop through cameras to see if one has a view
		while (j < csps[i].pts.size() && !csps[i].inViews[j])
			j++;

		// no gps and no camera has view - error, so quit
		if (j >= csps[i].pts.size())
			exit(1);

		CvMat * HInv = cvCreateMat(3, 3, CV_64FC1);
		cvmInvert(Hs[j], HInv);
		CvPoint2D64d gps = ApplyM64d(HInv, csps[i].pts[j]);
		
		csps[i].gps.latN = gps.y;
		csps[i].gps.longW = gps.x;
		csps[i].gps.hasTrue = false;

		cvReleaseMat(&HInv);
	}
}
