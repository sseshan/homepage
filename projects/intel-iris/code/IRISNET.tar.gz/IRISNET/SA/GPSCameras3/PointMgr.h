/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef POINTMGR_H
#define POINTMGR_H

#include <vector>

#include <cv.h>

#include "GPSCoord.h"
#include "imgproc.h"
#include "FakeCam.h"
#include "OptProb.h"
#include "FakeGPS.h"

class Corres {
public:
	bool hasGPS;
	GPSCoord gps;
	vector <CvPoint2D64d> pts;
	vector <bool> inViews;

	void applyHCToP(vector<CvMat *> * Hs) {
		pts.clear();
		pts.resize(Hs->size());

		for (unsigned int i = 0; i < Hs->size(); i++) {
			pts[i] = ApplyM64d((*Hs)[i], gps.toCvPoint2D64d());
		}
        }
	
};

class Corres2pts {
public:
        GPSCoord c;
        CvPoint2D64d p;

        Corres2pts() {
        }

        Corres2pts(GPSCoord & c, CvPoint2D64d p) {
                this->c = c;
                this->p = p;
        }


        void applyHCToP(CvMat * H) {
                p = ApplyM64d(H, c.toCvPoint2D64d());
        }


};




class PointMgr : public OptProb {
private:
	int c2cpts;

	int numcams;

	vector <Corres> corrlist;

	vector<CvMat *> camH;  // gps coord -> image point

	vector<FakeCam *> fakecams;
	FakeGPS * fakegps;

	int count;
	
	
	void printCorres();
	void computeH(vector <Corres> & csps, vector <CvMat *> & Hs);
	void computeHDlt(vector <Corres> & csps, vector <CvMat *> & Hs);
	void computeHGold(vector <Corres> & csps, vector <CvMat *> & Hs);
	void computeError(vector <Corres> & csps, vector <CvMat *> &  Hs); 
       
	void updateCorres();
	void printH(CvMat * H);
	void goldUnwrap(vector<Corres> & csps, vector <CvMat *> * Hs, vector<double> & v);
	void goldWrap(vector<Corres> & csps, vector <CvMat *> * Hs, vector<double> & v);
	// estimate GPS location from camera to camera correspondences
	void estimateC2C(vector <Corres> & csps, vector <CvMat *> &  Hs);
public:
	bool useransac;

	void evalState(vector<double> & state, vector<double> & fvec, int * iflag);

	PointMgr(vector<FakeCam *> fakecams, FakeGPS * fakegps);
	~PointMgr();

	void add(GPSCoord & c, vector<CvPoint2D64d> & pts, vector<bool> & inViews);
};


#endif
