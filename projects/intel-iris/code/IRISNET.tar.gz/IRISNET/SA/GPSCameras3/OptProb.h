/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef OPTPROB_H
#define OPTPROB_H

#include <vector>

using namespace std;

class OptProb {
public:
	virtual void evalState(vector<double> & state, vector<double> & fvec, int * iflag) = 0;
	virtual ~OptProb() {};
};

#endif
