/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#include "csapp.h"
#include "imgproc.h"

#include "FakeGPSCam.h"
#include "GPSCommand.h"
#include "RndGen.h"

#define PI 3.14159265358979323846

void * thread(void * vargp) {
	//printf("GPS helper thread started.\n");

	((FakeGPSCam *) vargp)->gpsthread();
	return NULL;
}

/*

            ^             +------------------>
            |             |(0, 0)      (w, 0)
                          | 
  P1   P2   L             | 
            a     <--->   |  
  P4   P3   t             |
            N             | 
                          |(0, h)      (w, h)
            |             |
<-- LongW --+             v

*/

FakeGPSCam::FakeGPSCam(SharedFIFO * gpsFIFOin,
		       CvPoint2D64d fromP1, CvPoint2D64d fromP2,
		       CvPoint2D64d fromP3, CvPoint2D64d fromP4,
		       int wd, int ht) {

	width = wd;
	height = ht;

	gpsFIFO = gpsFIFOin;

	CvPoint2D64d e; e.x = 0, e.y = 0;
	CvPoint2D64d f; f.x = width, f.y = 0;
	CvPoint2D64d g; g.x = width, g.y = height;
	CvPoint2D64d h; h.x = 0, h.y = height;

	H = ProjectiveTransform64d(fromP1, fromP2, fromP3, fromP4,
				   e, f, g, h);
	HInv = cvCreateMat(3, 3, CV_64FC1);

	cvInvert(H, HInv);

	printf("Fake GPS H:\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
	}

	printf("\n");
	
	gpserror = 1.0 / 1000000;
	camerror = 1;
	outlierrate = 0;

}

FakeGPSCam::~FakeGPSCam() {
	cvReleaseMat(&H);
	cvReleaseMat(&HInv);
}


void FakeGPSCam::startCapture(GPSCoord & coord) {
}

CvPoint2D64d FakeGPSCam::stopCapture(GPSCoord & coord) {
	if (rndgen.uniformDouble() < outlierrate) {
		CvPoint2D64d q;
		q.x = rndgen.uniformInt(width);
		q.y = rndgen.uniformInt(height);

		return q;
	}

	CvPoint2D64d q = ApplyM64d(H, coord.trueToCvPoint2D64d());
	double angle = rndgen.uniformDouble(2*PI);
	double len = fabs(rndgen.gaussian(0, camerror));

	q.y += len * sin(angle);
	q.x += len * cos(angle);

	/*
	q.y += rndgen.gaussian();
	q.x += rndgen.gaussian();
	*/

	return q;
}



void FakeGPSCam::startGPS() {
	stopThread = false;
	Pthread_create(&gpstid, NULL, thread, (void *) this);
}

void FakeGPSCam::stopGPS() {
	stopThread = true;
	Pthread_join(gpstid, NULL);
}

void FakeGPSCam::gpsthread() {
	printf("GPS thread started.\n");
	

	bool isStart = true;

	GPSCoord coord;

	while (!stopThread) {
		while (gpsFIFO->hasMoreItems())
			usleep(1000);

		if (isStart) {
			//coord.latN = 45;
			//coord.longW = 90;

			int x = rndgen.uniformInt(width);
			int y = rndgen.uniformInt(height);

			CvPoint2D64d c;
			c.x = x;
			c.y = y;

			printf("Image point (true): (%d, %d)\n", x, y);

			CvPoint2D64d p = ApplyM64d(HInv, c);
			
			coord.trueLatN = p.y;
			coord.trueLongW = p.x;

			double angle = rndgen.uniformDouble(2*PI);
			double len = fabs(rndgen.gaussian(0, gpserror));
			coord.latN = coord.trueLatN + len * sin(angle);
			coord.longW = coord.trueLongW + len * cos(angle);

			coord.hasTrue = true;

			GPSCommand * cmd = new GPSCommand(GPSCommand::DETECT_ON, coord);
			
			
			gpsFIFO->insert((unsigned int) cmd);
		       
		} else {
			GPSCommand * cmd = new GPSCommand(GPSCommand::DETECT_OFF, coord);
			gpsFIFO->insert((unsigned int) cmd);
		}
		
		isStart = !isStart;
		usleep(100000);
	}

	printf("GPS thread stopped.\n");
}


