/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef RANSAC_H
#define RANSAC_H

#include <vector>
#include <cv.h>

#include "RndGen.h"
#include "PointMgr.h"

using namespace std;

class RndPointGen {
private:
	int maxindex;
	int maxcount;
	
	int count;

	RndGen rndgen;
public:
	RndPointGen(int maxindex, int maxcount);
        bool hasNext();
        vector <int> next();
};


class Ransac {
private:
	int numiter;
	vector<Corres> * corrlist;
	CvMat * bestH;
	double bestMedianError;
	double best3QuartileError;

	void findBestH();
	CvMat * findH(vector<int> indices);
	void calcHError(CvMat * H, double & medianError, double & thirdQuartileError);
public:
	Ransac(vector<Corres> * corrlist, int numiter);
	vector<Corres> getInliers();
	~Ransac();
};


#endif
