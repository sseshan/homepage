/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef POINTMGR_H
#define POINTMGR_H

#include <vector>

#include <cv.h>

#include "GPSCoord.h"
#include "imgproc.h"

using namespace std;

class Corres {
public:
	GPSCoord c;
	CvPoint2D64d p;

	Corres() {
	}

	Corres(GPSCoord & c, CvPoint2D64d p) {
		this->c = c;
		this->p = p;
	}

	void applyHCToP(CvMat * H) {
		p = ApplyM64d(H, c.toCvPoint2D64d());
	}

};

class PointMgr {
private:
	vector <Corres> corrlist;

	CvMat * bestH;  // gps coord -> image point
	CvMat * trueH;  // gps coord -> image point

	int count;

	void printCorres();
	void computeH(vector <Corres> & c, CvMat ** H);
	void computeH4Pts(vector <Corres> & c, CvMat ** H);
	void computeHDlt(vector <Corres> & c, CvMat ** H);
	void computeHGold(vector <Corres> &c, CvMat **H);
	void computeError(vector <Corres> & c, CvMat * H); 
	void updateCorres();
	void printH(CvMat * H);
public:
	PointMgr(CvMat * trueH);
	~PointMgr();

	void add(GPSCoord c, CvPoint2D64d p);
};


#endif
