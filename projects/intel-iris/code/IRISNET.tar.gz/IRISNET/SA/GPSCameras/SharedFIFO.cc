/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#include "csapp.h"
#include "SharedFIFO.h"

/* Create an empty, bounded, shared FIFO buffer with n slots */
SharedFIFO::SharedFIFO(int n)
{
	buf = (unsigned int *) Malloc(n * sizeof(unsigned int)); 
	this->n = n;                 /* Buffer holds max of n items */
	front = rear = 0;            /* Empty buffer iff front == rear */
	Sem_init(&mutex, 0, 1);      /* Binary semaphore for locking */
	Sem_init(&slots, 0, n);      /* Initially, buf has n empty slots */
	Sem_init(&items, 0, 0);      /* Initially, buf has zero data items */
}

/* Clean up buffer sp */
SharedFIFO::~SharedFIFO()
{
	Free(buf);
}

/* Insert item onto the rear of shared buffer sp */

void SharedFIFO::insert(unsigned int item)
{
	P(&slots);                          /* Wait for available slot */
	P(&mutex);                          /* Lock the buffer */
	buf[(++rear)%(n)] = item;           /* Insert the item */
	V(&mutex);                          /* Unlock the buffer */
	V(&items);                          /* Announce available item */
}


/* Remove and return the first item from buffer sp */
unsigned int SharedFIFO::remove()
{
	unsigned int item;
	P(&items);                          /* Wait for available item */
	P(&mutex);                          /* Lock the buffer */
	item = buf[(++front)%(n)];          /* Remove the item */
	V(&mutex);                          /* Unlock the buffer */
	V(&slots);                          /* Announce available slot */
	return item;
}

bool SharedFIFO::hasMoreItems() {
	return !(front == rear);
}


