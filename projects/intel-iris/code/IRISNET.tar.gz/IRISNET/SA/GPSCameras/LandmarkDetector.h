/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef LANDMARKDETECTOR_H
#define LANDMARKDETECTOR_H

#include <cv.h>

#include "GPSCoord.h"

// abstract
class LandmarkDetector {
protected:
	GPSCoord coord;
public:
	virtual void startCapture(GPSCoord & coord) = 0;
	virtual CvPoint2D64d stopCapture(GPSCoord & coord) = 0;
	virtual ~LandmarkDetector() {};
};

#endif
