/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <iostream>

#include "imgproc.h"

#include "PointMgr.h"
#include "Ransac.h"
#include "Dlt.h"
#include "Lm.h"

PointMgr::PointMgr(CvMat * trueH) {
	this->trueH = trueH; 
	bestH = NULL;
	count = 0;

}

PointMgr::~PointMgr() {
	delete(bestH);
	bestH = NULL;

}

void PointMgr::add(GPSCoord c, CvPoint2D64d p) {
	Corres corres(c, p);
	
	corrlist.push_back(corres);

	cout << "PointMgr.add(): Adding point correspondence" << endl;

	count++;

	if (count % 10 == 0) {
		updateCorres();
	}

}

// compute H from the first 4 points of cs
void PointMgr::computeH4Pts(vector <Corres> & cs, CvMat ** H) {
	CvPoint2D64d a = cs[0].c.toCvPoint2D64d();
	CvPoint2D64d b = cs[1].c.toCvPoint2D64d();
	CvPoint2D64d c = cs[2].c.toCvPoint2D64d();
	CvPoint2D64d d = cs[3].c.toCvPoint2D64d();

	CvPoint2D64d e = cs[0].p;
	CvPoint2D64d f = cs[1].p;
	CvPoint2D64d g = cs[2].p;
	CvPoint2D64d h = cs[3].p;

	*H = ProjectiveTransform64d(a, b, c, d,
				    e, f, g, h);

}

void PointMgr::computeHDlt(vector <Corres> & cs, CvMat ** H) {

	vector<CvPoint2D64d> list;


	for (vector<Corres>::iterator iter = cs.begin(); iter != cs.end(); iter++) {
		//list.push_back(iter->p);
		list.push_back(iter->c.toCvPoint2D64d());
		list.push_back(iter->p);	
	}

	*H = dlt(list);	
}

void goldWrap(vector<Corres> & c, CvMat * H, vector<double> & v) {
	v.clear();

	if (H != NULL) {
		//printf("H size = %d\n", H->rows * H->cols);
		for (int j = 0; j < H->rows; j++) {
			for (int i = 0; i < H->cols; i++) {
				v.push_back(cvmGet(H, j, i));
			}
		}
	}

	for (vector<Corres>::iterator iter = c.begin(); iter != c.end(); iter++) {
		
		v.push_back(iter->c.latN);
		v.push_back(iter->c.longW);

		if (H == NULL) {
			v.push_back(iter->p.y);
			v.push_back(iter->p.x);
		}
	}


}

void goldUnwrap(vector<Corres> & c, CvMat * H, vector<double> & v) {
	vector<double>::iterator iter = v.begin();
 

	if (H != NULL) {
		for (int j = 0; j < H->rows; j++) {
			for (int i = 0; i < H->cols; i++) {
				cvmSet(H, j, i, *iter++);
			}
		}
	}

	c.clear();

	while (iter != v.end()) {
		Corres cs;
		
		cs.c.latN = *iter++;
		cs.c.longW = *iter++;

		if (H == NULL) {
			cs.p.y = *iter++;
			cs.p.x = *iter++;
		} else {
			cs.applyHCToP(H);	
		}

		c.push_back(cs);
	}

	
}
 

double dist(CvPoint2D64d a, CvPoint2D64d b) {
	//printf("dist(): Calculating distance between (%f, %f) and (%f, %f)\n", a.x, a.y, b.x, b.y);
	double x = b.x - a.x;
	double y = b.y - a.y;
	return sqrt(x*x + y*y);
}

void fcn(vector<double> & state, vector<double> & x, vector<double> & fvec, int *iflag)
{
	
	vector<Corres> guess;
	vector<Corres> init;

	CvMat * H = cvCreateMat(3, 3, CV_64FC1);

	goldUnwrap(guess, H, x);
	goldUnwrap(init, NULL, state);
	
	//printf("fcn(): state.size = %d   x.size = %d   guess.size = %d   init.size = %d\n",
	//       state.size(), x.size(), guess.size(), init.size());

	for (unsigned int i = 0; i < fvec.size(); i++) {
		fvec[i] = 0;
	}

	for (unsigned int i = 0; i < guess.size(); i++) {
		fvec[2*i] = 10e5 * guess[i].c.dist(init[i].c);
	        fvec[2*i+1] = dist(guess[i].p, init[i].p);
	}

	cvReleaseMat(&H);
}

void PointMgr::computeHGold(vector <Corres> &c, CvMat **H) {
	CvMat * initH;
	vector<double> state;
	vector<double> x;
	vector<double> fvec(2*c.size() + 9);

	printf("Gold wrapping measurement state\n");

	goldWrap(c, NULL, state);

	printf("Computing initial H\n");

	computeHDlt(c, &initH);

	printf("Gold wrapping initial state\n");
	
	goldWrap(c, initH, x);

	printf("x size = %d    fvec size = %d\n", x.size(), fvec.size());
	lm(fcn, state, x, fvec);

	vector<Corres> tc(c.size());

	goldUnwrap(tc, initH, x);
	
	double totalmeasured = 0;
	double totaladjusted = 0;
	for (unsigned int i = 0; i < c.size(); i++) {
		printf("Corres %d:  ", i);
		double measured = c[i].c.distToTrue(c[i].c);
		printf("Measure Error: %.8f   ", measured);
		double adjusted = c[i].c.distToTrue(tc[i].c);
		printf("Adjusted Error: %.8f\n", adjusted);
		totalmeasured += measured;
		totaladjusted += adjusted;
	}

	printf("Total             Measured  %.8f     Adjusted  %.8f\n", totalmeasured, totaladjusted);
	printf("Percent better = %f%%\n", 100 * (totalmeasured - totaladjusted) / totalmeasured);
	*H = initH;
}

void PointMgr::computeH(vector <Corres> & cs, CvMat ** H) {

	cout << "PointMgr.computeH(): Computing H" << endl;

	computeHGold(cs, H);
	//computeHDlt(cs, H);
	
}



void PointMgr::printH(CvMat * H) {
	cout << "H Matrix:" << endl;

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
	}

	cout << endl;
}


void PointMgr::computeError(vector <Corres> & c, CvMat * H) {
	if (H == NULL)
		return;

	double error = 0;

	for (vector<Corres>::iterator iter = c.begin(); iter != c.end(); iter++) {
		CvPoint2D64d p = ApplyM64d(H, iter->c.trueToCvPoint2D64d());
		CvPoint2D64d q = ApplyM64d(trueH, iter->c.trueToCvPoint2D64d());

		error += dist(p, q);
		//error += abs(p.x - iter->p.x) + abs(p.y - iter->p.y);
		//cout << iter->c.longW << " " << iter->c.latN << " -> "
		//     << iter->p.x << " " << iter->p.y << endl;
		//cout << "                  " << p.x << " " << p.y << endl;
	}

	cout << "Total error per point: " << error / c.size() << endl; 
}

void PointMgr::printCorres() {
	for (vector<Corres>::iterator iter = corrlist.begin(); iter != corrlist.end(); iter++) {
		cout << iter->c.longW << " " << iter->c.latN << endl;
	}

}

void PointMgr::updateCorres() {

	cout << "Iteration " << count << endl;

	cout << "Without RANSAC" << endl;
	computeH(corrlist, &bestH);
	printH(bestH);
	computeError(corrlist, bestH);

	cvReleaseMat(&bestH);
	bestH = NULL;

	
	cout << endl;
	cout << "With RANSAC" << endl;
	Ransac ransac(&corrlist, 10);
	vector <Corres> inliers = ransac.getInliers();	
	computeH(inliers, &bestH);
	printH(bestH);
	computeError(inliers, bestH);

	cvReleaseMat(&bestH);
	bestH = NULL;
	
	
}
