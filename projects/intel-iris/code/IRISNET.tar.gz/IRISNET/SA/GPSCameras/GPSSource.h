/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef GPSSOURCE_H
#define GPSSOURCE_H


// abstract
class GPSSource {
public:
	virtual void startGPS() = 0;
	virtual void stopGPS() = 0;
};



#endif
