/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


#include <cv.h>
//#include "highgui.h"
//#include "SA.h"
//#include <sys/shm.h>
//#include <math.h>
//#include <sys/times.h>
//#include <sys/resource.h>
//#include "shmman.h"
//#include "imgproc.h"
//#include "csapp.h"


#include "FakeGPSCam.h"
#include "SharedFIFO.h"
#include "GPSCommand.h"
#include "LandmarkDetector.h"
#include "PointMgr.h"

class CalCams {
private:
	GPSSource * gpssource;
	SharedFIFO * gpsFIFO;
	LandmarkDetector * lmDetector;
	PointMgr * pointmgr;
 public:
	CalCams();
	~CalCams();

	void start();
	void stop();
};

CalCams::CalCams() {
	gpsFIFO = new SharedFIFO(10);
	
	CvPoint2D64d a; a.x = 90.0001, a.y = 45.0001;
	CvPoint2D64d b; b.x = 90, b.y = 45.0001;
	CvPoint2D64d c; c.x = 90, c.y = 45;
	CvPoint2D64d d; d.x = 90.0001, d.y = 45;
	
	/*
	CvPoint2D64d a; a.x = 95, a.y = 50;
	CvPoint2D64d b; b.x = 90, b.y = 50;
	CvPoint2D64d c; c.x = 90, c.y = 45;
	CvPoint2D64d d; d.x = 95, d.y = 45;
	*/

	FakeGPSCam * tmp = new FakeGPSCam(gpsFIFO,
					  a, b, c, d,
					  640, 480);
	gpssource = tmp;
	lmDetector = tmp;

	pointmgr = new PointMgr(tmp->H);
}

CalCams::~CalCams() {
	delete(gpsFIFO);
	gpsFIFO = NULL;

	delete(gpssource);
	gpssource = NULL;

	delete(lmDetector);
	lmDetector = NULL;

	delete(pointmgr);
	pointmgr = NULL;
}


void CalCams::start() {
	GPSCoord coord;

	gpssource->startGPS();
	
	int count = 0;

	while (true) {
	//while (count < 25) {
		GPSCommand * cmd = (GPSCommand *) gpsFIFO->remove();
		//printf("GPS FIFO Command: %d\n", cmd->cmd);

		if (cmd->cmd == GPSCommand::DETECT_ON) {
			coord = cmd->coord;
			lmDetector->startCapture(coord);
		}
		else {
			CvPoint2D64d pt = lmDetector->stopCapture(coord);
			printf("GPS point (true): (%.8fN, %.8fW)\n", coord.trueLatN, coord.trueLongW);
			printf("Image point (measured): (%f, %f)\n", pt.x, pt.y);
			printf("GPS point (measured): (%.8fN, %.8fW)\n", coord.latN, coord.longW);

			pointmgr->add(coord, pt);
			printf("\n");
		}			


		delete (cmd);
		cmd = NULL;
		count++;
	}
}


void CalCams::stop() {
	gpssource->stopGPS();
}

int main(int argc, char * argv[])
{

	CalCams * cams = new CalCams();
	cams->start();

	

	cams->stop();

	return 0;
}
