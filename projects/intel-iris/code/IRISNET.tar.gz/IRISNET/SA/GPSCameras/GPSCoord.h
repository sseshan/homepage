/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef GPSCOORD_H
#define GPSCOORD_H

#include <math.h>

class GPSCoord {
public:
	double latN;
	double longW;
	bool hasTrue;
	double trueLatN;
	double trueLongW;

	CvPoint2D64d toCvPoint2D64d() {
		CvPoint2D64d p;
		p.x = longW;
		p.y = latN;

		return p;
	}
	
	CvPoint2D64d trueToCvPoint2D64d() {
		CvPoint2D64d p;
		p.x = trueLongW;
		p.y = trueLatN;

		return p;
	}

	double dist(GPSCoord c) {
		// HACK - need to fix to real coordinates
		double x = longW - c.longW;
		double y = latN - c.latN;
		return sqrt(x*x + y*y);
	}

	double distToTrue(GPSCoord c) {
		// HACK - need to fix to real coordinates
		double x = trueLongW - c.longW;
		double y = trueLatN - c.latN;
		return sqrt(x*x + y*y);
	}

};

#endif
