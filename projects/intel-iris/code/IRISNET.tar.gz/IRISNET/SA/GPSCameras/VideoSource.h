/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef VIDEOSOURCE_H
#define VIDEOSOURCE_H

#include "VideoFrame.h"

// abstract
class VideoSource {
public:
	virtual VideoFrame * newFrameBuffer() = 0;
	virtual bool nextFrame(VideoFrame * buffer) = 0;
};

#endif
