/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef VIDEOFRAME_H
#define VIDEOFRAME_H


class VideoFrame {
public:
	int width;
	int height;
};

#endif
