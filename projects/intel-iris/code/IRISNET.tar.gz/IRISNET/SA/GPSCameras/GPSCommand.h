/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef GPS_COMMAND_H
#define GPS_COMMAND_H

#include "GPSCoord.h"

class GPSCommand {

public:
	enum Command {DETECT_ON, DETECT_OFF};
	Command cmd;
	GPSCoord coord;

	GPSCommand(Command c, GPSCoord & g) {
		cmd = c;
		coord = g;
	}

};

#endif
