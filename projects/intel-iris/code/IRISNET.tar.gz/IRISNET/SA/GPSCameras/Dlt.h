#ifndef DLT_H
#define DLT_H

#include <vector>
#include <cv.h>

using namespace std;

CvMat * dlt(vector<CvPoint2D64d> pointList);

void normdlt(vector<CvPoint2D64d> pointList);


#endif
