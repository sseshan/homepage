/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef FAKEGPSCAM_H
#define FAKEGPSCAM_H

#include <stdlib.h>

#include <cv.h>

#include "LandmarkDetector.h"
#include "GPSSource.h"
#include "SharedFIFO.h"
#include "RndGen.h"

class FakeGPSCam : public LandmarkDetector, public GPSSource {
private:
	RndGen rndgen;

	// LandmarkDetector
	
	CvMat * HInv;

	int width, height;


	// GPSSource
	pthread_t gpstid;
	SharedFIFO * gpsFIFO;
	bool stopThread;
	

public:
	CvMat * H;
	double gpserror;
	double camerror;
	double outlierrate;

	FakeGPSCam(SharedFIFO * gpsFIFO,
		   CvPoint2D64d fromP1, CvPoint2D64d fromP2,
		   CvPoint2D64d fromP3, CvPoint2D64d fromP4,
		   int w, int h);

	~FakeGPSCam();

	void gpsthread();

	// LandmarkDetector methods
	void startCapture(GPSCoord & coord);
	CvPoint2D64d stopCapture(GPSCoord & coord);

	// GPSSource methods
	void startGPS();
	void stopGPS();
};


#endif
