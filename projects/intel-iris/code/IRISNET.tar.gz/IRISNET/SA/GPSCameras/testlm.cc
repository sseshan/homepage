/************************lmdif*************************/

/*
 * Solves or minimizes the sum of squares of m nonlinear
 * functions of n variables.
 *
 * From public domain Fortran version
 * of Argonne National Laboratories MINPACK
 *
 * C translation by Steve Moshier
 */


#include "Lm.h"


/****************Sample main program******************/
#define BUG 0
#define N 4
#define M 4


/***********Sample of user supplied function****************
 * m = number of functions
 * n = number of variables
 * x = vector of function arguments
 * fvec = vector of function values
 * iflag = error return variable
 */
void fcn(vector<double> & state, vector<double> & x, vector<double> & fvec, int *iflag)
{
	double temp;
	double exp(), sin(), log(), cos();

/* an arbitrary test function: */
/*
	fvec[0] =
	    1.0 - 0.3 * x[0] + 0.9 * x[1] - 1.7 * x[2] + log(1.5 + x[3]);
	fvec[1] = sin(-4.0 * x[0]) - 3.0 * x[1] + 0.1 * x[2] + x[3] * x[3];
	temp = (x[2] + 2.0) * x[2] * x[1];
	fvec[2] = 0.5 * x[1] - sin(x[2] + 1.0) + temp + .3 * x[3];
	fvec[3] = x[0] * x[1] + x[1] * x[2] + x[0] * x[2] - x[3] * x[3];
*/
	fvec[0] = x[0] + 1;
	fvec[1] = 0;
	fvec[2] = 0;
	fvec[3] = 0;

}

int main()
{
	int m, n, info;
/*
*	fcn is the name of the user-supplied subroutine which
*	  calculates the functions. fcn must be declared
*	  in an external statement in the user calling
*	  program, and should be written as follows.
*
*	  subroutine fcn(m,n,x,fvec,iflag)
*	  integer m,n,iflag
*	  double precision x(n),fvec(m)
*	  ----------
*	  calculate the functions at x and
*	  return this vector in fvec.
*	  ----------
*	  return
*	  end
*
*	  the value of iflag should not be changed by fcn unless
*	  the user wants to terminate execution of lmdif1.
*	  in this case set iflag to a negative integer.
*
*	m is a positive integer input variable set to the number
*	  of functions.
*
*	n is a positive integer input variable set to the number
*	  of variables. n must not exceed m.
*
*	x is an array of length n. on input x must contain
*	  an initial estimate of the solution vector. on output x
*	  contains the final estimate of the solution vector.
*
*	fvec is an output array of length m which contains
*	  the functions evaluated at the output x.
*
*
*     argonne national laboratory. minpack project. march 1980.
*     burton s. garbow, kenneth e. hillstrom, jorge j. more
*
*     **********
*/

	int iflag = 0;
	vector <double> state;
	vector <double> x(N);
	vector <double> fvec(M);
	
	x[0] = -1.2;

	fcn(state, x, fvec, &iflag);

	/*
	printf("initial x\n");
	pmat(1, x.size(), x);		// display 1 by n matrix 
	printf("initial function\n");
	pmat(1, fvec.size(), fvec);
	*/

	lm(fcn, state, x, fvec);

	/*
	//printf("%d function evaluations\n", nfev);
	// display solution and function vector
	printf("x\n");
	pmat(1, x.size(), x);
	printf("fvec\n");
	pmat(1, fvec.size(), fvec);
	printf("function norm = %.15e\n", enorm(fvec.size(), fvec));
	*/


	return 0;
}

