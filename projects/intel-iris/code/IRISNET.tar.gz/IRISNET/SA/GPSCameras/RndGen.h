/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef RNDGEN_H
#define RNDGEN_H

class RndGen {
private:
	bool haveNextGaussian;
	double nextGaussian;
	
public:
	RndGen();
	
	double beta(int alpha, int beta);
	double gamma1(int alpha);
	int uniformInt();
	int uniformInt(int max);
	long uniformLong(long max);
	long uniformLong();
	long uniformPosLong();
	double uniformDouble();
	double uniformDouble(double max);
	double exponential(double alpha);
	double gaussian(double m = 0, double sd = 1);
};


#endif
