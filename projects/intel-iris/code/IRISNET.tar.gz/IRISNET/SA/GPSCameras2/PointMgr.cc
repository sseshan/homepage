/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <iostream>

#include "imgproc.h"

#include "PointMgr.h"
#include "Ransac.h"
#include "Dlt.h"
#include "Lm.h"

PointMgr::PointMgr(vector<FakeCam *> fakecams) {
	this->fakecams = fakecams;
	count = 0;
	useransac = false;
}

PointMgr::~PointMgr() {


}
void initHV(vector <CvMat *> * Hs, int size) {
	
	for (int i = 0; i < Hs->size(); i++) {
		cvReleaseMat(&(*Hs)[i]);
	}
	
	Hs->clear();
	Hs->resize(size, 0);
	
}

void PointMgr::add(GPSCoord & c, vector<CvPoint2D64d> & pts, vector<bool> & inViews) {
	Corres corres;
	corres.c = c;
	corres.pts = pts;
	corres.inViews = inViews;
	
	corrlist.push_back(corres);

	count++;

	cout << "PointMgr.add(): Adding point " << count << " correspondence" << endl << endl;

	if (count % 20 == 0) {
		updateCorres();
		corrlist.clear();
	}

}

void PointMgr::computeHDlt(vector <Corres> & cs, vector <CvMat *> & Hs) {
	//cout << " Computing H via DLT " << endl;

	for (unsigned int i = 0; i < Hs.size(); i++) {
		vector<CvPoint2D64d> list;
		
		for (vector<Corres>::iterator iter = cs.begin(); iter != cs.end(); iter++) {
			if (iter->inViews[i]) {
				list.push_back(iter->c.toCvPoint2D64d());
				list.push_back(iter->pts[i]);
			}
		}

		Hs[i] = dlt(list);
		cout << "Camera " << fakecams[i]->id << ":" << endl;
		printH(Hs[i]);
	}	
}


void stateWrap(vector<Corres> & c, vector<double> & v) {
	v.clear();


	for (vector<Corres>::iterator iter = c.begin(); iter != c.end(); iter++) {
		
		v.push_back(iter->c.latN);
		v.push_back(iter->c.longW);
		/*

		v.push_back(iter->c.trueLatN);
		v.push_back(iter->c.trueLongW);
		*/
		v.push_back(iter->pts.size());
		
		for (int i = 0; i < iter->pts.size(); i++) {
			v.push_back(iter->inViews[i]);
			v.push_back(iter->pts[i].y);
			v.push_back(iter->pts[i].x);
		
		}
	}


}

void stateUnwrap(vector<Corres> & c, vector<double> & v) {
	vector<double>::iterator iter = v.begin();
 
	c.clear();

	while (iter != v.end()) {
		Corres cs;
		
		cs.c.latN = *iter++;
		cs.c.longW = *iter++;

		int size = *iter++;
		CvPoint2D64d pt;
		
		for (int i = 0; i < size; i++) {
			cs.inViews.push_back(*iter++);
			pt.y = *iter++;
			pt.x = *iter++;
			
			cs.pts.push_back(pt);
		}

		c.push_back(cs);
	}

	
}



void goldWrap(vector<Corres> & c, vector <CvMat *> * Hs, vector<double> & v) {
	v.clear();
	
	for (int k = 0; k < Hs->size(); k++) {
		//printf("H size = %d\n", H->rows * H->cols);
		for (int j = 0; j < (*Hs)[k]->rows; j++) {
			for (int i = 0; i < (*Hs)[k]->cols; i++) {
				v.push_back(cvmGet((*Hs)[k], j, i));
			}
		}
	}
	

	for (vector<Corres>::iterator iter = c.begin(); iter != c.end(); iter++) {
		v.push_back(iter->c.latN);
		v.push_back(iter->c.longW);
	}


}

void goldUnwrap(vector<Corres> & c, vector <CvMat *> * Hs, vector<double> & v) {
	vector<double>::iterator iter = v.begin();
 
	int Hsize = 2; // HACK
	
	Hs->resize(Hsize);
       
	for (int k = 0; k < Hsize; k++) {
		(*Hs)[k] = cvCreateMat(3, 3, CV_64FC1);
		
		for (int j = 0; j < (*Hs)[k]->rows; j++) {
			for (int i = 0; i < (*Hs)[k]->cols; i++) {
				cvmSet((*Hs)[k], j, i, *iter++);
			}
		}
	}
	

	c.clear();

	while (iter != v.end()) {
		Corres cs;
		
		cs.c.latN = *iter++;
		cs.c.longW = *iter++;
		cs.applyHCToP(Hs);
		
		c.push_back(cs);
	}

	
}


double dist(CvPoint2D64d a, CvPoint2D64d b) {
	//printf("dist(): Calculating distance between (%f, %f) and (%f, %f)\n", a.x, a.y, b.x, b.y);
	double x = b.x - a.x;
	double y = b.y - a.y;
	return sqrt(x*x + y*y);
}


void fcn(vector<double> & state, vector<double> & x, vector<double> & fvec, int *iflag)
{
	
	vector<Corres> guess;
	vector<Corres> init;

	vector <CvMat *> Hs;

	goldUnwrap(guess, &Hs, x);

	stateUnwrap(init, state);
	
	//printf("fcn(): state.size = %d   x.size = %d   guess.size = %d   init.size = %d\n",
	//       state.size(), x.size(), guess.size(), init.size());

	for (unsigned int i = 0; i < fvec.size(); i++) {
		fvec[i] = 0;
	}

	int numcams = init[0].pts.size();

	for (unsigned int i = 0; i < guess.size(); i++) {
		fvec[(numcams + 1) * i] = guess[i].c.dist(init[i].c);

		for (int j = 0; j < numcams; j++) {
			if (init[i].inViews[j])
				fvec[(numcams + 1) * i + (j + 1)] = 10e10 * dist(guess[i].pts[j], init[i].pts[j]);
		}
	}

	for (int i = 0; i < Hs.size(); i++) 
		cvReleaseMat(&Hs[i]);
}

void PointMgr::computeHGold(vector <Corres> &c, vector <CvMat *> & Hs) {
	vector <CvMat *> initHs;

	vector<double> state;
	vector<double> x;

	vector<double> fvec((1 + Hs.size()) *  c.size());

	printf("Gold wrapping measurement state\n");

	stateWrap(c, state);

	printf("Computing initial H's (%d total)\n", Hs.size());

	initHV(&initHs, Hs.size());

	computeHDlt(c, initHs);

	printf("Gold wrapping initial state\n");
	
	goldWrap(c, &initHs, x);

	printf("x size = %d    fvec size = %d\n", x.size(), fvec.size());
	lm(fcn, state, x, fvec);

	vector<Corres> tc(c.size());

	goldUnwrap(tc, &initHs, x);
	
	double totalmeasured = 0;
	double totaladjusted = 0;
	for (unsigned int i = 0; i < c.size(); i++) {
		printf("Corres %d:  ", i);
		double measured = c[i].c.distToTrue(c[i].c);
		printf("Meas. Err: %.8f   ", measured);
		double adjusted = c[i].c.distToTrue(tc[i].c);
		printf("Adj Err: %.8f\n", adjusted);
		totalmeasured += measured;
		totaladjusted += adjusted;
	}

	
	for (unsigned int j = 0; j < c[0].pts.size(); j++) {
		printf("Camera %d\n", j + 1);
		for (unsigned int i = 0; i < c.size(); i++) {
			CvPoint2D64d p = ApplyM64d(initHs[j], tc[i].c.toCvPoint2D64d());
			//CvPoint2D64d p = ApplyM64d(goldH, c[i].c.trueToCvPoint2D64d());
			//CvPoint2D64d p = c[i].p;
		
			CvPoint2D64d truep = ApplyM64d(fakecams[j]->H, c[i].c.trueToCvPoint2D64d());

			printf("Adj P - True P: (%.2f, %.2f) - (%.2f, %.2f)\n", p.x, p.y, truep.x, truep.y);
		}
	}

	printf("Total             Measured  %.8f     Adjusted  %.8f\n", totalmeasured, totaladjusted);
	printf("Percent better = %f%%\n", 100 * (totalmeasured - totaladjusted) / totalmeasured);
	Hs = initHs;
}

void PointMgr::computeH(vector <Corres> & cs, vector <CvMat *> & Hs) {

	cout << "PointMgr.computeH(): Computing H" << endl;

	computeHGold(cs, Hs);
	//computeHDlt(cs, Hs);
	
}



void PointMgr::printH(CvMat * H) {
	cout << "H Matrix:" << endl;

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
	}

	cout << endl;
}


void PointMgr::computeError(vector <Corres> & c, vector <CvMat *> & Hs) {

	for (int i = 0; i < Hs.size(); i++) {
		double error = 0;
		int count = 0;

		for (vector<Corres>::iterator iter = c.begin(); iter != c.end(); iter++) {
			if (!iter->inViews[i])
				continue;

			CvPoint2D64d p = ApplyM64d(Hs[i], iter->c.trueToCvPoint2D64d());
			CvPoint2D64d q = ApplyM64d(fakecams[i]->H, iter->c.trueToCvPoint2D64d());
			
			error += dist(p, q);
			count++;

			//error += abs(p.x - iter->p.x) + abs(p.y - iter->p.y);
			//cout << iter->c.longW << " " << iter->c.latN << " -> "
			//     << iter->p.x << " " << iter->p.y << endl;
			//cout << "                  " << p.x << " " << p.y << endl;
		}
		cout << "Camera " << fakecams[i]->id << ":" << endl;
		cout << "Total pixel error per point: " << error / count << endl; 
	}
	


}

void PointMgr::printCorres() {
	for (vector<Corres>::iterator iter = corrlist.begin(); iter != corrlist.end(); iter++) {
		cout << iter->c.longW << " " << iter->c.latN << endl;
	}

}

void PointMgr::updateCorres() {

	cout << "Iteration " << count << endl;
 
	initHV(&camH, corrlist[0].pts.size());

        if (!useransac) {
                cout << "Without RANSAC" << endl;
                computeH(corrlist, camH);
                computeError(corrlist, camH);

                cout << endl;
        } else {
                cout << "With RANSAC" << endl;
                //Ransac ransac(&corrlist, 100);
                //vector <Corres> inliers = ransac.getInliers();
                //computeH(inliers, camH);
                //computeError(inliers, camH);
      
                cout << endl;
        }

	
}
