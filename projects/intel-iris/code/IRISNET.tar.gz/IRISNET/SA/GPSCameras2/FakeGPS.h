/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef FAKEGPS_H
#define FAKEGPS_H

#include <stdlib.h>

#include <cv.h>

#include "GPSSource.h"
#include "SharedFIFO.h"
#include "RndGen.h"

class FakeGPS : public GPSSource {
private:
	RndGen rndgen;

	// GPSSource
	pthread_t gpstid;
	SharedFIFO * gpsFIFO;
	bool stopThread;
	CvPoint2D64d P1;
	double width, height;

public:
	double gpserror;
	
	FakeGPS(SharedFIFO * gpsFIFO,
		CvPoint2D64d P1, double height, double width);

	~FakeGPS();

	void gpsthread();

	// GPSSource methods
	void startGPS();
	void stopGPS();
};

#endif
