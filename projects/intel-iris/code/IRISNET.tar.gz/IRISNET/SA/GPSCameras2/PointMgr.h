/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef POINTMGR_H
#define POINTMGR_H

#include <vector>

#include <cv.h>

#include "GPSCoord.h"
#include "imgproc.h"
#include "FakeCam.h"

using namespace std;

class Corres {
public:
	GPSCoord c;
	vector <CvPoint2D64d> pts;
	vector <bool> inViews;

	/*
	Corres() {
	}

	Corres(GPSCoord & c, CvPoint2D64d p) {
		this->c = c;
		this->p = p;
	}
	*/
	void applyHCToP(vector<CvMat *> * Hs) {
		pts.clear();
		pts.resize(Hs->size());

		for (int i = 0; i < Hs->size(); i++) {
			pts[i] = ApplyM64d((*Hs)[i], c.toCvPoint2D64d());
		}
        }
	
};
 
class Corres2pts {
public:        
	GPSCoord c;
        CvPoint2D64d p;
 
        Corres2pts() {
        }
 
        Corres2pts(GPSCoord & c, CvPoint2D64d p) {
                this->c = c;
                this->p = p;
        }
 
      
	void applyHCToP(CvMat * H) {
                p = ApplyM64d(H, c.toCvPoint2D64d());
        }
  

};


class PointMgr {
private:
	vector <Corres> corrlist;

	vector<CvMat *> camH;  // gps coord -> image point

	vector<FakeCam *> fakecams;

	int count;

	
	void printCorres();
	void computeH(vector <Corres> & c, vector <CvMat *> & Hs);

	void computeHDlt(vector <Corres> & c, vector <CvMat *> & Hs);
	void computeHGold(vector <Corres> &c, vector <CvMat *> & Hs);
	void computeError(vector <Corres> & c, vector <CvMat *> &  Hs); 
	void updateCorres();
	void printH(CvMat * H);
public:
	bool useransac;

	PointMgr(vector<FakeCam *> fakecams);
	~PointMgr();

	void add(GPSCoord & c, vector<CvPoint2D64d> & pts, vector<bool> & inViews);
};


#endif
