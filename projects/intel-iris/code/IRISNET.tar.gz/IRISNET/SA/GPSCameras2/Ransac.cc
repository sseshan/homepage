/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <algorithm>
#include <iostream>

#include <stdlib.h>
#include <math.h>

#include "imgproc.h"
#include "Ransac.h"

RndPointGen::RndPointGen(int maxindex, int maxcount) {
	this->maxindex = maxindex;
	this->maxcount = maxcount;
	
	count = 0;
            
        }
        
bool RndPointGen::hasNext() {
	return (count < maxcount);
}
        
vector<int> RndPointGen::next() {
	count++;
	
	
	vector<int> indices;
	indices.resize(4);

	do {
                indices[0] = rndgen.uniformInt(maxindex);
                indices[1] = rndgen.uniformInt(maxindex);
                indices[2] = rndgen.uniformInt(maxindex);
                indices[3] = rndgen.uniformInt(maxindex);
                
	} while (indices[0] == indices[1]
		 || indices[0] == indices[2]
		 || indices[0] == indices[3]
		 || indices[1] == indices[2]
		 || indices[1] == indices[3]
		 || indices[2] == indices[3]);
	
	return indices;

}


Ransac::Ransac(vector<Corres2pts> * corrlist, int numiter) {
	this->corrlist = corrlist;
	this->numiter = numiter;

	bestH = NULL;

	findBestH();
}

Ransac::~Ransac() {
	if (bestH != NULL) {
		cvReleaseMat(&bestH);
		bestH = NULL;
	}

}

void Ransac::findBestH() {

	//cout << "Ransac: Finding best H" << endl;
	RndPointGen rgen(corrlist->size(), numiter);


	if (bestH != NULL) {
		cvReleaseMat(&bestH);
		bestH = NULL;
	}

	bestH = findH(rgen.next());


	calcHError(bestH, bestMedianError, best3QuartileError);

	while (rgen.hasNext()) {
		CvMat * H = findH(rgen.next());
		double medError, q3Error;
		calcHError(H, medError, q3Error);
	
		if (medError < bestMedianError) {
			cvReleaseMat(&bestH);
			bestH = H;
			bestMedianError = medError;
			best3QuartileError = q3Error;
		}
	}
}

CvMat * Ransac::findH(vector<int> indices) {
	/*
	cout << "Ransac: Finding H for " << indices[0] << " "
	     << indices[1] << " " << indices[2] << " " 
	     << indices[3] << endl;
	*/

	CvPoint2D64d a = (*corrlist)[indices[0]].c.toCvPoint2D64d();
	CvPoint2D64d b = (*corrlist)[indices[1]].c.toCvPoint2D64d();
	CvPoint2D64d c = (*corrlist)[indices[2]].c.toCvPoint2D64d();
	CvPoint2D64d d = (*corrlist)[indices[3]].c.toCvPoint2D64d();

	CvPoint2D64d e = (*corrlist)[indices[0]].p;
	CvPoint2D64d f = (*corrlist)[indices[1]].p;
	CvPoint2D64d g = (*corrlist)[indices[2]].p;
	CvPoint2D64d h = (*corrlist)[indices[3]].p;

	return ProjectiveTransform64d(a, b, c, d,
				      e, f, g, h);
}

void Ransac::calcHError(CvMat * H, double & medianError, double & thirdQuartileError) {
	vector<double> distances;

        for (vector<Corres2pts>::iterator iter = corrlist->begin(); iter != corrlist->end(); iter++) {
		CvPoint2D64d p = ApplyM64d(H, iter->c.trueToCvPoint2D64d());
		double xerr = p.x - iter->p.x;
		double yerr = p.y - iter->p.y;

		double distance = sqrt(xerr * xerr + yerr * yerr);

		distances.push_back(distance);
	}

	// take median
        nth_element(distances.begin(), distances.begin() + distances.size() / 2,
		    distances.end());	

        medianError = distances[distances.size() / 2];

	nth_element(distances.begin(), distances.begin() + distances.size() * 3 / 4,
		    distances.end());
	
	thirdQuartileError = distances[distances.size() * 3 / 4];
}


vector<Corres2pts> Ransac::getInliers() {
	vector<Corres2pts> newcorrlist;

	
	
	for (vector<Corres2pts>::iterator iter = corrlist->begin(); iter != corrlist->end(); iter++) {
		CvPoint2D64d p = ApplyM64d(bestH, iter->c.trueToCvPoint2D64d());
		double xerr = p.x - iter->p.x;
		double yerr = p.y - iter->p.y;

		double distance = sqrt(xerr * xerr + yerr * yerr);

		if (distance < best3QuartileError)
			newcorrlist.push_back(*iter);
	}

	return newcorrlist;

}
