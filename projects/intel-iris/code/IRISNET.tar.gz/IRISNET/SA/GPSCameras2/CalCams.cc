/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


#include <cv.h>
//#include "highgui.h"
//#include "SA.h"
//#include <sys/shm.h>
//#include <math.h>
//#include <sys/times.h>
//#include <sys/resource.h>
//#include "shmman.h"
//#include "imgproc.h"
//#include "csapp.h"


#include "FakeCam.h"
#include "FakeGPS.h"
#include "SharedFIFO.h"
#include "GPSCommand.h"
#include "LandmarkDetector.h"
#include "PointMgr.h"

class CalCams {
private:
	GPSSource * gpssource;
	FakeGPS * fakegps;

	SharedFIFO * gpsFIFO;

	vector<LandmarkDetector *> lmDetectors;
	vector <FakeCam *> fakecams; 

	PointMgr * pointmgr;
 public:
	CalCams();
	~CalCams();

	void start();
	void stop();
};

CalCams::CalCams() {
	gpsFIFO = new SharedFIFO(1);
	

	CvPoint2D64d a; a.x = 10, a.y = 10;
        CvPoint2D64d b; b.x = 0, b.y = 10;
        CvPoint2D64d c; c.x = 0, c.y = -1;
        CvPoint2D64d d; d.x = 10, d.y = -1;
	
	fakegps =  new FakeGPS(gpsFIFO, c, a.y - d.y, a.x - b.x);
	gpssource = fakegps;

	a.x = 10, a.y = 10;
	b.x = 0, b.y = 10;
        c.x = 0, c.y = 0;
	d.x = 10, d.y = 0;
	
	FakeCam * fc = new FakeCam(a, b, c, d, 1000, 1000);

	
	a.x = 10, a.y = 8;
	b.x = 0, b.y = 8;
	c.x = 0, c.y = -1;
	d.x = 10, d.y = -1;
	FakeCam * fc2 = new FakeCam(a, b, c, d, 1000, 1000);


	lmDetectors.push_back(fc);
	lmDetectors.push_back(fc2);


	
	fakecams.push_back(fc);
	fakecams.push_back(fc2);


	pointmgr = new PointMgr(fakecams);
}

CalCams::~CalCams() {
	delete(gpsFIFO);
	gpsFIFO = NULL;

	delete(gpssource);
	gpssource = NULL;

	for (unsigned int i = 0; i < lmDetectors.size(); i++)
		delete(lmDetectors[i]);

	delete(pointmgr);
	pointmgr = NULL;
}


void CalCams::start() {
	GPSCoord coord;

	fakegps->gpserror = 0.1;
	
	gpssource->startGPS();
	
	int count = 0;

	while (true) {
	//while (count < 25) {
		GPSCommand * cmd = (GPSCommand *) gpsFIFO->remove();
		//printf("GPS FIFO Command: %d\n", cmd->cmd);

		if (cmd->cmd == GPSCommand::DETECT_ON) {
			coord = cmd->coord;
			for (unsigned int i = 0; i < lmDetectors.size(); i++)
				lmDetectors[i]->startCapture(coord);
		}
		else {
			vector <CvPoint2D64d> campts;
			vector <bool> inViews;
  
			for (unsigned int i = 0; i < lmDetectors.size(); i++) {
				bool inView = false;
				CvPoint2D64d pt = lmDetectors[i]->stopCapture(coord, inView);
				CvPoint2D64d campt = ApplyM64d(fakecams[i]->H, coord.trueToCvPoint2D64d());
				printf("Camera ID: %d\n", lmDetectors[i]->id);
				printf("Image point (true): (%f, %f)\n", campt.x, campt.y);
				printf("GPS point (true): (%.8fN, %.8fW)\n", coord.trueLatN, coord.trueLongW);
				printf("Image point (measured): (%f, %f)\n", pt.x, pt.y);
				printf("GPS point (measured): (%.8fN, %.8fW)\n", coord.latN, coord.longW);
				
				if (inView)
					printf("In view\n");
				else
					printf("NOT in view.\n");
				//pointmgr->add(coord, pt);
				printf("\n");

				campts.push_back(pt);
				inViews.push_back(inView);
			}

			pointmgr->add(coord, campts, inViews);
		}			


		delete (cmd);
		cmd = NULL;
		count++;
	}
}


void CalCams::stop() {
	gpssource->stopGPS();
}

int main(int argc, char * argv[])
{

	CalCams * cams = new CalCams();
	cams->start();

	

	cams->stop();

	return 0;
}
