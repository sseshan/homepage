/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef FAKECAM_H
#define FAKECAM_H

#include <stdlib.h>

#include <cv.h>

#include "LandmarkDetector.h"
#include "SharedFIFO.h"
#include "RndGen.h"

class FakeCam : public LandmarkDetector {
private:


	RndGen rndgen;

	// LandmarkDetector
	


	int width, height;
	
public:	

	CvMat * H; // gps->cam
	CvMat * HInv; // cam->gps
	double camerror;

	FakeCam(CvPoint2D64d fromP1, CvPoint2D64d fromP2,
		CvPoint2D64d fromP3, CvPoint2D64d fromP4,
		int w, int h);

	~FakeCam();

	// LandmarkDetector methods
	void startCapture(GPSCoord & coord);
	CvPoint2D64d stopCapture(GPSCoord & coord, bool & inView);

};

#endif
