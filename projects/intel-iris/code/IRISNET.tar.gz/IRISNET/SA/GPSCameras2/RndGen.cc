/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include <stdlib.h>
#include <math.h>

#include <time.h>

#include "RndGen.h"


RndGen::RndGen()
{
	srand(time(NULL));
	haveNextGaussian = false;
}

double RndGen::uniformDouble()
{
	return (double) rand() / RAND_MAX;
}

double RndGen::uniformDouble(double max) {
	return uniformDouble() * max;
}

double RndGen::beta(int alpha, int beta)
{
	double gammaalpha = gamma1(alpha);

	return gammaalpha / (gammaalpha + gamma1(beta));
}

double RndGen::gamma1(int alpha)
{
	double sum = 0;

	for (int i = 0; i < alpha; i++) {
		sum += uniformDouble();
	}

	return log(sum);
}

int RndGen::uniformInt()
{
	return rand();
}

int RndGen::uniformInt(int max)
{
	// not really uniformly random
	return rand() % max;
}

double RndGen::exponential(double alpha)
{
	return -1 / alpha * log(uniformDouble());
}

// mean 0.0, stddev 1.0
double RndGen::gaussian(double m /*= 0*/, double sd /*= 1*/)
{
	if (haveNextGaussian) {
		haveNextGaussian = false;
		return nextGaussian * sd + m;
	} else {
		double v1, v2, s;
		do {
			v1 = 2 * uniformDouble() - 1;	// between -1.0 and 1.0
			v2 = 2 * uniformDouble() - 1;	// between -1.0 and 1.0
			s = v1 * v1 + v2 * v2;
		} while (s >= 1 || s == 0);
		double multiplier = sqrt(-2 * log(s) / s);
		nextGaussian = v2 * multiplier;
		haveNextGaussian = true;
		return v1 * multiplier * sd + m;
	}

}
