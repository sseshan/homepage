/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#include "csapp.h"
#include "imgproc.h"

#include "FakeCam.h"
#include "GPSCommand.h"
#include "RndGen.h"

#define PI 3.14159265358979323846


/*

            ^             +------------------>
            |             |(0, 0)      (w, 0)
                          | 
  P1   P2   L             | 
            a     <--->   |  
  P4   P3   t             |
            N             | 
                          |(0, h)      (w, h)
            |             |
<-- LongW --+             v

*/

FakeCam::FakeCam(CvPoint2D64d fromP1, CvPoint2D64d fromP2,
		 CvPoint2D64d fromP3, CvPoint2D64d fromP4,
		 int wd, int ht) {

	
	static int id = 0;
	id++;
	this->id = id;

	width = wd;
	height = ht;


	CvPoint2D64d e; e.x = 0, e.y = 0;
	CvPoint2D64d f; f.x = width, f.y = 0;
	CvPoint2D64d g; g.x = width, g.y = height;
	CvPoint2D64d h; h.x = 0, h.y = height;

	H = ProjectiveTransform64d(fromP1, fromP2, fromP3, fromP4,
				   e, f, g, h);
	HInv = cvCreateMat(3, 3, CV_64FC1);

	cvInvert(H, HInv);

	printf("Camera ID: %d\n", id);

	printf("Fake GPS H:\n");

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
	}

	printf("\n");
	

	camerror = 0;

}

FakeCam::~FakeCam() {
	cvReleaseMat(&H);
	cvReleaseMat(&HInv);
}


void FakeCam::startCapture(GPSCoord & coord) {
}

CvPoint2D64d FakeCam::stopCapture(GPSCoord & coord, bool & inView) {
	CvPoint2D64d q = ApplyM64d(H, coord.trueToCvPoint2D64d());
	double angle = rndgen.uniformDouble(2*PI);
	double len = fabs(rndgen.gaussian(0, camerror));

	q.y += len * sin(angle);
	q.x += len * cos(angle);


	/*
	q.y += rndgen.gaussian();
	q.x += rndgen.gaussian();
	*/

	if (q.x < 0 || q.y < 0 ||
	    q.x >= width || q.y > height)
		inView = false;
	else
		inView = true;

	return q;
}



