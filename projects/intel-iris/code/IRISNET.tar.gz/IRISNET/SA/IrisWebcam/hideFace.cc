/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include "plugin.h"

// opencv includes
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

// SA common
#include <shmman.h>
#include <imgproc.h>

// Unix system includes
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>


CvHidHaarClassifierCascade* new_face_detector(void)
{
	CvHaarClassifierCascade* cascade = cvLoadHaarClassifierCascade("<default_face_cascade>", cvSize(24,24));
	/* images are assigned inside cvHaarDetectObject, so pass NULL pointers here */
	CvHidHaarClassifierCascade* hid_cascade = cvCreateHidHaarClassifierCascade( cascade, 0, 0, 0, 1 );
	/* the original cascade is not needed anymore */
	cvReleaseHaarClassifierCascade( &cascade );
	return hid_cascade;
}


void BlurFaces(IplImage * image, CvSeq * faces)
{
    	/* draw all the rectangles */
    	for(int i = 0; i < faces->total; i++ )
    	{
        	/* extract the rectanlges only */
        	CvRect rect = *(CvRect*)cvGetSeqElem( faces, i, 0 );
		CvPoint start = cvPoint(rect.x, rect.y);
		CvPoint end = cvPoint(rect.x+rect.width, rect.y+rect.height);

        	cvRectangle(image, start, end, CV_RGB(255,0,0), 20 );
		cvRectangle(image, start, end, CV_RGB(0, 0, 0), -1);
    	}

}

CvSeq * DetectFaces(IplImage * image, CvMemStorage * storage)
{
	CvHidHaarClassifierCascade* cascade = new_face_detector();

    	CvSeq* faces;

    	/* use the fastest variant */
    	faces = cvHaarDetectObjects( image, cascade, storage, 1.2, 2, CV_HAAR_DO_CANNY_PRUNING );
	
	cvReleaseHidHaarClassifierCascade( &cascade );

	// printf("%d faces detected.\n", faces->total);
	return faces;

}

void HideFaces(IplImage * image)
{
	CvMemStorage * storage = cvCreateMemStorage();
	CvSeq * faces = NULL;

	IplImage * gray = MyColorToGray(image);
	
	faces = DetectFaces(gray, storage);

	BlurFaces(image, faces);
	
	//cvNamedWindow("result", 1);
	//cvShowImage( "result", gray );
	//cvResizeWindow("result", gray->width + 1, gray->height+1);

	cvReleaseImage(&gray);
	cvReleaseMemStorage(&storage);

}

extern "C" {

int ProcessFrame(IplImage * image) {

	HideFaces(image);

	return 0;
}

}
