#!/bin/sh
export LD_LIBRARY_PATH=../../packages/opencv/cv/src/.libs/:../../packages/opencv/cvaux/src/.libs/:../../packages/opencv/otherlibs/highgui/.libs/:../../packages/ffmpeg/libavcodec/
./webcam 1 640 480 200000 1

