/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include "plugin.h"

// opencv includes
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

// SA common
#include <shmman.h>
#include <imgproc.h>

// Unix system includes
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>


void Blur(IplImage * image) {
	IplImage *smallImage = NULL;
	IplImage *tinyImage = NULL;

	// down-scale and upscale the image to filter out the noise
	smallImage = cvCreateImage( cvSize(image->width/2, image->height/2),
				    image->depth, image->nChannels );
	tinyImage = cvCreateImage( cvSize(smallImage->width/2, smallImage->height/2),
				    smallImage->depth, smallImage->nChannels );


	cvPyrDown( image, smallImage, IPL_GAUSSIAN_5x5 );
	cvPyrDown( smallImage, tinyImage, IPL_GAUSSIAN_5x5);
	cvPyrUp(tinyImage, smallImage, IPL_GAUSSIAN_5x5);
	cvPyrUp( smallImage, image, IPL_GAUSSIAN_5x5 );

	cvReleaseImage(&smallImage);
	cvReleaseImage(&tinyImage);
}

void Grayscale(IplImage * image) {
	CvSize size = cvSize(image->width, image->height);

	IplImage * gray = cvCreateImage(size, image->depth, 1);

	cvCvtColor(image, gray, CV_RGB2GRAY);

	IplImage * newImage = cvCreateImage(size, image->depth, 3);

	cvCvtPlaneToPix(gray, gray, gray, 0, newImage);

	memcpy(image->imageDataOrigin, newImage->imageDataOrigin, image->imageSize);

	cvReleaseImage(&gray);
	cvReleaseImage(&newImage);

}


extern "C" {



int ProcessFrame(IplImage * image) {

	//Blur(image);
	Grayscale(image);

	return 0;
}

}
