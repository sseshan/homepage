/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:5; tab-width:5; indent-tabs-mode:t -*- */

/* Displays the image loaded into the shared memory using 'loadImage' tool */

#include "unp.h"
#include "cv.h"
#include "highgui.h"
#include "SA.h"
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>
#include "shmman.h"
#include "imgproc.h"

int Start(int shm_key)
{
	IplImage *image0 = 0;
	IplImage *background = NULL;
	IplImage *subback = NULL;
	IplImage *subback2 = NULL;
	IplImage *threshold = NULL;
	IplImage *highlight = NULL;
	IplImage *final = NULL;

	int step;
	CvSize size;
	shmHeaderType *shmHeader;
	void * shm;
	
	shm = OpenSharedMemoryKey(shm_key);

	if (shm == NULL) {
		printf( "Error in opening shared segment");
		return 0;
	}

	shmHeader = (shmHeaderType*)shm;
	
	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;
	
	cvvNamedWindow("Current_Image", 1);

	cvvNamedWindow("Background_Image", 1);
	cvvNamedWindow("SubtractedBackground", 1);
	//	cvvNamedWindow("Threshold_Image", 1);
	cvvNamedWindow("Final", 1);


	for (;;) {
		image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
		cvSetImageData(image0, (uchar*) ((uchar *)shm + shmHeader->offsets[shmHeader->buffHead]), step * shmHeader->width);


		IplImage * orig = cvCloneImage(image0);

		if (background == NULL) {
			background = cvCloneImage(orig);
			subback = cvCloneImage(orig);
			subback2 = cvCloneImage(orig);
			threshold = cvCloneImage(orig);
			final = cvCloneImage(orig);
			highlight = MyColorToGray(orig);

		} else {
			cvSub(orig, background, subback);
			cvSub(background, orig, subback2);
			cvAdd(subback, subback2, subback);


			cvThreshold(subback, threshold, 30, 255, CV_THRESH_BINARY);
			cvErode(threshold, threshold, 0, 1);
			cvDilate(threshold, threshold, 0, 8);
			cvErode(threshold, threshold, 0, 1);

			cvCvtColor(threshold, highlight, CV_RGB2GRAY);
			cvThreshold(highlight, highlight, 5, 1, CV_THRESH_BINARY);

			//cvvShowImage("Threshold_Image", highlight);
			//cvResizeWindow("Threshold_Image", threshold->width + 1, threshold->height+1);

			cvCvtColor(highlight, threshold, CV_GRAY2RGB);

			cvMul(threshold, orig, final, 1);
			cvAddWeighted(orig, 0.4, final, 0.6, 0, final);

			MyRunningAvg(orig, background, 0.1);
			cvvShowImage("Background_Image", background);
			cvResizeWindow("Background_Image", background->width + 1, background->height+1);

			cvvShowImage("Final", final);
			cvResizeWindow("Final", background->width + 1, background->height+1);

			
			cvvShowImage("Current_Image", orig);
			cvResizeWindow("Current_Image", image0->width + 1, image0->height+1);

			cvvShowImage("SubtractedBackground", subback);
			cvResizeWindow("SubtractedBackground", subback->width + 1, subback->height+1);


		}

		cvReleaseImage(&orig);
		cvReleaseImageHeader(&image0);
		usleep(150000);
	}
	
	return 0;
}



int main(int argc, char * argv[])
{
	int shm_key = 74, key;
  
	if (argc > 1) {
		if (sscanf(argv[1], "%d", &key) == 1){
			shm_key = key;
		}
	}
	
	printf("Reading from the shared memory with SHM_KEY=%d. To use different SHM_KEY, use 'showImage <SHM_ID>'.\n", shm_key);
	
	Start(shm_key);
	
	return 0;
}

