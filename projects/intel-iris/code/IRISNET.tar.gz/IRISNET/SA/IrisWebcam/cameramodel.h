/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef CAMERA_MODEL_H
#define CAMERA_MODEL_H

#include <cv.h>
#include <time.h>

class CameraModel {
 private:
	const static int maxframes = 10;
	const static int minframes = 5;
	const static int traindelay = 5; // seconds
	const static int newtraindelay = 60; // seconds

	int nCols;
	int nRows;
	int nCorners;
	int numFrames;

	CvPoint2D32f * uv;
	CvPoint3D32f * objCoords;
	int * nCornersArray;

	CvVect32f distortion;
	CvMatr32f cameraMatrix;
	CvVect32f transVects;
	CvMatr32f rotMatrixes;

	CvSize frameSize;

	time_t lasttime;

	void drawCorners(IplImage * srcImage, CvPoint2D32f * corners);
	int findCorners(IplImage * srcImage, CvPoint2D32f * corners);
	void calcDistortion();

 public:
	CameraModel(int nCols, int nRows);
	~CameraModel();

	// returns true if srcImage is a training image (checkerboard found)
	bool train(IplImage * srcImage);
	void undistort(IplImage * srcImage, IplImage * dstImage);
};

#endif
