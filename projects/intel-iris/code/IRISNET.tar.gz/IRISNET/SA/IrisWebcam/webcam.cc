
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

// camstream includes
#include <VideoDevice.h>
#include <VideoCollector.h>

// opencv includes
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

// SA common
#include <shmman.h>
#include <imgproc.h>
#include "plugin.h"

// debug print library
#include <dbgprintlib.h>

// Unix system includes
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>
#include <dlfcn.h>
#include <sys/stat.h>

#include <list>


#include "cameramodel.h"

using namespace std;

// need to fold this into make file
#undef NDEBUG
#include <assert.h>

// video rame information
typedef struct {
	int width;
        int height;
	int bytesPerPixel;
} frameInfoType;


// Returns the first video device on the system
// If no devices are found, then return NULL
CVideoDevice * GetVideoDevice()
{
        CVideoDevice * video = NULL;
	CVideoCollector * videoDevices;
	QString dName;

 	// find a video device
	videoDevices = CVideoCollector::Instance();
	for (int i = 0; i < videoDevices->NumberOfVideoDevices(); i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		if (dName.isNull()) {
			dName = video->GetNodeName();
			dprintf(0, "Camera found: %s",
				(const char *) dName);
			break;
		}
	}

	return video;
}

// loads webcam video frame into shared memory
// loops forever
// returns 0 on error
int LoadFrame(int sleepSeconds, int displayFlag)
{
	CameraModel cammodel = CameraModel(8, 6);
	CVideoDevice *video = NULL;
	QString dName;
	int currFrame = 0;
	uchar *rawImgData = NULL;
	void *rawmem = NULL;

	shmHeaderType *rawshmHeader = NULL;

	// open shared memory
	rawmem = OpenSharedMemoryKey(IMAGE_RAW_SHM_KEY);

	if (rawmem == NULL) {
	        printf("LoadFrame(): Error opening shared memory.\n");
		return 0;
	}

	printf("Shared memory mapped to %x\n",
	       (unsigned int) rawmem);

	rawImgData = (uchar *) rawmem;

	rawshmHeader = (shmHeaderType *) rawImgData;

	printf("Width: %d  Height: %d  Channels: %d\n", rawshmHeader->width, rawshmHeader->height, rawshmHeader->bytesPerPixel);

	CvSize imgSize;
	imgSize.width = rawshmHeader->width;
	imgSize.height = rawshmHeader->height;


	// Get video device
	video = GetVideoDevice();

	if (video == NULL) {
	        printf("LoadFrame(): No video devices found.\n");
		return 0;
	}

	dName = video->GetNodeName();

	// open video device
	if (video->Open(1) < 0) {
		dperror(0, "LoadFrame(): Error in opening video device %s",
			(const char *) dName);
		return 0;
	}

	// set frame size
	video->SetSize(rawshmHeader->width, rawshmHeader->height);
	video->EnableRGB(1);

	printf("LoadFrame(): Frame rate was: %d\n", video->GetFramerate());
	video->SetFramerate(10);
	printf("LoadFrame(): Frame rate set to: %d\n", video->GetFramerate());

	long lasttime = GetTime();
	int count = 0;
	int interval = 10;

	// dump frames in shared memory
	for (;;) {
		// our camera gives us 4 bytes per pixel, which we need to convert to 3
		// get raw data from camera feed to IplImage format.

		IplImage * rawImage = cvCreateImageHeader(imgSize, IPL_DEPTH_8U,
			4);

	
		if (video->ReadImage() != 0) {
			printf("LoadImage(): Error reading image from video buffer.\n");
			return 0;
		}

		cvSetImageData(rawImage, video->GetRGB()->bits(),
			       4 * rawshmHeader->width);
		
		IplImage * threeChanImage = Cvt4to3(rawImage);

		cvReleaseImageHeader(&rawImage);

		rawImage = threeChanImage;

		if (displayFlag)
			DisplayIplImage(rawImage, "Raw Image");
		
		IplImage * correctedImage = cvCloneImage(rawImage);
		
		cammodel.train(rawImage);
		cammodel.undistort(rawImage, correctedImage);
			
		if (displayFlag)
			DisplayIplImage(correctedImage, "Corrected Image");

		cvReleaseImage(&rawImage);
		rawImage = correctedImage;

		int size = rawshmHeader->width * rawshmHeader->height
			* rawshmHeader->bytesPerPixel;

		memcpy(rawImgData + rawshmHeader->offsets[currFrame],
		       rawImage->imageDataOrigin, size);

		rawshmHeader->buffHead = (int) currFrame;

		rawshmHeader->lastUpdateTime = GetTime();
		rawshmHeader->timestamps[currFrame] = GetTime();
		


		cvReleaseImage(&rawImage);

		currFrame = (currFrame + 1) % rawshmHeader->numFrames;
		// printf("Hi %x\n", * ((unsigned int *) (safeImgData + safeshmHeader->offsets[currFrame])));
		count++;

		if (count % interval == 0) {
			float msperframe = (float) (GetTime() - lasttime) / interval;
			printf("Perf: %f ms per frame.\n", msperframe);
			lasttime = GetTime();
		}

		if (sleepSeconds < 100)
			sleep(sleepSeconds);
		else
			usleep(sleepSeconds);
	}


	return 1;
}


// Logs the process id to /tmp/IRISWEBCAM.pid.*
void LogPid()
{
	pid_t pid;
	char buf[80];
	FILE *outf;


	pid = getpid();
	sprintf(buf, "/tmp/IRISWEBCAM.pid.%d", pid);

	outf = fopen(buf, "w");

	if (outf == NULL) {
	      printf("LogPid(): File open error on %s\n", buf);
	      return;
	}

	sprintf(buf, "%d\n", pid);
	fwrite(buf, 1, strlen(buf), outf);
	fflush(outf);
	fclose(outf);
}


int main(int argc, char *argv[])
{
	frameInfoType fInfo;
	int numFrames, displayFlag, secondsPerFrame;

	if (argc != 6) {
		printf
		    ("Usage: webcam <#frames in buffer> <width> <height> <SecondsPerFrame> <displayFlag>\n");
		return 1;
	}

	if ((sscanf(argv[1], "%d", &numFrames) != 1) ||
	    (sscanf(argv[2], "%d", &fInfo.width) != 1) ||
	    (sscanf(argv[3], "%d", &fInfo.height) != 1) ||
	    (sscanf(argv[4], "%d", &secondsPerFrame) != 1) ||
	    (sscanf(argv[5], "%d", &displayFlag) != 1)) {
		printf("Error in argv format\n");
		return 1;
	};

	fInfo.bytesPerPixel = 3;

	// creating raw shared memory
	if (CreateSharedMemory(numFrames, fInfo.width, fInfo.height,
			       fInfo.bytesPerPixel,
			       IMAGE_RAW_SHM_KEY, S_IRWXU | S_IRWXG) == 0) {
	        printf("Failed to create raw shared memory.\n");
		return 1;
	}

	printf("Configuration : \n");
	printf("\tVideo framesize: (Width: %d x Height: %d)\n", fInfo.width, fInfo.height);
	printf("\tRefresh rate: 1 frame per %d seconds\n", secondsPerFrame);
	printf("\tNumber of frames in shared memory: %d\n", numFrames);
	printf("\tShared memory keyID: %d\n", IMAGE_RAW_SHM_KEY);
	
	LogPid();
	LoadFrame(secondsPerFrame, displayFlag);

	return 0;
}
