/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

///////////////////////////////////////////////////////////////////
#include "math.h"
#include "stdlib.h"
#include "cv.h"
#include "highgui.h"
#include "stdio.h"
#include "string.h"

int numcols = 5;
int numrows = 7;
int maxnumcorners = numcols * numrows; // max number of inner points to look for

int numimages = 4;		// number of images to process
// initialize the names of the calibration images
//char *names[] = { "s1.png", "s2.png", "s3.png", "s4.png" };
char *names[] = { "s1.jpg", "s2.jpg", "s3.jpg", "s4.jpg" };
//char *names[] = { "a0.jpg", "a1.jpg", "a2.jpg", "a3.jpg" };
//char *names[] = { "b1.jpg", "b2.jpg", "b4.jpg" };
//char *names[] = { "c1.jpg", "c2.jpg", "c4.jpg" };


// returns number of corners found
// corners written to corners *
int FindCorners(IplImage * srcImg, CvPoint2D32f * corners) 
{
	int numcorners;

        CvSize imgsize = cvSize(srcImg->width, srcImg->height);
        IplImage * grayImg = cvCreateImage(imgsize, IPL_DEPTH_8U, 1);
	cvCvtColor(srcImg, grayImg, CV_RGB2GRAY);	// convery color image to grey
	
	IplImage * threshImg = cvCloneImage(grayImg);
	
	// Find Corners - rough guess
	int ret = cvFindChessBoardCornerGuesses(grayImg, threshImg, NULL,
						cvSize (numrows, numcols), corners,
						&numcorners);
	if (ret == 0) {
		printf("Corners not in correct order.\n");
	} else {
		printf("Corners in correct order.\n");
	}

	// Find sub-corners - pinpoint
	cvFindCornerSubPix(grayImg, corners, numcorners,
			   cvSize(5, 5), cvSize (-1, -1),
			   cvTermCriteria(CV_TERMCRIT_ITER | CV_TERMCRIT_EPS,
					  10, 0.1));
	
	// print corner coordinates
		/*
		for (int t = 0; t < numcorners; t++) { 
			printf("Point: %i = ", t);
			printf("x: %f ", corners[t].x);
			printf("y: %f\n", corners[t].y);
		}*/


		

	cvReleaseImage(&threshImg);
	cvReleaseImage(&grayImg);

	
	return numcorners;
	
}

void DrawCorners(IplImage * srcImg, int numcorners, CvPoint2D32f * corners) {
	//for visual number effect to see the corners that were found
	char *numbers[] = {
		"1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
		"11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
		"21", "22", "23", "24",	"25", "26", "27", "28", "29", "30",
		"31", "32", "33", "34", "35", "36", "37", "38", "39", "40",
		"41", "42", "43", "44", "45", "46", "47", "48",	"49", "50",
		"51", "52", "53", "54", "55", "56", "57", "58", "59", "60",
		"61", "62", "63", "64", "65", "66", "67", "68", "69", "70",
		"71", "72", "73", "74", "75", "76", "77", "78", "79", "80",
		"81", "82", "83", "84", "85", "86", "87", "88", "89", "90",
		"91", "92", "93", "94", "95", "96", "97", "98", "99", "100",
		"101", "102", "103", "104", "105", "106", "107", "108", "109", "110",
		"111", "112", "113", "114", "115", "116", "117", "118", "119", "120",
		"121", "122", "123", "124", "125", "126", "127", "128", "129", "130",
		"131", "132", "133", "134", "135", "136", "137", "138", "139", "140",
		"141", "142", "143", "144", "145", "146", "147", "148",	"149", "150",
		"151", "152", "153", "154", "155", "156", "157", "158", "159", "160",

	};
	
	cvNamedWindow("image", 1);	//create window with the name "image"

	// initalize font for drawing numbers on images
	CvFont dfont;
	float hscale = 0.3;
	float vscale = 0.3;
	float italicscale = 0.0f;
	int thickness = 1;
	cvInitFont(&dfont, CV_FONT_VECTOR0, hscale, vscale,
		   italicscale, thickness);



	IplImage * displayImg = cvCloneImage(srcImg);	// make another copy of the image

	// draw a circle at each corner found
	for (int t = 0; t < numcorners; t++) {
		CvPoint onecorner;
		onecorner.x = (int) corners[t].x;
		onecorner.y = (int) corners[t].y;
		cvCircle(displayImg, onecorner, 6, CV_RGB(0, 255, 0), 2);
	}
	
	
	//draw a circle and put the corner number at each subcorner found
	for (int t = 0; t < numcorners; t++) {
		CvPoint onecorner;
		onecorner.x = (int) corners[t].x;
		onecorner.y = (int) corners[t].y;
		cvCircle(displayImg, onecorner, 3, CV_RGB(255, 0, 0), 1);
		
		  cvPutText(displayImg, numbers[t],
		  cvPoint(onecorner.x +2, onecorner.y + 2),
		  &dfont, CV_RGB(255, 0, 0));
		
	}
	
	cvShowImage("image", displayImg);
	cvWaitKey(0);	// wait for key press before displaying next image

	cvReleaseImage(&displayImg);
		
}
 
void SortRow(CvPoint2D32f * corners, int nc) {
	for (int i = 0; i < nc; i++) {
		for (int j = i+1; j < nc; j++) {
			if (corners[j].x < corners[i].x) {
				CvPoint2D32f tmp = corners[i];
				corners[i] = corners[j];
				corners[j] = tmp;
				//printf("Swapping %d %d\n", i, j);
			}
		}
	}

}


void SortCorners(CvPoint2D32f * corners, int nr, int nc) {
	for (int j = 0; j < nr; j++) {
		SortRow(corners + nc*j, nc);
	}
}

void CalcDistortion(CvSize imgsize, CvPoint2D32f * uv, CvVect32f distortion, CvMatr32f cameraMatrix) {
	int * pointnumbers = new int[numimages];

	for (int i = 0; i < numimages; i++) {
		pointnumbers[i] = maxnumcorners;
	}

	CvPoint3D32f *XYZ = new CvPoint3D32f[maxnumcorners * numimages];

	for (int currImage = 0; currImage < numimages; currImage++) {
		for (int i = 0; i < numcols; i++) {
			for (int j = 0; j < numrows; j++) {
				XYZ[currImage * maxnumcorners +
				    i * numrows + j].x = numcols - i;
				
				XYZ[currImage * maxnumcorners +
				    i * numrows + j].y = numrows - j;
				
				XYZ[currImage * maxnumcorners +
				    i * numrows + j].z = 0;
				}
		}
	}


	/* matrix must exist */
	CvVect32f transVects = new float[3 * 4];

	/* 3 - size of transpose vector (1*3), and 5 - number of vectors */
	CvMatr32f rotMatrixes = new float[3 * 3 * 4];

	/* 3x3 - size of rotation matrix and 5 - number of rotate matrixes */
	int useIntrinsicGuess = 0;

	printf("about to calibrate.\n");

	// calibrate camera
	cvCalibrateCamera(numimages, pointnumbers, imgsize, uv,
			  XYZ, distortion, cameraMatrix,
			  transVects, rotMatrixes, useIntrinsicGuess);

	CvVect32f focal = new float[2];
	focal[0] = cameraMatrix[0];
	focal[1] = cameraMatrix[4];
	CvPoint2D32f principal;
	principal.x = cameraMatrix[2];
	principal.y = cameraMatrix[5];
	//lets see the results!!!
	printf("matrix\n%f %f %f\n%f %f %f\n%f %f %f\ndistortion\n%f %f %f %f\n",
	       cameraMatrix[0], cameraMatrix[1], cameraMatrix[2],
	       cameraMatrix[3], cameraMatrix[4], cameraMatrix[5],
	       cameraMatrix[6], cameraMatrix[7], cameraMatrix[8],
	       distortion[0], distortion[1], distortion[2], distortion[3]);
	

	cvFindExtrinsicCameraParams(maxnumcorners, imgsize, uv, XYZ, focal, principal,
				    distortion, rotMatrixes, transVects);




	delete focal;
	delete rotMatrixes;
	delete transVects;
	delete XYZ;
	delete pointnumbers;
}


void UndistortImage(IplImage *srcImg, CvVect32f distortion, CvMatr32f cameraMatrix) {
	IplImage * displayImg = cvCreateImage(cvSize(srcImg->width, srcImg->height),
					      srcImg->depth, srcImg->nChannels);
	
	cvUnDistortOnce(srcImg, displayImg,
			cameraMatrix, distortion, 1);
	
	cvShowImage("orig", srcImg);
	cvShowImage("undistort", displayImg);
	cvWaitKey(0);	// wait for key press before displaying next image

		
	cvReleaseImage(&displayImg);
}

///////////////////////////////////////

int main()
{
	printf("Finding corners (max %d)...\n", maxnumcorners);

	CvSize imgsize;
	CvPoint2D32f *uv = new CvPoint2D32f[maxnumcorners * numimages];

	
	// loop through the images
	for (int i = 0; i < numimages; i++) {
		//reset numcorners to the max number of inner points to look for
		//you must do this since cvFindChessBoardCornerGuesses set numcorners
		//to the actual number found during each pass 

		printf("Loading %s\n", names[i]);

		int numcorners = maxnumcorners;  // number of inner points found
		IplImage * srcImg = cvLoadImage(names[i]);	// load next image
		if (srcImg == NULL) {
			printf("Null image loaded.\n");
			return 1;
		}

		imgsize = cvSize(srcImg->width, srcImg->height);

		CvPoint2D32f * corners = new CvPoint2D32f[maxnumcorners];

		numcorners = FindCorners(srcImg, corners);
		printf("Corners found in image %d: %d\n", i, numcorners);
		//SortCorners(corners, numrows, numcols);
		//printf("Done sorting corners.\n");
		DrawCorners(srcImg, numcorners, corners);

		
		for (int currPoint = 0; currPoint < maxnumcorners; currPoint++) {
			// Copy image points data 
			uv[i * maxnumcorners + currPoint].x =
				corners[currPoint].x;
			
			uv[i * maxnumcorners + currPoint].y =
				corners[currPoint].y;
		}

		// release images
		cvReleaseImage(&srcImg);

		delete corners;
	}

	printf("Calculating distortion\n");

	// allocate memory for camera calibration
	CvVect32f distortion = new float[4];
	/* array for distortion must exist */
	CvMatr32f cameraMatrix = new float[3 * 3];

	CalcDistortion(imgsize, uv, distortion, cameraMatrix);

	
	cvNamedWindow("orig", 1);	//create window with the name "image"
	cvNamedWindow("undistort", 1);

	for (int i = 0; i < numimages; i++) {
		IplImage * srcImg = cvLoadImage(names[i]);	// load next image
		UndistortImage(srcImg, distortion, cameraMatrix);
		cvReleaseImage(&srcImg);
	}

	delete cameraMatrix;
	delete distortion;

	delete uv;

	return 0;
}
