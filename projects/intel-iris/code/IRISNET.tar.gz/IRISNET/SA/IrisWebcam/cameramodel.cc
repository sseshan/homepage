/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


#include "cameramodel.h"

#include <highgui.h>
#include <stdio.h>
#include <math.h>

#include "imgproc.h"

#undef NDEBUG
#include <assert.h>

CameraModel::CameraModel(int nCols, int nRows) {
	assert(nCols > 0);
	assert(nRows > 0);

	this->nCols = nCols;
	this->nRows = nRows;
	nCorners = nCols * nRows;
	uv = new CvPoint2D32f[nCorners * maxframes];

	objCoords = new CvPoint3D32f[nCorners * maxframes];
	for (int currImage = 0; currImage < maxframes; currImage++) {
		for (int i = 0; i < nCols; i++) {
			for (int j = 0; j < nRows; j++) {
				objCoords[currImage * nCorners +
					  i * nRows + j].x = nCols - i;
				
				objCoords[currImage * nCorners +
					  i * nRows + j].y = nRows - j;
				
				objCoords[currImage * nCorners +
					  i * nRows + j].z = 0;
			}
		}
	}

	nCornersArray = new int[maxframes];

	for (int i = 0; i < maxframes; i++) {
		nCornersArray[i] = nCorners;
	}

	distortion = new float[4];
	cameraMatrix = new float[3 * 3];
	transVects = new float[3 * maxframes];
	rotMatrixes = new float[3 * 3 * maxframes];

	numFrames = 0;

	time(&lasttime);
}

CameraModel::~CameraModel() {
	delete uv;
	delete objCoords;
	delete distortion;
	delete cameraMatrix;
	delete nCornersArray;
	delete transVects;
	delete rotMatrixes;
}

int CameraModel::findCorners(IplImage * srcImage, CvPoint2D32f * corners) {
	// numcorners MUST be set to maximum number of corners
	int numcorners = nCorners;

        frameSize = cvSize(srcImage->width, srcImage->height);
        IplImage * grayImage = cvCreateImage(frameSize, IPL_DEPTH_8U, 1);
	cvCvtColor(srcImage, grayImage, CV_RGB2GRAY);	// convery color image to grey
	
	IplImage * threshImage = cvCloneImage(grayImage);
	
	// Find Corners - rough guess
	int ret = cvFindChessBoardCornerGuesses(grayImage, threshImage, NULL,
						cvSize (nRows, nCols), corners,
						&numcorners);

	//printf ("%d corners found\n", numcorners);

	if (ret == 0 || numcorners != nCorners) { 
		cvReleaseImage(&threshImage);
		cvReleaseImage(&grayImage); 
		return 0;
	}

	// Find sub-corners - pinpoint
	cvFindCornerSubPix(grayImage, corners, numcorners,
			   cvSize(5, 5), cvSize (-1, -1),
			   cvTermCriteria(CV_TERMCRIT_ITER | CV_TERMCRIT_EPS,
					  10, 0.1));

	cvReleaseImage(&threshImage);
	cvReleaseImage(&grayImage);
	

	return numcorners;

}

void CameraModel::drawCorners(IplImage * srcImage, CvPoint2D32f * corners) {
	//for visual number effect to see the corners that were found
	char *numbers[] = {
		"1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
		"11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
		"21", "22", "23", "24",	"25", "26", "27", "28", "29", "30",
		"31", "32", "33", "34", "35", "36", "37", "38", "39", "40",
		"41", "42", "43", "44", "45", "46", "47", "48",	"49", "50",
		"51", "52", "53", "54", "55", "56", "57", "58", "59", "60",
		"61", "62", "63", "64", "65", "66", "67", "68", "69", "70",
		"71", "72", "73", "74", "75", "76", "77", "78", "79", "80",
		"81", "82", "83", "84", "85", "86", "87", "88", "89", "90",
		"91", "92", "93", "94", "95", "96", "97", "98", "99", "100",
		"101", "102", "103", "104", "105", "106", "107", "108", "109", "110",
		"111", "112", "113", "114", "115", "116", "117", "118", "119", "120",
		"121", "122", "123", "124", "125", "126", "127", "128", "129", "130",
		"131", "132", "133", "134", "135", "136", "137", "138", "139", "140",
		"141", "142", "143", "144", "145", "146", "147", "148",	"149", "150",
		"151", "152", "153", "154", "155", "156", "157", "158", "159", "160",

	};
	
	int numcorners = nCorners;

	if (numcorners > 160)
		numcorners = 160;

	// initalize font for drawing numbers on images
	CvFont dfont;
	float hscale = 0.5;
	float vscale = 0.5;
	float italicscale = 0.0f;
	int thickness = 1;
	cvInitFont(&dfont, CV_FONT_VECTOR0, hscale, vscale,
		   italicscale, thickness);

	IplImage * displayImage = cvCloneImage(srcImage);	// make another copy of the image

	// draw a circle at each corner found
	for (int t = 0; t < numcorners; t++) {
		CvPoint onecorner;
		onecorner.x = (int) corners[t].x;
		onecorner.y = (int) corners[t].y;
		cvCircle(displayImage, onecorner, 6, CV_RGB(0, 255, 0), 2);
	}
	
	
	//draw a circle and put the corner number at each subcorner found
	for (int t = 0; t < numcorners; t++) {
		CvPoint onecorner;
		onecorner.x = (int) corners[t].x;
		onecorner.y = (int) corners[t].y;
		cvCircle(displayImage, onecorner, 3, CV_RGB(255, 0, 0), 1);
		
		  cvPutText(displayImage, numbers[t],
		  cvPoint(onecorner.x + 5, onecorner.y),
		  &dfont, CV_RGB(255, 0, 0));
		
	}
	
	DisplayIplImage(displayImage, "Training Image");

	cvReleaseImage(&displayImage);
		
}

void CameraModel::calcDistortion() {
	// does not work well if all images are in the same plane
	// make sure board is on different planes

	int useIntrinsicGuess = 0;

	// calibrate camera
	cvCalibrateCamera(numFrames, nCornersArray, frameSize, uv,
			  objCoords, distortion, cameraMatrix,
			  transVects, rotMatrixes, useIntrinsicGuess);
	

	printf("matrix\n%f %f %f\n%f %f %f\n%f %f %f\ndistortion\n%f %f %f %f\n",
	       cameraMatrix[0], cameraMatrix[1], cameraMatrix[2],
	       cameraMatrix[3], cameraMatrix[4], cameraMatrix[5],
	       cameraMatrix[6], cameraMatrix[7], cameraMatrix[8],
	       distortion[0], distortion[1], distortion[2], distortion[3]);

	
	for (int i = 0; i < 9; i++) {
		if (fabs(cameraMatrix[i]) > 100000) {
			numFrames = 0;
			return;
		}
	}

	for (int i = 0; i < 4; i++) {
		if (fabs(distortion[i]) > 100) {
			numFrames = 0;
			return;
		}
	}
	
}

bool CameraModel::train(IplImage * srcImage) {
	if (srcImage == NULL)
		return false;
	time_t now;
	time(&now);

	if (now - lasttime < traindelay)
		return false;

	if (numFrames >= maxframes && now - lasttime < newtraindelay)
		return false;

	CvPoint2D32f corners[nCorners];
	
	
	int numcorners = findCorners(srcImage, corners);
	
	if (numcorners != nCorners)
		return false;
	

	//drawCorners(srcImage, corners);

	if (now - lasttime >= newtraindelay) {
		numFrames = 0;
		time(&lasttime);
	}

	printf ("Training frame %d\n", numFrames);

	for (int currPoint = 0; currPoint < nCorners; currPoint++) {
		// Copy image points data 
		uv[numFrames * nCorners + currPoint].x =
			corners[currPoint].x;
		
		uv[numFrames * nCorners + currPoint].y =
			corners[currPoint].y;
	}

	numFrames++;

	
	if (numFrames >= minframes)
		calcDistortion();
	

	time(&lasttime);

	return true;
}

void CameraModel::undistort(IplImage * srcImage, IplImage * dstImage) {
	if (srcImage == NULL)
		return;

	if (dstImage == NULL)
		return;

	if (numFrames < minframes)
		return;

	cvUnDistortOnce(srcImage, dstImage, cameraMatrix, distortion, 1);
}
