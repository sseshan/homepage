/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

// reads an image file and loads it into the shared memory

#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#include <string.h>

#undef NDEBUG
#include <assert.h>

#include "cv.h"
#include "highgui.h"
#include "shmman.h"


void ERROR(char *st)
{
	assert (st != NULL);

	printf("%s\n", st);
	exit(1);
}


// need to update with CreateSharedMemory() API from shmman
int main(int argc, char *argv[])
{
	IplImage *image = NULL;
	IplImage *testImage = NULL;
	int key = 0, shmid = 0;
	int bufsize = 0;
	void *shm = NULL;
	shmHeaderType *shmHeader = 0;

	if (argc != 3) {
		printf("usage: %s <image file> <shm key>\n", argv[0]);
		exit(1);
	}

	image = cvvLoadImage(argv[1]);
	if (image == NULL)
		ERROR("Image file could not be opened");

	printf("Image size: %d, height: %d, width: %d, channels: %d\n",
		image->imageSize, image->height, image->width, image->nChannels);

	if (sscanf(argv[2], "%d", &key) != 1)
		ERROR("Error in parsing shared memory key");

	printf("Shared memory key: %d\n", key);

	bufsize = sizeof(shmHeaderType) + image->imageSize;
	
	if ((shmid = shmget(key, bufsize, 0777)) < 0) {	// shmem was not allocated before
		printf("Allocating shm of size : %d\n", bufsize);
		if ((shmid = shmget(key, bufsize, 0777 | IPC_CREAT)) < 0) 
			ERROR("Error in creating shared memory");
	}

	// need to update with CreateSharedMemory() API from shmman

	// load the image into the shared memory
	shm = (void*)shmat(shmid, 0, 0); 
	shmHeader = (shmHeaderType *)shm;
	shmHeader->width = image->width;
	shmHeader->height = image->height;
	shmHeader->numFrames = 1;
	shmHeader->bytesPerPixel = image->nChannels;
	shmHeader->buffHead = 0;
	shmHeader->offsets[0] = sizeof(shmHeaderType);
	shmHeader->lastUpdateTime = GetTime();
	shmHeader->bufsize = bufsize;
	shmHeader->isInit = SHM_INITIALIZED;

	memcpy((char *)shm + sizeof(shmHeaderType), image->imageData, image->imageSize);

	/*
	// read the image from the shared memory
	size.width =  shmHeader->width;
	size.height = shmHeader->height;
	nChannels	= shmHeader->bytesPerPixel;

	testImage = cvCreateImageHeader(size, IPL_DEPTH_8U, nChannels);
	cvSetImageData(testImage, (uchar*)(shm + sizeof(shmHeaderType)), size.width * nChannels); 
	
	*/
	// display the newly created image
//	cvvNamedWindow("Test", 1);
//	cvvShowImage("Test", testImage);
//	cvvWaitKey(0);
	//shmdt(shm);

	return 1;
}

