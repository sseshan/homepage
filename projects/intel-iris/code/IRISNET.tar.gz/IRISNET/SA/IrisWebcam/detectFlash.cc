/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* Displays the image loaded into the shared memory using 'loadImage' tool */

#include "cv.h"
#include "highgui.h"
#include "SA.h"
#include <sys/shm.h>
#include <math.h>
#include <sys/times.h>
#include <sys/resource.h>
#include "shmman.h"
#include "imgproc.h"
#include "csapp.h"

#define S_IDLE 0
#define S_ON 1
#define S_OFF 2

int state = S_IDLE;
float counton = 0;
float countoff = 0;
void *thread(void *vargp);

void StartNet() {
	int port = 8000;
	signal(SIGPIPE, SIG_IGN);
	int listenfd = Open_listenfd(port);
	int connfd;
        int count = 0;
                                                                                
        struct sockaddr_in clientaddr;
        int clientlen = sizeof(clientaddr);
                                                                                
	while (true) {
		int total = 0;
		char buf[MAXLINE];
		rio_t rio;
		int size = 1;
		
		printf("main(): Listening on port %d\n", port);
                                                                                
		connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
		printf("main(): Connection established to %s:%d on fd %d\n",
			inet_ntoa(clientaddr.sin_addr), clientaddr.sin_port, connfd);
		
		Rio_readinitb(&rio, connfd);

		buf[0] = 0;

		while (size > 0) {
			size = Rio_readnb(&rio, buf, MAXLINE);
			total += size;
			sleep(0);
		}
		
		Close(connfd);
		
		count++;
		printf("Total size read: %d\n", total);

		if (total == 1) {
			if (buf[0] == '1') {
				sleep(1);
				state = S_ON;
				counton = 0;
				printf("Received: Light ON\n");
			
			}
			else if (buf[0] == '0') {
				state = S_OFF;
				countoff = 0;
				printf("Received: Light OFF\n");
			}
		}

		printf("Total connection count: %d\n", count);

		usleep(150000);
        }
}

void DrawCentroid(CvSeq * contours, IplImage * threshold, IplImage * dstImage) {
       
	cvCvtColor(threshold, dstImage, CV_GRAY2RGB);
	int i = 0;

        double largearea = 0;
	CvPoint largepoint = cvPoint(0, 0);

	while (contours != NULL) {
		CvMoments moments;
		
		cvContourMoments(contours, &moments);
	
		double area = cvGetSpatialMoment(&moments, 0, 0);
		double xc = cvGetSpatialMoment(&moments, 1, 0) / area;
		double yc = cvGetSpatialMoment(&moments, 0, 1) / area;

		//printf("iteration %d  xc %f  yc %f area %f\n", i, xc, yc, area);

		CvPoint centroid = cvPoint((int) (xc ), (int) (yc ));

		if (centroid.x < 0 || centroid.y < 0) {
			contours = contours->h_next;
			i++;
			continue;
		}
		
		//cvCircle(dstImage, centroid, 5, CV_RGB(220, 220, 0), 5);
		if (area > largearea) {
			largearea = area;
			largepoint = centroid;
		}
	
		printf("Landmark %d = (%d, %d)\n", i, centroid.x, centroid.y); 
		//printf("Landmark (%d, %d)\n",  centroid.x, centroid.y); 
		
		contours = contours->h_next;
		i++;
	}

	if (largearea != 0) {
	cvCircle(dstImage, largepoint, 5, CV_RGB(220, 220, 0), 5);	
	}

	DisplayIplImage(dstImage, "Centroids");
	cvWaitKey(0);

}

int Start(int shm_key)
{
	IplImage * image0 = NULL;
	IplImage * lighton = NULL;
	IplImage * lightoff = NULL;
	IplImage * sub = NULL;
	IplImage * sub2 = NULL;
	IplImage * threshold = NULL;


	int step;
	CvSize size;
	shmHeaderType *shmHeader;
	void * shm;
	
	shm = OpenSharedMemoryKey(shm_key);

	if (shm == NULL) {
		printf( "Error in opening shared segment");
		return 0;
	}

	shmHeader = (shmHeaderType*)shm;
	
	step = shmHeader->bytesPerPixel;
	size.width = shmHeader->width;
	size.height = shmHeader->height;

	lightoff = cvCreateImage(size, IPL_DEPTH_8U, step);
	sub = cvCreateImage(size, IPL_DEPTH_8U, step);
	sub2 = cvCreateImage(size, IPL_DEPTH_8U, step);
	lighton = cvCreateImage(size, IPL_DEPTH_8U, step);
	lightoff = cvCreateImage(size, IPL_DEPTH_8U, step);
	threshold = cvCreateImage(size, IPL_DEPTH_8U, 1);
	IplImage * centroids = cvCreateImage(size, IPL_DEPTH_8U, step);

	for (;;) {
		//printf("State: %d\n", state);

		if (state == S_IDLE) {
			usleep(150000);

			DisplayIplImage(lighton, "Light ON");
			DisplayIplImage(lightoff, "Light OFF");
			DisplayIplImage(sub, "Subtracted Image");
			DisplayIplImage(threshold, "Threshold Image");
			DisplayIplImage(centroids, "Centroids");
			continue;
		}
		
		if (state == S_OFF && countoff == 0)
			sleep(1);

		image0 = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
		cvSetImageData(image0, (uchar*) ((uchar *)shm + shmHeader->offsets[shmHeader->buffHead]),
			       step * shmHeader->width);
      
		IplImage * orig = cvCloneImage(image0);
		cvReleaseImageHeader(&image0);

		if (sub == NULL) {
			
		} else {
			if (state == S_ON) {
				counton++;
				printf("Capturing light on frame: %d\n", (int) counton);
				MyRunningAvg(orig, lighton, 1.0 / counton);
			} else {
				if (countoff > counton) {
					cvSub(lighton, lightoff, sub);
					cvSub(lightoff, lighton, sub2);
					cvAdd(sub, sub2, sub);
					
					bool done = false;
					
					int pixthreshold = 254;
					IplImage * subgray = MyColorToGray(sub);
					CvSeq * contours = NULL;

					CvMemStorage * storage = cvCreateMemStorage(0);

					do {
						fprintf(stderr, "Trying match threshold %d\n", pixthreshold);
						cvThreshold(subgray, threshold, pixthreshold, 255, CV_THRESH_BINARY);
						cvErode(threshold, threshold, NULL, 2);
						// find contours and store them all as a list
						cvFindContours(threshold, storage, &contours, sizeof(CvContour),
								CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );

						pixthreshold -= 20;

						if (pixthreshold < 10 || NumContours(contours, 20) >= 1) {
							done = true;
						}

					} while (!done);

					pixthreshold += 20;

					DrawCentroid(contours, threshold, centroids);

					cvThreshold(subgray, threshold, pixthreshold, 255, CV_THRESH_BINARY);
					cvErode(threshold, threshold, NULL, 2);
					cvReleaseImage(&subgray);
					cvReleaseMemStorage(&storage);
					
					state = S_IDLE;
					continue;
				}

				if (countoff == 0) {
					cvCopy(orig, lightoff);
				}

				// state == S_OFF
				countoff++;
				printf("Capturing light off frame: %d\n", (int) countoff);

				MyRunningAvg(orig, lightoff, 1.0 / counton);
			
			}

		}

		cvReleaseImage(&orig);
		DisplayIplImage(lighton, "Light ON");
		DisplayIplImage(lightoff, "Light OFF");
		DisplayIplImage(sub, "Subtracted Image");
		DisplayIplImage(threshold, "Threshold Image");
		DisplayIplImage(centroids, "Centroids");
		
		usleep(200000);
	}
	
	return 0;
}



int main(int argc, char * argv[])
{
	int shm_key = 74, key;
  
	if (argc > 1) {
		if (sscanf(argv[1], "%d", &key) == 1){
			shm_key = key;
		}
	}
	
	printf("Reading from the shared memory with SHM_KEY=%d. To use different SHM_KEY, use 'showImage <SHM_ID>'.\n", shm_key);

	pthread_t tid;
	Pthread_create(&tid, NULL, thread, NULL);

	
	Start(shm_key);
	Pthread_join(tid, NULL);

	return 0;
}


void *thread(void *vargp)
{
	StartNet();
	return NULL;
}
