/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

// camstream includes
#include <VideoDevice.h>
#include <VideoCollector.h>

// opencv includes
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

// SA common
#include <shmman.h>
#include <imgproc.h>

// debug print library
#include <dbgprintlib.h>

// Unix system includes
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>

// video rame information
typedef struct {
	int width;
        int height;
	int bytesPerPixel;
} frameInfoType;




// Creates shared memory to dump the frames from the webcam.
// The shared memory segment must be initialized with this function
// before it can be used.
// We write a header block to the beginning of the shared memory, and then
// mark the rest of the memory for the frames.
//
// the frames are assumed to be of 4-byte color
// the frames are used as a circular buffer 
// 
// The first int in the shared buffer indocates the head of the circular queue
// The rest of the buffer is the circular buffer
//
// returns 0 if failure, 1 if successful
int CreateSharedMemory(int numFrames, frameInfoType fInfo)
{
	int size = fInfo.width * fInfo.height * fInfo.bytesPerPixel; // 4-byte color
	int shmid; // shared memory id
	int i;
	shmHeaderType *shmHeader;

	// check frames range
	if (numFrames > MAX_SHM_FRAMES) {
		printf("Num frames of %d too high.  Adjusted to %d frames\n",
		       numFrames, MAX_SHM_FRAMES);
		numFrames = MAX_SHM_FRAMES;
	}

	if (numFrames <= 0) {
		printf("%d frames is invalid.  Setting to 1.\n", numFrames);
		numFrames = 1;
	}
	
	dprintf(0, "Creating %d bytes shared memory for %d webcam frames\n",
		sizeof(shmHeaderType) + size * numFrames, numFrames);

	// createss shared memory segment with proper size and id
	if ((shmid =
	     shmget(IMAGE_SHM_KEY,
		    sizeof(shmHeaderType) + size * numFrames,
		    0777 | IPC_CREAT)) < 0) {
		dperror(0, "Failed to create shared memory");
		printf("This may happen when another application previously\n");
		printf("allocated shared memory that was too small.\n");
		printf("You may also get this error when using 'loadImage' to\n");
		printf("load images with smaller size or depth into shared memory.\n");
		printf("When upgrading to a new version of this program, you may get this error.\n");
		printf("Please reboot your machine and try again.\n");
		return 0;
	}

	// put header at the beginning of shared memory
	shmHeader = (shmHeaderType *) shmat(shmid, 0, 0);
	shmHeader->isInit = SHM_NOTINIT;
	shmHeader->width = fInfo.width;
	shmHeader->height = fInfo.height;
	shmHeader->numFrames = numFrames;
	shmHeader->bytesPerPixel = fInfo.bytesPerPixel;
	shmHeader->bufsize = sizeof(shmHeaderType) + numFrames * size;
	shmHeader->buffHead = 0;

	/*
	shmInfo->numFrames = numFrames;
	shmInfo->shmKey = IMAGE_SHM_KEY;
	shmInfo->size = shmHeader->bufsize;
	*/
	// mark frames in shared memory
	for (i = 0; i < numFrames; i++) {
		shmHeader->offsets[i] = sizeof(shmHeaderType) + i * size;
		//shmInfo->offsets[i] = shmHeader->offsets[i];
		printf("CreateSharedMemory(): Setting offset %d to %x\n", i, shmHeader->offsets[i]);
	}


       	shmHeader->isInit = SHM_INITIALIZED;

	shmdt((void *) shmHeader);

	return 1;
}

// Returns the first video device on the system
// If no devices are found, then return NULL
CVideoDevice * GetVideoDevice()
{
        CVideoDevice * video = NULL;
	CVideoCollector * videoDevices;
	QString dName;

 	// find a video device
	videoDevices = CVideoCollector::Instance();
	for (int i = 0; i < videoDevices->NumberOfVideoDevices(); i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		if (dName.isNull()) {
			dName = video->GetNodeName();
			dprintf(0, "Camera found: %s",
				(const char *) dName);
			break;
		}
	}

	return video;
}

CvHidHaarClassifierCascade* new_face_detector(void)
{
	CvHaarClassifierCascade* cascade = cvLoadHaarClassifierCascade("<default_face_cascade>", cvSize(24,24));
	/* images are assigned inside cvHaarDetectObject, so pass NULL pointers here */
	CvHidHaarClassifierCascade* hid_cascade = cvCreateHidHaarClassifierCascade( cascade, 0, 0, 0, 1 );
	/* the original cascade is not needed anymore */
	cvReleaseHaarClassifierCascade( &cascade );
	return hid_cascade;
}


void BlurFaces(IplImage * image, CvSeq * faces)
{
    	/* draw all the rectangles */
    	for(int i = 0; i < faces->total; i++ )
    	{
        	/* extract the rectanlges only */
        	CvRect rect = *(CvRect*)cvGetSeqElem( faces, i, 0 );
		CvPoint start = cvPoint(rect.x, rect.y);
		CvPoint end = cvPoint(rect.x+rect.width, rect.y+rect.height);

        	cvRectangle(image, start, end, CV_RGB(255,0,0), 3 );
		cvRectangle(image, start, end, CV_RGB(0, 0, 0), -1);
    	}

}

CvSeq * DetectFaces(IplImage * image, CvMemStorage * storage)
{
	CvHidHaarClassifierCascade* cascade = new_face_detector();

    	CvSeq* faces;

    	/* use the fastest variant */
    	faces = cvHaarDetectObjects( image, cascade, storage, 1.2, 2, CV_HAAR_DO_CANNY_PRUNING );
	
	cvReleaseHidHaarClassifierCascade( &cascade );

	// printf("%d faces detected.\n", faces->total);
	return faces;

}

void HideFaces(IplImage * image)
{
	CvMemStorage * storage = cvCreateMemStorage();
	CvSeq * faces = NULL;

	IplImage * gray = MyColorToGray(image);
	
	faces = DetectFaces(gray, storage);

	BlurFaces(image, faces);
	
	//cvNamedWindow("result", 1);
	//cvShowImage( "result", gray );
	//cvResizeWindow("result", gray->width + 1, gray->height+1);

	cvReleaseImage(&gray);
	cvReleaseMemStorage(&storage);

}


// loads webcam video frame into shared memory
// loops forever
// returns 0 on error
int LoadFrame(int sleepSeconds, int displayFlag)
{

	CVideoDevice *video = NULL;
	QString dName;
	int currFrame = 0;
	uchar *imgData = NULL;
	void *mem = NULL;
	shmHeaderType *shmHeader = NULL;

	// open shared memory
	mem = OpenSharedMemory();

	if (mem == NULL) {
	        printf("LoadFrame(): Error opening shared memory.\n");
		return 0;
	}

	printf("Shared memory mapped to %x\n", (unsigned int) mem);

	imgData = (uchar *) mem;
	shmHeader = (shmHeaderType *) imgData;

	printf("Width: %d  Height: %d  Channels: %d\n", shmHeader->width, shmHeader->height, shmHeader->bytesPerPixel);

	CvSize imgSize;

	// if displayFlag option is ON, create the image to display
	if (displayFlag) {
		imgSize.width = shmHeader->width;
		imgSize.height = shmHeader->height;

		if (cvNamedWindow("webcam", HG_AUTOSIZE) != 1) {
			printf("Error creating display window.\n");
			return 0;
		}
	}

	// Get video device
	video = GetVideoDevice();

	if (video == NULL) {
	        printf("LoadFrame(): No video devices found.\n");
		return 0;
	}

	dName = video->GetNodeName();

	// open video device
	if (video->Open(1) < 0) {
		dperror(0, "LoadFrame(): Error in opening video device %s",
			(const char *) dName);
		return 0;
	}

	// set frame size
	video->SetSize(shmHeader->width, shmHeader->height);
	video->EnableRGB(1);

	printf("LoadFrame(): Frame rate was: %d\n", video->GetFramerate());
	video->SetFramerate(10);
	printf("LoadFrame(): Frame rate set to: %d\n", video->GetFramerate());

	IplImage * srcImage;

	// dump frames in shared memory
	for (;;) {
		// get raw data from camera feed to IplImage format.
		int size = shmHeader->width * shmHeader->height
			* shmHeader->bytesPerPixel;
		IplImage * rawImage = cvCreateImageHeader(imgSize, IPL_DEPTH_8U,
			shmHeader->bytesPerPixel);

	
		if (video->ReadImage() != 0) {
			printf("LoadImage(): Error reading image from video buffer.\n");
			return 0;
		}

		cvSetImageData(rawImage, video->GetRGB()->bits(),
			       shmHeader->bytesPerPixel * shmHeader->width);
		
		srcImage = cvCloneImage(rawImage);
		cvReleaseImageHeader(&rawImage);
	
		HideFaces(srcImage);

		if (displayFlag) {	       
			cvShowImage("webcam", srcImage);
			// this fixes bug in highgui of not automatically resizing
			cvResizeWindow("webcam", srcImage->width + 1, srcImage->height+1);
		}
		
		// printf("Copying %d bytes to shared memory\n", size);
		memcpy(imgData + shmHeader->offsets[currFrame],
		       srcImage->imageDataOrigin, size);

		shmHeader->buffHead = (int) currFrame;

		time(& (shmHeader->lastUpdateTime));
		//printf("loading in offset %d %d..\n", currFrame, shmInfo.offsets[currFrame]);

		currFrame = (currFrame + 1) % shmHeader->numFrames;
		// printf("Hi %x\n", * ((unsigned int *) (imgData + shmHeader->offsets[currFrame])));

		cvReleaseImage(&srcImage);

		usleep(sleepSeconds);
	}

	cvReleaseImage(&srcImage);

	return 1;
}


// Logs the process id to /tmp/IRISWEBCAM.pid.*
void LogPid()
{
	pid_t pid;
	char buf[80];
	FILE *outf;


	pid = getpid();
	sprintf(buf, "/tmp/IRISWEBCAM.pid.%d", pid);

	outf = fopen(buf, "w");

	if (outf == NULL) {
	      printf("LogPid(): File open error on %s\n", buf);
	      return;
	}

	sprintf(buf, "%d\n", pid);
	fwrite(buf, 1, strlen(buf), outf);
	fflush(outf);
	fclose(outf);
}


int main(int argc, char *argv[])
{
	frameInfoType fInfo;
	int numFrames, displayFlag, secondsPerFrame;

	if (argc != 6) {
		printf
		    ("Usage: webcam <#frames in buffer> <width> <height> <SecondsPerFrame> <displayFlag>\n");
		return 1;
	}

	if ((sscanf(argv[1], "%d", &numFrames) != 1) ||
	    (sscanf(argv[2], "%d", &fInfo.width) != 1) ||
	    (sscanf(argv[3], "%d", &fInfo.height) != 1) ||
	    (sscanf(argv[4], "%d", &secondsPerFrame) != 1) ||
	    (sscanf(argv[5], "%d", &displayFlag) != 1)) {
		printf("Error in argv format\n");
		return 1;
	};

	fInfo.bytesPerPixel = 4;
	if (CreateSharedMemory(1,fInfo) == 0) {
	        printf("Failed to create shared memory.\n");
		return 1;
	}

	printf("Configuration : \n");
	printf("\tVideo framesize: (Width: %d x Height: %d)\n", fInfo.width, fInfo.height);
	printf("\tRefresh rate: 1 frame per %d seconds\n", secondsPerFrame);
	printf("\tNumber of frames in shared memory: %d\n", numFrames);
	printf("\tShared memory keyID: %d\n", IMAGE_SHM_KEY);

	LogPid();
	LoadFrame(secondsPerFrame, displayFlag);

	return 0;
}
