/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef RESOURCEMAN_H
#define RESOURCEMAN_H

#include <string>

using namespace std;


/** Resource Manager.
 * - Talks to service discovery server
 * - Sends info baout load/network/id, etc.
 * - Sends plugin info
 */
class ResourceMan {

};

#endif
