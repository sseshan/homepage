/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef SECURITYMAN_H
#define SECURITYMAN_H

#include <string>

using namespace std;


/** Security Manager.
 * Manages Sensing Agent security
 */
class SecurityMan {

};

#endif
