/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef SENSORMAN_H
#define SENSORMAN_H

#include <string>

using namespace std;


/** Sensor Manager.
 * - Manages input sensors
 * - Discovers what sensors are available
 * 
 * @see Sensor
 */
class SensorMan {
	/** Loads sensors in subdirectories of initDir
	 */
	SensorMan(string initDir);
};

#endif
