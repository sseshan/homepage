/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef SENSELETMAN_H
#define SENSELETMAN_H

#include <string>

using namespace std;


/** Senselet Manager.
 */
class SenseletMan {

};

#endif
