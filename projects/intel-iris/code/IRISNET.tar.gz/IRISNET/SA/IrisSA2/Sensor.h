/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef SENSOR_H
#define SENSOR_H

#include <string>

using namespace std;

/** Encapsulates a sensor input device.
 */
class Sensor {
public:
	string guid; ///< Globally unique ID
	string name; ///< Human readable name
	string certificate; ///< Security certificate

	/** Sensor state constants.
	 *  - UNINITIALIZED - initial state
	 *  - INSECURE - Sensor did not pass security checks, and can not run.
	 *  - READY - The sensor is stopped, but is ready to run.
	 *  - RUNNING - The sensor is running.
	 *  - ERROR - The sensor is in a stopped, error state.
	 */
	static enum state {UNINITIALIZED, UNSECURE, READY, RUNNING, ERROR};

	/** Constructs a sensor object located at initDir
	 */
	Sensor(string initDir);
	
};

#endif
