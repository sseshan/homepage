/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#ifndef PFILTERMAN_H
#define PFILTERMAN_H

#include <string>

using namespace std;


/** Privacy Filter Manager.
 */
class PFiltertMan {

};

#endif
