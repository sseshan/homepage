/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include "shmemlib.h"

SHM_ID *SHM_Open(int key)
{
  int status;
  SHM_ID *newIDPtr;
  
  newIDPtr = (SHM_ID *) malloc(sizeof(SHM_ID));
  status = shmget(key, 0, 0666);
  if (status < 0) {
    perror("SHMLIB: getid");
    free(newIDPtr);
    return(NULL);
  }
  
  newIDPtr->id = status;
  return(newIDPtr);
}

SHM_ID *SHM_New(int key, u_int size)
{
  int status;
  SHM_ID *newIDPtr;
  
  newIDPtr = (SHM_ID *)malloc(sizeof(SHM_ID));


  status = shmget(key, size, IPC_CREAT | 0666);
  if (status < 0) {
    free(newIDPtr);
    perror("SHMLIB: getid");
    return(NULL);
  }
  
  newIDPtr->id = status;
  newIDPtr->address = NULL;
  return(newIDPtr);
}

void SHM_Close(SHM_ID *idPtr) 
{
  free(idPtr);
}

void *SHM_Attach(SHM_ID *idPtr, void *addr)
{
  void* status;

  status = shmat(idPtr->id, addr, 0);
  if (status < 0) {
    perror("SHMLIB: attach");
    idPtr->address = NULL;
  }
  idPtr->address = (void *)status;
  return(status);
}

SHM_Status SHM_Detach(SHM_ID *idPtr)
{
  int status;

  status = shmdt(idPtr->address);
  if (status < 0) {
    perror("SHMLIB: detach");
  }
  idPtr->address = NULL;
  return(status);
}

void SHM_SetMode(SHM_ID *idPtr, short mode)
{
  struct shmid_ds buf;

  shmctl(idPtr->id, IPC_STAT, &buf);

  buf.shm_perm.mode = mode;
  
  shmctl(idPtr->id, IPC_SET, &buf);

}

SHM_Status SHM_Free(SHM_ID *idPtr)
{
  struct shmid_ds buf;
  int status; 

  status = shmctl(idPtr->id, IPC_RMID, &buf);
  if (status < 0)
    perror("SHMLIB: close");
  
  free(idPtr);
  return(status);
}

