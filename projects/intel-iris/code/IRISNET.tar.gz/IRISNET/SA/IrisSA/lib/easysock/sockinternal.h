/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#define SOCK_SIDE_CLIENT                        1<<1
#define SOCK_SIDE_SERVER                        1<<2

#define SOCK_CTRL_TIMEOUT_SEC                   0
#define SOCK_CTRL_TIMEOUT_USEC                  500000
#define SOCK_MIN_USLEEP                         1500
#define SOCK_DEFAULT_BUF_SIZE                   32768
#define SOCK_DEFAULT_TTL                        4
#define SOCK_MAXHOSTNAME                        1024

#define SOCK_NOT_BROADCAST              0
#define SOCK_BROADCAST                  1
#define SOCK_NOT_MOBILE                 0
#define SOCK_MOBILE                     1
#define SOCK_DONT_USE_CTRL            	0
#define SOCK_USE_CTRL                   1
#define SOCK_NOT_CTRL                   0
#define SOCK_CTRL                       1
#define SOCK_COMPATIBLE                 1
#define SOCK_NOT_COMPATIBLE             0
#define SOCK_BLOCK                      1
#define SOCK_NON_BLOCK                  0

#define SOCK_STATE_ALLOCATED                    1
#define SOCK_STATE_LISTENING                    2
#define SOCK_STATE_CONNECTED                    3
#define SOCK_STATE_ACCEPTED                     4
#define SOCK_STATE_HANDOFF                      5
#define SOCK_STATE_CLOSED                       6
#define SOCK_STATE_CLOSING                      7

#define SOCK_CTRL_INIT_HANDOFF                  1
#define SOCK_CTRL_DO_HANDOFF                    2
#define SOCK_CTRL_SET_RATE                      3
#define SOCK_CTRL_SET_REMOTE                    4
#define SOCK_CTRL_SET_REMOTE_CTRL               5
#define SOCK_CTRL_SET_REMOTE_CTRL_PORT          6
#define SOCK_CTRL_NEW_CTRL_CHANNEL              7
#define SOCK_CTRL_FAREWELL                 	8
#define SOCK_CTRL_CLOSE_CTRL_CHANNEL            9
#define SOCK_CTRL_HELLO                 	10
#define SOCK_CTRL_ACK							11 /* A Socket-library-layer ack */

#define SOCK_UNAVAIL                            0x01 /*slot in cache is used */
#define SOCK_AVAIL                              0x10 /* usused */

typedef struct SockCtrlHello {
     char ipAddr[SOCK_MAX_IP_LEN];
     Port udpCtrlPort;
     Port tcpCtrlPort;
} SockCtrlHello;

typedef struct SockCtrlFarewell {
     char ipAddr[SOCK_MAX_IP_LEN];
} SockCtrlFarewell;

typedef struct SockCtrlInitHandoff {
     char ipAddr[SOCK_MAX_IP_LEN];
} SockCtrlInitHandoff;

typedef struct SockCtrlDoHandoff {
     char ipAddr[SOCK_MAX_IP_LEN];
} SockCtrlDoHandoff;

typedef struct SockCtrlSetRate {
     int rate;
} SockCtrlSetRate;

typedef struct SockCtrlSetRemote {
     Port port;
} SockCtrlSetRemote;

typedef struct SockCtrlAck {
	int numBytes;
} SockCtrlAck;

typedef struct SockCtrlNewCtrlChannel {
     int protocol;
     char ipAddr[SOCK_MAX_IP_LEN];
     int port;
} SockCtrlNewCtrlChannel;

typedef struct SockCtrlPkt {
     int reqType;
     struct sockaddr_in srcAddr;
     union {
	  SockCtrlInitHandoff         	initHandoff;
	  SockCtrlDoHandoff           	doHandoff;
	  SockCtrlSetRate             	setRate;
	  SockCtrlSetRemote           	setRemote;
	  SockCtrlNewCtrlChannel  	newCtrlChannel;
	  SockCtrlFarewell		farewell;
	  SockCtrlHello			hello;
	  SockCtrlAck			ack;
     } data;
} SockCtrlPkt;


extern Sock_Status      Sock_RecvCtrl(Socket *ctrlSdPtr, Socket *sdPtr);
extern Sock_Status 	Sock_SendCtrl(Socket *sdPtr, RemoteHost *rhost, 
				      SockCtrlPkt *ctrlPktPtr);
extern Sock_Status      Sock_CtrlSetAddr(Socket *ctrlSdPtr, Port port);
extern Sock_Status      Sock_CtrlSetCtrlAddr(Socket *ctrlSdPtr, Port port);
extern Sock_Status      Sock_CtrlSetCtrlPort(Socket *ctrlSdPtr, Port port);
extern char             *BroadcastAddr(char *normAddr);
extern int              IsIPAddr(char *id, int length);
extern int 		Sock_TimeDiff(timev t1, timev t2);
