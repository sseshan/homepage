/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:5; tab-width:5; indent-tabs-mode:t -*- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <math.h>
//#include "osflags.h"
#include "dbgprintlib.h"
#include "easysocklib.h"
#include "sockinternal.h"

/*************************************************************************
			 Utility  Routines
*************************************************************************/

void Sock_SigPipeHandle()
{
     signal(SIGPIPE, SIG_IGN);
}

static float Sock_Random(void)
{
     float  temp;
#ifdef RANDOM
     while ((temp = (double) (random() % 10000000) / 10000000) == 0.0);
#else
#ifdef RAND
     while ((temp = (double) (rand() % 10000000) / 10000000) == 0.0);
#endif
#endif
     return (temp);
}


/* Return a Poisson variate with specified mean */
static int Sock_PoissonDist(float err_prob)
{
     double   prob;

     prob = -err_prob * log(Sock_Random());
     return (int) (1 / (8.0 * prob));
}

/*
 * Poisson error generator 
 */

void Sock_PoissonError(Socket *sdPtr, char *pktPtr, int size)
{
     static int first_time = 1;
     
     while (sdPtr->berState.bytesToNextError <= size) {
	  if (first_time)
	       first_time = 0;
	  else {
	       pktPtr[sdPtr->berState.bytesToNextError] = 
		    pktPtr[sdPtr->berState.bytesToNextError] ^ 
			 (1 << (int)(Sock_Random() * 8));
	       sdPtr->berState.bitsDropped++;
	  }
          sdPtr->berState.bytesToNextError += 
	       Sock_PoissonDist(sdPtr->berState.errorProb[0]);
     }
     sdPtr->berState.bytesToNextError -= size;
     sdPtr->berState.totalBits += size <<3;
}

void Sock_DelayPacket(Socket *sdPtr, int length)
{
     struct timeval curTime, nextTime, time1, time2;
     int usecWait=0;
     static int minUsleep = SOCK_MIN_USLEEP;
     int temp;
     double tempd;

     tempd = (double)sdPtr->lastPktSize * 1000000/sdPtr->xmitRate;
     temp = sdPtr->lastPktTime.tv_usec + tempd;
     nextTime.tv_sec = sdPtr->lastPktTime.tv_sec + (int)(temp/1000000);
     nextTime.tv_usec = temp % 1000000;
     gettimeofday(&curTime, NULL);
     usecWait = ((nextTime.tv_sec - curTime.tv_sec) * 1000000) +
	       nextTime.tv_usec- curTime.tv_usec;
     dprintf(110,"nxt us %d lst us %d wait %d lps %d temp %d\n",
	     nextTime.tv_usec, sdPtr->lastPktTime.tv_usec, 
	     usecWait, sdPtr->lastPktSize, temp);
     if (usecWait < 0) {
	  sdPtr->lastPktTime.tv_sec = curTime.tv_sec;
	  sdPtr->lastPktTime.tv_usec = curTime.tv_usec;
	  sdPtr->lastPktSize = length;
	  return;
     }
     if (usecWait > 0 && usecWait > minUsleep) {
	  gettimeofday(&time1, NULL);
	  //microsleep(usecWait); // XXX: sknath
	  gettimeofday(&time2, NULL);
	  temp = (time2.tv_usec - time1.tv_usec) +
	       (time2.tv_sec - time1.tv_sec) * 1000000;
	  dprintf(110, "usecWait %d realWait %d minUsleep %d\n", 
		  usecWait, temp, minUsleep);
	  if (temp > 1.25 * usecWait && temp > minUsleep) {
	       minUsleep = 1.25 * temp;
	  }
  	  sdPtr->lastPktTime.tv_sec = nextTime.tv_sec;
	  sdPtr->lastPktTime.tv_usec = nextTime.tv_usec;
	  sdPtr->lastPktSize = length;
	  return;
     }
     sdPtr->lastPktSize += length;
}


char *Sock_BroadcastAddr(char *normAddr)
{
     char *newAddr;
     int i,dotCount=0, length;

     length = strlen(normAddr) + 3;
     newAddr = (char *)calloc(length, sizeof(char));
     for (i=0; i< length; i++) {
          if (((normAddr[i] < '0') || (normAddr[i] > '9')) && (normAddr[i] != '.')) {
               free(newAddr);
               return(NULL);
          }
          newAddr[i]=normAddr[i];
          if (normAddr[i] == '.') {
               dotCount++;
               if (normAddr[i+1] == '.') {
                    free(newAddr);
                    return(NULL);
               }
          }
          if (dotCount == 3)
               break;
     }
     newAddr[i+1] = '0';
     newAddr[i+2] = '0';
     newAddr[i+3] = '0';
     dprintf(109,"set broadcast address to %s\n", newAddr);
     return(newAddr);
}

int Sock_IsIPAddr(char *id)
{
#ifdef INADDR_NONE
     return (inet_addr(id) != INADDR_NONE) ;
#else
     return (inet_addr(id) != -1);
#endif

}

int Sock_NameToSin(char *hostname, Port port, Address *sinPtr) 
{
     int hostAddr;
     char tempstr[1024];
     struct hostent *hp;

#ifdef INADDR_NONE
     if ((hostAddr = inet_addr(hostname)) != INADDR_NONE) {
#else
     if ((hostAddr = inet_addr(hostname)) != -1) {
#endif
	  dprintf(109, "getting host info from addr\n");
	  memcpy(&(sinPtr->sin_addr), &hostAddr, sizeof(hostAddr));
     }
     else {
	  dprintf(109, "getting host info from name\n");
#ifdef THREADED
	  hp = &hpt;
	  hp = gethostbyname_r(hostname,
			  hp, tempstr, 1024, &temp);
#else
	  hp = gethostbyname(hostname);
#endif
	  endhostent();
	  if (hp == NULL) {
	       sprintf(tempstr, "error setting remote host to %s", hostname);
	       dprintf(110, tempstr);
	       endhostent();
	       return SOCK_FAILURE;
	  }
	  memcpy(&(sinPtr->sin_addr), hp->h_addr, hp->h_length);
     }

     sinPtr->sin_family = AF_INET;
     sinPtr->sin_port = htons(port);
     return SOCK_SUCCESS;
}

int Sock_SinToName(char *hostnamePtr, int length, Port *port, Address *sinPtr) 
{
     struct hostent *hp;

     *port = ntohs(sinPtr->sin_port);
     if (IN_CLASSD(ntohl(sinPtr->sin_addr.s_addr))) {
	  hp = NULL;
     } else {
#ifdef THREADED
	  hp = &hpt;
	  hp = gethostbyaddr_r((char *)&(sinPtr->sin_addr), 
			       sizeof(struct in_addr), AF_INET,
			       hp, tempstr, 1024, &temp);
#else
	  hp = gethostbyaddr((char *)&(sinPtr->sin_addr), 
			     sizeof(struct in_addr), AF_INET);
#endif
     }
     if ( hp == NULL) {
	  endhostent();
	  dprintf(109,"setting remote to %s\n", inet_ntoa(sinPtr->sin_addr));
	  strncpy(hostnamePtr, inet_ntoa(sinPtr->sin_addr), (size_t) length);
	  dprintf(110, "couldn't set remote name by addr");
	  return SOCK_SUCCESS;
     }
     endhostent();
     dprintf(109, "setting remote to %s\n", hp->h_name);
     strncpy(hostnamePtr, hp->h_name, (size_t) length);
     return SOCK_SUCCESS;
}

/*************************************************************************
			 Control Socket Routines
*************************************************************************/

/* recv a ctrl packet on ctrlsdptr and apply operation on sdptr */
int Sock_RecvCtrl(Socket *ctrlSdPtr, Socket *sdPtr)
{
     SockCtrlPkt ctrlPkt;
     int status=SOCK_SUCCESS;
     int temp,addrLen;
     Address rSin;
     struct timeval end_tp;
     struct timezone end_tzp;
     double t_i, b_i;
     
     dprintf(109, "Sock_RecvCtrl\n");
     addrLen = sizeof(rSin);
     temp = recvfrom(ctrlSdPtr->fd, (char *)&ctrlPkt, sizeof(ctrlPkt), 0,
                     (struct sockaddr *)&(rSin), &addrLen);
     if (temp==-1) {
          dprintf(109,"recvctrl:recv failed\n");
          return(SOCK_FAILURE);
     }

     switch (ntohl(ctrlPkt.reqType)) {

	 case SOCK_CTRL_ACK:
		 dprintf(109, "recvctrl:Saw ack of %d bytes\n", ctrlPkt.data.ack.numBytes);
		 dprintf(109, "recvctrl:bytesSentSoFar=%d, bytesAckedSoFar=%d\n", sdPtr->bytesSentSoFar, sdPtr->bytesAckedSoFar);

		 /* Use this to calculate the bandwidth */
		 /* If no bytes left outstanding, then Stop Timer and calculate bandwidth */
		 if (sdPtr->bytesSentSoFar == sdPtr->bytesAckedSoFar) {
				 gettimeofday(&end_tp, &end_tzp);
				 
				 t_i = (end_tp.tv_sec*1000000+end_tp.tv_usec)-(sdPtr->start_tp.tv_sec*1000000+sdPtr->start_tp.tv_usec);

/*				 sdPtr->stats.bandwidthClosedLoop = (sdPtr->bytesAckedSoFar*8.)/t_i*1000000.;*/
				 
				 sdPtr->bytesSentSoFar=0;
				 sdPtr->bytesAckedSoFar=0;
				 
				 dprintf(109, "recvctrl:bw est is %f Mb/sec\n", b_i);
		 } else {
				 /* Increase the number of bytes that have been acked */
				 sdPtr->bytesAckedSoFar += ctrlPkt.data.ack.numBytes;
		 }
		 
		 break;
     case SOCK_CTRL_FAREWELL:
          dprintf(109, "recvctrl:farewell ctrl pkt\n");
	  sdPtr->state = SOCK_STATE_CLOSING;
	  break;
     case SOCK_CTRL_HELLO:
          dprintf(109, "recvctrl:hello ctrl pkt\n");
          dprintf(109, "Hello from %s at udp %d tcp %d\n", 
		  ctrlPkt.data.hello.ipAddr, ctrlPkt.data.hello.udpCtrlPort, 
		  ctrlPkt.data.hello.tcpCtrlPort);
	  /* search and add to rhost list XXXX */
	  break;
     case SOCK_CTRL_INIT_HANDOFF:
          /* XXXX should use multicast add of new member */
          dprintf(109, "recvctrl:init handoff ctrl pkt\n");
          /*
             status = Sock_AddDestination(sdPtr, ctrlPkt.data.initHandoff.hostname);
             */
          break;
     case SOCK_CTRL_DO_HANDOFF:
          dprintf(109, "recvctrl:do handoffctrl pkt\n");
          /*
             for (i=0; i<(MAX_MULTICAST_HOSTS); i++) {
             if (sdPtr->activeHosts[i]) {
             if (strcmp(sdPtr->remoteName[i], ctrlPkt.data.initHandoff.hostname))
             status = Sock_DelDestination(sdPtr,
             ctrlPkt.data.initHandoff.hostname);
             }
             }
             */
          break;
     case SOCK_CTRL_SET_RATE:
          /* tested */
          sdPtr->xmitRate = ctrlPkt.data.setRate.rate;
          dprintf(109, "recvctrl:set rate ctrl pkt rate %d\n", sdPtr->xmitRate);
          break;
     case SOCK_CTRL_SET_REMOTE:
          /* tested */
          dprintf(109, "recvctrl:set remote ctrl pkt\n");
          memcpy(&(sdPtr->rSin), &rSin, sizeof(Address));
          Sock_SetRemoteByAddr(sdPtr, &(sdPtr->rSin));
          break;
     case SOCK_CTRL_NEW_CTRL_CHANNEL:
          /* tested 
	     dprintf(109, "recvctrl:new ctrl channel\n");
	     for (i=SOCK_MAX_MULTICAST_HOSTS;
	     i<(SOCK_MAX_MULTICAST_HOSTS+SOCK_MAX_CTRL_HOSTS); i++) {
	     if (!sdPtr->activeHosts[i])
	     break;
	     }
	     sdPtr->ctrlChannel[i] = Sock_Socket(ctrlPkt.data.newCtrlChannel.protocol);
	     status = Sock_Connect(sdPtr->ctrlChannel[i],
	     ctrlPkt.data.newCtrlChannel.hostname,
	     ctrlPkt.data.newCtrlChannel.port);
	     sdPtr->activeHosts[i] = 1;
	     break;
	     */
     default:
          dprintf(109,"unrecognized ctrl pkt: type %d\n",ctrlPkt.reqType);
     }

     return(status);
}

int Sock_SendCtrl(Socket *sdPtr, RemoteHost *rhostPtr, 
			  SockCtrlPkt *ctrlPktPtr)
{
     if (rhostPtr->tcpCtrl != NULL)
	  Sock_Send(rhostPtr->tcpCtrl, (char *) ctrlPktPtr, sizeof(*ctrlPktPtr));
     else {
	  if (sendto(sdPtr->udpCtrlChannel->fd, (char *)ctrlPktPtr, 
		     sizeof(*ctrlPktPtr), 0,
		     (struct sockaddr *)&(rhostPtr->udpRSin),
		     sizeof(rhostPtr->udpRSin)) == -1) {
	       dprintf(110, "Sock_SendCtrl: error in sendto");
	       return(SOCK_FAILURE);
	  }
     }
     return(SOCK_SUCCESS);
}

/* Send a socket-layer acknowledgement on the control port */
int Sock_CtrlSendAck(Socket *sdPtr, int length, RemoteHost *rhostPtr)
{
     SockCtrlPkt ctrlPkt;
     
     dprintf(109, "sendctrl:ack ctrl pkt\n");
	 
	 ctrlPkt.data.ack.numBytes=length;
     ctrlPkt.reqType = htonl(SOCK_CTRL_ACK);
     return(Sock_SendCtrl(sdPtr, rhostPtr, &ctrlPkt));
}

int Sock_CtrlSendFarewell(Socket *sdPtr, RemoteHost *rhostPtr)
{
     SockCtrlPkt ctrlPkt;
     
     dprintf(109, "sendctrl:farewell ctrl pkt\n");
     strcpy(ctrlPkt.data.farewell.ipAddr, sdPtr->localIPAddr);
     ctrlPkt.reqType = htonl(SOCK_CTRL_FAREWELL);
     return(Sock_SendCtrl(sdPtr, rhostPtr, &ctrlPkt));
}
/*
   int Sock_CtrlSetAddr(Socket *ctrlSdPtr, Port port)
   {
	SockCtrlPkt ctrlPkt;

	ctrlPkt.data.setRemote.port = port;
	ctrlPkt.reqType = SOCK_CTRL_SET_REMOTE;
	return(Sock_SendCtrl(ctrlSdPtr, &ctrlPkt));
   }
   
   int Sock_CtrlSetCtrlAddr(Socket *ctrlSdPtr, Port port)
   {
	SockCtrlPkt ctrlPkt;

	ctrlPkt.data.setRemote.port = port;
	ctrlPkt.reqType = SOCK_CTRL_SET_REMOTE_CTRL;
	return(Sock_SendCtrl(ctrlSdPtr, &ctrlPkt));
   }
   
   Socket *Sock_CtrlNewCtrl(Socket *ctrlSdPtr, char *hostname,
			    Port port, int protocol)
			    {
				 SockCtrlPkt ctrlPkt;
				 Socket *sdPtr, *cdPtr;
				 int status;

				 sdPtr = Sock_Socket(protocol);
				 status = Sock_Listen(sdPtr, port);
				 ctrlPkt.data.newCtrlChannel.port = sdPtr->localPort;
				 ctrlPkt.data.newCtrlChannel.protocol = protocol;
				 strcpy(ctrlPkt.data.newCtrlChannel.hostname, sdPtr->localName);
				 ctrlPkt.reqType = SOCK_CTRL_NEW_CTRL_CHANNEL;
				 status = Sock_SendCtrl(ctrlSdPtr, &ctrlPkt);
				 cdPtr = Sock_Accept(sdPtr);
				 Sock_Close(sdPtr);
				 return(cdPtr);
			    }
			    
			    int Sock_CtrlSetRate(Socket *ctrlSdPtr, int rate)
			    {
				 SockCtrlPkt ctrlPkt;

				 ctrlPkt.data.setRate.rate= rate;
				 ctrlPkt.reqType = SOCK_CTRL_SET_RATE;
				 return(Sock_SendCtrl(ctrlSdPtr, &ctrlPkt));
			    }
			    
			    int Sock_CtrlInitHandoff(Socket *ctrlSdPtr, char *newHost)
			    {
				 SockCtrlPkt ctrlPkt;

				 dprintf(109, "entering init handoff to %s\n", newHost);
				 strcpy(ctrlPkt.data.initHandoff.hostname, newHost);
				 ctrlPkt.reqType = SOCK_CTRL_INIT_HANDOFF;
				 return(Sock_SendCtrl(ctrlSdPtr, &ctrlPkt));
			    }
			    
			    int Sock_CtrlDoHandoff(Socket *ctrlSdPtr, char *newHost)
			    {
				 SockCtrlPkt ctrlPkt;

				 dprintf(109, "entering init handoff to %s\n", newHost);
				 strcpy(ctrlPkt.data.doHandoff.hostname, newHost);
				 ctrlPkt.reqType = SOCK_CTRL_DO_HANDOFF;
				 return(Sock_SendCtrl(ctrlSdPtr, &ctrlPkt));
			    }
			    */
			       
/*************************************************************************
  				Socket Routines
*************************************************************************/

Socket *Sock_Socket(PROTOCOLS protocol)
{
     Socket *sdPtr;
     struct protoent *proto;
     int i, j;
     char *protoStr;
     SockCache *cache;

     dprintf(112, "Sock_Socket\n");
     j = sizeof(i);
     sdPtr = (Socket *)malloc(sizeof(Socket));
     memset(sdPtr, 0, sizeof(Socket));
     sdPtr->isCtrl = SOCK_NOT_CTRL;
     switch (protocol) {
     case SOCK_TCP_CTRL:
          sdPtr->isCtrl = SOCK_CTRL;
     case SOCK_TCP:
          sdPtr->protocol = SOCK_TCP;
          sdPtr->type = SOCK_STREAM;
          protoStr="tcp";
          break;
     case SOCK_UDP_CTRL:
          sdPtr->isCtrl = SOCK_CTRL;
     case SOCK_UDP:
          sdPtr->protocol = SOCK_UDP;
          sdPtr->type = SOCK_DGRAM;
          protoStr="udp";
          break;
     case SOCK_UDP_RELIABLE:
	  sdPtr->protocol = SOCK_UDP_RELIABLE;
          sdPtr->type = SOCK_DGRAM;
          protoStr="udp";
	  break;
     case SOCK_UDP_MULTI_CTRL:
          sdPtr->isCtrl = SOCK_CTRL;
     case SOCK_UDP_MULTI:
          sdPtr->protocol = SOCK_UDP_MULTI;
          sdPtr->type = SOCK_DGRAM;
          protoStr="udp";
          break;
     case SOCK_UDP_REL_MULTI:
          sdPtr->protocol = SOCK_UDP_REL_MULTI;
          sdPtr->type = SOCK_DGRAM;
          protoStr="udp";
          break;
     case SOCK_IP:
          sdPtr->protocol = SOCK_IP;
          sdPtr->type = SOCK_RAW;
          protoStr="ip";
          break;
     default:
          printf( "Sock_socket: invalid protocol");
          free(sdPtr);
          return((Socket *)SOCK_FAILURE);
     }
#ifdef THREADED
     proto = &protoTemp;
     proto = getprotobyname_r(protoStr, proto, tempstr, 256);
#else
     proto = getprotobyname(protoStr);
#endif
     endprotoent();

     /* get the socket */
     if ((sdPtr->fd = socket(AF_INET, sdPtr->type, proto->p_proto)) == -1) {
          dprintf(110, "Sock_socket: error opening socket");
          return((Socket *)SOCK_FAILURE);
     }

     if (sdPtr->protocol == SOCK_UDP_REL_MULTI)
	  if ((sdPtr->sfd=socket(AF_INET, sdPtr->type, proto->p_proto))==-1) {
	       dprintf(110, "Sock_socket: error opening socket");
	       return((Socket *) SOCK_FAILURE);
	  }

     /* set defaults */
     i=1;
     if (sdPtr->protocol==SOCK_TCP) {
	  if (setsockopt(sdPtr->fd, proto->p_proto, TCP_NODELAY, 
			 (char *)&i, j) < 0)
	       dprintf(110, "Sock_Socket: tcp_nodelay");
     }
     if (setsockopt(sdPtr->fd, SOL_SOCKET, SO_BROADCAST, (char *)&i,j) < 0)
          dprintf(110, "Sock_Socket: so_broadcast");
     if (setsockopt(sdPtr->fd, SOL_SOCKET, SO_REUSEADDR, (char *)&i,j) < 0)
          dprintf(110, "Sock_Socket: reuseaddr");
     sdPtr->remotePort = 0;
     Sock_SetBufferSize(sdPtr, SOCK_DEFAULT_BUF_SIZE);
     gethostname(sdPtr->localName, SOCK_MAX_HOST_NAME_LEN);
     Sock_SetTimeout(sdPtr, SOCK_NO_TIMEOUT);
     gettimeofday(&(sdPtr->lastPktTime), NULL);
     sdPtr->lastPktSize = 0;
     sdPtr->ttl = SOCK_DEFAULT_TTL;
     sdPtr->xmitRate = 0;
     sdPtr->localPort = 0;
     sdPtr->block = SOCK_BLOCK;
     sdPtr->broadcast = SOCK_NOT_BROADCAST;
     sdPtr->compatible = SOCK_NOT_COMPATIBLE;
     sdPtr->mobile = SOCK_NOT_MOBILE;
     sdPtr->udpCtrlChannel = NULL;
     sdPtr->tcpCtrlChannel = NULL;
     sdPtr->numActiveRHost = 0;
     sdPtr->rHost = NULL;
     sdPtr->lFlags = 0;

     sdPtr->berState.ErrorGen = NULL;
     sdPtr->state = SOCK_STATE_ALLOCATED;

	 /* Set up state for Network Connection Monitor Stuff */
	 sdPtr->bandwidthLessThanFunc=NULL;
	 sdPtr->bandwidthMoreThanFunc=NULL;
	 /* Not Implemented Yet */
#if 0
	 sdPtr->LatencyLessThanFunc=NULL;
	 sdPtr->LatencyMoreThanFunc=NULL;
	 sdPtr->PerLessThanFunc=NULL;
	 sdPtr->PerMoreThanFunc=NULL;
 	 
	 /* Set the Maximum and Optimal Packet Size */
	 /* BUG: For Now, these will be statically fixed at 1200 bytes */
	 if (sdPtr->protocol==SOCK_TCP  ||
		 sdPtr->protocol==SOCK_TCP_CTRL) {
		 sdPtr->stats.maxPacketSize=1200;
	 } else if (sdPtr->protocol==SOCK_UDP ||
				sdPtr->protocol==SOCK_UDP_CTRL ||
				sdPtr->protocol==SOCK_UDP_RELIABLE ||
				sdPtr->protocol==SOCK_UDP_MULTI ||
				sdPtr->protocol==SOCK_UDP_MULTI_CTRL ||
				sdPtr->protocol==SOCK_UDP_REL_MULTI) {
		 sdPtr->stats.maxPacketSize=1200;
	 } else if (sdPtr->protocol==SOCK_IP) {
		 sdPtr->stats.maxPacketSize=1200;
	 }
#endif

	 /* Set the functions used to compute the cost to Send/Receive Chunks */
	 /* BUG: Not actually set. */

	 /* Set the functions used to compute the power to Send/Receive Chunks */
	 /* BUG: Not actually set. */

	 /* Set the functions used to compute the power to Turn the interface On/Off */
	 /* BUG: Not actually set. */

     /* set up state for reliable UDP protocol */
     if (sdPtr->protocol == SOCK_UDP_RELIABLE || 
	 sdPtr->protocol == SOCK_UDP_REL_MULTI) {
	  sdPtr->delack = 1; /* default number of packets before sending ack */
	  cache = sdPtr->cache = (SockCache *) Sock_Malloc(sizeof(SockCache));
	  cache->lastSent = cache->lastRead = cache->lastAck = 
	       cache->ackBase = -1;
	  cache->ackMask = cache->delack = 0;
	  cache->srtt = SOCK_INITRTT;
	  
	  for (i = 0; i < SOCK_MAXWIND; i++) {
	       cache->pkts[i] = (SockPkt *) Sock_Malloc(sizeof(SockPkt));
	       cache->pkts[i]->localHdr.numRxmit = 0;
	       cache->pkts[i]->validFlag = SOCK_AVAIL;
	       cache->rcvPkts[i] = (SockPkt *) Sock_Malloc(sizeof(SockPkt));
	       cache->rcvPkts[i]->validFlag = SOCK_AVAIL;
	  }
     }
     return(sdPtr);
}

int 
Sock_Connect(Socket *sdPtr, char *hostname, Port port)
{
     int status;
     int length;
     Address tempAddr;
     PROTOCOLS proto;
     
     dprintf(112, "Sock_Connect %s %d\n", hostname, port);
     
     sdPtr->rHost = (RemoteHost *) malloc(sizeof(RemoteHost));
     memset(sdPtr->rHost, 0, sizeof(RemoteHost));
     if (Sock_SetRemoteByName(sdPtr, hostname, port) == SOCK_FAILURE)
          return(SOCK_FAILURE);
     
     if (sdPtr->compatible == SOCK_NOT_COMPATIBLE && 
	 sdPtr->isCtrl != SOCK_CTRL) {
	  sdPtr->tcpCtrlChannel = Sock_Socket(SOCK_TCP_CTRL);
	  Sock_Listen(sdPtr->tcpCtrlChannel, SOCK_ANY_PORT);
	  sdPtr->udpCtrlChannel = Sock_Socket(SOCK_UDP_CTRL);
	  Sock_Listen(sdPtr->udpCtrlChannel, SOCK_ANY_PORT);
     }

     if (sdPtr->compatible == SOCK_NOT_COMPATIBLE) {
	  Sock_NameToSin(sdPtr->localName, 10000, &tempAddr);
	  strcpy(sdPtr->localIPAddr, inet_ntoa(tempAddr.sin_addr));
     }

     /* create connection to remote host */
     proto = sdPtr->protocol;
     switch (sdPtr->protocol) {
     case SOCK_UDP:
	  if (sdPtr->state == SOCK_STATE_ALLOCATED) {
	       sdPtr->lSin.sin_family = AF_INET;
	       sdPtr->lSin.sin_port = htons(0);
	       sdPtr->lSin.sin_addr.s_addr = htonl(INADDR_ANY);
	       if ((bind(sdPtr->fd,
			 (struct sockaddr *)&sdPtr->lSin,
			 sizeof(sdPtr->lSin))) == -1) {
		    dprintf(110, "Sock_connect: error binding socket");
		    return(SOCK_FAILURE);
	       }
	  }
     case SOCK_UDP_RELIABLE:
          if (sdPtr->compatible == SOCK_NOT_COMPATIBLE && 
	      sdPtr->isCtrl != SOCK_CTRL) {
	       SockCtrlPkt temp;
	       sdPtr->protocol = SOCK_UDP;
               /* send "Hello connect me" packet */
	       strcpy(temp.data.hello.ipAddr, sdPtr->localIPAddr);
	       temp.data.hello.tcpCtrlPort = htons(Sock_GetTCPCtrlPort(sdPtr));
	       temp.data.hello.udpCtrlPort = htons(Sock_GetUDPCtrlPort(sdPtr));
	       if (Sock_Send(sdPtr, (char *)&temp, sizeof(temp)) == 
		   SOCK_FAILURE) {
		    dprintf(110, "error sending, connect failed\n");
		    return SOCK_FAILURE;
	       }
	       /* receive "Hello accepted" packet */
	       Sock_RecvFull(sdPtr, (char *)&temp, sizeof(temp));
	       sdPtr->rHost->udpCtrlPort=ntohs(temp.data.hello.udpCtrlPort);

	       sdPtr->rHost->tcpCtrlPort=ntohs(temp.data.hello.tcpCtrlPort);
	       sdPtr->rHost->tcpCtrl=NULL;
	       sdPtr->rHost->next=NULL;
	       strcpy(sdPtr->rHost->remoteIPAddr, temp.data.hello.ipAddr);
	       Sock_NameToSin(sdPtr->rHost->remoteIPAddr, 
			      sdPtr->rHost->udpCtrlPort,
			      &(sdPtr->rHost->udpRSin));
	       sdPtr->protocol = proto;
	       dprintf(100, "protocol: %d\n", sdPtr->protocol);
	       if (sdPtr->protocol == SOCK_UDP) {
		    sdPtr->numActiveRHost = 1;
		    break;
	       }
	       if ((status=connect(sdPtr->fd, (struct sockaddr *)&sdPtr->rSin, 
				sizeof(sdPtr->rSin))) == -1) {
		    dprintf(110, "Sock_connect: Error connecting");
		    dprintf(110, " errno %d\n", errno);
		    return(SOCK_FAILURE);
	       }
          }
	  sdPtr->numActiveRHost = 1;
          break;
#ifdef MULTICAST
     case SOCK_UDP_MULTI:
     case SOCK_UDP_REL_MULTI:
          sdPtr->lSin = sdPtr->rSin;
	  if (IN_CLASSD(ntohl(sdPtr->rSin.sin_addr.s_addr))) {
	       struct ip_mreq mr;
	       int fd;
	       /*
		* Try to bind the multicast address as the socket
		* dest address.  On many systems this won't work
		* so fall back to a destination of INADDR_ANY if
		* the first bind fails.
		*/       
	       if ((bind(sdPtr->fd,
			 (struct sockaddr *)&sdPtr->lSin,
			 sizeof(sdPtr->lSin))) == -1) {
		    sdPtr->lSin.sin_addr.s_addr = htonl(INADDR_ANY);
		    if ((bind(sdPtr->fd,
			      (struct sockaddr *)&sdPtr->lSin,
			      sizeof(sdPtr->lSin))) == -1) {
			 dprintf(110, "Sock_connect: error binding socket");
			 return(SOCK_FAILURE);
		    }
	       }
	       /* 
		* XXX This is bogus multicast setup that really
		* shouldn't have to be done (group membership should be
		* implicit in the IP class D address, route should contain
		* ttl & no loopback flag, etc.).  Steve Deering has promised
		* to fix this for the 4.4bsd release.	       
		*/
	       mr.imr_multiaddr.s_addr = sdPtr->rSin.sin_addr.s_addr;
	       mr.imr_interface.s_addr = INADDR_ANY;
	       if (setsockopt(sdPtr->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, 
			      (char *)&mr, sizeof(mr)) < 0) {
		    dprintf(110, "sock_connect: IP_ADD_MEMBERSHIP");
		    return(SOCK_FAILURE);
	       }
	       /* 
		* Cannot bind and connect same multicast socket fd, so use
		* separate socket fds for send and receive.
		*/
	       if (sdPtr->protocol == SOCK_UDP_MULTI)
		    fd = sdPtr->fd;
	       else
		    fd= sdPtr->sfd;
	       if (sdPtr->protocol == SOCK_UDP_REL_MULTI)
		    if (connect(fd, (struct sockaddr *)&sdPtr->rSin, 
				sizeof(sdPtr->rSin)) < 0) {
			 dprintf(110, "sock_connect error %d\n");
			 exit(1);
		    }
	       c = 0;
	       if (setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, &c, 1) < 0)
		    dprintf(110, "Sock_Connect: ip_multicast_loop");
	       if (setsockopt(fd,IPPROTO_IP,IP_MULTICAST_TTL,&sdPtr->ttl,1)<0)
		    dprintf(110, "Sock_Connect: ip_multicast_ttl");
	       if (sdPtr->protocol == SOCK_UDP_MULTI && 
		   sdPtr->compatible == SOCK_NOT_COMPATIBLE && 
		   sdPtr->isCtrl != SOCK_CTRL) {
		    SockCtrlPkt temp;
		    sdPtr->rHost->udpCtrlPort=port+1;
		    sdPtr->rHost->tcpCtrlPort=-1;
		    sdPtr->rHost->tcpCtrl=NULL;
		    sdPtr->rHost->next=NULL;
		    sdPtr->rHost->remoteName="MULTICAST";
		    Sock_NameToSin(hostname, sdPtr->rHost->udpCtrlPort, 
				   &(sdPtr->rHost->udpRSin));
		    /* send "Hello" packet */
		    strcpy(temp.data.hello.ipAddr, sdPtr->localIPAddr);
		    temp.data.hello.tcpCtrlPort = htons(Sock_GetTCPCtrlPort(sdPtr));
		    temp.data.hello.udpCtrlPort = htons(Sock_GetUDPCtrlPort(sdPtr));
		    Sock_SendCtrl(sdPtr, sdPtr->rHost, &temp);
		    /* no welcome/accepted pkt */
	       }
	       sdPtr->numActiveRHost=1;
	       break;
	  } else 
	       return(SOCK_FAILURE);
#endif
     default:
	  if ((status = connect(sdPtr->fd, (struct sockaddr *)&sdPtr->rSin,
				sizeof(sdPtr->rSin))) == -1) {
	       dprintf(110, "Sock_connect: Error connecting");
	       return(SOCK_FAILURE);
	  }
	  if (sdPtr->compatible == SOCK_NOT_COMPATIBLE && 
	      sdPtr->isCtrl != SOCK_CTRL) {
	       SockCtrlPkt temp;
	       /* send "Hello connect" packet */
	       strcpy(temp.data.hello.ipAddr, sdPtr->localIPAddr);
	       temp.data.hello.tcpCtrlPort = htons(Sock_GetTCPCtrlPort(sdPtr));
	       temp.data.hello.udpCtrlPort = htons(Sock_GetUDPCtrlPort(sdPtr));
	       if (Sock_Send(sdPtr, (char *)&temp, sizeof(temp)) == SOCK_FAILURE) {
		    dprintf(101, "error sending, connect failed\n");
		    return SOCK_FAILURE;
	    }
	       /* receive "Hello accept" packet */
	       Sock_RecvFull(sdPtr, (char *)&temp, sizeof(temp));
	       sdPtr->rHost->udpCtrlPort=ntohs(temp.data.hello.udpCtrlPort);
	       sdPtr->rHost->tcpCtrlPort=ntohs(temp.data.hello.tcpCtrlPort);
	       sdPtr->rHost->tcpCtrl=NULL;
	       sdPtr->rHost->next=NULL;
	       strcpy(sdPtr->rHost->remoteIPAddr, temp.data.hello.ipAddr);
	       Sock_NameToSin(sdPtr->rHost->remoteIPAddr, 
			      sdPtr->rHost->udpCtrlPort,
			      &(sdPtr->rHost->udpRSin));
	  }
	  sdPtr->numActiveRHost=1;
     }  
     sdPtr->side = SOCK_SIDE_CLIENT;
     length = sizeof(Address);
     if ((status = getsockname(sdPtr->fd, (struct sockaddr *)&sdPtr->lSin,
			       &length)) == -1) {
	  dprintf(110, "Sock_Connect: error getting socket name");
	  return(SOCK_FAILURE);
     }
     sdPtr->localPort = ntohs(sdPtr->lSin.sin_port);
     dprintf(109,"connected from inet port %d to %d tcp, %d udp\n",
	     sdPtr->localPort, sdPtr->rHost->tcpCtrlPort, 
	     sdPtr->rHost->udpCtrlPort );
     sdPtr->state = SOCK_STATE_CONNECTED;
     return(SOCK_SUCCESS);
}
     
int Sock_Listen(Socket *sdPtr, Port port)
{
     int temp;
     int length;

     dprintf(112, "Sock_Listen %d \n",port);
     sdPtr->lSin.sin_family = AF_INET;
     sdPtr->lSin.sin_port = htons(port);
     if (!sdPtr->acceptFlag)
	  sdPtr->lSin.sin_addr.s_addr = htonl(INADDR_ANY);
     if ((bind(sdPtr->fd,
	       (struct sockaddr *)&sdPtr->lSin,
	       sizeof(sdPtr->lSin))) == -1) {
	  dprintf(110, "Sock_listen: error binding socket");
	  return(SOCK_FAILURE);
     }
     length = sizeof(Address);
     if ((temp = getsockname(sdPtr->fd, (struct sockaddr *)&sdPtr->lSin,
			     &length)) == -1) {
	  dprintf(110, "Sock_Listen: error getting socket name");
	  return(SOCK_FAILURE);
     }
     sdPtr->localPort = ntohs(sdPtr->lSin.sin_port);
     dprintf(109,"listening at inet port %d\n",sdPtr->localPort);
     if (sdPtr->protocol == SOCK_TCP) {
	  if ((temp = listen(sdPtr->fd, 5)) == -1) {
	       dprintf(110, "Sock_listen: error listening");
	       return(SOCK_FAILURE);
	  }
     }
     sdPtr->state = SOCK_STATE_LISTENING;
     return(SOCK_SUCCESS);
}

Socket *
Sock_Accept(Socket *sdPtr)
{
     int ts;
     Socket *cdPtr;
     int addrLen;
     Address tempAddr;

     dprintf(112, "Sock_Accept\n");
     cdPtr = (Socket *)malloc(sizeof(Socket));
     memcpy(cdPtr, sdPtr, sizeof(Socket));
     cdPtr->rHost = (RemoteHost *) malloc(sizeof(RemoteHost));
     memset(cdPtr->rHost, 0, sizeof(RemoteHost));

     if (cdPtr->compatible == SOCK_NOT_COMPATIBLE && 
	 cdPtr->isCtrl != SOCK_CTRL) {
	  cdPtr->tcpCtrlChannel = Sock_Socket(SOCK_TCP_CTRL);
	  cdPtr->udpCtrlChannel = Sock_Socket(SOCK_UDP_CTRL);
	  Sock_Listen(cdPtr->udpCtrlChannel, SOCK_ANY_PORT);
	  Sock_Listen(cdPtr->tcpCtrlChannel, SOCK_ANY_PORT);
     }
     if (sdPtr->compatible == SOCK_NOT_COMPATIBLE) {
	  Sock_NameToSin(sdPtr->localName, 10000, &tempAddr);
	  strcpy(sdPtr->localIPAddr, inet_ntoa(tempAddr.sin_addr));
     }

     switch (cdPtr->protocol) {
     case SOCK_IP:
	  return(cdPtr);
     case SOCK_UDP:
     case SOCK_UDP_RELIABLE:
	  if (cdPtr->compatible == SOCK_NOT_COMPATIBLE) {
	       SockCtrlPkt temp;
	       PROTOCOLS proto = cdPtr->protocol;
	       /* expect a "connect me" packet */
	       cdPtr->protocol = SOCK_UDP;
	       Sock_RecvFull(cdPtr, (char *)&temp, sizeof(temp));
	       cdPtr->rHost->udpCtrlPort=ntohs(temp.data.hello.udpCtrlPort);
	       cdPtr->rHost->tcpCtrlPort=ntohs(temp.data.hello.tcpCtrlPort);
	       cdPtr->rHost->tcpCtrl=NULL;
	       cdPtr->rHost->next=NULL;
	       strcpy(cdPtr->rHost->remoteIPAddr, temp.data.hello.ipAddr);
	       Sock_SetRemoteByAddr(cdPtr, &(cdPtr->lastRSin));
	       Sock_NameToSin(cdPtr->rHost->remoteIPAddr, 
			      cdPtr->rHost->udpCtrlPort,
			      &(cdPtr->rHost->udpRSin));
	       /* send and "accepted" packet */
	       strcpy(temp.data.hello.ipAddr, cdPtr->localIPAddr);
	       temp.data.hello.tcpCtrlPort = htons(Sock_GetTCPCtrlPort(cdPtr));
	       temp.data.hello.udpCtrlPort = htons(Sock_GetUDPCtrlPort(cdPtr));
	       if (Sock_Send(cdPtr, (char *)&temp, sizeof(temp)) 
		   == SOCK_FAILURE) {
		    dprintf(110, "couldn't send %d\n", sizeof(temp));
		    exit(1);
	       }
		    
	       sdPtr->fd = -1;
	       cdPtr->protocol = proto;
	       dprintf(100, "protocol: %d\n", cdPtr->protocol);
	  }
	  cdPtr->numActiveRHost=1;
	  break;
     case SOCK_TCP:
	  addrLen = sizeof(cdPtr->rSin);
	  if ((ts = accept(cdPtr->fd, (struct sockaddr *)&(cdPtr->rSin),
			   &addrLen))==-1) {
	       dprintf(110, "Sock_accept: error accepting connection");
	       return((Socket *)SOCK_FAILURE);
	  }
	  cdPtr->fd = ts;
	  cdPtr->fd = ts;
	  if (cdPtr->compatible == SOCK_NOT_COMPATIBLE) {
	       SockCtrlPkt temp;
	       /* expect a "connect me" packet */
	       Sock_RecvFull(cdPtr, (char *)&temp, sizeof(temp));
	       cdPtr->rHost->udpCtrlPort=ntohs(temp.data.hello.udpCtrlPort);
	       cdPtr->rHost->tcpCtrlPort=ntohs(temp.data.hello.tcpCtrlPort);
	       cdPtr->rHost->tcpCtrl=NULL;
	       cdPtr->rHost->next=NULL;
	       strcpy(cdPtr->rHost->remoteIPAddr, temp.data.hello.ipAddr);
	       Sock_NameToSin(cdPtr->rHost->remoteIPAddr,
			      cdPtr->rHost->udpCtrlPort,
			      &(cdPtr->rHost->udpRSin));
	       /* send and "accepted" packet */
	       strcpy(temp.data.hello.ipAddr, cdPtr->localIPAddr);
	       temp.data.hello.tcpCtrlPort = htons(Sock_GetTCPCtrlPort(cdPtr));
	       temp.data.hello.udpCtrlPort = htons(Sock_GetUDPCtrlPort(cdPtr));
	       Sock_Send(cdPtr, (char *)&temp, sizeof(temp));
	  }
	  Sock_SetRemoteByAddr(cdPtr, &(cdPtr->rSin));
	  cdPtr->numActiveRHost=1;
	  break;
#ifdef MULTICAST
     case SOCK_UDP_MULTI:
	  dprintf(109, "Sock_Accept: multicast\n");
	  break;
#endif
     default:
	  dprintf(109, "Sock_Accept: other protocol\n");
     }

     dprintf(109,"connected from inet port %d to %d tcp, %d udp\n",
	     cdPtr->localPort, cdPtr->rHost->tcpCtrlPort, 
	     cdPtr->rHost->udpCtrlPort );
     cdPtr->side = SOCK_SIDE_SERVER;
     cdPtr->state = SOCK_STATE_ACCEPTED;
     return(cdPtr);
}

int
Sock_Ready(Socket *sdPtr)
{
	struct timeval poll = {0,0};
	fd_set fdvar;
     int temp;

     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);
     if ((temp = select(sdPtr->fd + 1, &fdvar, (fd_set *)0, (fd_set *)0,&poll)) <= 0) 
		return 0;
	return FD_ISSET(sdPtr->fd, &fdvar);
}

int Sock_Close(Socket *sdPtr)
{
     int temp = SOCK_SUCCESS, i;
     RemoteHost *rhPtr;
     
     dprintf(112, "Sock_Close\n");
     if (sdPtr->state == SOCK_STATE_CLOSED)
	  return(SOCK_SUCCESS);

     /* send "farewell" message to first rhost */
     while (sdPtr->numActiveRHost > 0) {
	  rhPtr=sdPtr->rHost;
	  if (rhPtr == NULL)
	       dprintf(101,"Sock_close1: # of rhost error\n");
	  if (sdPtr->compatible == SOCK_NOT_COMPATIBLE) 
	       Sock_CtrlSendFarewell(sdPtr, rhPtr);
	  sdPtr->rHost = rhPtr->next;
	  sdPtr->numActiveRHost--;
	  if (rhPtr->tcpCtrl != NULL) {
	       temp = Sock_Close(rhPtr->tcpCtrl);
	       temp = Sock_Free(sdPtr->rHost[i].tcpCtrl);
	  }
	  free(rhPtr->remoteName);
	  free(rhPtr);
	  
     }
     
     if (sdPtr->rHost != NULL)
	  dprintf(101,"Sock_close: # of rhost error\n");
     if (sdPtr->tcpCtrlChannel != NULL) {
	  Sock_Close(sdPtr->tcpCtrlChannel);
	  Sock_Free(sdPtr->tcpCtrlChannel);
     }
     if (sdPtr->udpCtrlChannel != NULL) {
	  Sock_Close(sdPtr->udpCtrlChannel);
	  Sock_Free(sdPtr->udpCtrlChannel);
     }

     if (sdPtr->fd != -1) {
	  temp = shutdown(sdPtr->fd, 2);
	  close(sdPtr->fd);
     }

     sdPtr->state = SOCK_STATE_CLOSED;
     return((int)temp);

}

int Sock_Free(Socket *sdPtr)
{
     int i;

     if (sdPtr->state != SOCK_STATE_CLOSED)
	  return(SOCK_FAILURE);
     if (sdPtr->protocol == SOCK_UDP_RELIABLE) {
	  /* free the cache and all that state */
	  for (i = 0; i < SOCK_MAXWIND; i++) {
	       free(sdPtr->cache->pkts[i]);
	       free(sdPtr->cache->rcvPkts[i]);
	  }
	  free(sdPtr->cache);
     }
     free(sdPtr);
     return(SOCK_SUCCESS);
}

/*************************************************************************
  send/recv routines
  return val: SOCK_FAILURE or bytes xmitd/recvd
  *************************************************************************/

void Check_Ctrl(Socket *sdPtr)
{
     RemoteHost *rhPtr;
     fd_set fdvar;
     static struct timeval poll = {0,0};
     int temp;

     rhPtr = sdPtr->rHost;
     FD_ZERO(&fdvar);
     while (rhPtr != NULL) {
	  if (rhPtr->tcpCtrl != NULL)
	       FD_SET(rhPtr->tcpCtrl->fd, &fdvar);
	  rhPtr = rhPtr->next;
     }
     FD_SET(sdPtr->udpCtrlChannel->fd, &fdvar);
     FD_SET(sdPtr->tcpCtrlChannel->fd, &fdvar);
     if ((temp = select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
			&poll)) <= 0) {
	  dprintf(120,"Sock_Recv: no ctrl info\n");
     }
     else {
	  dprintf(112,"Sock_Recv: ctrl info temp = %d\n",temp);
	  if (FD_ISSET(sdPtr->udpCtrlChannel->fd, &fdvar))
	       Sock_RecvCtrl(sdPtr->udpCtrlChannel,sdPtr);
	  if (FD_ISSET(sdPtr->tcpCtrlChannel->fd, &fdvar))
	       /* XXXX */
	       dprintf(120,"Sock_Recv: accept new tcp ctrl\n");
	  rhPtr = sdPtr->rHost;
	  while (rhPtr != NULL) {
	       if (rhPtr->tcpCtrl != NULL)
		    if (FD_ISSET(rhPtr->tcpCtrl->fd, &fdvar))
			 Sock_RecvCtrl(rhPtr->tcpCtrl,sdPtr); 
	       rhPtr = rhPtr->next;
	  }
     }
     
}

int Sock_Recv(Socket *sdPtr, char *buffer, int length)
{
     int status;
     fd_set fdvar;
     int temp;
     static double s_i=0, t_i=0, S_i=0, T_i=0, sqrt_sum_squares=0, n=0;
     struct timeval start_tp, end_tp, diff_tp;
     struct timezone end_tzp;
     double b_i, B_i;
     
     dprintf(112, "Sock_Recv %d\n", length);
     while (1) {
		 if (sdPtr->useCtrl == SOCK_USE_CTRL)
			 Check_Ctrl(sdPtr);
		 
		 if (sdPtr->state == SOCK_STATE_CLOSED || 
			 sdPtr->state == SOCK_STATE_CLOSING)
			 return(SOCK_FD_CLOSED);
		 
		 FD_ZERO(&fdvar);
		 FD_SET(sdPtr->fd, &fdvar);
		 
		 if (sdPtr->block == SOCK_NON_BLOCK)
			 break;
		 
		 if ((temp = select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
							sdPtr->toutPtr)) > 0) {
			 break;
		 }
		 else if (temp==0) {
			 dprintf(102,"Sock_Recv: timeout\n");
			 
			 /* Send a message back to the Sender on the control channel (if one exists) */
			 /* That a timeout occurred. The Sender will use this amount to determine the */
			 /* total bandwidth */
			 if (sdPtr->useCtrl == SOCK_USE_CTRL){
				 Sock_CtrlSendAck(sdPtr, sdPtr->bytesRecvSoFar, sdPtr->rHost);
			 }
			 sdPtr->bytesRecvSoFar=0;
			 return(SOCK_TIMEOUT);
		 }
	 }

     switch (sdPtr->type) {
     case SOCK_STREAM:
	  status = Sock_RecvStream(sdPtr, buffer, length);
	  break;
     case SOCK_DGRAM:
	  if (sdPtr->protocol == SOCK_UDP_RELIABLE)
	       status = Sock_RecvReliableDgram(sdPtr, buffer, length, NULL);
	  else
	       status = Sock_RecvDgram(sdPtr, buffer, length);
	  break;
     default:
	  dprintf(101, "unknown socket type\n");
	  status = SOCK_FAILURE;
     }

	 /* Increment the count of number of bytes received so far */
	 sdPtr->bytesRecvSoFar += status;

	 /* The data was successfully received; Collect Statistics */
	 /* We calculate the average bandwidth and compute the standard deviation of the bandwidth as follows: */
	 /* Variables: t_i= time taken to complete the ith send */
	 /*            s_i= size of the ith send */
	 /*            b_i=(s_i)/(t_i) bandwidth for the ith send */
	 /*            T_i=t_i+T_(i-1)=total time for first i sends */
	 /*            S_i=s_i+S_(i-1)=total size for first i sends */
	 /*            B_i=E(b_i)=(S_i/T_i)=Average bandwidth after first i sends */
	 /*            Standard Deviation=Sum(sqrt((B_i-b_i)**2))/n */
	 
	 gettimeofday(&end_tp, &end_tzp);
	 diff_tp.tv_sec=end_tp.tv_sec-start_tp.tv_sec;
	 diff_tp.tv_usec=end_tp.tv_usec-start_tp.tv_usec;
	 if (diff_tp.tv_usec < 0) {
		 diff_tp.tv_usec += 1000000;
		 diff_tp.tv_sec -= 1;
	 }
	 
	 s_i += status;
	 t_i +=(diff_tp.tv_sec + (float) diff_tp.tv_usec/1000000.0);
	 if (s_i >= 2*sdPtr->lXmitBufSize){

		 n++;
		 b_i=(s_i*8.)/(t_i)/1000000.0;
		 T_i+=t_i;
		 S_i+=s_i;
		 B_i=S_i*8./T_i/1000000.0;
		 sqrt_sum_squares+=sqrt((B_i-b_i)*(B_i-b_i));
		 
		 sdPtr->stats.bandwidth=B_i;
		 sdPtr->stats.bandwidthAge.tv_sec=end_tp.tv_sec;
		 sdPtr->stats.bandwidthAge.tv_usec=end_tp.tv_usec;
		 sdPtr->stats.bandwidthStdDev=sqrt_sum_squares/n;
		 
		 dprintf(110, "Sock_Recv: recv %f bytes in %f secs, BW is %f Mb/sec\n", s_i, t_i, sdPtr->stats.bandwidth);
		 s_i=0;
		 t_i=0;

		 /* Check bandwidth, possibly do upcall if bandwidth has changed */
		 CHECK_BANDWIDTH(sdPtr);
	 }
	 
     return(status);
}

int Sock_RecvStream(Socket *sdPtr, char *buffer, int length)
{
     int temp;

     temp = read(sdPtr->fd, buffer, length);
     if(temp == 0) {
       if (errno == EACCES) {
	 return(SOCK_FD_CLOSED);
       }
       return(SOCK_FAILURE);
     }
     if (temp == -1)
	  dprintf(101,"Sock_recv: error in recv\n");
     if (temp != length)
	  dprintf(109, "Sock_Recv: warning short read %d read %d wanted\n",
		  temp, length);
     return(temp);
}

int Sock_RecvDgram(Socket *sdPtr, char *buffer, int length)
{
     int addrLen, temp;

     addrLen = sizeof(sdPtr->lastRSin);
     temp = recvfrom(sdPtr->fd, buffer, length, 0,
		     (struct sockaddr *)&(sdPtr->lastRSin),
		     &addrLen);
	 dprintf(101, "sdPtr->lastRSin=%x\n", sdPtr->lastRSin);
     if (temp == -1) {
	  dprintf(101,"Sock_RecvDgram: bad recvfrom\n");
	  return(SOCK_FAILURE);
     }
     if (temp != length)
	  dprintf(109, "Sock_RecvDgram: warning short read %d read %d wanted\n",
		  temp, length);
     return(temp);
}


int Sock_RecvFull(Socket *sdPtr, char *buffer, int length)
{
     int status;
     fd_set fdvar;
     int temp;
     static double s_i=0, t_i=0, S_i=0, T_i=0, sqrt_sum_squares=0, n=0;
     struct timeval start_tp, end_tp, diff_tp;
     struct timezone start_tzp, end_tzp;
     double b_i, B_i;
     
     gettimeofday(&start_tp, &start_tzp);
     
     dprintf(112, "Sock_RecvFull %d\n", length);
     
     while (1) {
		 if (sdPtr->useCtrl == SOCK_USE_CTRL)
			 Check_Ctrl(sdPtr);

		 if (sdPtr->state == SOCK_STATE_CLOSED || 
			 sdPtr->state == SOCK_STATE_CLOSING)
			 return(SOCK_FD_CLOSED);
		 
		 FD_ZERO(&fdvar);
		 FD_SET(sdPtr->fd, &fdvar);
		 
		 temp = select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
					   sdPtr->toutPtr);
		 if (temp == 0) {
			 dprintf(102,"Sock_Recv: timeout\n");
			 
			 /* Send a message back to the Sender on the control channel (if one exists) */
			 /* That a timeout occurred. The Sender will use this amount to determine the */
			 /* total bandwidth */
			 if (sdPtr->useCtrl == SOCK_USE_CTRL){
				 Sock_CtrlSendAck(sdPtr, sdPtr->bytesRecvSoFar, sdPtr->rHost);
			 }
			 sdPtr->bytesRecvSoFar=0;
			 
			 return(SOCK_TIMEOUT);
		 } else if (temp > 0) {
			 break;
		 }
	 }
	 
     switch (sdPtr->type) {
     case SOCK_STREAM:
	  status = Sock_RecvStreamFull(sdPtr, buffer, length);
	  break;
     case SOCK_DGRAM:
	  if (sdPtr->protocol == SOCK_UDP_RELIABLE || 
	      sdPtr->protocol == SOCK_UDP_REL_MULTI) {
	       dprintf(100, "reliable udp recv\n");
	       status = Sock_RecvReliableDgram(sdPtr, buffer, length, NULL);
	  }
	  else 
	       status = Sock_RecvDgramFull(sdPtr, buffer, length);
	  break;
     default:
	  dprintf(101, "unknown socket type\n");
	  status = SOCK_FAILURE;
     }

	 /* Increment the count of number of bytes received so far */
	 sdPtr->bytesRecvSoFar += status;

	 /* The data was successfully received; Collect Statistics */
	 /* We calculate the average bandwidth and compute the standard deviation of the bandwidth as follows: */
	 /* Variables: t_i= time taken to complete the ith send */
	 /*            s_i= size of the ith send */
	 /*            b_i=(s_i)/(t_i) bandwidth for the ith send */
	 /*            T_i=t_i+T_(i-1)=total time for first i sends */
	 /*            S_i=s_i+S_(i-1)=total size for first i sends */
	 /*            B_i=E(b_i)=(S_i/T_i)=Average bandwidth after first i sends */
	 /*            Standard Deviation=Sum(sqrt((B_i-b_i)**2))/n */

	 gettimeofday(&end_tp, &end_tzp);
	 diff_tp.tv_sec=end_tp.tv_sec-start_tp.tv_sec;
	 diff_tp.tv_usec=end_tp.tv_usec-start_tp.tv_usec;
	 if (diff_tp.tv_usec < 0) {
		 diff_tp.tv_usec += 1000000;
		 diff_tp.tv_sec -= 1;
	 }
	 s_i += length;
	 t_i +=(diff_tp.tv_sec + (float) diff_tp.tv_usec/1000000.0);
	 if (s_i >= 3*sdPtr->lXmitBufSize){
		 n++;
		 b_i=(s_i*8.)/(t_i)/1000000.0;
		 T_i+=t_i;
		 S_i+=s_i;
		 B_i=S_i*8./T_i/1000000.0;
		 sqrt_sum_squares+=sqrt((B_i-b_i)*(B_i-b_i));
		 
		 sdPtr->stats.bandwidth=B_i;
		 sdPtr->stats.bandwidthAge.tv_sec=end_tp.tv_sec;
		 sdPtr->stats.bandwidthAge.tv_usec=end_tp.tv_usec;
		 sdPtr->stats.bandwidthStdDev=sqrt_sum_squares/n;
		 
		 dprintf(110, "Sock_Recvfull: sent %f bytes in %f secs, BW is %f Mb/sec\n", s_i, t_i, sdPtr->stats.bandwidth);
		 s_i=0;
		 t_i=0;

		 /* Check bandwidth, possibly do upcall if bandwidth has changed */
		 CHECK_BANDWIDTH(sdPtr);
	 }
     return(status);
}


/*
 *                      M R E A D
 *
 * This function performs the function of a read(II) but will
 * call read(II) multiple times in order to get the requested
 * number of characters.  This can be necessary because
 * network connections don't deliver data with the same
 * grouping as it is written with.  Written by Robert S. Miles, BRL.
 */
int Sock_RecvStreamFull(Socket *sdPtr, register char *buffer, int length)
{
     register unsigned     count = 0;
     register int          nread;
     fd_set fdvar;

     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);

     do {
	  if (select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
		     sdPtr->toutPtr) == 0) {
	       dprintf(102,"Sock_Recv: timeout\n");
	       return(SOCK_TIMEOUT);
	  }
	  nread = read(sdPtr->fd, buffer, length-count);
	  if(nread < 0)  {
	       dprintf(101,"Sock_RecvFull: error in read\n");
	       return(SOCK_FAILURE);
	  }
	  if(nread == 0) {
	    if (errno == EACCES) {
	      return(SOCK_FD_CLOSED);
	    }
	    return(SOCK_FAILURE);
	  }
	  count += (unsigned)nread;
	  buffer += nread;
     } while(count < length);
     
     return((int)count);
}

int
Sock_RecvDgramFull(Socket *sdPtr, char *buffer, int length)
{
     fd_set fdvar;
     int addrLen;
     register unsigned     count = 0;
     register int          nread;

     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);

     dprintf(102, "recvdgramfull %d\n", length);
     
     do {
          if (select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
                     sdPtr->toutPtr) == 0) {
               dprintf(102,"Sock_RecvDgramFull: timeout\n");
               return(SOCK_TIMEOUT);
          }
          addrLen = sizeof(sdPtr->lastRSin);
          nread=recvfrom(sdPtr->fd,buffer,length,0,
                         (struct sockaddr *)&(sdPtr->lastRSin),
                         &addrLen);
	  dprintf(102, "\tnread %d\n", nread);
          if (nread == -1) {
               dprintf(10, "Sock_RecvDgramFull: bad recvfrom");
               return(SOCK_FAILURE);
          }
          if (nread == 0)
               return((int)count);
          count += (unsigned)nread;
          buffer += nread;
     } while(count < length);

     return((int)count);
}

int
Sock_RecvReliableDgram(Socket *sdPtr, char *buffer, int length, 
		       timev *timeout)
{
     int nread;
     SockCache *cache = sdPtr->cache;
     SockPkt *pkt = cache->rcvPkts[(cache->lastRead + 1) % SOCK_MAXWIND];

     if (pkt->validFlag == SOCK_UNAVAIL) {
	  dprintf(155, "read %d from rcvbuf\n", pkt->sendHdr.seq);
	  ++cache->lastRead;
	  pkt->validFlag = SOCK_AVAIL;		    
	  memcpy(buffer, pkt->buf, 
		 (size_t) (nread = SOCK_MIN(length, pkt->sendHdr.size)));
	  if (length != pkt->sendHdr.size)
	       dprintf(110, "incomplete recv: length %d, read %d\n");
	  if (pkt->sendHdr.pktFlags & SOCK_ACK)
	       Sock_ProcessAck(sdPtr, pkt->sendHdr.ack, pkt->sendHdr.ackBits);
	  free((void *) pkt->buf);
	  return nread;
     }
     return Sock_ReadNetPkt(sdPtr, buffer, length, timeout);
}

int Sock_ReadNetPkt(Socket *sdPtr, char *buffer, int length, timev *timeout)
{
     fd_set fdvar;
     struct iovec iov[2];
     SockCache *cache = sdPtr->cache;
     int hdrSize = sizeof(SockSendHdr), totalLen;
     char *hdrBuf = (char *) Sock_Malloc(hdrSize);
     SockPkt *pkt = cache->rcvPkts[(cache->lastRead + 1) % SOCK_MAXWIND];
     SockSendHdr *recvHdr;

     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);
     if (select(FD_SETSIZE, &fdvar, (fd_set *)0, (fd_set *)0,
		timeout) == 0)
	  return SOCK_TIMEOUT;
     iov[0].iov_base = (caddr_t) hdrBuf;
     iov[0].iov_len = hdrSize;
     iov[1].iov_base = (caddr_t) buffer;
     iov[1].iov_len = length;
	  
     while (1) {
	  if ((totalLen = readv(sdPtr->fd, &iov[0], 2)) < hdrSize)
	       return SOCK_FAILURE;
	  recvHdr = (SockSendHdr *) hdrBuf;
	  recvHdr->seq = ntohl(recvHdr->seq);
	  recvHdr->ack = ntohl(recvHdr->ack);
	  recvHdr->ackBits = ntohl(recvHdr->ackBits);
	  recvHdr->size = ntohl(recvHdr->size);
	  
	  if (totalLen - hdrSize != recvHdr->size) {
	       /* error in readv */
	       dprintf(119, "ReadNetPkt: total %d, hdrsize %d, length %d\n",
		       totalLen, hdrSize, length);
	       return SOCK_FAILURE;
	  }

	  if (recvHdr->pktFlags & SOCK_FIN) {
	       Sock_Close(sdPtr);
	       Sock_Free(sdPtr);
	       free((void *) hdrBuf);
	       return 0;	/* ??? */
	  }

	  if (recvHdr->pktFlags & SOCK_ACK) {
	       Sock_ProcessAck(sdPtr, recvHdr->ack, recvHdr->ackBits);
	       if (recvHdr->size == 0) /* pure ack */
		    break;	
	  }
	  
	  if (recvHdr->seq == cache->lastRead + 1) { /* common case */
	       ++cache->lastRead;
	       do {
		    /*cache->ackMask >> 1;*/ /* doesn't work under Solaris */
		    cache->ackMask /= 2;
		    ++cache->ackBase;
	       } while (cache->ackMask % 2);
	       if (Sock_SendAck(sdPtr, SOCK_DELACK) == SOCK_FAILURE)
		    dprintf(110, "Error sending ack\n");
	       break;

	  } else if (recvHdr->seq > cache->lastRead) {
	       int index = recvHdr->seq % SOCK_MAXWIND;
	       int diff;

	       dprintf(155, "out of seq %d, lastread %d\n", recvHdr->seq, cache->lastRead);
	       pkt = cache->rcvPkts[index];
	       if (pkt->validFlag & SOCK_UNAVAIL) {
		    /* drop the packet, don't generate ack, read again.
		       actually, this couldn't possibly have happened. */
		    dprintf(110, "readnetpkt: inconsistent state\n");
		    continue;
	       }
	       /* insert pkt in rcvPkts cache (recvHdr->size > 0) */
	       pkt->validFlag = SOCK_UNAVAIL;
	       pkt->buf = (char *) Sock_Malloc(recvHdr->size); /* XXX */
	       memcpy(pkt->buf, buffer, recvHdr->size);
	       pkt->sendHdr.seq = recvHdr->seq;
	       pkt->sendHdr.ack = recvHdr->ack;
	       pkt->sendHdr.size = recvHdr->size;
	       
	       diff = recvHdr->seq - cache->ackBase;
	       cache->ackMask |= (1 << (diff - 1));
	       /* send an ack with ack field set to recvHdr->seq */
	       if (Sock_SendAck(sdPtr, SOCK_NODELACK) == SOCK_FAILURE)
		    dprintf(110, "Error sending ack\n");
	  } else
	       /* sender retransmitted packet, maybe ack got lost */
	       Sock_SendAck(sdPtr, SOCK_NODELACK);
     }
     free((void *) hdrBuf);
     return(recvHdr->size);
}

int
Sock_SendAck(Socket *sdPtr, int delack)
{
     SockSendHdr sendHdr;
     char *buffer = (char *) &sendHdr;
     SockCache *cache = sdPtr->cache;
     int status;

     if (delack == SOCK_DELACK)	/* generate a delayed ack */
	  if (++cache->delack != sdPtr->delack)
	       return SOCK_SUCCESS;

     cache->delack = 0; /* reset number of delayed ack waits */
     if (cache->ackMask != 0)
	  dprintf(150, "sent ack %d mask %x\n", cache->ackBase, cache->ackMask);
     else
	  dprintf(155, "sent ack %d mask %x\n", cache->ackBase, cache->ackMask);
     sendHdr.pktFlags = SOCK_ACK;
     sendHdr.seq = htonl(++cache->lastSent);
     sendHdr.ack = htonl(cache->ackBase); /* cumulative ack */
     sendHdr.ackBits = htonl(cache->ackMask); /* bit pattern of holes */
     sendHdr.size = 0;
     
     /* 
      * If reliable multicast, use Sock_SendPkt to send ack, 
      * otherwise simply use sendto ('truly' connectioneless protocol.
      */
     if (sdPtr->protocol == SOCK_UDP_REL_MULTI) {
	  SockPkt *pkt = Sock_MakePkt(buffer, cache->lastSent, 
				       cache->ackBase, cache->ackMask, 0);
	  pkt->sendHdr.pktFlags = SOCK_ACK;
	  return Sock_SendPkt(sdPtr, pkt);
     }

     if ((status = Sock_SendDgram(sdPtr, buffer, sizeof(SockSendHdr))) == 
	 SOCK_FAILURE)
	  dprintf(110, "error in sending ack, status %d\n", status);
     return status;
     /* Sock_SendPkt needs a connect done from the receiver as well
     return Sock_SendPkt(sdPtr, pkt);
     */
}
     
inline void 
Sock_FreePkts(SockCache *cache, int index, SockSeq pktSeq, SockSeq baseAck)
{
     SockSeq seq;
     int i = index;
     /* cleans whole cache each time */
     do {
	  seq = cache->pkts[i]->localHdr.seq;
	  if (cache->pkts[i]->validFlag == SOCK_UNAVAIL &&
	      (seq <= baseAck || seq == pktSeq)) {
	       dprintf(155, "freeing %d at %d\n", seq, index);
	       cache->pkts[i]->validFlag = SOCK_AVAIL;
	       free(cache->pkts[i]->buf);
	  }
	  i = (i + 1) % SOCK_MAXWIND;
     } while (i != index);
}

int 
Sock_ComputeRtt(SockCache *cache, SockSeq baseAck)
{
     int index = baseAck % SOCK_MAXWIND;
     SockPkt *pkt = cache->pkts[index];
     int rtt;			/* rtt estimate for current packet */
     timev curTime;

     if (pkt->validFlag == SOCK_UNAVAIL && pkt->localHdr.seq == baseAck) {
	  gettimeofday(&curTime, NULL);
	  rtt = Sock_TimeDiff(curTime, pkt->localHdr.sndTime);
	  /* XXX optimize this later */
	  cache->srtt = SOCK_RTT_MULTIPLIER * rtt + 
	       (1 - SOCK_RTT_MULTIPLIER) * cache->srtt;
     }
     return cache->srtt;
}


int 
Sock_TimeDiff(timev t1, timev t2)
{
     return ((t1.tv_sec - t2.tv_sec)*1000000 + (t1.tv_usec - t2.tv_usec));
}

int
Sock_ProcessAck(Socket *sdPtr, SockSeq baseAck, u_int ackMask)
{
     int index = baseAck % SOCK_MAXWIND, forceRtx = 0, rtxIndex;
     SockCache *cache = sdPtr->cache;
     SockSeq lastAck, pktSeq = baseAck;

     if (ackMask != 0)
	  dprintf(150, "ackbase %d, mask %x\n", baseAck, ackMask);
     else
	  dprintf(155, "ackbase %d, mask %x\n", baseAck, ackMask);
     if (ackMask == 0) {
	  if (cache->lastAck < baseAck)
	       Sock_ComputeRtt(cache, baseAck);
	  cache->lastAck = baseAck;
	  Sock_FreePkts(cache, index, pktSeq, baseAck);
	  return SOCK_SUCCESS;
     }

     /* ackMask != 0; guaranteed that there is a "hole" */
     lastAck = baseAck;
     rtxIndex = (baseAck + 1) % SOCK_MAXWIND;
     if (ackMask & SOCK_FULLMASK) {
	  dprintf(155, "full mask\n");
	  /* current window xmitted, so can rexmit even if done once */
	  forceRtx = 1;
     }
     /* clean cache of packets <= baseAck */
     Sock_FreePkts(cache, index, baseAck, baseAck); 
     /* now clean cache of higher number packets using ackmask */
     while (ackMask) {
	  SockPkt *pkt = cache->pkts[index];
	  index = (index + 1) % SOCK_MAXWIND;
	  ++pktSeq;
	  if (ackMask % 2) 	/* packet has reached receiver */
	       if (pkt->validFlag == SOCK_UNAVAIL && 
		   pkt->localHdr.seq == pktSeq) {
		    dprintf(150, "free %d at %d\n", pkt->localHdr.seq, index);
		    pkt->validFlag = SOCK_AVAIL;
		    free(pkt->buf);
	       }
	  ++lastAck;
	  ackMask /= 2;		/* bit shift breaks under Solaris? */
     }     
     
     if (cache->lastAck < lastAck)
	  cache->lastAck = lastAck;

     /* 
      * Retransmit packet if a 'hole' is present in the ack sequence, i.e, 
      * if there is an unack'd packet and a later one has been ack'd.
      */
     if (cache->pkts[rtxIndex]->validFlag == SOCK_UNAVAIL) {
       if (cache->pkts[rtxIndex]->localHdr.numRxmit == 0 || forceRtx) {
	 dprintf(155, "rtx pkt %d at %d\n", cache->pkts[rtxIndex]->localHdr.seq, rtxIndex);
	 return Sock_RexmtPkt(sdPtr, cache->pkts[rtxIndex]);
       }
       else 
	 return SOCK_UNAVAIL;
     }
     return SOCK_FAILURE;
}

/* Send routines */
int
Sock_Send(Socket *sdPtr, char *buffer, int length)
{
     int status;
     struct timeval start_tp, end_tp, diff_tp;
     struct timezone start_tzp, end_tzp;
     static double T_i=0, S_i=0, s_i=0, sqrt_sum_squares=0; 
     static double n=0, t_i=0;
     double b_i, B_i;
     int srtt, rttvar;
	 
	 gettimeofday(&start_tp, &start_tzp);
	 
     if (sdPtr->useCtrl == SOCK_USE_CTRL)
	  Check_Ctrl(sdPtr);

     if (sdPtr->state == SOCK_STATE_CLOSED ||
	 sdPtr->state == SOCK_STATE_CLOSING)
               return(SOCK_FD_CLOSED);

     if (sdPtr->xmitRate > 0)
	  Sock_DelayPacket(sdPtr, length);

     if (sdPtr->berState.ErrorGen != NULL) 
	  (sdPtr->berState.ErrorGen)(sdPtr, buffer, length);

     switch (sdPtr->type) {
     case SOCK_STREAM:
	  status = Sock_SendStream(sdPtr, buffer, length);
	  break;
     case SOCK_DGRAM:
	  if (sdPtr->protocol == SOCK_UDP_RELIABLE || 
	      sdPtr->protocol == SOCK_UDP_REL_MULTI)
	       status = Sock_SendReliableDgram(sdPtr, buffer, length);
	  else
	       status = Sock_SendDgram(sdPtr, buffer, length);
	  break;
     default:
	  dprintf(101, "unknown socket type\n");
	  status = SOCK_FAILURE;
     }

	 /* If there weren't any outstanding bytes previously, start a timer */
	 if (sdPtr->bytesSentSoFar == 0){
			 gettimeofday(&sdPtr->start_tp, &sdPtr->start_tzp);
	 }	

	 sdPtr->bytesSentSoFar += status;
	 
     if (status < 0) {
	  sdPtr->lastPktSize = 0;
	 } else {
		 /* The data was successfully sent; Collect Statistics */

		 /* We calculate the average bandwidth and compute the standard deviation of the bandwidth as follows: */
		 /* Variables: t_i= time taken to complete the ith send */
		 /*            s_i= size of the ith send */
		 /*            b_i=(s_i)/(t_i) bandwidth for the ith send */
		 /*            T_i=t_i+T_(i-1)=total time for first i sends */
		 /*            S_i=s_i+S_(i-1)=total size for first i sends */
		 /*            B_i=E(b_i)=(S_i/T_i)=Average bandwidth after first i sends */
		 /*            Standard Deviation=Sum(sqrt((B_i-b_i)**2))/n */

		 gettimeofday(&end_tp, &end_tzp);
		 diff_tp.tv_sec=end_tp.tv_sec-start_tp.tv_sec;
		 diff_tp.tv_usec=end_tp.tv_usec-start_tp.tv_usec;
		 if (diff_tp.tv_usec < 0) {
			 diff_tp.tv_usec += 1000000;
			 diff_tp.tv_sec -= 1;
		 }

		 s_i += length;
		 t_i +=(diff_tp.tv_sec + (float) diff_tp.tv_usec/1000000.0);
		 if (s_i >= 3*sdPtr->lXmitBufSize){
			 n++;
			 b_i=(s_i*8.)/(t_i)/1000000.0;
			 T_i+=t_i;
			 S_i+=s_i;
			 B_i=S_i*8./T_i/1000000.0;
			 sqrt_sum_squares+=sqrt((B_i-b_i)*(B_i-b_i));
			 
			 sdPtr->stats.bandwidth=B_i;
			 sdPtr->stats.bandwidthAge.tv_sec=end_tp.tv_sec;
			 sdPtr->stats.bandwidthAge.tv_usec=end_tp.tv_usec;
			 sdPtr->stats.bandwidthStdDev=sqrt_sum_squares/n;
			 
			 dprintf(110, "Sock_Send: sent %f bytes in %f secs, BW is %f Mb/sec, b_i %f var %f B_i %f s_i %f t_i %f\n", S_i, T_i, sdPtr->stats.bandwidth, b_i, sdPtr->stats.bandwidthStdDev, B_i, s_i, t_i);
			 s_i=0;
			 t_i=0;

			 /* Check bandwidth, possibly do upcall if bandwidth has changed */
			 CHECK_BANDWIDTH(sdPtr);

			 /* Check the tcp srtt and rttvar too */
			 if (sdPtr->protocol==SOCK_TCP) {
				 srtt=Sock_GetTCPSrtt(sdPtr);
				 rttvar=Sock_GetTCPRttvar(sdPtr);
				 dprintf(110, "Sock_Send: srtt=%d usecs, rttvar=%d usecs\n", srtt, rttvar);
			 }
		 }
	 }
     return(status);
}

int 
Sock_SendStream(Socket *sdPtr, char *buffer, int length)
{
     int temp;
     if ((temp = send(sdPtr->fd, buffer, length, sdPtr->lFlags)) == -1) {
	  if (errno == EWOULDBLOCK)
	       return(SOCK_FAILURE);
	  dprintf(110, "Sock_send: error in send\n");
	  if (errno == EPIPE) {
	       sdPtr->state = SOCK_STATE_CLOSED;
	       return(SOCK_FD_CLOSED);
	  }
	  return(SOCK_FAILURE);
     }
	 
     return(temp);
}

/* send length bytes from buffer to rsin (faster) */
int Sock_SendDgram(Socket *sdPtr, char *buffer, int length)
{
     int temp;
     fd_set fdvar;

     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);
     select(FD_SETSIZE, (fd_set *)0,  &fdvar, (fd_set *)0, NULL);
     while (1) {
	  temp = sendto(sdPtr->fd, buffer, length, sdPtr->lFlags,
			(struct sockaddr *)&(sdPtr->rSin), 
			sizeof(sdPtr->rSin));
	  if (temp < 0) {
	       if (errno == ENOBUFS)
		    continue;
	       dprintf(110, "Sock_SendDgram: error %d in sendto\n", errno);
	       if (errno == EPIPE) {
		    sdPtr->state = SOCK_STATE_CLOSED;
		    return(SOCK_FD_CLOSED);
	       }
	       return(SOCK_FAILURE);
          }
	  return temp;
     }
}


/* make a packet to put in the socket cache */
SockPkt *
Sock_MakePkt(char *buffer, SockSeq seq, SockSeq ack, u_int ackBits, 
	     size_t length)
{
     SockPkt *pkt = (SockPkt *) malloc(sizeof(SockPkt));

     pkt->localHdr.seq = seq;
     pkt->localHdr.ack = ack;
     pkt->localHdr.size = length;
     pkt->localHdr.numRxmit = 0;
     gettimeofday(&(pkt->localHdr.sndTime), NULL);

     pkt->sendHdr.seq = htonl(seq);
     pkt->sendHdr.ack = htonl(ack);
     pkt->sendHdr.ackBits = htonl(ackBits);
     pkt->sendHdr.size = htonl(length);
     pkt->sendHdr.pktFlags = 0;

     pkt->buf = (char *) Sock_Malloc(length);
     pkt->buf = memcpy(pkt->buf, buffer, length);
     return pkt;
}

/* insert packet into cache and keep it there until we get an ack for it */
int
Sock_InsertPkt(SockCache *cache, SockPkt *pkt)
{
     int index = cache->lastSent % SOCK_MAXWIND;

     if (cache->pkts[index]->validFlag == SOCK_AVAIL) {
	  /* this place is available in the cache, so insert packet here */
	  pkt->validFlag = SOCK_UNAVAIL;
	  cache->pkts[index] = pkt;
	  return SOCK_SUCCESS;
     } else			/* return -1 to let caller block */
	  return SOCK_FAILURE;
}

int 
Sock_SendPkt(Socket *sdPtr, SockPkt *pkt)
{
     struct iovec iov[2];
     int size, writeErr;
     fd_set sfdvar;

     if (sdPtr->protocol == SOCK_UDP_REL_MULTI) {
	  FD_ZERO(&sfdvar);
	  FD_SET(sdPtr->sfd, &sfdvar);
	  select(FD_SETSIZE, (fd_set *)0,  &sfdvar, (fd_set *)0, NULL);
     }

     iov[0].iov_base = (char *)&(pkt->sendHdr);
     iov[0].iov_len = sizeof(SockSendHdr);
     iov[1].iov_base = pkt->buf;
     iov[1].iov_len = pkt->localHdr.size;

     size = pkt->localHdr.size;
     gettimeofday(&(pkt->localHdr.sndTime), NULL);
     
     if (sdPtr->protocol == SOCK_UDP_RELIABLE)
       writeErr = writev(sdPtr->fd, &iov[0], 2);
     else			/* SOCK_UDP_REL_MULTI */
       writeErr = writev(sdPtr->sfd, &iov[0], 2);
     if (writeErr != sizeof(SockSendHdr) + size) {
       if (writeErr < 0)
	 printf("SendPkt: writeErr %d, errno %d\n", writeErr, errno);
       dprintf(110, "Sock_SendPkt: error in writev");
       if (errno == EPIPE) {
	 sdPtr->state = SOCK_STATE_CLOSED;
	 return(SOCK_FD_CLOSED);
       }
       return(SOCK_FAILURE);
     }
     dprintf(155, "sent %d\n", pkt->localHdr.seq);
     return(size);
}

/* 
 * Send datagrams reliably. The data to be sent is in char *buffer and has 
 * of 'length' bytes.
 */
int
Sock_SendReliableDgram(Socket *sdPtr, char *buffer, int length)
{
     int index;
     fd_set fdvar;
     SockCache *cache;
     SockPkt *p;
     timev *timeout;
     
     FD_ZERO(&fdvar);
     FD_SET(sdPtr->fd, &fdvar);
     select(FD_SETSIZE, (fd_set *)0,  &fdvar, (fd_set *)0, NULL);

     cache = sdPtr->cache;
     p = Sock_MakePkt(buffer, ++cache->lastSent, 0, 0, length);
     index = cache->lastSent % SOCK_MAXWIND;

     if (Sock_InsertPkt(sdPtr->cache, p) == SOCK_FAILURE)
	  while (cache->pkts[index]->validFlag == SOCK_UNAVAIL) {
	       /* 
		* Can't send because this space is filled up, so try receiving 
		* instead and hope that we get an ack soon to free up the slot.
		*/
	       timeout = UtimeToTval(2*cache->srtt);
	       dprintf(155, "rtt %d, sec %d, usec %d\n", cache->srtt, timeout->tv_sec, timeout->tv_usec);
	       if (Sock_RecvReliableDgram(sdPtr, buffer, sizeof(SockSendHdr),
					   timeout) == SOCK_TIMEOUT)
		    Sock_RexmtPkt(sdPtr, cache->pkts[index]);
	       if (Sock_InsertPkt(sdPtr->cache, p) != SOCK_FAILURE)
		    break;
	  }
     return (Sock_SendPkt(sdPtr, p)); /* send only if successfully buffered */
}

timev *
UtimeToTval(int microsecs)
{
     timev *tv;

     tv = (timev *) Sock_Malloc(sizeof (timev));
     tv->tv_usec = microsecs%1000000;
     tv->tv_sec = microsecs/1000000;
     return tv;
}

int 
Sock_RexmtPkt(Socket *sdPtr, SockPkt *pkt)
{
     dprintf(140, "rexmit %d\n", pkt->localHdr.seq);
     ++pkt->localHdr.numRxmit;
     return Sock_SendPkt(sdPtr, pkt);
}

int
Sock_ReadInt(Socket *sdPtr, int *i)
{
     int status;
     
     status = Sock_RecvFull(sdPtr, (char *)i, sizeof(int));
     *i = ntohl(*i);
     return(status);
}

int
Sock_SendInt(Socket *sdPtr, int i)
{
     i = htonl(i);
     return(Sock_Send(sdPtr, (char *)&i, sizeof(int)));
}

int Sock_ReadChar(Socket *sdPtr, char *c)
{
     return(Sock_RecvFull(sdPtr, c, sizeof(char)));
}

int Sock_SendChar(Socket *sdPtr, char c)
{
     return(Sock_Send(sdPtr, (char *)&c, sizeof(char)));
}

int Sock_ReadLong(Socket *sdPtr, long *l)
{
     int status;
     
     status = Sock_RecvFull(sdPtr, (char *)l, sizeof(long));
     *l = ntohl(*l);
     return(status);
}

int Sock_SendLong(Socket *sdPtr, long l)
{
     l = htonl(l);
     return(Sock_Send(sdPtr, (char *)&l, sizeof(long)));
}

int Sock_ReadString(Socket *sdPtr, char *s)
{
     const int startingBufSize = 100;
     long bytesRead, currentRead;
     static char currentBufSize = -1;
     static char* buffer = NULL;

     if ((buffer = (char *)malloc(startingBufSize)) == NULL) {
          dprintf(110, "Sock_ReadString: Couldn't allocate initial buffer");
          return(SOCK_FAILURE);
     }
     currentBufSize = startingBufSize;
     bytesRead = 0;
     do {
          currentRead += Sock_RecvFull(sdPtr, buffer+bytesRead, sizeof(char));
          if (currentRead != sizeof(char)) {
               return(SOCK_FAILURE);
          }
          bytesRead += currentRead;
          if (bytesRead == currentBufSize) {
               /* grow the buffer */
               buffer = (char *)realloc(buffer, currentBufSize * 2);
               currentBufSize *= 2;
          }
     } while (buffer[bytesRead] != '\0');
     
     strcpy(s, buffer);
     free(buffer);
     return((int)bytesRead);
}

int Sock_SendString(Socket *sdPtr, char *s)
{
     return(Sock_Send(sdPtr, (char *)s, strlen(s)));
}

/*************************************************************************
  get/set routines
  *************************************************************************/

int Sock_SetOption(Socket *sdPtr, OPTIONS option, int value)
{
     int status=SOCK_SUCCESS;

     switch (option) {
#ifdef MULTICAST
     case TTL:
     {
	  int j = sizeof(value);
	  if (setsockopt(sdPtr->fd, IPPROTO_IP, IP_TTL,
			 (char *)&value,j) < 0) {
	       dprintf(110, "Sock_Socket: ip_ttl");
	       status=SOCK_FAILURE;
	  } else 
	       sdPtr->ttl = value;
     }
	  break;
#endif
#ifdef TOS	 
     case IPTOS:
     {
	  int j = sizeof(value);
	  if (setsockopt(sdPtr->fd, IPPROTO_IP, IP_TOS,
			 (char *)&value,j) < 0) {
	       dprintf(110, "Sock_Socket: ip_tos");
	       status=SOCK_FAILURE;
	  }
     }
	  break;
#endif
     case SEND_FLAG:
	  sdPtr->lFlags = value;
	  break;
     case MSS:
     {
	  int i, j = sizeof(value);
	  struct protoent *proto = getprotobyname("tcp");
	  if (sdPtr->protocol==SOCK_TCP) {
	       if (value < 500)
		    dprintf(109,"Sock_Setopt: low mss\n");
	       if (setsockopt(sdPtr->fd,proto->p_proto, 
			      TCP_MAXSEG,(char *)&value,j) < 0)
		    dprintf(110, "Sock_SetOpt: set mss");
	       if (getsockopt(sdPtr->fd,proto->p_proto, 
			      TCP_MAXSEG,(char *)&i,&j) < 0)
		    dprintf(110, "Sock_SetOpt: get mss");
	       dprintf(109,"Sock_Setopt: set mss to %d\n", i);
	  }
     }
	  break;
     case NODELAY: 
     {
	  int i,j = sizeof(i);
	  struct protoent *proto = getprotobyname("tcp");
	  i=1;
	  if (sdPtr->protocol==SOCK_TCP) {
	       if (value)
		    i = 1;
	       else 
		    i = 0;
	       if (setsockopt(sdPtr->fd,proto->p_proto, 
			      TCP_NODELAY,(char *)&i,j) < 0)
		    dprintf(110, "Sock_Socket: tcp_nodelay");
	  }
     }
	  break;
#ifdef TCPSTATS
     case TCP_STATS:
     {
	  int j = sizeof(value);
	  dprintf(110, "tcp stats");
	  if (setsockopt(sdPtr->fd, IPPROTO_TCP,
			 TCP_ENABLE_STATS, (char *)&value, j) < 0)
	       dprintf(110, "Sock_Socket: tcp_stats");
     }
	  break;
#endif
     case PROTOCOL:
          dprintf(101, "Sock_SetOption: not implemented\n");
          status=SOCK_FAILURE;
          break;
     case TYPE:
          dprintf(101, "Sock_SetOption: not implemented\n");
          status=SOCK_FAILURE;
          break;
     case CLEAR_SOCKET_FLAG:
     {
          int val;
          val = fcntl(sdPtr->fd, F_GETFL, 0);
          if (val < 0)
               status = SOCK_FAILURE;
          else {
               val &= ~value;
               if (fcntl(sdPtr->fd, F_SETFL, val) < 0)
                    status = SOCK_FAILURE;
          }
     }
	  break;
     case SET_SOCKET_FLAG:
     {
          int val;
          val = fcntl(sdPtr->fd, F_GETFL, 0);
          if (val < 0)
               status = SOCK_FAILURE;
          else {
               val |= value;
               if (fcntl(sdPtr->fd, F_SETFL, val) < 0)
                    status = SOCK_FAILURE;
          }
     }
          break;
     case BUFFER_SIZE:
     {
          int k=0,l,m=0,n;

          l = sizeof(k);
          n = sizeof(m);
          setsockopt(sdPtr->fd, SOL_SOCKET,SO_SNDBUF,(char*)&value,
                     sizeof(value));
          getsockopt(sdPtr->fd,SOL_SOCKET,SO_SNDBUF,(char*)&k,&l);
          setsockopt(sdPtr->fd,SOL_SOCKET,SO_RCVBUF,(char*)&value,
                     sizeof(value));
          getsockopt(sdPtr->fd,SOL_SOCKET,SO_RCVBUF,(char*)&m,&n);
          dprintf(109, "Sock_setbuffersize: send buf %d, recv buf %d\n", k, m);
          sdPtr->lRecvBufSize = m;
          sdPtr->lXmitBufSize = k;
          if ((k == value) && (m == value))
               status = SOCK_SUCCESS;
          else
               status = SOCK_FAILURE;
     }
          break;
     case TIMEOUT:
          if (value == SOCK_NO_TIMEOUT) {
               sdPtr->toutPtr = NULL;
               dprintf(109, "no timeouts\n");
          }
          else {
               sdPtr->toutPtr = &(sdPtr->timeout);
               sdPtr->timeout.tv_sec = value/1000000;
               sdPtr->timeout.tv_usec = value -
                    (sdPtr->timeout.tv_sec * 1000000);
               dprintf(109, "timeout set to %d sec %d usec\n",
                       sdPtr->timeout.tv_sec, sdPtr->timeout.tv_usec );
          }
          break;
     case USE_CTRL_CHANNEL:
          sdPtr->useCtrl = value;
          break;
     case XMIT_RATE:
          sdPtr->xmitRate = value;
          break;
     case COMPATIBILITY:
          sdPtr->compatible = value;
          break;
     case BLOCKING:
          if (value==1) {
               if ((status = Sock_ClearFlag(sdPtr, O_NDELAY)) != SOCK_FAILURE)
		    sdPtr->block = SOCK_BLOCK;
          }
          else {
               if ((status = Sock_SetFlag(sdPtr, O_NDELAY)) != SOCK_FAILURE)
		    sdPtr->block = SOCK_NON_BLOCK;
          }
          break;
     case MOBILE:
          if (value==0)
               sdPtr->mobile = SOCK_NOT_MOBILE;
          else {
               sdPtr->mobile = SOCK_MOBILE;
               sdPtr->useCtrl = SOCK_USE_CTRL;
          }
          break;
     case BROADCAST:
          if (value==0) {
               Port port;
               
               if (sdPtr->protocol == SOCK_TCP)
                    return(SOCK_FAILURE);
               if (sdPtr->broadcast == SOCK_NOT_BROADCAST)
                    return(SOCK_SUCCESS);
               if (!((sdPtr->state==SOCK_STATE_CONNECTED) ||
                     (sdPtr->state==SOCK_STATE_ACCEPTED)))
                    return(SOCK_SUCCESS);
               if (sdPtr->rHost == NULL)
                    return(SOCK_FAILURE);
               port = Sock_GetRemotePort(sdPtr);
               status=Sock_SetRemoteByName(sdPtr, sdPtr->rHost->remoteName, 
					   port);
               sdPtr->broadcast = SOCK_NOT_BROADCAST;
          }
          else {
               Address *rSinPtr = (Address *) Sock_Malloc(sizeof (Address));
               char *ipAddr, *newIPAddr;
               Port port;

               if (sdPtr->protocol == SOCK_TCP)
                    return(SOCK_FAILURE);
               if (sdPtr->broadcast == SOCK_BROADCAST)
                    return(SOCK_SUCCESS);
               sdPtr->broadcast = SOCK_BROADCAST;
               if (!((sdPtr->state==SOCK_STATE_CONNECTED) ||
                     (sdPtr->state==SOCK_STATE_ACCEPTED)))
                    return(SOCK_SUCCESS);
               /* XXXX fix to get correct addr */
               Sock_GetRemoteAddr(sdPtr, rSinPtr);
               port = Sock_GetRemotePort(sdPtr);
               ipAddr = inet_ntoa(rSinPtr->sin_addr);
               newIPAddr = Sock_BroadcastAddr(ipAddr);
               status = Sock_SetRemoteByName(sdPtr, newIPAddr, port);
          }
          break;
     case DELACK:
	  sdPtr->delack = value;
	  break;
     case ACCEPT_FLAG:
	  sdPtr->acceptFlag = 1;
	  sdPtr->lSin.sin_addr.s_addr = (u_long) htonl((u_long) value);
	  break;
     default:
          dprintf(101, "Sock_SetOption: invalid option %d\n", option);
          status = SOCK_FAILURE;
     }
     return(status);
}

int Sock_GetOption(Socket *sdPtr, OPTIONS option)
{
     int value;

     switch (option) {
#ifdef MULTICAST
     case TTL:
     {
	  int j = sizeof(value);
	  if (getsockopt(sdPtr->fd, IPPROTO_IP, IP_TTL,
			 (char *)&value,&j) < 0) {
	       dprintf(110, "Sock_Socket: ip_ttl");
	       value=SOCK_FAILURE;
	  }
     }
	  break;
#endif
#ifdef TOS	 
     case IPTOS:
     {
	  int j = sizeof(value);
	  if (getsockopt(sdPtr->fd, IPPROTO_IP, IP_TOS,
			 (char *)&value,&j) < 0) {
	       dprintf(110, "Sock_Socket: ip_tos");
	       value=SOCK_FAILURE;
	  }
     }
	  break;
#endif
     case SEND_FLAG:
	  value = sdPtr->lFlags;
	  break;
     case NODELAY:
     {
	  int j = sizeof(value);
	  if (getsockopt(sdPtr->fd,IPPROTO_TCP,
			 TCP_NODELAY,(char *)&value,&j) < 0)
		    dprintf(110, "Sock_Socket: tcp_nodelay");
     }
	  break;
#ifdef TCPSTATS
     case TCP_STATS:
     {
	  int j = sizeof(value);
	  if (getsockopt(sdPtr->fd, IPPROTO_TCP,
			 TCP_ENABLE_STATS, (char *)&value, &j) < 0)
	    dprintf(110, "Sock_Socket: tcp_stats");
     }
     break;
#endif
       case SOCK_GET_SRTT:
       {
	 //int j = sizeof(value);
	 //if (getsockopt(sdPtr->fd, IPPROTO_TCP, TCP_GET_SRTT, (char *)&value,&j) < 0) 
	   {
	   dprintf(110, "Sock_Socket: sock_get_srtt");
	   value=SOCK_FAILURE;
	 }
       }
       break;
       case SOCK_GET_RTTVAR:
       {
	 //int j = sizeof(value);
	 //if (getsockopt(sdPtr->fd, IPPROTO_TCP, TCP_GET_RTTVAR,(char *)&value,&j) < 0) 
	   {
	   dprintf(110, "Sock_Socket: sock_get_rttvar");
	   value=SOCK_FAILURE;
	 }
       }
       break;
     case PROTOCOL:
          value=sdPtr->protocol;
          break;
     case TYPE:
          value=sdPtr->type;
          break;
     case GET_SOCKET_FLAG:
          value = fcntl(sdPtr->fd, F_GETFL, 0);
          break;
     case BUFFER_SIZE:
          value=sdPtr->lRecvBufSize;
          break;
     case TIMEOUT:
          if (sdPtr->toutPtr == NULL) {
               value = SOCK_NO_TIMEOUT;
          }
          else {
               value=sdPtr->timeout.tv_sec * 1000000 + sdPtr->timeout.tv_usec;
          }
          break;
     case USE_CTRL_CHANNEL:
          value = sdPtr->useCtrl;
          break;
     case XMIT_RATE:
          value = sdPtr->xmitRate;
          break;
     case COMPATIBILITY:
          value = sdPtr->compatible;
          break;
     case BLOCKING:
          value = sdPtr->block;
          break;
     case MOBILE:
          value = sdPtr->mobile;
          break;
     case BROADCAST:
          value = sdPtr->broadcast;
          break;
     default:
          dprintf(101, "Sock_GetOption: invalid option %d\n", option);
          value = SOCK_FAILURE;
     }
     return(value);
}

int Sock_GetFD(Socket *sdPtr)
{
     return(sdPtr->fd);
}

char *Sock_GetRemoteName(Socket *sdPtr)
{
     char *retStr;

     retStr = (char *)malloc(strlen(sdPtr->rHost->remoteName));
     strcpy(retStr,sdPtr->rHost->remoteName);
     return(retStr);
}

void Sock_SetBer(Socket *sdPtr, float val)
{
     sdPtr->berState.ErrorGen = Sock_PoissonError;
     sdPtr->berState.errorProb[0] = val;
     sdPtr->berState.bytesToNextError = 0;
     sdPtr->berState.bitsDropped = 0;
     sdPtr->berState.totalBits = 0;
}

float Sock_GetBer(Socket *sdPtr) 
{
     return(sdPtr->berState.errorProb[0]);
}

Address *Sock_GetRemoteAddr(Socket *sdPtr, Address *addr)
{
     memcpy(addr, &(sdPtr->rSin), sizeof(Address));
     return(addr);
}

Address *Sock_GetLocalAddr(Socket *sdPtr, Address *addr)
{
     memcpy(addr, &(sdPtr->lSin), sizeof(Address));
     return(addr);
}

Address *Sock_GetLastSenderAddr(Socket *sdPtr, Address *addr)
{
     memcpy(addr, &(sdPtr->lastRSin), sizeof(Address));
     return(addr);
}

Port Sock_GetLocalPort(Socket *sdPtr)
{
     return(sdPtr->localPort);
}

Port Sock_GetRemotePort(Socket *sdPtr)
{
     return(sdPtr->remotePort);
}

Port Sock_GetTCPCtrlPort(Socket *sdPtr)
{
     if (sdPtr->tcpCtrlChannel != NULL)
	  return(sdPtr->tcpCtrlChannel->localPort);
     else
	  return(SOCK_FAILURE);
}

Port Sock_GetUDPCtrlPort(Socket *sdPtr)
{
     if (sdPtr->udpCtrlChannel != NULL)
	  return(sdPtr->udpCtrlChannel->localPort);
     else
	  return(SOCK_FAILURE);
}

int Sock_SetRemoteByName(Socket *sdPtr, char *hostname, Port port)
{
     /* get remote host address */
     dprintf(109,"setting remote to %s %d\n", hostname, port);
     Sock_NameToSin(hostname, port, &(sdPtr->rSin));
     /* set up socket descriptor */
     if (sdPtr->rHost->remoteName == NULL)
	  sdPtr->rHost->remoteName = (char *) Sock_Malloc(SOCK_MAXHOSTNAME);
     strncpy(sdPtr->rHost->remoteName, hostname, SOCK_MAXHOSTNAME);
     sdPtr->remotePort = port;
     return(SOCK_SUCCESS);
}

int Sock_SetRemoteByAddr(Socket *sdPtr, Address *rSinPtr)
{
     if (rSinPtr != &(sdPtr->rSin))
	  memcpy(&(sdPtr->rSin), rSinPtr, sizeof(sdPtr->rSin));
     if (sdPtr->rHost->remoteName == NULL)
	  sdPtr->rHost->remoteName = (char *) Sock_Malloc(SOCK_MAXHOSTNAME);
     Sock_SinToName(sdPtr->rHost->remoteName, SOCK_MAXHOSTNAME, 
		    &(sdPtr->remotePort), rSinPtr);
     return(SOCK_SUCCESS);
}

int Sock_AddDestination(Socket *sdPtr, char *hostname)
{
  //Socket *newSdPtr;
     int status;
     int i=0;
     /*
	
	if (sdPtr->protocol == SOCK_TCP)
	return(SOCK_FAILURE);
	if (sdPtr->broadcast == SOCK_NOT_BROADCAST)
	return(SOCK_FAILURE);
	if (!((sdPtr->state== SOCK_STATE_CONNECTED) ||
	(sdPtr->state== SOCK_STATE_ACCEPTED)))
	return(SOCK_FAILURE);
	
	newSdPtr = Sock_Socket(sdPtr->protocol);
	status = Sock_Connect(newSdPtr, hostname, sdPtr->remotePort);
	
	if (status == SOCK_FAILURE) {
	dprintf(109, "couldn't add destination %s\n", hostname);
	return(SOCK_FAILURE);
	}
	
	for (i=0; i < SOCK_MAX_MULTICAST_HOSTS; i++)
	if (sdPtr->activeHosts[i] == 0)
	break;
	
	strcpy(sdPtr->remoteName[i], newSdPtr->rHost->remoteName);
	sdPtr->ctrlChannel[i] = newSdPtr->ctrlChannel[0];
	sdPtr->activeHosts[i] = 1;
	*/
     dprintf(109, "added destination %s as %d\n", hostname, i);
     return(status);
}

int Sock_MergeDestinations(Socket *sdPtr1, Socket *sdPtr2)
{
     int i;
     /*
	if (sdPtr1->protocol == SOCK_TCP)
	return(SOCK_FAILURE);
	if (!((sdPtr1->state==SOCK_STATE_CONNECTED) ||
	(sdPtr1->state==SOCK_STATE_ACCEPTED)))
	return(SOCK_FAILURE);
	
	for (i=0; i < SOCK_MAX_MULTICAST_HOSTS; i++)
	if (sdPtr1->activeHosts[i] == 0)
	break;
	
	strcpy(sdPtr1->remoteName[i], sdPtr2->rHost->remoteName);
	sdPtr1->ctrlChannel[i] = sdPtr2->ctrlChannel[0];
	sdPtr1->activeHosts[i] = 1;
	*/
     dprintf(109, "merged destination %s as %d\n",sdPtr2->rHost->remoteName , i);
     return(SOCK_SUCCESS);
}

int Sock_DelDestination(Socket *sdPtr, char *hostname)
{
  //int i,j=0;

     /*     for (i=0; i < SOCK_MAX_MULTICAST_HOSTS; i++)
	    if (sdPtr->activeHosts[i] == 1)
	    if (strcmp(sdPtr->remoteName[i], hostname))
	    break;
	    
	    dprintf(109, "deleting host %d = %s\n", i, hostname);
	    
	    Sock_CtrlClose(sdPtr->ctrlChannel[i], sdPtr->localName);
	    Sock_Close(sdPtr->ctrlChannel[i]);
	    sdPtr->activeHosts[i] = 0;
	    */
  return 0;
}

void *Sock_Malloc(int size)
{
     void *mem;
     if ((mem = malloc((size_t) size)) == NULL)
	  perror("Sock_Malloc: malloc failed");
     return mem;
}

/*************************************************************
*
* Network Connection Monitor Routines
*
*************************************************************/

void Sock_RegisterBWLessThan(Socket *sdPtr, float newBandwidth, void (*ChangedFunc)(SockStats *))
{
	sdPtr->bandwidthLowWater=newBandwidth;
	sdPtr->bandwidthLessThanFunc=ChangedFunc;
}
void Sock_RegisterBWMoreThan(Socket *sdPtr, float newBandwidth, void (*ChangedFunc)(SockStats *))
{
	sdPtr->bandwidthHighWater=newBandwidth;
	sdPtr->bandwidthMoreThanFunc=ChangedFunc;
}

/* These aren't implemented yet */
#if 0
void Sock_RegisterLatencyLessThan(Socket *sdPtr, float newLatency, void (*ChangedFunc)(SockStats *))
{
}

void Sock_RegisterLatencyMoreThan(Socket *sdPtr, float newLatency, void (*ChangedFunc)(SockStats *))
{
}

void Sock_RegisterPerLessThan(Socket *sdPtr, float newPer, void (*ChangedFunc)(SockStats *))
{
}

void Sock_RegisterPerMoreThan(Socket *sdPtr, float newPer, void (*ChangedFunc)(SockStats *))
{
}
#endif


