/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdarg.h>
#include "dbgprintlib.h"

#define DP_PRINT 0
#define DP_SET_LEVEL 1
#define DP_SET_FD 2
#define DP_FLUSH_FD 3
#define DP_SET_PE_LEVEL 4
#define DP_PERROR 5

int _dprintf(int command, char *filename, int level, const char *format, va_list ap)
{
  static int currentDebugLevel = 0;
  static int currentPerrorLevel = 0;
  FILE *f;

  f = stderr;

  switch (command){
  case DP_PRINT:
      if (currentDebugLevel >= level)
	  return(vfprintf(f, format, ap));
      else return(0);
  case DP_SET_LEVEL:
      currentDebugLevel = level;
      return 0;
  case DP_SET_PE_LEVEL:
      currentPerrorLevel = level;
      return 0;
  case DP_PERROR:{
      char *error = strerror(errno);
      int i;

      if (currentPerrorLevel >= level) {
	  fprintf(f, "DPERROR - ");
	  i = vfprintf(f, format, ap);
	  fprintf(f, ": %s\n", error);
	  return i;
      }
      return(0);
  }
  case DP_SET_FD:
      if (f != stderr)
	  fclose(f);
      f = fopen(filename, "w");
      if (f == 0) {
	  perror(filename);
	  f = stderr;
	  return -1;
      }
      return 0;
  case DP_FLUSH_FD:
      fflush(f);
      return 0;
  default:
      return -1;
  }
}

int __dprintf(int command, char *filename, int level, const char *format, ...)
{
  va_list ap;
  int n;

  va_start(ap, format);
  n = _dprintf(command, filename, level, format, ap);
  va_end(ap);
  return n;
}

int 
dprintf(int level, const char *format, ...)
{
  int n = 0;
  va_list ap;
  
  va_start(ap, format); 
  n = _dprintf(DP_PRINT, NULL, level, format, ap);
  va_end(ap); 
  return n;
}


int
dperror(int level, const char *format, ...)
{
  int n = 0;
  va_list ap;

  va_start(ap, format); 
  n = _dprintf(DP_PERROR, NULL, level, format, ap);
  va_end(ap); 
  return n;
}

int
SetDebugLevel(int level)
{
    return(__dprintf(DP_SET_LEVEL, NULL, level, "debug level set to %d\n", level));
}

int
SetDebugFile(char *filename)
{
  return(__dprintf(DP_SET_FD, filename, 100,  
		   "setting file for debugging to %s", filename));
}

int 
SetDperrorLevel(int level)
{
    return(__dprintf(DP_SET_PE_LEVEL, NULL, level, "debug level set to %d\n", level));
}

int
FlushDebugFile()
{
    return(_dprintf(DP_FLUSH_FD,  NULL, 100, "", NULL));
}
    












