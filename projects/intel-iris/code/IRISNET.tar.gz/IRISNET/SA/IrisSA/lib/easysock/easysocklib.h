/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef NETLIB
#define NETLIB
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <unistd.h>

#define SOCK_RELIABLE_DGRAM             10
#define SOCK_NO_TIMEOUT                 -1
#define SOCK_ANY_PORT                   0
#define SOCK_SUCCESS                    0
#define SOCK_FAILURE                    -1
#define SOCK_TIMEOUT                    -2
#define SOCK_FD_CLOSED                  -3

#define SOCK_MAX_MULTICAST_HOSTS                4
#define SOCK_MAX_HOST_NAME_LEN                  80
#define SOCK_MAX_IP_LEN                  	16
#define SOCK_MAX_HANDOFF_HOSTS                  4
#define SOCK_MAX_CTRL_HOSTS                     2


typedef enum {SOCK_UDP, SOCK_UDP_RELIABLE, SOCK_UDP_MULTI, SOCK_UDP_REL_MULTI,
		   SOCK_TCP, SOCK_IP, SOCK_UDP_CTRL, SOCK_UDP_MULTI_CTRL,
		   SOCK_TCP_CTRL} PROTOCOLS;
typedef enum {BROADCAST, MOBILE, USE_CTRL_CHANNEL, COMPATIBILITY, BLOCKING,
                   GET_SOCKET_FLAG, SET_SOCKET_FLAG, CLEAR_SOCKET_FLAG, 
		   TIMEOUT, BUFFER_SIZE, XMIT_RATE, PROTOCOL, TYPE, 
		   POISSON_BER, NODELAY, MSS, BER, ERR_MODEL, IPTOS, 
		   TTL, SEND_FLAG, DELACK, ACCEPT_FLAG, TCP_STATS, SOCK_GET_SRTT, SOCK_GET_RTTVAR} OPTIONS;
typedef int Port;
typedef int Usec;
typedef struct sockaddr_in Address;
typedef int Sock_Status;
typedef struct timeval timev;
typedef struct BerState {
     void    (*ErrorGen)();
     int     bytesToNextError; 
     /* Update rate of Markov state machine 100 ms */
     int     timeGranularity; /* time granularity of call */
     timev   lastCallTime;
     /* XXX This is private state dependent on the error model used */
     int     markovState;
     float   transProb[2];
     float   errorProb[2];
     /* For statistics */
     int bitsDropped;
     int totalBits;
} BerState;

typedef struct RemoteHost {
     int active;
     char *remoteName;
     char remoteIPAddr[SOCK_MAX_IP_LEN];
     Address udpRSin;
     Port udpCtrlPort;
     Port tcpCtrlPort;
     struct Socket *tcpCtrl;
     struct RemoteHost *next;
} RemoteHost;

/*
   #include "sockinternal.h"
   */
typedef int SockSeq;

#define SOCK_MAXWIND 32
#define SOCK_FULLMASK 0x00000001 << (SOCK_MAXWIND - 1)
#define SOCK_ACK 0x01
#define SOCK_FIN 0x10
#define SOCK_RTT_MULTIPLIER 0.125
#define SOCK_INITRTT 3000000
#define SOCK_DELACK 1
#define SOCK_NODELACK 2

typedef struct SockSendHdr {	/* sent over network */
     SockSeq seq;		/* seq number of packet */
     SockSeq ack;		/* base cumulative ack */
     size_t  size;		/* size of pakcet payload */
     /* 0's and 1's showing holes and recd pkts starting from 'ack' */
     u_int   ackBits;
     u_char  pktFlags;		/* is the ack valid? */
     char    padding[3];
} SockSendHdr;

typedef struct SockPktHdr {	/* locally maintained */
     SockSeq seq;		/* seq number of packet */
     SockSeq ack;		/* base cumulative ack */
     size_t  size;		/* size of pakcet payload */
     /* 0's and 1's showing holes and recd pkts starting from 'ack' */
     short   numRxmit;		/* number of retransmissions so far */
     timev   sndTime;		/* for timestamps -- unused so far */
} SockPktHdr;

typedef struct SockPkt {
     SockSendHdr sendHdr;	/* pkt header sent over network */
     SockPktHdr localHdr;	/* locally processed header fields */
     char *buf;			/* actual data */
     u_char validFlag;		/* valid entry or not (in cache)? */
     char padding[3];		/* for word alignment */
} SockPkt;

typedef struct SockCache {
     u_short fstate;		/* active, alive, closed,... */
     SockSeq lastSent;		/* seq number of last packet sent */
     SockSeq lastRead;		/* last pkt read by application */
     SockSeq firstUnack;	/* first unack'd packet */
     SockSeq lastAck;		/* seq number of last ack */
     SockSeq ackBase;		/* cumulative ack base */
     u_int   ackMask;		/* bit pattern of recd pkts and "holes" */
     int     srtt;		/* smoothed round-trip time estimate */
     int     delack;		/* number of pkts before delayed ack */
     SockPkt *pkts[SOCK_MAXWIND]; /* cache of unack'd packets */
     SockPkt *rcvPkts[SOCK_MAXWIND]; /* buf recd pkts for inorder delivery */
} SockCache;

typedef struct SockStats {
	 /* Stuff for statistics collection */
	float bandwidth;               /* Bandwidth seen in bytes per second */
	float bandwidthStdDev;           /* Variance in bandiwdth */
	struct timeval bandwidthAge;           /* When the bandwidth was last calculated */
	float closedLoopBandwidth;               /* Bandwidth seen in bytes per second */
	float closedLoopBandwidthStdDev;           /* Variance in bandiwdth */
	struct timeval closedLoopBandwidthAge;           /* When the bandwidth was last calculated */
	float tcpBandwidth;               /* Bandwidth seen in bytes per second */
	float tcpBandwidthStdDev;           /* Variance in bandiwdth */
	struct timeval tcpBandwidthAge;           /* When the bandwidth was last calculated */
/* These aren't implemented yet */
#if 0
	float latency;                 /* Round-trip latency in milliseconds */
	float latencyStdDev;             /* Variance in latency */
	struct timeval latencyAge;             /* When the latency was last calculated */
	float per;                     /* Packet error rate */
	float perStdDev;                 /* Variance in packet error rate */
	struct timeval perAge;                 /* When the packet error rate was last calculated */
	float maxPacketSize;           /* Maximum allowable packet size */
	float bestPacketSize;          /* "Best" packet size */
	float (*PowerSend)(int);       /* Power to send a chunk of x bytes */
	float (*PowerRecv)(int);       /* Power to receive a chunk of x bytes */
	float (*CostSend)(int);        /* Cost to send a chunk of x bytes */
	float (*CostRecv)(int);        /* Cost to receive a chunk of x bytes */
	float (*PowerTurnOn)(char *);  /* Power to Turn on interface i */
	float (*PowerTurnOff)(char *); /* Power to Turn off interface i */
#endif	
} SockStats;

typedef struct Socket {
     int fd;
     int sfd;
     int compatible;
     int state;
     int side;
     int type;
     int acceptFlag;		/* 1: bind to fixed address; 0: INADDR_ANY */
     PROTOCOLS protocol;
     BerState berState;
     char localName[SOCK_MAX_HOST_NAME_LEN];
     char localIPAddr[SOCK_MAX_IP_LEN];
     Port localPort;
     Address lSin;
     int lRecvBufSize;
     int lXmitBufSize;
     int lFlags;
     char ttl;
     timev timeout, *toutPtr;
     int xmitRate;
     struct timeval lastPktTime;
     int lastPktSize;
	 int bytesSentSoFar;
	 int bytesAckedSoFar;
	 int bytesRecvSoFar;
	 struct timeval start_tp;
	 struct timezone start_tzp;
     int broadcast;
     int mobile;
     int isCtrl;
     int useCtrl;
     int block;
     struct Socket *udpCtrlChannel;
     struct Socket *tcpCtrlChannel;
     int numActiveRHost;
     RemoteHost *rHost;
     Port remotePort;
     Address rSin;
     Address lastRSin;
     SockCache *cache;		/* cache of pkts for udp_reliable protocol */
     int delack;		/* number of pkts before delayed ack */

	 SockStats stats;

	 void (*bandwidthLessThanFunc)(SockStats *);  /* The function that is called when the bandwidth */
                                           /* statistics change enough to trigger a registration */
	 float bandwidthLowWater;               /* If the bandwidth decreases to less than this, call the */
	                                        /* BandwidthLessThan Function */
	 void (*bandwidthMoreThanFunc)(SockStats *);  /* The function that is called when the bandwidth */
                                            /* statistics change enough to trigger a registration */
	 float bandwidthHighWater;              /* If the bandwidth increases more than this, call the */
	                                        /* BandwidthMoreThan Function */

/* These aren't implemented yet */
#if 0	 
	 SockStats * (*LatencyLessThanFunc);    /* The function that is called when the latency */
                                          /* statistics change enough to trigger a registration */
	 SockStats * (*LatencyMoreThanFunc);    /* The function that is called when the latency */
                                          /* statistics change enough to trigger a registration */
	 SockStats * (*PerLessThanFunc);        /* The function that is called when the per */
                                          /* statistics change enough to trigger a registration */
	 SockStats * (*PerMoreThanFunc);        /* The function that is called when the per */
                                          /* statistics change enough to trigger a registration */
#endif	 
} Socket;

/*
   
   protocols currently supported
   
   tcp (stream)
   udp (dgram)
   
   protocols to be added
   ip  (raw)
   */

/*************************************************************************
  Control Socket Routines
  *************************************************************************/

/* get a socket with appropriate protocol,
   return val: a socket id or FAILURE */
extern Socket* Sock_Socket(PROTOCOLS protocol);

/* connect socket to remote socket
   return val: a new socket id connected to hostname or FAILURE */
extern Sock_Status Sock_Connect(Socket *sdPtr, char *hostname, Port port);

/* listen for connections on port
   return val: FAILURE or SUCCESS */
extern Sock_Status Sock_Listen(Socket *sdPtr, Port port);

/* accept a connection on a port
   return val: socket connected to hostname */
extern Socket* Sock_Accept(Socket *sdPtr);

/* close socket and connection and then free associated storage
   return val: FAILURE or SUCCESS */
int Sock_Ready(Socket *sdPtr);
extern Sock_Status Sock_Close(Socket *sdPtr);
extern Sock_Status Sock_CloseCtrl(Socket *sdPtr);
extern Sock_Status Sock_Free(Socket *sdPtr);


/*************************************************************************
  send/recv routines
  return val: FAILURE or bytes xmitd/recvd
  *************************************************************************/

/* generic recv will check type of socket and do appropriate recv
   recv at most length bytes */
extern Sock_Status Sock_Recv(Socket *sdPtr, char *buffer, int length);

/* generic send length bytes from buffer */
extern Sock_Status Sock_Send(Socket *sdPtr, char *buffer, int length);
int Sock_SendDgram(Socket *sdPtr, char *buffer, int length);
int Sock_SendStream(Socket *sdPtr, char *buffer, int length);

int Sock_RexmtPkt(Socket *sdPtr, SockPkt *pkt);

/* generic recv full will check type of socket and do recv of length bytes */
extern Sock_Status Sock_RecvFull(Socket *sdPtr, char *buffer, int length);

/* utility functions */
extern Sock_Status Sock_ReadInt(Socket *sd, int *i) ;
extern Sock_Status Sock_SendInt(Socket *sd, int i) ;
extern Sock_Status Sock_ReadChar(Socket *sd, char *c) ;
extern Sock_Status Sock_SendChar(Socket *sd, char c) ;
extern Sock_Status Sock_ReadLong(Socket *sd, long *l) ;
extern Sock_Status Sock_SendLong(Socket *sd, long l) ;
extern Sock_Status Sock_ReadString(Socket *sd, char *s) ;
extern Sock_Status Sock_SendString(Socket *sd, char *s) ;


/*************************************************************************
  Control Source/Destinations
  *************************************************************************/

/* set host at other end of link, useful for dgram sockets only
   return val: FAILURE or SUCCESS */
extern Sock_Status      Sock_SetRemoteByName(Socket *sdPtr, char *hostname,
                                             Port port);
extern Sock_Status      Sock_SetRemoteByAddr(Socket *sdPtr, Address *rSinPtr);
extern char*            Sock_GetRemoteName(Socket *sdPtr);
extern Port             Sock_GetLocalPort(Socket *sdPtr);
extern Address*         Sock_GetLocalAddr(Socket *sdPtr, Address *addr);
extern Port             Sock_GetTCPCtrlPort(Socket *sdPtr);
extern Port             Sock_GetUDPCtrlPort(Socket *sdPtr);
extern Port             Sock_GetRemotePort(Socket *sdPtr);
extern Address*         Sock_GetRemoteAddr(Socket *sdPtr, Address *addr);
extern Address*         Sock_GetLastSenderAddr(Socket *sdPtr, Address *addr);
extern int              Sock_GetFD(Socket *sdPtr);
/* when in broadcast mode, you may add and delete destinations. The remote
   end must be prepared to accept connections. Delete destination closes the
   connection
   */
extern Sock_Status      Sock_AddDestination(Socket *sdPtr, char *hostname);
extern Sock_Status      Sock_DelDestination(Socket *sdPtr, char *hostname);

/*************************************************************************
  Get/Set Socket Options
  *************************************************************************/

extern int              Sock_SetOption(Socket *sdPtr, OPTIONS option,
                                       int value);
extern int              Sock_GetOption(Socket *sdPtr, OPTIONS option);
extern float		Sock_GetBer(Socket *sdPtr); 
extern void		Sock_SetBer(Socket *sdPtr, float val);

#define Sock_SetXmitRate(sdPtr, xmitRate) 	Sock_SetOption(sdPtr, XMIT_RATE, xmitRate)
#define Sock_SetTimeout(sdPtr, usec)      	Sock_SetOption(sdPtr, TIMEOUT, usec)
#define Sock_SetBufferSize(sdPtr, bufSize) 	Sock_SetOption(sdPtr, BUFFER_SIZE, bufSize)
#define Sock_SetUseCtrl(sdPtr, ctrl) 		Sock_SetOption(sdPtr, USE_CTRL_CHANNEL, ctrl)
#define Sock_SetCompatible(sdPtr, compat) 	Sock_SetOption(sdPtr, COMPATIBILITY, compat)
#define Sock_SetBroadcast(sdPtr) 		Sock_SetOption(sdPtr, BROADCAST, 1)
#define Sock_UnsetBroadcast(sdPtr) 		Sock_SetOption(sdPtr, BROADCAST, 0)
#define Sock_SetMobile(sdPtr) 			Sock_SetOption(sdPtr, MOBILE, 1)
#define Sock_SetBlock(sdPtr, blockOn) 		Sock_SetOption(sdPtr, BLOCKING, blockOn)
#define Sock_SetNoDelay(sdPtr, on) 		Sock_SetOption(sdPtr, NODELAY, on)
#define Sock_SetOOB(sdPtr) 			Sock_SetOption(sdPtr, SEND_FLAG, MSG_OOB | sdPtr->lFlags)
#define Sock_SetERRMODEL(sdPtr, size) 		Sock_SetOption(sdPtr, ERR_MODEL, size)
#define Sock_SetBER(sdPtr, size) 		Sock_SetOption(sdPtr, BER, size)
#define Sock_SetMSS(sdPtr, size) 		Sock_SetOption(sdPtr, MSS, size)
#define Sock_SetFlag(sdPtr, flags) 		Sock_SetOption(sdPtr, SET_SOCKET_FLAG, flags)
#define Sock_ClearFlag(sdPtr, flags) 		Sock_SetOption(sdPtr, CLEAR_SOCKET_FLAG, flags)
#define Sock_SetTOS(sdPtr, tos)			Sock_SetOption(sdPtr, IPTOS, tos)
#define Sock_SetDelack(sdPtr, delack)           Sock_SetOption(sdPtr, DELACK, delack)
#define Sock_SetAcceptFlag(sdPtr, addr)         Sock_SetOption(sdPtr, ACCEPT_FLAG, addr)
#define Sock_SetTCPStats(sdPtr, optflag)         Sock_SetOption(sdPtr, TCP_STATS , optflag)
     
#define Sock_GetType(sdPtr)             Sock_GetOption(sdPtr, TYPE)
#define Sock_GetProtocol(sdPtr)         Sock_GetOption(sdPtr, PROTOCOL)
#define Sock_GetXmitRate(sdPtr)         Sock_GetOption(sdPtr, XMIT_RATE)
#define Sock_GetTimeout(sdPtr)          Sock_GetOption(sdPtr, TIMEOUT)
#define Sock_GetBufferSize(sdPtr)       Sock_GetOption(sdPtr, BUFFER_SIZE)
#define Sock_GetCtrl(sdPtr)             Sock_GetOption(sdPtr, USE_CTRL_CHANNEL)
#define Sock_GetCompatible(sdPtr)       Sock_GetOption(sdPtr, COMPATIBILITY)
#define Sock_GetBroadcast(sdPtr)        Sock_GetOption(sdPtr, BROADCAST)
#define Sock_GetTCPStats(sdPtr)         Sock_GetOption(sdPtr, TCP_STATS)
#define Sock_GetTCPSrtt(sdPtr)          Sock_GetOption(sdPtr, SOCK_GET_SRTT)
#define Sock_GetTCPRttvar(sdPtr)        Sock_GetOption(sdPtr, SOCK_GET_RTTVAR)

     /*****************************************************************
       remote ctrl routines
       *************************************************************************/
     
/* some useful ctrl functions that affect the remote side of connection
   you must set_ctrl on both sides before using these
   
   all Sockets have an global ctrl channel for creating new connections
   (for multicast) and processing ctrl info from machines not "connected" to
   this socket. All machines that are "connected" to this socket have separate
   ctrl channels.
   This is global ctrl channel is a udp socket, the port
   number is obtained by using Sock_GetLocalCtrlPort().
   */

/* if you would like to ctrl the connecttion between a set of hosts from a
   outside (third-party) host you should create a ctrl-only channel with
   Sock_CtrlNewCtrl()
   */

extern Socket           *Sock_CtrlNewCtrl(Socket *ctrlSdPtr, char *hostname,
					  Port port, int protocol);

/* set transmission rate of remote side */
extern Sock_Status      Sock_CtrlSetRate(Socket *ctrlSdPtr, int rate);

/* force remote side to close */
extern Sock_Status      Sock_CtrlClose(Socket *ctrlSdPtr, char *localName);

/* add a host to multicast tree */
extern Sock_Status      Sock_CtrlInitHandoff(Socket *ctrlSdPtr, char *newHost);

/* remove all hosts from multicast except newHost */
extern Sock_Status      Sock_CtrlDoHandoff(Socket *ctrlSdPtr, char *newHost);


/* coming soon
   more remote ctrl utils.
   ex: set remote buffer sizes, timeouts, etc
   modified UDP's -        1) automatically ctrl rate according to net congestion
   2) flow ctrl?
   
   Name service hooks
   extern Sock_Status Sock_NSLookup(SockNSRequestHdr reqHdr, char *data);
   ~allanl/src/lib/socket
   */

/* Function Prototypes having to do with Network Conn. Monitor. For more details, see the working doc */
extern void Sock_RegisterBWLessThan(Socket *sdPtr, float newBandwidth, void (*ChangedFunc)(SockStats *));
extern void Sock_RegisterBWMoreThan(Socket *sdPtr, float newBandwidth, void (*ChangedFunc)(SockStats *));

/* Macro to check bandwidths and possibly call bandwidthChanged functions */
#define CHECK_BANDWIDTH(sdPtr) {  if (sdPtr->stats.bandwidth<sdPtr->bandwidthLowWater && sdPtr->bandwidthLessThanFunc!=NULL){ \
									  sdPtr->bandwidthLessThanFunc(&(sdPtr->stats)); \
                                 } else if (sdPtr->stats.bandwidth>sdPtr->bandwidthHighWater && sdPtr->bandwidthMoreThanFunc!=NULL) { \
									  sdPtr->bandwidthMoreThanFunc(&(sdPtr->stats)); \
                                 } \
							   }

/* These aren't implemented yet */
#if 0
extern void Sock_RegisterLatencyLessThan(Socket *sdPtr, float newLatency, void (*ChangedFunc)(SockStats *));
extern void Sock_RegisterLatencyMoreThan(Socket *sdPtr, float newLatency, void (*ChangedFunc)(SockStats *));
extern void Sock_RegisterPerLessThan(Socket *sdPtr, float newPer, void (*ChangedFunc)(SockStats *));
extern void Sock_RegisterPerMoreThan(Socket *sdPtr, float newPer, void (*ChangedFunc)(SockStats *));
#endif

/* Prototypes for reliable datagram protocol */

#define SOCK_MIN(x,y) ((x)<(y)?(x):(y))

/*
#define	SOCK_SEQ_LT(a,b)	((int)((a)-(b)) < 0)
#define	SOCK_SEQ_LEQ(a,b)	((int)((a)-(b)) <= 0)
#define	SOCK_SEQ_GT(a,b)	((int)((a)-(b)) > 0)
#define	SOCK_SEQ_GEQ(a,b)	((int)((a)-(b)) >= 0)
*/

int Sock_RecvDgram(Socket *sdPtr, char *buffer, int length);
int Sock_RecvStream(Socket *sdPtr, char *buffer, int length);
int Sock_RecvStreamFull(Socket *sdPtr, register char *buffer, int length);
int Sock_RecvDgramFull(Socket *sdPtr, char *buffer, int length);

extern int Sock_RecvReliableDgram(Socket *sdPtr, char *buffer, int length,
				  timev *timeout);
extern int Sock_ReadNetPkt(Socket *sdPtr, char *buffer, int length, 
			   timev *timeout);
extern int Sock_ProcessAck(Socket *sdPtr, SockSeq baseAck, u_int ackMask);
extern int Sock_SendAck(Socket *sdPtr, int delack);
extern SockPkt *Sock_MakePkt(char *buffer, SockSeq seq, SockSeq ack, 
			     u_int ackBits, size_t length);
extern int Sock_InsertPkt(SockCache *cache, SockPkt *pkt);
extern int Sock_SendPkt(Socket *sdPtr, SockPkt *pkt);
extern int Sock_SendReliableDgram(Socket *sdPtr, char *buffer, int length);
extern void *Sock_Malloc(int size);
extern timev *UtimeToTval(int microsecs);
extern int Sock_ComputeRtt(SockCache *cache, SockSeq baseAck);
#endif
