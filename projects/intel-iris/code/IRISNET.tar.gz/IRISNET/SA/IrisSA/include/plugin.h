#ifndef PLUGIN_H
#define PLUGIN_H

#include <cv.h>

extern "C" {

int ProcessFrame(IplImage * image);

typedef int (* filterFunc) (IplImage *);

};

#endif
