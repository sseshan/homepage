/* -*-  Mode:C; c-basic-offset:5; tab-width:5; indent-tabs-mode:t -*- */

// code for the organizing agent (OA)
 
#include "unp.h"
#include <dlfcn.h>
#include "OA.h"
#include "Agent.h"

// a naive one. returns an unused port
// will be transferred to a common library later
int NextPort(void)
{
 static unsigned int port = 4681;
 return port++;
}

// send the script given by the filename "fname" to the SA given by
// its IP and listening port

int OA_LoadScript(SensingAgent *sa, SA_ProcScript *script)
{ 
	char buff[BUFFLEN +1];
	int nread, fd, sockfd;
	struct sockaddr_in saaddr;
	CommandHeaderCommon hcommon;
	CommandHeaderLoad hload;

	sockfd = Socket(AF_INET, SOCK_STREAM, 0);
  
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(sa->port);
	//Inet_pton(AF_INET, sa->addr.s_addr, &saaddr.sin_addr);
	saaddr.sin_addr = sa->addr;  
	Connect(sockfd, (SA *) &saaddr, sizeof(saaddr));
	
	if ( (fd = open(script->fileName, O_RDONLY)) < 0) return FILE_ERROR;
	
	// first send the common header
	hcommon.command = COMMAND_LOAD;
	// Code name should be unique so that SA does not confuse between codes of different OA.
	// Code name can be made unique by appending the corresponding OA's IP address + PID 
	// Either of SA or OA can take care of this
	// Not implemented yet
	Write(sockfd, &hcommon, sizeof(hcommon));
	
	
	// send the COMMAND_LOAD specific part of the header
	strcpy(hload.scriptName, script->scriptName); 
	Write(sockfd, &hload, sizeof(hload));
	
	
	// now send the code	
	while ( (nread = Read(fd, buff, BUFFLEN)) > 0)
		Write(sockfd, buff, nread);
	printf("Sent code\n");
	Close(sockfd);	// close the write end to notify end of code
	Close(fd); 
	return OK;	
} 

SA_Handle *OA_Subscribe(SensingAgent *sa, char *scriptName)
{
	int sockfd, listenfd, port, clilen, connfd;
	struct sockaddr_in saaddr;
	SA_Handle *sh;
	CommandHeaderCommon hcommon;
	CommandHeaderSubscribe hsubs;
	struct sockaddr_in oaaddr;
	
	port = OA_PORT ;// the port on which OA will listen for the RPC feedback. Global   variable. XXX Should the port be global, or the listenfd should be make global?

	/* Open the socket to hear from the subscribed agent */ 	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	bzero(&oaaddr, sizeof(oaaddr));
	oaaddr.sin_family      = AF_INET;
	oaaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	oaaddr.sin_port        = htons(port);
	Bind(listenfd, (SA *) &oaaddr, sizeof(oaaddr));
	Listen(listenfd, LISTENQ);
	
	/* Send the subscribe command */
	sockfd = Socket(AF_INET, SOCK_STREAM, 0);
	
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(sa->port);
	//Inet_pton(AF_INET, sa->addr.s_addr, &saaddr.sin_addr);
	saaddr.sin_addr = sa->addr;
	
	Connect(sockfd, (SA *) &saaddr, sizeof(saaddr));
  
	// send the comon header
	hcommon.command = COMMAND_SUBSCRIBE;
	Write(sockfd, &hcommon, sizeof (hcommon));
	
	// send the subscribe specific command
	// Change the 2nd parameter to OA's IP address
	Inet_pton(AF_INET, "127.0.0.1", &hsubs.orgAgent.addr.s_addr);
	hsubs.orgAgent.port = port;
	strcpy(hsubs.scriptName, scriptName);
	Write(sockfd, &hsubs, sizeof(hsubs));
	
	Close(sockfd);
	
	// Accept a connection on the listening socket
	clilen = sizeof(oaaddr);
	connfd = Accept(listenfd, (SA*) &oaaddr, &clilen);
	Close(listenfd);

	// return the handle to the socket
	sh = Malloc(sizeof(SA_Handle));
	sh->fd = connfd;

	return sh;
}

// reads data (if available) sent by the SA via the socket "sockfd" and
// stores it in "buffer" 
int OA_Read(SA_Handle* handle, char *buffer, int bufflen)
{	
	struct timeval tv;
	fd_set rset;
	int nread;
	
	FD_ZERO(&rset);

	FD_SET(handle->fd, &rset);
	tv.tv_sec = tv.tv_usec = 0;
	Select(handle->fd + 1, &rset, NULL, NULL, &tv);
	if (FD_ISSET(handle->fd, &rset)) {
		if ( (nread = Read(handle->fd, buffer, bufflen)) >0) {
			// "buffer" contains the data read form SA
			return nread;
		}
		else {
			// Socket closed by the SA, so nothing was read in "buffer", return 0
			return nread;
		}
	}
	
	return -1; // data was not available for reading
}

int
main(int argc, char **argv)
{
	SensingAgent sa;
	SA_ProcScript script;
	SA_Handle *handle;
	char scriptName[256] = "myHello";
	char buffer[1024], fname[1024];
	
	if (argc != 4)
		err_quit("usage: org_agt <OA_Port> <SA IP> <SA Port> <Script file>");
  
	OA_PORT = atoi(argv[1]);
	Inet_pton(AF_INET, argv[2], &sa.addr.s_addr);
	sa.port = atoi(argv[3]);
	sscanf(argv[4], "%s", fname); 

	script.fileName = fname;
	strcpy(script.scriptName, scriptName);
	// send the code to the
	if (OA_LoadScript(&sa, &script) == OK) {
		printf("script loaded\n");
	}
	
	handle = OA_Subscribe(&sa, scriptName);
	// main loop
	for (;;) {
		if (OA_Read(handle, buffer, BUFFLEN) > 0)
			printf("Heard from SA: %s\n", buffer);
		;
		// do other org agt stuff
		sleep (1);
	}

	
	exit(0);
}

