/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


/* WARNING!!!
 * The calls to RawToLoad and RawToSubs are not safe.  Need to check for
 * packet format before calling them.  They are also not thread safe.
 * In general, the parsing of packets needs to be more robust
 */


#undef  NONBLOCKING
#define NONBLOCKING

#define DEBUG 1

#include "unp.h"
#include "SA.h"
#include "shmman.h"

#include "Agent.h"
#include "dbgprintlib.h"
#include <dlfcn.h>
#include "filter.h"
#include "protocol.h"

// need to fold this into make file
#undef NDEBUG
#include <assert.h>

#include <sys/shm.h>

#include <openssl/pem.h>
#include <openssl/sha.h>

runningFilterType runningFilter[MAXFILTER];

int currentlyRunning;

time_t shmLastCheckTime = 0;
int shmCheckInterval = 60; // second
int shmMaxIdleInterval = 60; // second

// Load application binary from network to disk
int Load(int connfd, char *packet)
{
	FILE *fp;
	char buffer[BUFFLEN + 1];
	char codeName[sizeof(CODEPATH) + MD5LEN + 1];
	CommandHeaderLoad hload;
	int nread;

	assert(packet != NULL);

	if (RawToLoad(packet, &hload) != 0) {
		return SOCK_ERROR;
	}


	sprintf(codeName, "%s%s.so", CODEPATH, hload.scriptName);

	if ((fp = fopen(codeName, "rb")) != NULL) {
		printf("WARNING: Load():  %s already exists\n", hload.scriptName);
		//return ERR_FILEEXISTS;	// code already exists
	}

	if ((fp = fopen(codeName, "wb")) == NULL) {
		printf("Load(): Error in opening file %s for writing\n", codeName);
		return FILE_ERROR;
	}

	printf("Load(): writing to file: %s\n", codeName);

	while ((nread = Read(connfd, buffer, BUFFLEN)) > 0) {
		fwrite(buffer, nread, 1, fp);
	}

	fclose(fp);

	printf("Load(): done.\n");

	return OK;
}

off_t GetFileSize(char * file) {
	struct stat buf;
	
	if (stat(file, &buf) == -1) {
		perror("GetFileSize()");
		return 0;
	}
	
	return buf.st_size;
	
}


// error conditions do not free memory - need to fix

// returns 0 if false, 1 if true
int IsTrusted(char * scriptName, char * scriptPath)
{
	int trusted = 1;

	char * pubkeyfile = "rsapubkey.pem";

	printf("IsTrusted(): Check script %s\n", scriptName);


	////////// Loading public key file
	printf("IsTrusted(): Opening public key file %s\n", pubkeyfile);

	FILE * fp = fopen(pubkeyfile, "r");

	if (fp == NULL) {
		perror("IsTrusted(): Loading public key file");
		return 0;
	}

	RSA * pubkey = RSA_new();

	printf("IsTrusted(): Loading public key file %s\n", pubkeyfile);

	if (PEM_read_RSA_PUBKEY(fp, &pubkey, NULL, NULL) == NULL) {
		printf("IsTrusted(): Error reading public key file.\n");
		RSA_free(pubkey);
		fclose(fp);
		return 0;
	}
	
	fclose(fp);

	////////// Loading script into memory
	off_t ssize = GetFileSize(scriptPath);

	if (ssize == 0) {
		printf("IsTrusted(): Script size is 0\n");
		return 0;
	}

	if ((fp = fopen(scriptPath, "rb")) == NULL) {
		perror("IsTrusted(): Opening script file");
		return 0;
	}
	
	unsigned char * scriptBuf = (unsigned char *) malloc(ssize);

	if (fread(scriptBuf, 1, ssize, fp) != (size_t) ssize) {
		perror("IsTrusted(): Reading script file");
		return 0;
	}
		
	printf("IsTrusted(): Read in %d bytes of script file\n", (int) ssize);
	
	fclose(fp);
	
	/////////// Calculating script digest
		
	unsigned char digestBuf[SHA_DIGEST_LENGTH];
	SHA1(scriptBuf, ssize, digestBuf);
        


	/////////// Loading signature into memory
	char sigPath[1024];

	sprintf(sigPath, "%s%s.sig", CODEPATH, scriptName);
	
	int sigsize = GetFileSize(sigPath);

	if (sigsize == 0) {
		printf("IsTrusted(): signature size is 0\n");
		return 0;
	}

	if ((fp = fopen(sigPath, "rb")) == NULL) {
		perror("IsTrusted(): Opening signature file");
		return 0;
	}

	unsigned char * sigBuf = (unsigned char *) malloc(sigsize);

	if (fread(sigBuf, 1, sigsize, fp) != (size_t) sigsize) {
		perror("IsTrusted(): Reading signature file");
		return 0;
	}

	printf("IsTrusted(): Read in %d bytes of signature.\n", sigsize);
	fclose(fp);

	printf("IsTrusted(): Verifying script...\n");
	/////////// Verifying digest, signature, and public key
	trusted = RSA_verify(NID_sha1, digestBuf, SHA_DIGEST_LENGTH, sigBuf, sigsize, pubkey);
       

	RSA_free(pubkey);

	free(scriptBuf);
	free(digestBuf);

	return trusted;
}

// Process request from OA to get sensor feed from application.
int Subscribe(int connfd, char *packet, int pipes[2], int secure)
{
	void (*function) (FilterParameter);
	void *handle;
	CommandHeaderSubscribe hsubs;
	FilterParameter param;
	char *error;
	char codeName[sizeof(CODEPATH) + MD5LEN + 1];

	assert(packet != NULL);

	if (RawToSubs(packet, &hsubs) == 0)
		return SOCK_ERROR;


	sprintf(codeName, "%s%s.so", CODEPATH, hsubs.scriptName);
	printf("Subscribe(): Loading and running the code: %s\n", codeName);


	if (IsTrusted(hsubs.scriptName, codeName) == 0 && secure) {
		printf("Subscribe(): Script is UNTRUSTED\n");

		// set uid and gid to nobody
		if (setgid(99) == -1) {
			perror("Subscribe(): setgid ()");
			printf("Subscribe(): Make sure you have root privileges.\n");
			return -1;
		}

		if (setuid(99) == -1) {
			perror("Subscribe(): setuid()");
			printf("Subscribe(): Make sure you have root privileges.\n");
			return -1;
		}


	}
	else {
		printf("Subscribe(): Script is TRUSTED\n");
	}

	// load and execute the script
	handle = dlopen(codeName, RTLD_LAZY);
	if (!handle) {
		fputs(dlerror(), stderr);
		return DL_LOAD_ERROR;
	}

	// assume that the filter routine is named as "Start()"
	function = (void(*)(FilterParameter)) dlsym(handle, "Start");
	if ((error = dlerror()) != NULL) {
		fputs(error, stderr);
		return DL_LOAD_ERROR;
	}

	// call the filter function
	strcpy(param.confFile, hsubs.confFile);
        param.oa = &hsubs.orgAgent;
        param.pipes[0] = pipes[0];
        param.pipes[1] = pipes[1];

	//param.shmKey = IMAGE_SHM_KEY;
	//strcpy(param.confFile, "parking.conf");
	(*function) (param);
	dlclose(handle);

	return OK;
}

// process the TalkToSenselet command
int  TalkToSenselet(char *packet)
{
        CommandHeaderTalkToSenselet cmd;
        int pipes[2], i;

        if (RawToTalkToSenselet(packet, &cmd) != 1) {
                printf("Error in parsing TalkToSenselet command\n");
                return SOCK_ERROR;
        }

        i = FindRunning(cmd.orgAgent.addr, cmd.senseletName);
        if (i == -1) return 1;

        // get the pipe to talk to the senselet
        pipes[0] = runningFilter[i].pipes[0] ;
        pipes[1] = runningFilter[i].pipes[1];

        // now send the command to the senselet
        write(pipes[1], cmd.command, strlen(cmd.command));
        return 0;
}

void Initialize(void)
{
	currentlyRunning = 0;
	SetDebugLevel(100);
	SetDperrorLevel(100);
	signal(SIGCLD, SIG_IGN);

}

// each running code has an entry in the runningFilter table
void AddToRunning(CommandHeaderSubscribe subsCmd, pid_t pid, int pipes[2])
{
        if (currentlyRunning >= MAXFILTER) {
                printf("AddToRunning(): Maximum number of applications reached.\n");
                return;
        }

        printf("Adding pid: %d\n", pid);
        runningFilter[currentlyRunning].subsCmd.orgAgent.addr =
            subsCmd.orgAgent.addr;
        runningFilter[currentlyRunning].subsCmd.orgAgent.port =
            subsCmd.orgAgent.port;
        strcpy(runningFilter[currentlyRunning].subsCmd.scriptName,
               subsCmd.scriptName);
        runningFilter[currentlyRunning].pid = pid;
        runningFilter[currentlyRunning].pipes[0] = pipes[0];
        runningFilter[currentlyRunning].pipes[1] = pipes[1];
        currentlyRunning++;
}


// Finds the index of the specified application
// Returns -1 if none found
int FindRunning(struct in_addr oa, char *senselet)
{
        int i;
        for (i = 0; i < currentlyRunning; i++) {
                if ((runningFilter[i].subsCmd.orgAgent.addr.s_addr == oa.s_addr)
                    // && (runningFilter[i].subsCmd.orgAgent.port == subsCmd.orgAgent.port)
                    && !(strcmp (runningFilter[i].subsCmd.scriptName, senselet)))
                        return i;
        }

        printf("FindRunning(): Application %s not found\n", senselet);
        return -1;
}

// Delete application at index
// Returns the number of applications currently running
// Returns -1 on error
int DeleteRunning(int index)
{
	int i;
	if (index >= currentlyRunning || index < 0) {
		printf("DeleteRunning(): Invalid index %d\n", index);
		return -1;
	}

	for (i = index + 1; i < currentlyRunning; i++)
		runningFilter[i - 1] = runningFilter[i];

	return --currentlyRunning;
}

// Logs the current process id to /tmp/IRISSA.pid.*
void LogPid()
{
	pid_t pid;
	char buf[80];
	FILE *outf;


	pid = getpid();
	sprintf(buf, "/tmp/IRISSA.pid.%d", pid);

	outf = fopen(buf, "w");

	if (outf == NULL) {
		printf("LogPid(): File open error on %s.\n", buf);
		return;
	}

	sprintf(buf, "%d\n", pid);
	fwrite(buf, 1, strlen(buf), outf);
	fflush(outf);
	fclose(outf);
}



// Checks the shared memory to make sure it has been recently updated
void CheckSharedMemory(shmHeaderType * shmHeader)
{
	double elapsedTime = 0;

	assert (shmHeader != NULL);

	// skip check if elapsed time since last check is too short.
	if (difftime(time(NULL), shmLastCheckTime) < shmCheckInterval)
		return;

	time(&shmLastCheckTime);
	
	if (shmHeader->isInit != SHM_INITIALIZED) {
		printf("CheckSharedMemory(): WARNING: Shared memory not initialized\n");
		return;
	}
	
	elapsedTime = (GetTime() - shmHeader->lastUpdateTime) / 1000;

	if (elapsedTime > shmMaxIdleInterval) {
		printf("CheckSharedMemory(): WARNING: Shared memory not updated for ");

		if (elapsedTime > 7200)
			printf("%d hours\n", (int) (elapsedTime / 3600));
		else if (elapsedTime > 120)
			printf("%d minutes\n", (int) (elapsedTime / 60));
		else
			printf("%d seconds\n", (int) elapsedTime);
	}


}

// Main loop for processing incoming connections
void MainLoop(int listenfd, int secure)
{
	struct timeval tv;
	socklen_t clilen;
	struct sockaddr_in oaaddr;
	int connfd;
	char status_str[256];
	char *packet_tmp, *packet, *command;
	long status;
	CommandHeaderSubscribe cmdSubs;
	int pid, pipes[2];
	int i;
	shmHeaderType * shmHeader;
	
#ifdef NONBLOCKING
	fd_set rset;

	FD_ZERO(&rset);
#endif

	shmHeader = OpenSharedMemoryHeader();

	if (shmHeader == NULL) {
		printf("MainLoop(): Error opening shared memory.\n");
		return;
	}

	tv.tv_sec = tv.tv_usec = 0;


	for (;;) {
		usleep(1000);
		CheckSharedMemory(shmHeader);

#ifdef  NONBLOCKING
		//check the listening socket
		FD_SET(listenfd, &rset);
		Select(listenfd + 1, &rset, NULL, NULL, &tv);
		if (FD_ISSET(listenfd, &rset))
#endif
		{
			clilen = sizeof(oaaddr);
			connfd =
			    Accept(listenfd, (SA *) & oaaddr, &clilen);
			if (DEBUG)
				printf("SA(): Got a connection\n");
			if ((packet_tmp = ReadFromSocket(connfd)) == NULL) {
				printf("SA(): Invalid packet received\n");
				continue;
			}

			command = packet_tmp;
			packet = packet_tmp + 2;
			if (DEBUG)
				printf("SA(): Packet: %s\n", packet);

			// process the packet
			switch (*command) {	// 3rd byte is the command OPCODE
			case COMMAND_QUERY:
				break;

			case COMMAND_LOAD:
				if ((pid = Fork()) == 0) {
					// this is the child process for handling
					// the socket operations
					Close(listenfd);
					status = Load(connfd, packet);
					sprintf(status_str, "%d",
						(int) status);
					//WriteToSocket(status_str);
					Close(connfd);
					exit(0);
				}
				break;

			case COMMAND_SUBSCRIBE:
				if (DEBUG)
                                        printf("SA(): Subscribing\n");

                                if (pipe(pipes) != 0) {
                                        printf("Subscribe: Cannot create pipe\n");
                                        break;
                                }

                                if ((pid = Fork()) == 0) {
                                        // this is the child process for handling
                                        // the socket operations
                                        Close(listenfd);
                                        close(pipes[1]);
                                        Subscribe(connfd, packet, pipes, secure);
                                        Close(connfd);
                                        exit(0);
                                } else {        // parent updates the runingFilter table
                                        close(pipes[0]);
                                        if (RawToSubs(packet, &cmdSubs) != 0)
                                                AddToRunning(cmdSubs, pid, pipes);
                                }
                                break;

			case COMMAND_UNSUBSCRIBE:
				if (RawToSubs(packet, &cmdSubs) == 0)
					break;

				i = FindRunning(cmdSubs.orgAgent.addr, cmdSubs.scriptName);

				if (i == -1)
					break;

				if (DEBUG) {
					printf("SA(): Killing process with ID %d\n",
					       runningFilter[i].pid);
				}

				kill(runningFilter[i].pid, SIGTERM);	// kill the process
				close(runningFilter[i].pipes[1]);
				DeleteRunning(i);
				break;

			case COMMAND_TALKTOSENSELET:
                                TalkToSenselet(packet);
                                break;

			}

			free(packet_tmp);
			Close(connfd);
		}
	}


}

// Opens the listening socket for incoming connections
// Returns file descriptor of the socket
int OpenListenFd(int port)
{
	struct sockaddr_in saaddr;
	int listenfd;
	
	// open the socket to listen from the OAs
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	saaddr.sin_port = htons(port);
	Bind(listenfd, (SA *) & saaddr, sizeof(saaddr));
	Listen(listenfd, LISTENQ);

	return listenfd;
}

int main(int argc, char **argv)
{
	int port;
	int secure = 0;

	if (argc != 3) {
		printf("Usage: SA <cmd_port> <secure>\n");
		return 0;
	}

	Initialize();

	port = atoi(argv[1]);
	secure = atoi(argv[2]);

	// main SA loop

	LogPid();

	printf("SA started.  Listening for commands on port %d...\n", port);

	MainLoop(OpenListenFd(port), secure);

	return 0;
}
