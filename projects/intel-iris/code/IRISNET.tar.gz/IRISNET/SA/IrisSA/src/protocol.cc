/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

/* WARNING!!!
 * RawToLoad and RawToSubs are not thread safe and modify the packets
 * Better checks need to be done.
 */

#include "unp.h"
#include "SA.h"
#include "Agent.h"
#include "protocol.h"

#include <assert.h>

/*
void WriteToSocket(int connfd, char *st)
{
	char pre[6];
	int sz = strlen(st) + 6;

        assert(st != NULL);

	//first 3 bytes of the packet os the length
	pre[0] = sz / (128 * 128);	//(len & 0xff0000) >> 16;
	pre[1] = (sz % (128 * 128)) / 128;	//(len & 0x00ff00) >> 8;
	pre[2] = (sz % (128 * 128)) % 128;	//(len & 0x0000ff);

	// put a dummy time stamp
	pre[3] = '0';
	pre[4] = '0';
	pre[5] = ' ';

	// write to socket
	Write(connfd, pre, 6);
	Write(connfd, st, sz - 6);
}
*/

// Read a packet from the socket
// Mallocs memory - caller must free it
// returns NULL on error
// Guarantees that packet terminates with a \0
char *ReadFromSocket(int connfd)
{
	char lengthBytes[3], c, *st;
	unsigned long length, nRead, pending;

	// read number of bytes in packet
	if ((nRead = Read(connfd, lengthBytes, 3)) != 3) {
		printf("ReadFromSocket(): Invalid packet length.\n");
		return NULL;
	}

	// signed int
	length =
	    lengthBytes[0] * 128 * 128 + lengthBytes[1] * 128 +
	    lengthBytes[2];

	if (length > MAX_PACKET_SIZE) {
		printf("ReadFromSocket(): Packet size greater than maximum of %d\n", MAX_PACKET_SIZE);
		return NULL;
	}

	// add 1 byte at end for terminating \0
	if ((st = (char *) calloc(1, length + 1)) == NULL) {
		printf("ReadFromSocket(): Error allocating memory of size %d\n", length  + 1);
		return NULL;
	}

	pending = length - 3;

	// skip the timestamp
	do {
		if ((nRead = Read(connfd, &c, 1)) != 1) {
			printf("ReadFromSocket(): Timestamp not found.\n");
			free(st);
			return NULL;
		}
		pending--;
	} while (c != ' ');

	if ((nRead = Read(connfd, st, pending)) != pending) {
		printf("ReadFromSocket(): Incorrect number of bytes read in packet.\n");
		free(st);
		return NULL;
	}

	st[nRead] = 0;

	return st;
}


void subString(char *string, int start, int len, char *substring)
{
	int i;

	assert(string != NULL && substring != NULL);

	for (i = 0; i < len; i++)
		substring[i] = string[start + i];

	substring[i] = 0;
}


// parse the LOAD packet and fills the loadCmd structure
// returns 1 on success, 0 on error
int RawToLoad(char *packet, CommandHeaderLoad * loadCmd)
{
	char *p = packet;
	char *last;

	assert (packet != NULL);
	assert (loadCmd != NULL);

	p = strtok_r(packet, " \n", &last);

	if (p == NULL) {
		printf("RawToLoad(): Language token error.\n");
		return 0;
	}

	loadCmd->language = p[0];

	p = strtok_r(NULL, " \n", &last);
	
	if (p == NULL) {
		printf("RawToLoad(): Script name token error.\n");
		return 0;
	}
	else if (strlen(p) > SCRIPT_NAME_LEN) {
		printf("RawToLoad(): Script name too long.\n");
		return 0;
	}

	strcpy(loadCmd->scriptName, p);

	printf("RawToLoad(): ScriptName: %s\n", loadCmd->scriptName);
	return 1;
}

// parse the Subscribe or Unsubscribe packet and fills
// in the subsCmd structure
// returns 1 on success, 0 on error
// format: "S <OA_IP> <OA_PORT> <SenseletName> <Config File Name>
int RawToSubs(char *packet, CommandHeaderSubscribe * subsCmd)
{
	char *p, *last;
	int ret = 0;

	assert(packet != NULL);
	assert(subsCmd != NULL);

	p = strtok_r(packet, " \n", &last);

	if (p == NULL) {
		printf("RawToSubs(): Org Agent address token error.\n");
		return 0;
	}

	ret = inet_pton(AF_INET, p, & (subsCmd->orgAgent.addr));

	if (ret <= 0) {
		perror("RawToSubs(): Address token error");
		return 0;
	}

	printf("RawToSubs(): Address: %s\n", p);

	p = strtok_r(NULL, " \n", &last);

	if (p == NULL) {
		printf("RawToSubs(): Port token error\n");
		return 0;
	}

	subsCmd->orgAgent.port = atoi(p);

	printf("RawToSubs(): Port: %d\n", subsCmd->orgAgent.port);

	p = strtok_r(NULL, " \n", &last);

	if (p == NULL) {
		printf("RawToSubs(): Script name token error\n");
		return 0;
	}

	if (strlen(p) > SCRIPT_NAME_LEN) {
		printf("RawToSubs(): Script name too long\n");
		return 0;
	}

	strcpy(subsCmd->scriptName, p);

	printf("RawToSubs(): ScriptName: %s\n", subsCmd->scriptName);

	p = strtok_r(NULL, " \n", &last);

        if (p != NULL) {
                if (strlen(p) > MAX_FNAME_LEN) {
                        printf("RawToSubs(): Configuration file name too long\n");
                        return 0;
                }
                strcpy(subsCmd->confFile, p);
        }

	printf("RawToSubs(): Configuration file: %s\n", subsCmd->confFile);
	
	return 1;
}

// parse the LoadConfig packet and fills
// in the loadConfigCmd structure
// returns 1 on success, 0 on error
// format: "R <OA_IP> <OA_PORT> <Senselet> <Config File>"
int RawToTalkToSenselet(char *packet, CommandHeaderTalkToSenselet * ttSenseletCmd)
{
        char *p, *last;
        int ret = 0;

        assert(packet != NULL);
        assert(ttSenseletCmd != NULL);

        p = strtok_r(packet, " \n", &last);

        if (p == NULL) {
                printf("RawToTalkToSenselet(): Org Agent address token error.\n");
                return 0;
        }

        ret = inet_pton(AF_INET, p, & (ttSenseletCmd->orgAgent.addr));

        if (ret <= 0) {
                perror("RawToTalkToSenselet(): Address token error");
                return 0;
        }

        printf("RawToSubs(): Address: %s\n", p);

        p = strtok_r(NULL, " \n", &last);

        if (p == NULL) {
                printf("RawToTalkToSenselet(): Port token error\n");
                return 0;
        }
        ttSenseletCmd->orgAgent.port = atoi(p);
        printf("RawToSubs(): Port: %d\n", ttSenseletCmd->orgAgent.port);

        p = strtok_r(NULL, " \n", &last);

        if (p == NULL) {
                printf("RawToTalkToSenselet(): Senselet name token error\n");
                return 0;
        }

        if (strlen(p) > SCRIPT_NAME_LEN) {
                printf("RawToTalkToSenselet(): Senselet name too long\n");
                return 0;
        }

        strcpy(ttSenseletCmd->senseletName, p);

        p = strtok_r(NULL, "\n", &last);

        if (p == NULL) {
                printf("RawToTalkToSenselet(): command token error\n");
                return 0;
        }

        if (strlen(p) > MAX_FNAME_LEN) {
                printf("RawToTalkToSenselet(): command too long\n");
                return 0;
        }

        strcpy(ttSenseletCmd->command, p);

        printf("RawToTalkToSenselet(): Senselet: %s, commnad: %s\n", ttSenseletCmd->senseletName, ttSenseletCmd->command);

        return 1;
}


