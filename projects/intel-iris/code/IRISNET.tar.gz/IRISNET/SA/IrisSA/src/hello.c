#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>
#include "unp.h"
#include "Agent.h"

void Start(OrgAgent *oa) {
 	char buffer[BUFFLEN+1];
	int  sockfd, i;
	struct sockaddr_in saaddr;

	// debug
	//inet_ntop(AF_INET, &(oa->addr.s_addr), buffer, 100);
	//printf("COnnecting to host %s, port %d\n", buffer, oa->port);

	sockfd = Socket(AF_INET, SOCK_STREAM, 0);
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(oa->port);
	//Inet_pton(AF_INET, sa->addr.s_addr, &saaddr.sin_addr);
	saaddr.sin_addr = oa->addr;  
	Connect(sockfd, (SA *) &saaddr, sizeof(saaddr));

	printf("Inside\n");
	for (i = 0; i<3; i++) {
	 	sprintf(buffer, "Hello world from SA. PID: %d, Timestamp: %d\n", getpid(), time(NULL));
		printf("Sending to OA: %s\n", buffer);
		Write(sockfd, buffer, BUFFLEN);
		sleep(1);
	}

}
