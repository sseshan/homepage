#!/usr/bin/perl

# Parsing the command line parameters
if ($#ARGV < 0) {
  print "Usage: sort_pspots.pl {pspots.conf} [pspot_to_be_deleted ...]\n";
  exit (1);
}

my $filename = $ARGV[0];
my $del_begin = 1;
my $del_end = $#ARGV;
my $num_to_delete = $del_end - $del_begin + 1;

open (IN, "$filename") or die "can't open $filename";

# read the first line
my $line = <IN>;
chomp ($line);

my $total_num = $line;

if ($total_num - $num_to_delete != 6) {
  print "Error: there are $total_num pspots in $filename\n";
  print "       if $num_to_delete pspots are to be deleted, then the rest is not equal to 6!\n";
  exit (1);
}

# read the parking spots
my (@x);
my (@y);
my (@width);
my (@height);
my (@number);
my (@name);

my $jj = 0;
for (my $ii = 0; $ii < $total_num; $ii ++) {
   $line = <IN>;
   chomp ($line);
   ($x[$jj], $y[$jj], $width[$jj], $height[$jj], $number[$jj], $name[$jj]) = split (/\s+/, $line);

   # test if this parking spot is to be deleted
   for (my $kk=$del_begin; $kk <= $del_end; $kk ++) {
      if ($ARGV[$kk] == $number[$jj]) {
        $jj --; 
	last;
      }
   }
   $jj ++;
}

# read the number of landmarks and their coordinates
my $num_landmarks = <IN>; chomp ($num_landmarks);
my $lm_coords = <IN>; chomp ($lm_coords);

close (IN);

if ($num_landmarks != 4) {
  print "Error: number of landmarks is not 4!\n";
  exit (1);
}

# -------------------------------------------------------------
# sort the parking spots by order of y
for (my $ii = 0; $ii < 5; $ii ++) {
  my $smallest = $ii;
  for (my $kk = $ii+1; $kk < 6; $kk ++) {
     if ($y[$kk] < $y[$smallest]) {
       $smallest = $kk;
     }
  }
  if ($smallest != $ii) {
    my $temp = $x[$smallest]; $x[$smallest] = $x[$ii]; $x[$ii] = $temp;
    $temp = $y[$smallest]; $y[$smallest] = $y[$ii]; $y[$ii] = $temp;
    $temp = $width[$smallest]; $width[$smallest] = $width[$ii]; $width[$ii] = $temp;
    $temp = $height[$smallest]; $height[$smallest] = $height[$ii]; $height[$ii] = $temp;
    $temp = $number[$smallest]; $number[$smallest] = $number[$ii]; $number[$ii] = $temp;
    $temp = $name[$smallest]; $name[$smallest] = $name[$ii]; $name[$ii] = $temp;
  }
}

# sort the parking spots by order of x, 2 parts
for (my $ii = 0; $ii < 2; $ii ++) {
  my $smallest = $ii;
  for (my $kk = $ii+1; $kk < 3; $kk ++) {
     if ($x[$kk] < $x[$smallest]) {
       $smallest = $kk;
     }
  }
  if ($smallest != $ii) {
    my $temp = $x[$smallest]; $x[$smallest] = $x[$ii]; $x[$ii] = $temp;
    $temp = $y[$smallest]; $y[$smallest] = $y[$ii]; $y[$ii] = $temp;
    $temp = $width[$smallest]; $width[$smallest] = $width[$ii]; $width[$ii] = $temp;
    $temp = $height[$smallest]; $height[$smallest] = $height[$ii]; $height[$ii] = $temp;
    $temp = $number[$smallest]; $number[$smallest] = $number[$ii]; $number[$ii] = $temp;
    $temp = $name[$smallest]; $name[$smallest] = $name[$ii]; $name[$ii] = $temp;
  }
}

for (my $ii = 3; $ii < 5; $ii ++) {
  my $smallest = $ii;
  for (my $kk = $ii+1; $kk < 6; $kk ++) {
     if ($x[$kk] < $x[$smallest]) {
       $smallest = $kk;
     }
  }
  if ($smallest != $ii) {
    my $temp = $x[$smallest]; $x[$smallest] = $x[$ii]; $x[$ii] = $temp;
    $temp = $y[$smallest]; $y[$smallest] = $y[$ii]; $y[$ii] = $temp;
    $temp = $width[$smallest]; $width[$smallest] = $width[$ii]; $width[$ii] = $temp;
    $temp = $height[$smallest]; $height[$smallest] = $height[$ii]; $height[$ii] = $temp;
    $temp = $number[$smallest]; $number[$smallest] = $number[$ii]; $number[$ii] = $temp;
    $temp = $name[$smallest]; $name[$smallest] = $name[$ii]; $name[$ii] = $temp;
  }
}

# -------------------------------------------------------------
# output the parking spots
print "6\n";
for ($jj=0; $jj<6; $jj ++) {
   $number[$jj] = $jj + 1;
   print "$x[$jj] $y[$jj] $width[$jj] $height[$jj] $number[$jj] $name[$jj]\n";
}

# output landmarks
print "$num_landmarks\n";
print "$lm_coords\n"
