/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


// opencv includes
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

// SA common
#include <shmman.h>
#include <imgproc.h>
#include "plugin.h"
#include <protocol.h>

#include <unp.h>

// Unix system includes
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <semaphore.h>

#include <list>
#include <string>

// need to fold this into make file
#undef NDEBUG
#include <assert.h>

using namespace std;

sem_t mylock;
list<filterFunc> filters;
list<void *> handles;

// Creates shared memory to dump the frames from the webcam.
// The shared memory segment must be initialized with this function
// before it can be used.
// We write a header block to the beginning of the shared memory, and then
// mark the rest of the memory for the frames.
//
// the frames are assumed to be of 4-byte color
// the frames are used as a circular buffer 
// 
// The first int in the shared buffer indocates the head of the circular queue
// The rest of the buffer is the circular buffer
//
// returns 0 if failure, 1 if successful
int CreateSharedMemory(shmHeaderType * shmHeader, int key, int flags)
{
	int size = shmHeader->width * shmHeader->height * shmHeader->bytesPerPixel; // 4-byte color
	int shmid; // shared memory id
	int i;

	printf("Create Shared Memory(): Creating memory with key %d and size %d\n", key, shmHeader->bufsize);

	// createss shared memory segment with proper size and id
	if ((shmid =
	     shmget(key,
		    shmHeader->bufsize,
		    flags | IPC_CREAT)) < 0) {
		perror("Failed to create shared memory");
		printf("This may happen when another application previously\n");
		printf("allocated shared memory that was too small.\n");
		printf("You may also get this error when using 'loadImage' to\n");
		printf("load images with smaller size or depth into shared memory.\n");
		printf("When upgrading to a new version of this program, you may get this error.\n");
		printf("Please reboot your machine and try again.\n");
		return 0;
	}

	void * mem = shmat(shmid, 0, 0);
	shmHeaderType * newshmHeader = (shmHeaderType *) mem;

	memcpy(mem, (void *) shmHeader, sizeof(shmHeaderType));

	// mark frames in shared memory
	for (i = 0; i < shmHeader->numFrames; i++) {
		newshmHeader->offsets[i] = sizeof(shmHeaderType)
			+ i * size;
		//shmInfo->offsets[i] = shmHeader->offsets[i];
		printf("CreateSharedMemory(): Setting offset %d to %x\n", i, newshmHeader->offsets[i]);
		newshmHeader->timestamps[i] = 0;
	}


       	newshmHeader->isInit = SHM_INITIALIZED;

	shmdt((void *) mem);

	return 1;
}

// loads webcam video frame into shared memory
// loops forever
// returns 0 on error
int LoadFrame(void * rawmem, int sleepSeconds, int displayFlag)
{

	int currFrame = 0;
	uchar *safeImgData = NULL, *rawImgData = NULL;
	void *safemem = NULL;

	shmHeaderType *safeshmHeader = NULL, *rawshmHeader = NULL;

	// open shared memory
	safemem = OpenSharedMemory();

	if (safemem == NULL || rawmem == NULL) {
	        printf("LoadFrame(): Error opening shared memory.\n");
		return 0;
	}

	printf("Shared memory mapped to %x, %x\n",
	       (unsigned int) safemem, (unsigned int) rawmem);

	safeImgData = (uchar *) safemem;
	rawImgData = (uchar *) rawmem;

	safeshmHeader = (shmHeaderType *) safeImgData;
	rawshmHeader = (shmHeaderType *) rawImgData;

	printf("Width: %d  Height: %d  Channels: %d\n", safeshmHeader->width, safeshmHeader->height, safeshmHeader->bytesPerPixel);

	CvSize imgSize;

	imgSize.width = safeshmHeader->width;
	imgSize.height = safeshmHeader->height;

	// if displayFlag option is ON, create the image to display
	if (displayFlag) {
		if (cvNamedWindow("webcam_raw", HG_AUTOSIZE) != 1) {
			printf("Error creating display window.\n");
			return 0;
		}

		if (cvNamedWindow("webcam_filtered", HG_AUTOSIZE) != 1) {
			printf("Error creating display window.\n");
			return 0;
		}
	}

	IplImage * srcImage;

	long lasttime = GetTime();
	int count = 0;
	int interval = 1;

	// dump frames in shared memory
	for (;;) {
		// get raw data from camera feed to IplImage format.
		int size = safeshmHeader->width * safeshmHeader->height
			* safeshmHeader->bytesPerPixel;
		IplImage * rawImage = cvCreateImageHeader(imgSize, IPL_DEPTH_8U,
			safeshmHeader->bytesPerPixel);

		cvSetImageData(rawImage,
			       rawImgData + rawshmHeader->offsets[rawshmHeader->buffHead],
			       rawshmHeader->bytesPerPixel * rawshmHeader->width);

		if (displayFlag) {	       
			cvShowImage("webcam_raw", rawImage);
			// this fixes bug in highgui of not automatically resizing
			cvResizeWindow("webcam_raw", rawImage->width + 1, rawImage->height+1);
		}

		//////////////////////////

		srcImage = cvCloneImage(rawImage);
		cvReleaseImageHeader(&rawImage);
	
		sem_wait(&mylock);
		for (list<filterFunc>::iterator iter = filters.begin();
		     iter != filters.end();
		     iter++) {

			(*iter)(srcImage);
		}
		sem_post(&mylock);
		
		// printf("Copying %d bytes to shared memory\n", size);
		memcpy(safeImgData + safeshmHeader->offsets[currFrame],
		       srcImage->imageDataOrigin, size);

		safeshmHeader->buffHead = (int) currFrame;

		safeshmHeader->lastUpdateTime = GetTime();
		//printf("loading in offset %d %d..\n", currFrame, shmInfo.offsets[currFrame]);

		if (displayFlag) {	       
			cvShowImage("webcam_filtered", srcImage);
			// this fixes bug in highgui of not automatically resizing
			cvResizeWindow("webcam_filtered", srcImage->width + 1, srcImage->height+1);
		}

		currFrame = (currFrame + 1) % safeshmHeader->numFrames;
		// printf("Hi %x\n", * ((unsigned int *) (safeImgData + safeshmHeader->offsets[currFrame])));

		cvReleaseImage(&srcImage);

		count++;

		if (count % interval == 0) {
			float msperframe = (float) (GetTime() - lasttime) / interval;
			printf("Perf: %f ms per frame.\n", msperframe);
			lasttime = GetTime();
		}

		if (sleepSeconds < 100)
			sleep(sleepSeconds);
		else
			usleep(sleepSeconds);

	}

	cvReleaseImage(&srcImage);

	return 1;
}


void LoadFiltersFromString(char * str) {
	
	char * token = strtok(str, " ");
	int num = atoi(token);

	sem_wait(&mylock);

	for (int i = 0; i < num; i++) {
		token = strtok(NULL, " ");
		printf("LoadFiltersFromString: Loading %s\n", token);
		
		void * handle = dlopen(token, RTLD_LAZY);
		if (!handle) {
			printf("%s\n", dlerror());
			continue;
		}
		
		filterFunc filter = (filterFunc) dlsym(handle, "ProcessFrame");
		char * error;

		if ((error = dlerror()) != NULL) {
			printf("%s\n", error);
			continue;
		}
		
		filters.push_back(filter);
		handles.push_back(handle);
		

	}

	sem_post(&mylock);
}


void LoadFiltersFromFile() {

	FILE * fh = fopen("filters.txt", "r");
	
	if (fh == NULL) {
		perror("LoadFiltersFromFile()");
		return;
	}

	char line[256];

	sem_wait(&mylock);

	while (fscanf(fh, "%s", line) > 0) {
		printf("LoadFiltersFromFile: Loading %s\n", line);
		
		void * handle = dlopen(line, RTLD_LAZY);
		if (!handle) {
			printf("%s\n", dlerror());
			continue;
		}
		
		filterFunc filter = (filterFunc) dlsym(handle, "ProcessFrame");
		char * error;

		if ((error = dlerror()) != NULL) {
			printf("%s\n", error);
			continue;
		}
		
		filters.push_back(filter);
		handles.push_back(handle);
	}

	sem_post(&mylock);

	fclose(fh);
}

void UnloadFilters() {
		
	sem_wait(&mylock);
	for (list<void *>::iterator iter = handles.begin();
	     iter != handles.end();
	     iter++) {
		dlclose(*iter);
	}

	handles.clear();
	filters.clear();

	sem_post(&mylock);
}

// Opens the listening socket for incoming connections
// Returns file descriptor of the socket
int OpenListenFd(int port)
{
	struct sockaddr_in saaddr;
	int listenfd;
	
	// open the socket to listen from the OAs
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	saaddr.sin_port = htons(port);
	Bind(listenfd, (SA *) & saaddr, sizeof(saaddr));
	Listen(listenfd, LISTENQ);

	return listenfd;
}

void * netthread (void *vargp) {
	int port = 3457;
	int listenfd = OpenListenFd(port);
	struct timeval tv;
	socklen_t clilen;
	struct sockaddr_in oaaddr;
	int connfd;
	char *packet_tmp, *packet, *command;


	fd_set rset;

	FD_ZERO(&rset);
	tv.tv_sec = tv.tv_usec = 0;

	printf("Filter(): Waiting for connection on port %d\n", port);

	for (;;) {
		usleep(1000);
		//check the listening socket
		FD_SET(listenfd, &rset);
		Select(listenfd + 1, &rset, NULL, NULL, &tv);
		if (FD_ISSET(listenfd, &rset)) {
			clilen = sizeof(oaaddr);
			connfd = Accept(listenfd, (SA *) & oaaddr, &clilen);
			printf("Filter(): Got a connection\n");
			if ((packet_tmp = ReadFromSocket(connfd)) == NULL) {
				printf("filter(): Invalid packet received\n");
				continue;
			}

			command = packet_tmp;
			packet = packet_tmp + 2;
			
			printf("Filter(): Packet: %s\n", packet);

			// process the packet
			switch (*command) {	// 3rd byte is the command OPCODE
			case COMMAND_FILTER:
				UnloadFilters();
				LoadFiltersFromString(packet);

				break;
			}

	
			free(packet_tmp);
			Close(connfd);
		}
	}

	return NULL;
}

int main(int argc, char *argv[])
{
	int displayFlag = 1, secondsPerFrame = 0;

	if (argc != 3) {
		printf
		    ("Usage: filter <sleep_time(s/ms)> <displayflag>\n");
		return 1;
	}

	if (sscanf(argv[1], "%d", &secondsPerFrame) != 1 ||
	    (sscanf(argv[2], "%d", &displayFlag) != 1)) {
		printf("Error in argv format\n");
	}

	/*
	if ((sscanf(argv[1], "%d", &numFrames) != 1) ||
	    (sscanf(argv[2], "%d", &fInfo.width) != 1) ||
	    (sscanf(argv[3], "%d", &fInfo.height) != 1) ||
	    (sscanf(argv[4], "%d", &secondsPerFrame) != 1) ||
	    (sscanf(argv[5], "%d", &displayFlag) != 1)) {
		printf("Error in argv format\n");
		return 1;
	};

	*/

	sem_init(&mylock, 0, 1);

	void * mem = OpenSharedMemoryKey(IMAGE_RAW_SHM_KEY);

	// creating censored shared memory
	if (CreateSharedMemory((shmHeaderType *) mem,
			       IMAGE_SHM_KEY, S_IRWXU | S_IRWXG | S_IRWXO) == 0) {
	        printf("Failed to create censored shared memory.\n");
		return 1;
	}
	


	LoadFiltersFromFile();

	pthread_t tid;
	pthread_create(&tid, NULL, netthread, 0);

	LoadFrame(mem, secondsPerFrame, displayFlag);
	pthread_join(tid, NULL);

	return 0;
}
