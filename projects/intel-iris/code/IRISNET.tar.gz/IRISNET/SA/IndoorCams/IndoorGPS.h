/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef INDOORGPS_H
#define INDOORGPS_H

#include <stdlib.h>

#include <cv.h>

#include "GPSSource.h"
#include "SharedFIFO.h"
#include "RndGen.h"

class IndoorGPS : public GPSSource {
private:
	RndGen rndgen;

	// GPSSource
	pthread_t gpstid;
	SharedFIFO * gpsFIFO;
	bool stopThread;

	int width, height;

public:
	double gpserror;
	
	IndoorGPS(SharedFIFO * gpsFIFO, double gpserror, int width, int height);

	~IndoorGPS();

	void gpsthread();

	// GPSSource methods
	void startGPS();
	void stopGPS();
};

#endif
