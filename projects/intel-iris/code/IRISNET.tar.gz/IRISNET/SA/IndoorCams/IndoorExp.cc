/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


#include <cv.h>
//#include "highgui.h"
//#include "SA.h"
//#include <sys/shm.h>
//#include <math.h>
//#include <sys/times.h>
//#include <sys/resource.h>
//#include "shmman.h"
//#include "imgproc.h"
//#include "csapp.h"

#include "imgproc.h"
#include "IndoorCam.h"
#include "SharedFIFO.h"
#include "GPSCommand.h"
#include "LandmarkDetector.h"
#include "PointMgr.h"
#include "IndoorGPS.h"

class IndoorExp {
private:
	GPSSource * gpssource;
	IndoorGPS * indoorgps;

	SharedFIFO * gpsFIFO;

	vector<LandmarkDetector *> lmDetectors;

	int numcams;
	PointMgr * pointmgr;
 public:
	IndoorExp();
	~IndoorExp();

	void start();
	void stop();
};

IndoorExp::IndoorExp() {
	gpsFIFO = new SharedFIFO(1);
	


	numcams = 3;
	double gpserror = 0.15;
	double camerror = 10;
	
	indoorgps =  new IndoorGPS(gpsFIFO, gpserror, 8, 8);
	gpssource = indoorgps;

	for (int i = 0; i < numcams; i++) {
		char tmp[10];
		sprintf(tmp, "cam%d", i + 1);
		IndoorCam * fc = new IndoorCam(tmp);

		lmDetectors.push_back(fc);
	
	}

	pointmgr = new PointMgr(numcams, gpserror, camerror);
}

IndoorExp::~IndoorExp() {
	delete(gpsFIFO);
	gpsFIFO = NULL;

	delete(gpssource);
	gpssource = NULL;

	for (unsigned int i = 0; i < lmDetectors.size(); i++)
		delete(lmDetectors[i]);

	delete(pointmgr);
	pointmgr = NULL;
}


void IndoorExp::start() {
	GPSCoord coord;

	gpssource->startGPS();
	
	int count = 0;
	bool done = false;

	while (!done) {
	//while (count < 25) {
		GPSCommand * cmd = (GPSCommand *) gpsFIFO->remove();
		//printf("GPS FIFO Command: %d\n", cmd->cmd);

		
		if (cmd->cmd == GPSCommand::DETECT_ON) {
			coord = cmd->coord;
			for (unsigned int i = 0; i < lmDetectors.size(); i++)
				lmDetectors[i]->startCapture(coord);
		}
		else {
			vector <CvPoint2D64d> campts;
			vector <bool> inViews;

			printf("GPS point (true): (%.8fN, %.8fW)\n", coord.trueLatN, coord.trueLongW);
			printf("GPS point (measured): (%.8fN, %.8fW)\n", coord.latN, coord.longW);
				
			bool anyInView = false;

			for (unsigned int i = 0; i < lmDetectors.size(); i++) {
				bool inView = false;
				CvPoint2D64d pt = lmDetectors[i]->stopCapture(coord, inView);
	
				printf("Camera ID: %d\n", lmDetectors[i]->id);
	
				printf("Image point (measured): (%f, %f)\n", pt.x, pt.y);
								
				if (inView) {
					printf("In view\n");
					anyInView = true;
				}
				else
					printf("NOT in view.\n");
				//pointmgr->add(coord, pt);
				//printf("\n");

				campts.push_back(pt);
				inViews.push_back(inView);
			}

			printf("\n");
			if (anyInView)
				pointmgr->add(coord, campts, inViews);
		}			


		delete (cmd);
		cmd = NULL;
		count++;

		printf ("%d points seen\n", count);
		if (count == 128) {
			pointmgr->updateCorres();
			done = true;
		}
	}

	for (int i = 0; i < numcams; i++) {
		char tmp[10];
		sprintf(tmp, "cam%d/base.png", i+1);
		
		IplImage * image = cvLoadImage(tmp);

		for (int x = 0; x < 8; x++) {
			for (int y = 0; y < 8; y++) {
				CvPoint p;
				p.x = x;
				p.y = y;

				CvPoint q = ApplyM(pointmgr->camH[i], p);
				cvCircle(image, q, 3, CV_RGB(255, 0, 0), 2);	
			}
		}

		DisplayIplImage(image, tmp);
		cvWaitKey(0);
	}
	
}


void IndoorExp::stop() {
	gpssource->stopGPS();
}

int main(int argc, char * argv[])
{

	IndoorExp * cams = new IndoorExp();
	cams->start();

	

	cams->stop();

	return 0;
}
