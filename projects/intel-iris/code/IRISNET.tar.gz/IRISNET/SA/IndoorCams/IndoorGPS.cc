/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#include "csapp.h"
#include "imgproc.h"

#include "IndoorGPS.h"
#include "GPSCommand.h"
#include "RndGen.h"

#define PI 3.14159265358979323846

void * thread(void * vargp) {
	//printf("GPS helper thread started.\n");

	((IndoorGPS *) vargp)->gpsthread();
	return NULL;
}



IndoorGPS::IndoorGPS(SharedFIFO * gpsFIFOin, double gpserror,
	 int width, int height) {

	this->height = height;
	this->width = width;

	gpsFIFO = gpsFIFOin;

	this->gpserror = gpserror;

}

IndoorGPS::~IndoorGPS() {

}




void IndoorGPS::startGPS() {
	stopThread = false;
	Pthread_create(&gpstid, NULL, thread, (void *) this);
}

void IndoorGPS::stopGPS() {
	stopThread = true;
	Pthread_join(gpstid, NULL);
}

void IndoorGPS::gpsthread() {
	printf("GPS thread started.\n");
	
	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {
			GPSCoord coord;

			coord.trueLatN = j;
			coord.trueLongW = i;

			double angle = rndgen.uniformDouble(2*PI);
			double len = fabs(rndgen.gaussian(0, gpserror));
			coord.latN = coord.trueLatN + len * sin(angle);
			coord.longW = coord.trueLongW + len * cos(angle);

			coord.hasTrue = true;

			GPSCommand * cmd = new GPSCommand(GPSCommand::DETECT_ON, coord);

			gpsFIFO->insert((unsigned int) cmd);

			cmd = new GPSCommand(GPSCommand::DETECT_OFF, coord);

			gpsFIFO->insert((unsigned int) cmd);
		}

	}

	printf("GPS thread stopped.\n");
}


