/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "Dlt.h"

CvMat * dlt(vector<CvPoint2D64d> pointList)
{
	//PList pointList;               // stores the point pairs. 
	//PList norm_pointList;          // store the normalized point pairs.
	//double * Hmatrix;              // global data struct for storing the homography
	//int algorithm=3;                 // decides which algorithm to implement to 
	// compute the homography
	// 1 -> DLT 
	// 2 -> Normalized DLT
	// 3 -> Gold Standard Algorithm

	

	unsigned int m, n;
	unsigned int i, j;

	m = pointList.size();
	n = 9;


	if (m < 10) {
		printf("dlt(): Error: Num points < 10\n");
		return NULL;
	}


	CvMat *A = cvCreateMat(m, n, CV_64FC1);
	CvMat *v = cvCreateMat(n, n, CV_64FC1);
	CvMat *u = cvCreateMat(m, n, CV_64FC1);
	CvMat *w = cvCreateMat(n, 1, CV_64FC1);

	
	//printf("Reading Point List and Constructing the A Matrix\n");


	// Implement DLT 

	//printf("Performing SVD on the A matrix \n");

	for (j = 0; j < pointList.size(); j += 2) {
		cvmSet(A, j, 0, 0);
		cvmSet(A, j, 1, 0);
		cvmSet(A, j, 2, 0);
		cvmSet(A, j, 3, -pointList[j].x);
		cvmSet(A, j, 4, -pointList[j].y);
		cvmSet(A, j, 5, -1);
		cvmSet(A, j, 6, pointList[j + 1].y * pointList[j].x);
		cvmSet(A, j, 7, pointList[j + 1].y * pointList[j].y);
		cvmSet(A, j, 8, pointList[j + 1].y);

		cvmSet(A, j + 1, 0, pointList[j].x);
		cvmSet(A, j + 1, 1, pointList[j].y);
		cvmSet(A, j + 1, 2, 1);
		cvmSet(A, j + 1, 3, 0);
		cvmSet(A, j + 1, 4, 0);
		cvmSet(A, j + 1, 5, 0);
		cvmSet(A, j + 1, 6, -pointList[j + 1].x * pointList[j].x);
		cvmSet(A, j + 1, 7, -pointList[j + 1].x * pointList[j].y);
		cvmSet(A, j + 1, 8, -pointList[j + 1].x);

	}

	//printf("--------------------\n");

	/*
	for (i = 0; i < pointList.size(); i++) {
		for (j = 0; j < 9; j++) {
			printf(" %f", cvmGet(A, i, j));
		}
		printf("\n");
	}
	*/


	//printf("calling svd routine\n");
	cvSVD(A, w, u, v);
	//dsvd(A->data.db, pointList.size(), 9, w, v);
	//printf("The linear least square method solution is \n");

	int s = n - 1;

	/*
	double minsingularvalue = 999999999;
	int s = -1;

	printf("the singular values are : \n");
	for (i = 0; i < n; i++) {

		if (cvmGet(w, i, 1) < minsingularvalue) {
			minsingularvalue = cvmGet(w, i, 1);
			s = i;
		}
		printf(" %f", cvmGet(w, i, 1));
	}
	*/

	/*
	printf("\n");
	printf("the V vector (%d): \n", s);
	
	for (i = 0; i < n; i++) {

		for (j = 0; j < 9; j++)
			printf("\t%f", cvmGet(v, i, j));
		printf("\n");
	}
	*/

	CvMat * H = cvCreateMat(3, 3, CV_64FC1);
	

	cvmSet(H, 0, 0, cvmGet(v, 0, s));
	cvmSet(H, 0, 1, cvmGet(v, 1, s));
	cvmSet(H, 0, 2, cvmGet(v, 2, s));
	cvmSet(H, 1, 0, cvmGet(v, 3, s));
	cvmSet(H, 1, 1, cvmGet(v, 4, s));
	cvmSet(H, 1, 2, cvmGet(v, 5, s));
	cvmSet(H, 2, 0, cvmGet(v, 6, s));
	cvmSet(H, 2, 1, cvmGet(v, 7, s));
	cvmSet(H, 2, 2, cvmGet(v, 8, s));

	/*
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++)
			printf("%lf ", cvmGet(H, i, j));
		printf("\n");
		}*/

	cvReleaseMat(&A);
	cvReleaseMat(&v);
	cvReleaseMat(&w);


	return H;

}

/*
void compute_centroid(double *c1x, double *c1y, double *c2x, double *c2y,
		      double *s1, double *s2, PList pointList)
{

	// first compute for the first image
	int n = pointList.size();
	int i;
	double xsum = 0;
	double ysum = 0;

	for (i = 0; i < n; i++) {
		xsum += pointList.xcoord[2 * i];
		ysum += pointList.ycoord[2 * i];
	}

	*c1x = xsum / n;
	*c1y = ysum / n;

	xsum = 0;
	ysum = 0;

	for (i = 0; i < n; i++) {
		xsum += pointList.xcoord[2 * i + 1];
		ysum += pointList.ycoord[2 * i + 1];
	}

	*c2x = xsum / n;
	*c2y = ysum / n;

	double dist1 = 0;
	double dist2 = 0;

	for (i = 0; i < n; i++) {
		dist1 +=
		    (pointList.xcoord[2 * i] -
		     *c1x) * (pointList.xcoord[2 * i] - *c1x) +
		    (pointList.ycoord[2 * i] -
		     *c1y) * (pointList.ycoord[2 * i] - *c1y);
		dist2 +=
		    (pointList.xcoord[2 * i + 1] -
		     *c2x) * (pointList.xcoord[2 * i + 1] - *c2x) +
		    (pointList.ycoord[2 * i + 1] -
		     *c2y) * (pointList.ycoord[2 * i + 1] - *c2y);
	}

	*s1 = sqrt(2.0 * n / dist1);
	*s2 = sqrt(2.0 * n / dist2);

	for (i = 0; i < n; i++) {
		printf("image[1] %lf %lf \t image[2] %lf %lf\n",
		       pointList.xcoord[2 * i], pointList.ycoord[2 * i],
		       pointList.xcoord[2 * i + 1],
		       pointList.ycoord[2 * i + 1]);
	}
	printf("c1 %f %f  \t c2 %f %f\n", *c1x, *c1y, *c2x, *c2y);
	printf("dist1 %f \t dist2 %f \n", dist1, dist2);
	printf("s1 %f \t s2 %f\n", *s1, *s2);


}


void normdlt(PList pointList)
{
	//PList pointList;               // stores the point pairs. 
	//PList norm_pointList;          // store the normalized point pairs.
	//double * Hmatrix;              // global data struct for storing the homography
	//int algorithm=3;                 // decides which algorithm to implement to 
	// compute the homography
	// 1 -> DLT 
	// 2 -> Normalized DLT
	// 3 -> Gold Standard Algorithm

	PList norm_pointList;

	double * Hmatrix;

	double **A, **v;
	double *w;
	int m, n;
	int i, j;

	m = pointList.size();
	n = 9;

	A = (double **) malloc(sizeof(double *) * m);
	v = (double **) malloc(sizeof(double *) * n);
	w = (double *) malloc(sizeof(double) * n);

	for (j = 0; j < m; j++) {
		A[j] = (double *) malloc(sizeof(double) * n);
	};
	for (j = 0; j < n; j++) {
		v[j] = (double *) malloc(sizeof(double) * n);
	}


	// Implement Normalized DLT 

	// 1. find the centroid of all points in the pointlist c, c'
	// 2. find the scale factor.    s , s'
	// 3. create the transformation T , T'
	// 4. find the modified points by applying the transformation
	// 5. Run DLT algo
	// 6. modify the new matrix H = inv(T').H'.T
	// 7. This is the homography

	double c1x, c1y, c2x, c2y, s1, s2;

	MATRIX_PTR T1, T2, H, result;
	MATRIX_PTR temp1, temp2, temp3;

	compute_centroid(&c1x, &c1y, &c2x, &c2y, &s1, &s2, pointList);


	T1 = alloc_matrix(3, 3);
	T2 = alloc_matrix(3, 3);

	T1->matrix[0][0] = s1;
	T1->matrix[1][0] = 0;
	T1->matrix[2][0] = 0;

	T1->matrix[0][1] = 0;
	T1->matrix[1][1] = s1;
	T1->matrix[2][1] = 0;

	T1->matrix[0][2] = -c1x * s1;
	T1->matrix[1][2] = -c1y * s1;
	T1->matrix[2][2] = 1;

	T2->matrix[0][0] = s2;
	T2->matrix[1][0] = 0;
	T2->matrix[2][0] = 0;

	T2->matrix[0][1] = 0;
	T2->matrix[1][1] = s2;
	T2->matrix[2][1] = 0;

	T2->matrix[0][2] = -c2x * s2;
	T2->matrix[1][2] = -c2y * s2;
	T2->matrix[2][2] = 1;

	for (i = 0; i < pointList.size(); i++) {

		norm_pointList.xcoord[2 * i] =
		    s1 * (pointList.xcoord[2 * i] - c1x);
		norm_pointList.ycoord[2 * i] =
		    s1 * (pointList.ycoord[2 * i] - c1y);
		norm_pointList.xcoord[2 * i + 1] =
		    s2 * (pointList.xcoord[2 * i + 1] - c2x);
		norm_pointList.ycoord[2 * i + 1] =
		    s2 * (pointList.ycoord[2 * i + 1] - c2y);

	}

	// Compute the Homography in the canonical coordinates 

	printf("Performing SVD on the A matrix \n");

	for (j = 0; j < pointList.size(); j += 2) {

		A[j][0] = 0;
		A[j][1] = 0;
		A[j][2] = 0;
		A[j][3] = (-1) * norm_pointList.xcoord[j];
		A[j][4] = (-1) * norm_pointList.ycoord[j];
		A[j][5] = -1;
		A[j][6] =
		    norm_pointList.ycoord[j +
					  1] * norm_pointList.xcoord[j];
		A[j][7] =
		    norm_pointList.ycoord[j +
					  1] * norm_pointList.ycoord[j];
		A[j][8] = norm_pointList.ycoord[j + 1];


		A[(j + 1)][0] = norm_pointList.xcoord[j];
		A[(j + 1)][1] = norm_pointList.ycoord[j];
		A[(j + 1)][2] = 1;
		A[(j + 1)][3] = 0;
		A[(j + 1)][4] = 0;
		A[(j + 1)][5] = 0;
		A[(j + 1)][6] =
		    (-1) * norm_pointList.xcoord[j +
						 1] *
		    norm_pointList.xcoord[j];
		A[(j + 1)][7] =
		    (-1) * norm_pointList.xcoord[j +
						 1] *
		    norm_pointList.ycoord[j];
		A[(j + 1)][8] = (-1) * norm_pointList.xcoord[j + 1];

	}

	printf("--------------------\n");

	for (i = 0; i < pointList.size(); i++) {
		for (j = 0; j < 9; j++) {
			printf(" %f", A[i][j]);
		}
		printf("\n");
	}

	printf("calling svd routine\n");
	dsvd(A, pointList.size(), 9, w, v);
	printf("The linear least square method solution is \n");

	double minsingularvalue = 9999999;
	int s = -1;
	printf("the singular values are : \n");
	for (i = 0; i < n; i++) {

		if (w[i] < minsingularvalue) {
			minsingularvalue = w[i];
			s = i;
		}
		printf(" %f", w[i]);
	}
	printf("\n");
	printf("the V vector : \n");
	for (i = 0; i < n; i++) {
		for (j = 0; j < 9; j++)
			printf("\t%f", v[i][j]);
		printf("\n");
	}

	printf("use the %dth vector\n", s);



	H = alloc_matrix(3, 3);
	result = alloc_matrix(3, 3);

	H->matrix[0][0] = fabs(v[0][s]);
	H->matrix[1][0] = fabs(v[3][s]);
	H->matrix[2][0] = fabs(v[6][s]);
	H->matrix[0][1] = fabs(v[1][s]);
	H->matrix[1][1] = fabs(v[4][s]);
	H->matrix[2][1] = fabs(v[7][s]);
	H->matrix[0][2] = (-1) * fabs(v[2][s]);
	H->matrix[1][2] = (-1) * fabs(v[5][s]);
	H->matrix[2][2] = fabs(v[8][s]);


	temp1 = inverse(T2);

	show_matrix(temp1);

	temp2 = matrix_multiply(H, T1);

	show_matrix(H);
	show_matrix(T1);
	temp3 = matrix_multiply(temp1, temp2);

	Hmatrix = (double *) malloc(sizeof(double) * 16);
	Hmatrix[0] = fabs(temp3->matrix[0][0]);
	Hmatrix[1] = fabs(temp3->matrix[1][0]);
	Hmatrix[2] = 0.0;
	Hmatrix[3] = fabs(temp3->matrix[2][0]);
	Hmatrix[4] = fabs(temp3->matrix[0][1]);
	Hmatrix[5] = fabs(temp3->matrix[1][1]);
	Hmatrix[6] = 0.0;
	Hmatrix[7] = fabs(temp3->matrix[2][1]);
	Hmatrix[8] = 0.0;
	Hmatrix[9] = 0.0;
	Hmatrix[10] = 1.0;
	Hmatrix[11] = 0.0;
	Hmatrix[12] = (-1) * fabs(temp3->matrix[0][2]);
	Hmatrix[13] = (-1) * fabs(temp3->matrix[1][2]);
	Hmatrix[14] = 0.0;
	Hmatrix[15] = fabs(temp3->matrix[2][2]);


	printf("solution computed using the normalized DLT algorithm \n");

	printf("\t%f\t%f\t%f\n", Hmatrix[0], Hmatrix[4], Hmatrix[12]);
	printf("\t%f\t%f\t%f\n", Hmatrix[1], Hmatrix[5], Hmatrix[13]);
	printf("\t%f\t%f\t%f\n", Hmatrix[3], Hmatrix[7], Hmatrix[15]);



}



int main(int argc, char *argv[])
{
	PList pl;

	pl.num = 10;
	pl.xcoord[0] = 0;
	pl.ycoord[0] = 0;
	pl.xcoord[2] = 0;
	pl.ycoord[2] = 1;
	pl.xcoord[4] = 1;
	pl.ycoord[4] = 0;
	pl.xcoord[6] = 1;
	pl.ycoord[6] = 1;
	pl.xcoord[8] = 1;
	pl.ycoord[8] = 1;

	pl.xcoord[1] = 0;
	pl.ycoord[1] = 0;
	pl.xcoord[3] = 0;
	pl.ycoord[3] = 1;
	pl.xcoord[5] = 1;
	pl.ycoord[5] = 0;
	pl.xcoord[7] = 1;
	pl.ycoord[7] = 1;
	pl.xcoord[9] = 1;
	pl.ycoord[9] = 2;

	normdlt(pl);

	return 0;
}
*/
