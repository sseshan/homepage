/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
#ifndef INDOORCAM_H
#define INDOORCAM_H

#include <string>

using namespace std;

#include <stdlib.h>

#include <cv.h>

#include "LandmarkDetector.h"
#include "SharedFIFO.h"
#include "RndGen.h"

class IndoorCam : public LandmarkDetector {
private:
	
	string camid;
	RndGen rndgen;
	
public:	

	double camerror;

	IndoorCam(string camid);

	~IndoorCam();

	// LandmarkDetector methods
	void startCapture(GPSCoord & coord);
	CvPoint2D64d stopCapture(GPSCoord & coord, bool & inView);

};

#endif
