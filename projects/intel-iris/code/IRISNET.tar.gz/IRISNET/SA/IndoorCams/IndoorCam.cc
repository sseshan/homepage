/* -*-  Mode:C++; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */

#include "csapp.h"
#include "imgproc.h"

#include "GPSCommand.h"
#include "RndGen.h"

#include "IndoorCam.h"

#include <iostream>

#define PI 3.14159265358979323846


IndoorCam::IndoorCam(string camid) {
	static int id = 0;
	id++;
	this->id = id;

	this->camid = camid;

	camerror = 0;

}

IndoorCam::~IndoorCam() {

}


void IndoorCam::startCapture(GPSCoord & coord) {
}

void DrawCentroid(IplImage * dstImage, CvPoint2D64d pt) {
	CvPoint q;
	q.x = (int) pt.x;
	q.y = (int) pt.y;

	cvCircle(dstImage, q, 5, CV_RGB(220, 220, 0), 5);	
	

	DisplayIplImage(dstImage, "Centroids");
	cvWaitKey(0);

}
CvPoint2D64d getCentroid(IplImage * lightoff, IplImage * lighton) {

	CvSize size;
	size.width = lighton->width;
	size.height = lightoff->height;
	int bpp = lighton->nChannels;
	
	IplImage * sub = cvCreateImage(size, IPL_DEPTH_8U, bpp);
	IplImage * sub2 = cvCreateImage(size, IPL_DEPTH_8U, bpp);
	IplImage * threshold = cvCreateImage(size, IPL_DEPTH_8U, 1);
	IplImage * centroids = cvCreateImage(size, IPL_DEPTH_8U, bpp);

	cvSub(lighton, lightoff, sub);
	cvSub(lightoff, lighton, sub2);
	cvAdd(sub, sub2, sub);
					
					
	int pixthreshold = 40;
	IplImage * subgray = MyColorToGray(sub);
	CvSeq * contours = NULL;

	CvMemStorage * storage = cvCreateMemStorage(0);

	bool done = false;


	do {
		//fprintf(stderr, "Trying match threshold %d\n", pixthreshold);
		cvThreshold(subgray, threshold, pixthreshold, 255, CV_THRESH_BINARY);


		cvErode(threshold, threshold, NULL, 1);

		// find contours and store them all as a list
		cvFindContours(threshold, storage, &contours, sizeof(CvContour),
			       CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE );

		pixthreshold -= 20;

		if (pixthreshold < 10 || NumContours(contours, 1) >= 1) {
			done = true;
		}

	} while (!done);



	int i = 0;

        double largearea = 0;
	CvPoint2D64d largepoint;
	
	while (contours != NULL) {
		CvMoments moments;
		
		cvContourMoments(contours, &moments);
	
		double area = cvGetSpatialMoment(&moments, 0, 0);
		double xc = cvGetSpatialMoment(&moments, 1, 0) / area;
		double yc = cvGetSpatialMoment(&moments, 0, 1) / area;

		//printf("iteration %d  xc %f  yc %f area %f\n", i, xc, yc, area);

		CvPoint2D64d centroid;
		centroid.x = xc;
		centroid.y = yc;

		if (centroid.x < 0 || centroid.y < 0) {
			contours = contours->h_next;
			i++;
			continue;
		}
		
		//cvCircle(dstImage, centroid, 5, CV_RGB(220, 220, 0), 5);
		if (area > largearea) {
			largearea = area;
			largepoint = centroid;
		}
	
		//printf("Landmark %d = (%f, %f)\n", i, centroid.x, centroid.y); 
		//printf("Landmark (%d, %d)\n",  centroid.x, centroid.y); 
		
		contours = contours->h_next;
		i++;
	}

	cout << i << " landmarks found." << endl;

	//DrawCentroid(lightoff, largepoint);

	cvReleaseMemStorage(&storage);
	cvReleaseImage(&subgray);
	cvReleaseImage(&centroids);
	cvReleaseImage(&threshold);
	cvReleaseImage(&sub2);
	cvReleaseImage(&sub);

	return largepoint;

}


CvPoint2D64d IndoorCam::stopCapture(GPSCoord & coord, bool & inView) {
	CvPoint2D64d q;
        char tmp[10];

	sprintf(tmp, "%1.0f%1.0f", coord.longW, coord.latN);

	string name(tmp);
	name = camid + "/" + camid + "-" + name;
	string namea = name + "a.png";
	string nameb = name + "b.png";

	cout << "Got GPS " << name << endl;

	IplImage * imagea = cvLoadImage(namea.c_str());
	IplImage * imageb = cvLoadImage(nameb.c_str());

	
	if (imagea == NULL || imageb == NULL)
		inView = false;
	else {
		inView = true;

		q = getCentroid(imagea, imageb);
		
		//cout << "Detected Centroid: " << q.x << " " << q.y << endl;
	}

	cvReleaseImage(&imagea);
	cvReleaseImage(&imageb);

	return q;
}



