#include "cv.h"
#include "highgui.h"
#include "SA.h"
#include "unistd.h"
#include "dbgprintlib.h"
#include <sys/shm.h>
#include "csapp.h"

// creates shared memory to dump the frames from the webcam.
// the frames are assumed to be of 4-byte color
// the frames are used as a circular buffer 
// 
// The first int in the shared buffer indocates the head of the circular queue
// The rest of the buffer is the circular buffer


void ShowCPUStat() {
        struct rusage ru;
		static int count = 0;

        getrusage(RUSAGE_SELF, &ru);

		count++;

        printf("\n");
		printf("Iteration: %d\n", count);
        printf("CPU User Time: %ld.%lds\n", ru.ru_utime.tv_sec, ru.ru_utime.tv_usec);
        printf("CPU System Time: %ld.%lds\n", ru.ru_stime.tv_sec, ru.ru_stime.tv_usec);

        printf("\n");


}

int CreateSharedMemory(int numFrames, shmInfoType *shmInfo, frameInfoType fInfo)
{
  int size = fInfo.width * fInfo.height * fInfo.bytesPerPixel; // 4-byte color
  int shmid;
  int i;
  shmHeaderType *shmHeader;
 
  if (numFrames > MAX_SHM_FRAMES) numFrames = MAX_SHM_FRAMES;

  dprintf(0, "Creating %d bytes shared memory for %d webcam frames", sizeof(shmHeaderType) + size * numFrames, numFrames);
  if ((shmid = shmget(IMAGE_SHM_KEY, sizeof(shmHeaderType) + size * numFrames, 0777 | IPC_CREAT)) < 0) {
    dperror(0, "Failed to create shared memory");
    return 0;
  }

  shmHeader = (shmHeaderType*) shmat(shmid, 0, 0);
  shmHeader->width = fInfo.width;
  shmHeader->height = fInfo.height;
  shmHeader->numFrames = numFrames;
  shmHeader->bytesPerPixel = fInfo.bytesPerPixel;
	
  shmInfo->numFrames = numFrames;
  shmInfo->shmKey = IMAGE_SHM_KEY;
  shmInfo->size = sizeof(shmHeaderType) + numFrames * size;
  for (i = 0; i <numFrames; i++)
    {
      shmInfo->offsets[i] = shmHeader->offsets[i] = sizeof(shmHeaderType) + i * size;
    }


  return 1;
}


// loads webcam video frame into shared memory
// loops forever
int LoadFrame(rio_t * rio, shmInfoType shmInfo, frameInfoType fInfo, int sleepSeconds, int displayFlag)
{


  int i, r, step, shmid, currFrame = 0;
  uchar *imgData;
  void *mem;
  IplImage *img;
  CvSize size;
  shmHeaderType *shmHeader;

  // if displayFlag option is ON, create the image to display
  if (displayFlag) {
    step = fInfo.bytesPerPixel;
    size.width = fInfo.width;
    size.height = fInfo.height;
    cvvNamedWindow("webcam", 1);
    img = cvCreateImageHeader(size, IPL_DEPTH_8U, step);
  }

  /*
  // open the video device
  videoDevices = CVideoCollector::Instance();
  for (i = 0; i <videoDevices->NumberOfVideoDevices(); i++) {
    video = videoDevices->GetVideoDevice(i);
    dName = video->GetIntfName();
    if (dName.isNull()) {
      dName = video->GetNodeName();
      dprintf(0, "Camera found: %s", (const char*)dName);
      break; 
    }
  }
  
   r = video->Open(shmInfo.numFrames);
  if (r < 0) {
    dperror(0, "Error in opening video device %s", (const char *)dName);
    return 0;
  }

  video->SetSize(fInfo.width, fInfo.height);
  video->EnableRGB(1);

  printf("Frame rate was: %d\n", video->GetFramerate());
  video->SetFramerate(30);
  printf("Frame rate set to: %d\n", video->GetFramerate());	 
 // open the shared memory to dump the frames
 */

  shmid = shmget(shmInfo.shmKey, shmInfo.size, 0777);
  if (shmid < 0) {
    dperror(0, "Error in opening shared segment");
    return 1;
  }
  mem = shmat(shmid, 0, 0);
  imgData = (uchar*)mem;
  shmHeader = (shmHeaderType*) imgData;

 
  // dump frames in shared memory
  for (;;) 
   {
     //printf("loading in offset %d %d..\n", currFrame, shmInfo.offsets[currFrame]);	
	 ShowCPUStat();
	 char buf[MAXLINE];
     int readsize = Rio_readlineb(rio, buf, MAXLINE);

	 printf("Read %d bytes header from the network\n", readsize);

	 readsize = atoi(buf);
	 printf("Reading additional %d data bytes from network\n", readsize);
     

     Rio_readnb(rio, imgData+shmInfo.offsets[currFrame], readsize);
 
	 //    memcpy(imgData+shmInfo.offsets[currFrame], video->GetRawRGB(), fInfo.height * fInfo.width * fInfo.bytesPerPixel);	
    shmHeader->buffHead = (int)currFrame;
    
    if (displayFlag) {
      cvSetImageData(img, imgData + shmHeader->offsets[shmHeader->buffHead], step * 
size.width);
      cvvShowImage("webcam", img);
    }

    currFrame = (currFrame + 1) % shmInfo.numFrames;
    sleep(sleepSeconds);
  }
  
  return 1;
}



int main(int argc, char *argv[])
{
 shmInfoType shmInfo;
 frameInfoType fInfo;
 int pid, numFrames, displayFlag, secondsPerFrame;
 
 if (argc != 6) {
   printf("Usage: webcam <#frames in buffer> <width> <height> <SecondsPerFrame> <displayFlag>\n");
   return 0;
 }

 if ( (sscanf(argv[1], "%d", &numFrames) != 1) ||
      (sscanf(argv[2], "%d", &fInfo.width) != 1) ||
      (sscanf(argv[3], "%d", &fInfo.height) != 1) ||
      (sscanf(argv[4], "%d", &secondsPerFrame) != 1) ||
      (sscanf(argv[5], "%d", &displayFlag) != 1) )
   {
     printf("Error in argv format\n");
     return 1;
   };
 
 fInfo.bytesPerPixel = 4;	
 CreateSharedMemory(1, &shmInfo, fInfo);
 
 printf("Configuration : \n\tVideo framesize: (Width: %d x Height: %d)\n\tRefresh rate: 1 frame per %d seconds\n\tNumber of frames in shared memory: %d\n\tShared memory keyID: %d\n", fInfo.width, fInfo.height, secondsPerFrame, numFrames, shmInfo.shmKey);
 

 struct sockaddr_in clientaddr;
 int clientlen = sizeof(clientaddr);

 signal(SIGPIPE, SIG_IGN);
 int listenfd = Open_listenfd(3000);
 int connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
 printf("main(): Connection established to %s:%d on fd %d\n" , inet_ntoa(clientaddr.sin_addr), clientaddr.sin_port, connfd);

 rio_t rio;
 Rio_readinitb(&rio, connfd);

 LoadFrame(&rio, shmInfo, fInfo, secondsPerFrame, displayFlag);
}
