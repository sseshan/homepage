#!/bin/sh
./webcam 1 640 480 1 1
