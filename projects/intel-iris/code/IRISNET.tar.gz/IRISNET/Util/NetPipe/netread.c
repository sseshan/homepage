/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include "csapp.h"

#define BUFSIZE 1024

// Reads from network socket and outputs to stdout

int main(int argc, char **argv)
{
	int port;
	int listenfd, connfd;
	int count = 0;
	struct sockaddr_in clientaddr;
	int clientlen = sizeof(clientaddr);
	char buf[BUFSIZE];
	rio_t rio;
	int size = 1;

	/* Check command line args */
	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(1);
	}

	/* otherwise, program will crash */
	signal(SIGPIPE, SIG_IGN);

	port = atoi(argv[1]);
	listenfd = Open_listenfd(port);
	fprintf(stderr, "netread(): Listening on port %d\n", port);
	connfd = Accept(listenfd, (SA *) & clientaddr, &clientlen);


	fprintf(stderr,
		"netread(): Connection established from %s:%d\n",
		inet_ntoa(clientaddr.sin_addr), clientaddr.sin_port);

	Rio_readinitb(&rio, connfd);

	while (size > 0) {

		size = Rio_readnb(&rio, buf, BUFSIZE);

		if (size > 0) {
			fwrite(buf, 1, size, stdout);
			count += size;
		}
		sleep(0);

	}



	Close(connfd);


	fprintf(stderr, "netread(): Total bytes read: %d\n", count);

	return 0;
}
