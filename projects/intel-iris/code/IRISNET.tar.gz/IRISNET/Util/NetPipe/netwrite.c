/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include "csapp.h"

#define BUFSIZE 1024

// Writes from standard in to network socket.

int main(int argc, char **argv)
{

	int port;
	char *host;
	rio_t rio;
	int clientfd;
	char buf[BUFSIZE];
	int size = 1;
	int count = 0;

	/* Check command line args */
	if (argc != 3) {
		fprintf(stderr, "usage: %s <host> <port>\n", argv[0]);

		exit(1);

	}

	host = argv[1];
	port = atoi(argv[2]);

	fprintf(stderr, "netwrite(): Connecting to %s on port %d\n", host,
		port);


	clientfd = Open_clientfd(host, port);

	Rio_readinitb(&rio, clientfd);

	while (size > 0) {
		size = fread(buf, 1, BUFSIZE, stdin);
		if (size > 0) {
			Rio_writen(clientfd, buf, size);
			count += size;
		}

	}

	fprintf(stderr, "netwrite(): Wrote %d bytes\n", count);

	return 0;
}
