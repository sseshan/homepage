/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>

void WriteToSocket(int connfd, char *st)
{
	char pre[6];
	int sz = strlen(st) + 6;

	//first 3 bytes of the packet os the length
	pre[0] = sz / (128 * 128);	//(len & 0xff0000) >> 16;
	pre[1] = (sz % (128 * 128)) / 128;	//(len & 0x00ff00) >> 8;
	pre[2] = (sz % (128 * 128)) % 128;	//(len & 0x0000ff);

	// put a dummy time stamp
	pre[3] = '0';
	pre[4] = '0';
	pre[5] = ' ';

	// write to socket
	write(connfd, pre, 6);
	write(connfd, st, sz - 6);
}

#define BUFFLEN 1024

int main(int argc, char *argv[])
{
	int sockfd, fd;
	struct sockaddr_in saaddr;
	char opCode[8], file[256],  lang[32];
	char buff[BUFFLEN];
	int nread;

	if (argc != 4) {
		printf("Usage: %s <IP> <port> \"<command>\"\n", argv[0]);
		printf("<command> = Load | Subs | Unsubs\n");
		printf
		    ("Load = L <Language> <Filter_name>\n");
		printf("Subs = S <OA_IP> <OA_PORT> <Filter_name> <Config file>\n");
		printf("Unsubs = U <OA_IP> <OA_PORT> <Filter_name>\n");
		printf("TalkToSenselet = T <OA_IP> <OA_PORT> <Filter-name> <Message>\n");
		printf("Example (start the senselet parking.so using the configuration file parking.conf):\n\t %s 127.0.0.1 3456 \"S 127.0.0.1 6789 parking parking.conf\"\n", argv[0]);

		printf
                    ("Example (Send the message \"CONFIG parking.conf\" to the senselet parking.so run by the OA 127.0.0.1:6789):\n\t %s 127.0.0.1 3456 \"T 127.0.0.1 6789 parking.so CONFIG parking.conf\"\n",
                     argv[0]);

		return 0;
	}


	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Error in creating socket\n");
		return 0;
	}

	bzero(&saaddr, sizeof(saaddr));
	saaddr.sin_family = AF_INET;
	saaddr.sin_port = htons(atoi(argv[2]));
	inet_pton(AF_INET, argv[1], &saaddr.sin_addr);

	if ((connect(sockfd, (struct sockaddr *) &saaddr, sizeof(saaddr)))
	    < 0) {
		printf("Error in connect to destination\n");
		return 0;
	}


	if (argv[3][0] != 'L')
		WriteToSocket(sockfd, argv[3]);

	if (argv[3][0] == 'L') {
		
		sscanf(argv[3], "%s %s %s", opCode, lang, file);
		if ( (fd = open(file, O_RDONLY)) < 0) return 0;
		
		WriteToSocket(sockfd, argv[3]);
		while ( (nread = read(fd, buff, BUFFLEN)) > 0)
			write(sockfd, buff, nread);
		printf("Sent code\n");
		close(fd);
	}
	close(sockfd);
	return 1;
}
