/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef DBGPRINTLIB
#define DBGPRINTLIB

/* Least verbose */
#define DBG_FATAL 0 /* FATAL ERRORS */
#define DBG_DIAG  2 /* Diagnotistic output */
#define DBG_DEBUG 4 /* Debug outptut */
#define DBG_HIDE  6 /* Debug outptut */

/* Most verbose */

#if defined(__cplusplus)
extern "C" {
    int SetDebugLevel(int level);
    int SetDebugFile(char *filename);
    int FlushDebugFile();
    int dprintf(int level, const char *format, ...);
    int dperror(int level, const char *format, ...);
    int SetDperrorLevel(int level);
}
#else
/* Set debug level.  Higher means more verbose */
extern int SetDebugLevel(int level);

/* Send debug output to file */
extern int SetDebugFile(char *filename);
extern int FlushDebugFile();

/* debug printf() */
extern int dprintf(int level, const char *format, ...);

extern int dperror(int level, const char *format, ...);
extern int SetDperrorLevel(int level);


#endif
#endif
