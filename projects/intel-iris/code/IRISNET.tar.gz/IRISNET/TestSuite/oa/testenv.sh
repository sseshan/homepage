#!/bin/sh

if test -z "$XINDICE_HOME"
then
	exit 1
else
	exit 0
fi