#!/bin/sh

source ../global.sh

XINDICE=../../packages/xml-xindice-1.0
XINDICE_PIDFILE=$XINDICE/config/xindice.pid
XINDICEADMIN=$XINDICE/bin/xindiceadmin

LogMsg "Starting OA tests..."


Testcase OA001 "Looking for java." "java -version"

pushd .
cd $XINDICE
./xindice.server stop
popd

sleep 3

Testcase OA002 "Stopping any running Xindice servers." "test ! -f $XINDICE_PIDFILE"

pushd .
cd $XINDICE
./xindice.server start
popd

sleep 3

echo Xindice pid is `cat $XINDICE_PIDFILE`

Testcase OA003 "Starting Xindice server." "test -f $XINDICE_PIDFILE"

Testcase OA004 "XINDICE_HOME set" "./testenv.sh"

$XINDICEADMIN add_collection -c /db -n atest
$XINDICEADMIN list_collections -c /db > tmpout.txt

Testcase OA005 "Creating /db/atest collection" "grep atest tmpout.txt"

$XINDICEADMIN add_document -c /db/atest -f xindicetest.xml -n xindicetest
$XINDICEADMIN list_documents -c /db/atest > tmpout.txt

Testcase OA006 "Adding xindicetest.xml to /db/atest with key xindicetest" "grep xindicetest tmpout.txt"

$XINDICEADMIN xpath -c /db/atest -q /xindicetestROOT/usRegion/state/county/city/neighborhood/block[@id='3'] > tmpout.txt

Testcase OA007 "Getting XPath query /xindicetestROOT/usRegion/state/county/city/neighborhood/block[@id='3']" "diff tmpout.txt xpathout.txt"

$XINDICEADMIN delete_collection -y -c /db -n atest

rm tmpout.txt

pushd .
cd $XINDICE
./xindice.server stop
popd
sleep 3
