#!/bin/sh

SADIR=../../SA/IrisSA/src
SACONTROLDIR=../../Util/SAControl

source ../global.sh

function KillAllSA()
{
	if test -f `ls /tmp/IRISSA.pid.* | head -n 1`
	then
		kill `cat /tmp/IRISSA.pid.*`
		rm -f /tmp/IRISSA.pid.*
		sleep 3
	fi
}

function StartSA()
{
	pushd .
	cd $SADIR
	./SA 3456 &
	popd
	sleep 3
}

LogMsg "Starting SA tests..."

pushd .
cd ../../Applications/dummy2
./configure
make
rm -f ../../SA/IrisSA/src/code/dummy2.so
cp dummy2.so ../../SA/IrisSA/src/code
popd

Testcase SA001 "dummy2 test application build." "test -f ../../Applications/dummy2/dummy2.so"

Testcase SA002 "dummy2 installed in SA directory." "test -f $SADIR/code/dummy2.so"

pushd .
cd $SADIR
make
popd

Testcase SA003 "SA build." "test -f $SADIR/SA"

# kill all existing SA's
KillAllSA

Testcase SA004 "No other SA currently running and /tmp/IRISSA.pid.* removed." "test ! -f /tmp/IRISSA.pid.*"


Testcase SA005 "LD_LIBRARY_PATH environment set correctly." "../webcam/testenv.sh"

StartSA

Testcase SA006 "SA started on port 3456..." "test -f /tmp/IRISSA.pid.*"

pushd .
cd $SACONTROLDIR
make
popd

Testcase SA007 "SAControl utility built correctly." "test -x $SACONTROLDIR/SAControl"

rm /tmp/IRISSA.dummy2.pid.*

Testcase SA008 "All /tmp/IRISSA.dummy2.pid.* removed." "test ! -f /tmp/IRISSA.dummy2.pid.*"

$SACONTROLDIR/SAControl 127.0.0.1 3456 "S 127.0.0.1 C dummy2"

sleep 3

Testcase SA009 "Dummy2 application started." "test -f /tmp/IRISSA.dummy2.pid.*"

$SACONTROLDIR/SAControl 127.0.0.1 3456 "U 127.0.0.1 C dummy2"

sleep 1
rm /tmp/IRISSA.dummy2.pid.*

KillAllSA

