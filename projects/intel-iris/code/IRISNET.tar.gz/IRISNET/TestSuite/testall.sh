#!/bin/sh

if test -z "$TESTRECURSE"
then
	export TESTRECURSE="true"
else
	echo " "
	echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	echo " "
	echo "Possible recursive call to root testall.sh"
	echo "unset TESTRECURSE environment variable if problem continues."
	echo " "
	echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	exit 1
fi

export TESTROOTDIR=`pwd`/

source ./global.sh


LogMsg "Starting comprehensive test suite."
echo `$DATE` "Logging to file $LOGFILE"

pushd .
cd sharedmem
./testall.sh
popd

pushd .
cd network
./testall.sh
popd

pushd .
cd videotest
./testall.sh
popd

pushd .
cd webcam
./testall.sh
popd 

pushd .
cd sa
./testall.sh
popd

pushd .
cd oa
./testall.sh
popd

echo ""

echo "Failed Tests:"

grep "FAILED" $LOGFILE

echo "See testcases.txt in their respective subdirectories for an explanation of the test case and possible fix."
