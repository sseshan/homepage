export DATE="date +%D%t%T"

export LOGFILE=$TESTROOTDIR./testlog.txt

function LogTest()
{   
	# $1 is test code
	# $2 is success/failure code
	# $3 is message to be logged

        echo `$DATE` $1":" $2":" $3 | tee -a $LOGFILE
        return
}

function LogMsg()
{
	# $1 is Log message
	echo `$DATE` $1 | tee -a $LOGFILE
	return
}


function Testcase()
{
	# $1 is test code
	# $2 is message to be logged

	# $3 is the test command

	if $3
	then
		TESTRESULT=SUCCESS
	else
		TESTRESULT=FAILED
	fi

	LogTest "$1" $TESTRESULT "$2"

	return
}
