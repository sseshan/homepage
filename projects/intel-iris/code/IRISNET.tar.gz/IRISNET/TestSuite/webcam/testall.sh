#!/bin/sh

source ../global.sh

WEBCAMDIR=../../SA/IrisWebcam

function KillAllWebcam()
{
        if test -f `ls /tmp/IRISWEBCAM.pid.* | head -n 1`
        then
                kill -9 `cat /tmp/IRISWEBCAM.pid.*`
                rm -f /tmp/IRISWEBCAM.pid.*
                sleep 3
        fi
}



LogMsg "Starting webcam tests..."


Testcase WC001 "Environment variables set." "./testenv.sh"

./configure

make

#second make - autoconf problems
make

Testcase WC002 "Webcam test suite build." "test -x ./testwebcam"

pushd .
cd $WEBCAMDIR
./configure
make
popd

Testcase WC003 "Webcam built." "test -x $WEBCAMDIR/webcam"

KillAllWebcam

Testcase WC004 "No other webcam currently running and /tmp/IRISWEBCAM.pid.* removed." "test ! -f /tmp/IRISWEBCAM.pid.*"

$WEBCAMDIR/webcam 1 640 480 1 0 &

sleep 3

Testcase WC005 "IRIS webcam running." "test -f /tmp/IRISWEBCAM.pid.*"


Testcase WC006 "Checking IRIS webcam for live image." "./testwebcam"

KillAllWebcam
