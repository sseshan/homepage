#!/bin/sh

TMP_PATH=`echo $LD_LIBRARY_PATH | tr ":" " "`

# echo $TMP_PATH

OPENCV_FOUND=0
HIGHGUI_FOUND=0
AVCODEC_FOUND=0

for i in $TMP_PATH
do
	if [ -f $i/libopencv.so ]
	then
		OPENCV_FOUND=1
	fi

	if [ -f $i/libhighgui.so ] 
	then
		HIGHGUI_FOUND=1
	fi

	if [ -f $i/libavcodec.so ] 
	then
		AVCODEC_FOUND=1
	fi
done


echo "libopencv.so found: " $OPENCV_FOUND
echo "libhighgui.so found: " $HIGHGUI_FOUND
echo "libavcodec.so found: " $AVCODEC_FOUND

if [ $OPENCV_FOUND -eq 1 ] && [ $HIGHGUI_FOUND -eq 1 ] && [ $AVCODEC_FOUND -eq 1 ]
then
	exit 0
else
	exit 1
fi
