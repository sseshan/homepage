#!/bin/sh

PINGCMD="ping -c 3 -w 15"

source ../global.sh

LogMsg "Starting network tests..."

# ./configure

# make


# Testcase NT001 "Network test suite build." "test -x ./testnet"

Testcase NT002 "Ping localhost" "$PINGCMD localhost"

Testcase NT003 "Ping 128.2.11.43 (web3.andrew.cmu.edu)" "$PINGCMD 128.2.11.43"

Testcase NT004 "Ping 171.64.14.237 (www2.stanford.edu)" "$PINGCMD 171.64.14.237"

Testcase NT005 "Ping www.cmu.edu" "$PINGCMD www.cmu.edu"

Testcase NT006 "Ping www.berkeley.edu" "$PINGCMD www.berkeley.edu"

Testcase NT007 "Ping www.boston.edu" "$PINGCMD www.boston.edu"

Testcase NT008 "Ping www.illinois.edu" "$PINGCMD www.illinois.edu"

Testcase NT009 "Ping www.ox.ac.uk" "$PINGCMD www.ox.ac.uk"
