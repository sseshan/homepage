#!/bin/sh

source ../global.sh

LogMsg "Starting shared memory tests..."

./configure

make

Testcase SM001 "Shared memory test suite build." "test -x ./sharedmem"

Testcase SM002 "Creating shared memory." "./sharedmem init"

Testcase SM003 "Checking shared memory." "./sharedmem check"

