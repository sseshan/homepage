#!/bin/sh

source ../global.sh

LogMsg "Starting video input tests..."

./configure

make

# autoconf problems for second make
make

Testcase VD001 "Video test suite build." "test -x ./videotest"

Testcase VD002 "Checking read permission on /dev/video0" "head -c 0 /dev/video0"

Testcase VD003 "Checking read permission on /dev/video1" "head -c 0 /dev/video1"

Testcase VD004 "Checking read permission on /dev/video2" "head -c 0 /dev/video2"

Testcase VD005 "Checking read permission on /dev/video3" "head -c 0 /dev/video3"

Testcase VD006 "Looking for video input devices." "./videotest detectcams"

Testcase VD007 "Looking for high resolution (640x480) device." "./videotest testres"

Testcase VD008 "Opening video input devices." "./videotest opencams"

Testcase VD009 "Testing for live image." "./videotest liveimage"

