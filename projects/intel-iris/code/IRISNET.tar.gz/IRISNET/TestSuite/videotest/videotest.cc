/* -*-  Mode:C; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include "VideoDevice.h"
#include "VideoCollector.h"
#include <unistd.h>

int detectcams()
{
	CVideoDevice *video;
	CVideoCollector *videoDevices;
	QString dName;
	QString dPort;
	QSize size;

	int i;
	int numdevs = 0;

	// open the video device
	videoDevices = CVideoCollector::Instance();

	numdevs = videoDevices->NumberOfVideoDevices();

	printf("Found %d video devices.\n", numdevs);

	for (i = 0; i < numdevs; i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		dPort = video->GetNodeName();

		printf("Camera found: %s on %s\n", (const char *) dName, 
			(const char *) dPort);

		size = video->GetMaxSize();
		printf("  Max video size: %d x %d\n", size.width(), size.height());
		size = video->GetMinSize();
		printf("  Min video size: %d x %d\n", size.width(), size.height());
		size = video->GetSize();
		printf("  Current video size: %d x %d\n", size.width(), size.height());
	}

	if (numdevs <= 0)
		return 1;
	else
		return 0;
}

int opencams()
{
	CVideoDevice *video;
	CVideoCollector *videoDevices;
	QString dName;
	QString dPort;
	QSize size;
	int res;
	bool bres;

	int i;
	int numdevs = 0;

	int numgood = 0;

	// open the video device
	videoDevices = CVideoCollector::Instance();

	numdevs = videoDevices->NumberOfVideoDevices();

	printf("Found %d video devices.\n", numdevs);

	for (i = 0; i < numdevs; i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		dPort = video->GetNodeName();

		printf("Camera found: %s on %s\n", (const char *) dName, 
			(const char *) dPort);

		size = video->GetMaxSize();
		printf("  Max video size: %d x %d\n", size.width(), size.height());
		size = video->GetMinSize();
		printf("  Min video size: %d x %d\n", size.width(), size.height());


		res = video->Open();
		if (res < 0) {
			printf("  Error opening video device %s\n",
			       (const char *) dName);
			break;
		}

		printf("  Video device successfully opened.\n");
		numgood++;

		size = video->GetSize();
		printf("  Current video size: %d x %d\n", size.width(), size.height());

		printf("  Setting size to 640 x 480.\n");
		bres = video->SetSize(640, 480);

		if (!bres)
			printf("  Error setting size.\n");

		size = video->GetSize();
		printf("  Current video size: %d x %d\n", size.width(), size.height());

		printf("  Enabling RBG\n");
		video->EnableRGB(1);

		printf("  Frame rate was: %d\n", video->GetFramerate());
		printf("  Setting frame rate to 30...\n");
		bres = video->SetFramerate(30);

		if (!bres)
			printf("  Error setting frame rate.\n");

		printf("  Frame rate set to: %d\n", video->GetFramerate());

	}

	if (numgood <= 0)
		return 1;
	else
		return 0;
}

int testres()
{
	CVideoDevice *video;
	CVideoCollector *videoDevices;
	QString dName;
	QString dPort;
	QSize size;

	int i;
	int numdevs = 0;

	int numgood = 0;

	// open the video device
	videoDevices = CVideoCollector::Instance();

	numdevs = videoDevices->NumberOfVideoDevices();

	printf("Found %d video devices.\n", numdevs);

	for (i = 0; i < numdevs; i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		dPort = video->GetNodeName();

		printf("Camera found: %s on %s\n", (const char *) dName, 
			(const char *) dPort);

		size = video->GetMaxSize();
		printf("  Max video size: %d x %d\n", size.width(), size.height());
		if (size.width() >= 640 && size.height() >= 480) {
			numgood++;
			printf("  High resolution camera found.\n");
		}
		size = video->GetMinSize();
		printf("  Min video size: %d x %d\n", size.width(), size.height());

	}

	if (numgood <= 0)
		return 1;
	else
		return 0;
}

// Checks the center of the image for noise between frames
int checkimage(CVideoDevice *video)
{
	const int BUFLEN = 2000;

	unsigned char buf[BUFLEN];
	
	int diff = 0;

	QSize size = video->GetSize();

	int offset = 4* (size.width() * (size.height() / 2) + (size.width() / 2));

	video->ReadImage();

	memcpy(buf, video->GetRGB()->bits() + offset, BUFLEN);

	usleep(200000);

	for (int i = 0; i < 10; i++) {
		video->ReadImage();
		diff += abs(memcmp(buf, video->GetRGB()->bits() + offset, BUFLEN));
		memcpy(buf, video->GetRGB()->bits() + offset, BUFLEN);
		usleep(200000);
	}

	printf("  Live image difference between frames: %d\n", diff);

	if (diff == 0)
		return 0;
	else
		return 1;
}

int liveimage() {
	CVideoDevice *video;
	CVideoCollector *videoDevices;
	QString dName;
	QString dPort;
	QSize size;
	int res;
	bool bres;

	int i;
	int numdevs = 0;

	int numgood = 0;

	// open the video device
	videoDevices = CVideoCollector::Instance();

	numdevs = videoDevices->NumberOfVideoDevices();

	printf("Found %d video devices.\n", numdevs);

	for (i = 0; i < numdevs; i++) {
		video = videoDevices->GetVideoDevice(i);
		dName = video->GetIntfName();
		dPort = video->GetNodeName();

		printf("Camera found: %s on %s\n", (const char *) dName, 
			(const char *) dPort);

		size = video->GetMaxSize();
		printf("  Max video size: %d x %d\n", size.width(), size.height());
		size = video->GetMinSize();
		printf("  Min video size: %d x %d\n", size.width(), size.height());


		res = video->Open();

		if (res < 0) {
			printf("  Error opening video device %s\n",
			       (const char *) dName);

			break;
		}

		printf("  Video device successfully opened.\n");

		size = video->GetSize();
		printf("  Current video size: %d x %d\n", size.width(), size.height());

		printf("  Setting size to 640 x 480.\n");
		bres = video->SetSize(640, 480);
		if (!bres)
			printf("  Error setting size.\n");

		size = video->GetSize();
		printf("  Current video size: %d x %d\n", size.width(), size.height());

		printf("  Enabling RBG\n");
		video->EnableRGB(1);

		printf("  Frame rate was: %d\n", video->GetFramerate());
		printf("  Setting frame rate to 30...\n");
		bres = video->SetFramerate(30);
		if (!bres)
			printf("  Error setting frame rate.\n");
		printf("  Frame rate set to: %d\n", video->GetFramerate());

		if (size.width() > 0 && size.height() > 0)
			numgood += checkimage(video);

	}

	if (numgood <= 0)
		return 1;
	else
		return 0;
}


int main(int argc, char *argv[])
{
	if (argc < 2) {
		printf("Usage: %s testcase\n", argv[0]);
		return 1;
	}
	else if (strcmp(argv[1], "detectcams") == 0) {
		return detectcams();
	}
	else if (strcmp(argv[1], "opencams") == 0) {
		return opencams();
	}
	else if (strcmp(argv[1], "testres") == 0) {
		return testres();
	}
	else if (strcmp(argv[1], "liveimage") == 0) {
		return liveimage();
	}

	return 1;
}
