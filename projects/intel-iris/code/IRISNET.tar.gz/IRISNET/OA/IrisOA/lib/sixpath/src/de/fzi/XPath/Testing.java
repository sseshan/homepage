package de.fzi.XPath;


public class Testing {
    public static void main(String[] args) {
        try {
            String q2 = "a/b/c/d[count(./e/f) = 5]/e/f";
            System.out.println("Query ==> " + q2);
            Expr parsetree = XPathQueryParser.parsequery(q2);
            System.out.println("Parsed Expression ==> " + parsetree);
        } catch (Exception e) {
        }
    }
}
