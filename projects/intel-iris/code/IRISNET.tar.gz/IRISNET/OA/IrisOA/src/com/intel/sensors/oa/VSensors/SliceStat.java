/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network

             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

      * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

      * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa.VSensors;

import HTTPClient.*;
import java.io.*;
import java.util.*;

public class SliceStat extends VSensor{
	String uriString; // URI of this sensor
	boolean everythingOK = true;

	// name of the comma seperated values in each slicestat line
	String attrs[] = { "slice", "ctx", "cpu","mem", "pmem","vmem","ntasks","send_bw1",
			   "send_bw5","send_bw15","recv_bw1","recv_bw5","recv_bw15" };

	public SliceStat(String confFile, String uri) {
		conf = new Configuration(confFile);
		if (!conf.everythingOK)
			everythingOK = false;
	    uriString = uri;
		System.out.println("Virtual sensor created with \n\t URI=>" + uriString + 
						   "\t Parametrs =>" + conf.toString());
	}

	public String toString() {
		return simpleGet(uriString);
	}


	//-----------------------------------
	// form the Xindice XUpdate query
	//-----------------------------------
	public String toXupdate() {
        String data = toString();
        return toXupdate(data);
    }

	String xupdateRemove() {
		StringBuffer xupdate = new StringBuffer(1024);
		//-------- "remove" old element
        xupdate.append("<xupdate:remove select=\"");
        xupdate.append(conf.xpath);
        xupdate.append("/node[@id='");
        xupdate.append(conf.nodeName);
        xupdate.append("']/sensor[@id='SLICESTAT']\"/>\n");

		return xupdate.toString();
	}

	String xupdateAppend(String data) {
		StringBuffer xupdate = new StringBuffer(1024);
		//--------- "add" the new element
        xupdate.append("<xupdate:append select=\"");
        xupdate.append(conf.xpath + "/node[@id='" + conf.nodeName + "']\">");


        xupdate.append("<xupdate:element name=\"sensor\"><xupdate:attribute name=\"id\">");
        xupdate.append("SLICESTAT");
        xupdate.append("</xupdate:attribute><xupdate:attribute name=\"status\">ownsthis</xupdate:attribute>");

        xupdate.append("<xupdate:attribute name=\"expiry\">");
        xupdate.append(System.currentTimeMillis());
        xupdate.append("</xupdate:attribute>\n");

/*
        xupdate.append("<xupdate:attribute name=\"name\">");
        xupdate.append(conf.hostName);
        xupdate.append("</xupdate:attribute>\n");
*/
        //xupdate.append("<sensor id=\"SLICESTAT\" status=\"ownsthis\" expiry='" + System.currentTimeMillis() +"'>\n");
        StringTokenizer lines = new StringTokenizer(data, "\n");
        while (lines.hasMoreTokens()) {
            String line = lines.nextToken();
            if (line.length() < 40) continue; // invalid line

            // process each line
            StringTokenizer tokens = new StringTokenizer(line, " ,\n");
            xupdate.append("<SLICE status=\"ownsthis\" id=\"" + tokens.nextToken() + "\"");
            for (int i = 1; tokens.hasMoreTokens(); i++) {
                xupdate.append(" " + attrs[i] + "=\"" + tokens.nextToken() + "\"");
            }
            xupdate.append("/>\n");
        }
        //xupdate.append("</sensor>");

        xupdate.append("</xupdate:element> </xupdate:append>");

		return xupdate.toString();
	}


	public String toXupdate(String data, boolean deleteOld, boolean appendNew) {
		StringBuffer xupdate = new StringBuffer(1024);

		// xupdate header
		xupdate.append("<xupdate:modifications version=\"1.0\" xmlns:xupdate=\"http://www.xmldb.org/xupdate\">\n");
		if (deleteOld)
			xupdate.append(xupdateRemove()); // remove old element
		if (appendNew)
			xupdate.append(xupdateAppend(data)); // append new element
		xupdate.append("</xupdate:modifications>"); // footer

		return xupdate.toString();
	}

	
	public String toXupdate(String data) {
		return toXupdate(data, true, true);
	}
	
	
	//-----------------------------------------------
	// form the Galax UpdateX query
	//-----------------------------------------------
	public String updateXDelete() 
	{
		StringBuffer updatex = new StringBuffer();
		updatex.append(conf.rootNode + " delete .");
		updatex.append(conf.xpath + "/host[@id=\"" + conf.nodeName + "\"]/sensor[@id=\"SLICESTAT\"];");
		return updatex.toString();
	}

	public String updateXInsert()
	{
		String data = toString();
		StringBuffer updatex = new StringBuffer(1024);

        //--------- "add" the new element
        updatex.append(conf.rootNode + " insert " );
		updatex.append("<sensor id=\"SLICESTAT\" status=\"ownsthis\" expiry=\"" + System.currentTimeMillis() + "\">");

        StringTokenizer lines = new StringTokenizer(data, "\n");
        while (lines.hasMoreTokens()) {
            String line = lines.nextToken();
            if (line.length() < 40) continue; // invalid line

            // process each line
            StringTokenizer tokens = new StringTokenizer(line, " ,\n");
            updatex.append("<SLICE status=\"ownsthis\" id=\"" + tokens.nextToken() + "\"");
            for (int i = 1; tokens.hasMoreTokens(); i++) {
                updatex.append(" " + attrs[i] + "=\"" + tokens.nextToken() + "\"");
            }
            updatex.append("/>\n");
        }
        updatex.append("</sensor> into .");
		updatex.append(conf.xpath + "/host[@id=\"" + conf.nodeName + "\"];");

        return updatex.toString();
	}
	

}

