/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import org.w3c.dom.*;

/** QueryInfo class records information about a query.
 *  
 *  @author Shimin
 */
public class QueryInfo {

  // ---
  // instance fields
  // ---
  public Node     root;		// current context node for query evaluation
  public boolean  continuous;	// is this query a continous query?
  public int      mode;		// 0. top-down  1. bottom-up fixed targets
				// 2. bottom-up variable targets
  public long     period;	// unit: ms
  public long     lease;	// unit: ms

  public String   subtree_consistency_checking;

  private String  query_for_root;
  private String  query_for_root_parent;
  private String  owner_agent_for_root_parent;

  // ---
  // instance methods
  // ---
  public QueryInfo ()
  {
	root = null;
	continuous = false;
	query_for_root = null;
	query_for_root_parent = null;
	owner_agent_for_root_parent = null;
	subtree_consistency_checking = null;
  }

  public QueryInfo (Element root_element)
  {
	root = root_element;
	continuous = false;
	query_for_root = null;
	query_for_root_parent = null;
	owner_agent_for_root_parent = null;
	subtree_consistency_checking = null;
  }

  // copy every state from parent and set root 
  public QueryInfo (QueryInfo parent_info, Element root_element)
  {
	// set root
	root = root_element;
	query_for_root = null;
	query_for_root_parent = null;
	owner_agent_for_root_parent = null;

	// copy every other state from parent
	continuous = parent_info.continuous;
	mode = parent_info.mode;
	period = parent_info.period;
	lease = parent_info.lease;
	subtree_consistency_checking = 
			parent_info.subtree_consistency_checking;
  }

  // return the path from real root to the context root
  public String queryForRoot ()
  {
	if (query_for_root == null) {
	  query_for_root =  ((root != null)&&(root instanceof Element))?
			QueryUtils.findQueryForThisElement ((Element)root):
			"";
	}
	return query_for_root;
  }

  public String queryForRootParent ()
  {
	if (query_for_root_parent == null) {
	  if ((root != null)&&(root instanceof Element)
	    &&(root.getParentNode() instanceof Element)) {
	    query_for_root_parent = QueryUtils.findQueryForThisElement (
			(Element) root.getParentNode());
	  }
	  else query_for_root_parent = "";
	}
	return query_for_root_parent;
  }

  public String ownerAgentForRootParent ()
  {
	if (owner_agent_for_root_parent == null) {
	  if ((root != null)&&(root instanceof Element)
	    &&(root.getParentNode() instanceof Element)) {
	    owner_agent_for_root_parent = DOMProcessing.findOwnerAgent (
			(Element) root.getParentNode());
	  }
	  else owner_agent_for_root_parent = "";
	}
	return owner_agent_for_root_parent;
  }

  // When there is an update, the update goes directly
  // to the Xindice database.  The cached dom tree is discarded. Therefore,
  // in a continuous query, we should not keep the root pointing to the old 
  // dom tree.
  //
  // In a continuous query, do the following:
  // 1) clearRoot () after every invokation (optional)
  //
  //    this removes a pointer to the discarded dom tree
  //    and gc may recollect the memory.
  //    Note that every resetRoot () will automatically remove the last
  //    pointer!
  //
  // 2) resetRoot () if the root is needed to evaluate the query.
  //    (this is true for mode 0, but false for mode 1)
  //
  //    critical for correctness if we need to execute xslt for the query
  //    evaluation. 
  //
  public void clearRoot ()
  {
	// query_for_root, query_for_root_parent, owner_agent_for_root_parent
	// will never change.

	// 1. make sure they are not null
	String temp = queryForRoot();
	temp = queryForRootParent();
	temp = ownerAgentForRootParent();

	// 2. set root to be null
	root = null;
  }

  public void resetRoot ()
  {
	// query_for_root is not null!
	root = QueryUtils.getContextNode (queryForRoot());
  }

} // QueryInfo
