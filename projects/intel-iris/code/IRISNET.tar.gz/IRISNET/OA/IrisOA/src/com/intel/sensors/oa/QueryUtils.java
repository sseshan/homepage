/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.util.*;

// dom processing
import org.w3c.dom.*;
import org.w3c.dom.traversal.*;

// sixpath: xpath parser
import de.fzi.XPath.*;

/** QueryUtils class provides static utility methods for QueryOperator
 *  operations.
 *  
 *  @author Shimin
 */
public class QueryUtils {

  // --------------------------------------------------------------------
  // given a dom tree and a location path
  // return the highest level in the location path that is owned
  // -1 is root level
  public static int getHighestOwnedLevel (Node root, LocationPath lp)
  {
	if (root instanceof Element)
	{
	   if (((Element) root).getAttribute("status").equals("ownsthis")) {
	     return (root.getParentNode() instanceof Element)?
		    0 : -1;
	   }

	   root = root.getParentNode(); 	// the context node of xpath
						// is different from xslt
	}

	int pos = findLongestIDStep (lp);
	if (pos < 0) return -1;	// no ID prefix?

	LocationPath prefix_lp = copyIDStep (lp, pos);
	Node node = null;
	try {
	  StringBuffer sb = new StringBuffer (pos*16);
	  while (true) {
	    // compose the xpath till pos
	    sb.append (prefix_lp.getStep(0).toString());
	    for (int ii=1; ii<=pos; ii++) {
	       sb.append ('/');
	       sb.append (prefix_lp.getStep(ii).toString());
	    }
	    
	    // if this node is available?
	    node = org.apache.xpath.XPathAPI.selectSingleNode (root, 
							sb.toString());
	    if (node != null)
	      break;
	    pos --;
	    if (pos < 0) 
	      Utils.error ("The query should not be routed to this OA!\n" +
			    lp.toString());
	    // clear the StringBuffer
	    sb.delete (0, sb.length());
	  }
        } catch (Exception e) {
	  e.printStackTrace ();
	  System.exit (1);
	}
	int highest_owned_ancestor = findHighestOwnedAncestor (node);
	if (highest_owned_ancestor > 0)
	  Utils.error ("The query should not be routed to this OA!\n" +
			lp.toString());
	return pos + highest_owned_ancestor;
  }

  // find the longest prefix of the location path such that every step
  // in the prefix is a name test and contains ID predicate
  // return: the last step in the prefix
  public static int findLongestIDStep (LocationPath lp)
  {
	int num_steps = lp.getStepsCount();
	for (int ii = 0; ii < num_steps; ii ++) {
	   boolean is_id_step = false;

	   Step st = lp.getStep(ii);
	   if ((st.getAxis() == Axis.CHILD) && 
               (st.getNodeTest() instanceof NameTest)) {
	     for (int jj=st.getPredicatesCount()-1; jj>=0; jj--)
		if (QueryAnalysis.isIdPredicate (st.getPredicate(jj))) {
		  is_id_step = true;
		  break;
		}
	   }

	   if (! is_id_step) {
	     return ii-1;
	   }
	}
	return num_steps - 1;
  }

  // copy location path from step 0 to step 'end'
  // Only ID predicates are copied, other predicates are ignored
  public static LocationPath copyIDStep (LocationPath lp, int end)
  {
	LocationPath new_lp = new LocationPath (lp.isAbsolute());
	for (int ii=0; ii<=end; ii++) {
	   Step st = lp.getStep(ii);
	   Step new_st = new Step (st.getAxis(), st.getNodeTest());
	   for (int jj=st.getPredicatesCount()-1; jj>=0; jj--) {
	      Expr predicate = st.getPredicate(jj);
	      if (QueryAnalysis.isIdPredicate (predicate)) {
		new_st.addPredicate (predicate);
	      }
	   }
	   new_lp.addStep (new_st);
	}
	return new_lp;
  }

  // we go up the dom tree to look for the highest ancestor of n
  // that is owned.
  // return the number of steps back up the tree.
  // i.e. -1: one step, -2: two steps
  public static int findHighestOwnedAncestor (Node n)
  {
	int highest = 1;
	for (int pos=0; (n instanceof Element); pos--, n = n.getParentNode())
	   if (((Element) n).getAttribute("status").equals("ownsthis")) {
	     highest = pos;
	   }
	return highest;
  }

  // --------------------------------------------------------------------
  // we make a copy of the lp
  // StoredProcedure calls are localized.
  // if the last step is attribute, it is removed
  public static LocationPath prepareLPforXslt (LocationPath lp)
  {
	return prepareLPforXslt (lp, 0, lp.getStepsCount ()-1);
  }

  // end and start inclusive
  public static LocationPath prepareLPforXslt (LocationPath lp, 
					       int start, int end)
  {
	LocationPath new_lp = (start == 0) ?
	  	(new LocationPath (lp.isAbsolute())) :
		(new LocationPath ());
	if (start <= end) {
	  boolean has_attr_step = false;
	  if ((end == lp.getStepsCount ()-1) &&
	      (lp.getStep (end).getAxis () == Axis.ATTRIBUTE)) {
	    end --;
	    has_attr_step = true;
	  }
	  for (int ii=start; ii<=end; ii++) {
	     Step ss = copyAndLocalizeSP (lp.getStep (ii));
	     new_lp.addStep (ss);
	  }
	  // change the attribute into an existance predicate
	  if (has_attr_step && (start <= end)) {
	    Step ss = lp.getStep (end+1);
	    LocationPath attr_lp = new LocationPath ();
	    attr_lp.addStep (ss);
	    new_lp.getStep (end-start).addPredicate (attr_lp);
	  }
	}
	return new_lp;
  }

  static Step copyAndLocalizeSP (Step st)
  {
	Step new_st = new Step (st.getAxis(), st.getNodeTest());
	int  num_predicates = st.getPredicatesCount();
	for (int ii=0; ii<num_predicates; ii++) {
	   Expr predicate = copyAndLocalizeSP (st.getPredicate(ii));
	   new_st.addPredicate (predicate);
	}
	return new_st;
  }

  static Expr copyAndLocalizeSP (Expr expr)
  {
	Expr new_expr = null;

        // FilterExpr
        if (expr instanceof FilterExpr) {
          FilterExpr fe = (FilterExpr) expr;
	  Expr primary = copyAndLocalizeSP (fe.getPrimary());
	  FilterExpr new_fe = new FilterExpr (primary);
	  new_expr = new_fe;
        }

        // FunctionCall
        else if (expr instanceof FunctionCall) {
          FunctionCall fc = (FunctionCall) expr;

	  String class_name = fc.getPrefix ();
	  if (class_name == null)
	    class_name = "com.intel.sensors.oa.SPBuiltIn";

	  int num_args = fc.getArgumentCount();
	  if (num_args == 0) {
	    Utils.error ("stored procedure call must have at least one arg!");
	  }
	  else if (num_args > 10) {
	    Utils.error ("too many args!");
	  }
	  FunctionCall new_fc = new FunctionCall ("SPUtils:xsltCall" 
				    + (num_args-1));
	  new_fc.addArgument (new de.fzi.XPath.Literal(class_name));
	  new_fc.addArgument (new de.fzi.XPath.Literal(fc.getLocalName ()));
	  for (int ii=0; ii<num_args; ii++) {
	     new_fc.addArgument (copyAndLocalizeSP(fc.getArgument(ii)));
	  }
	  new_expr = new_fc;
        }

        // Literal
        else if (expr instanceof de.fzi.XPath.Literal) {
	  return expr;
        }

        // LocationPath
        else if (expr instanceof LocationPath) {
          LocationPath lp = (LocationPath) expr;
	  LocationPath new_lp = new LocationPath (lp.isAbsolute());
	  int num_steps = lp.getStepsCount ();
	  for (int ii=0; ii<num_steps; ii++) {
	     Step ss = copyAndLocalizeSP (lp.getStep (ii));
	     new_lp.addStep (ss);
	  }
	  new_expr = new_lp;
        }

        // NaryExpr
        else if (expr instanceof NaryExpr) {
          NaryExpr ne = (NaryExpr) expr;
	  NaryExpr new_ne = null;
	  if (expr instanceof AndExpr) {
	    new_ne = new AndExpr ();
	  }
	  else if (expr instanceof OrderedExpr) {
	    if (expr instanceof AdditiveExpr)
	      new_ne = new AdditiveExpr ();
	    else if (expr instanceof EqualityExpr)
	      new_ne = new EqualityExpr ();
	    else if (expr instanceof MultiplicativeExpr)
	      new_ne = new MultiplicativeExpr ();
	    else if (expr instanceof RelationalExpr)
	      new_ne = new RelationalExpr ();
	    else
	      new_ne = new OrderedExpr ();
	  }
	  else if (expr instanceof OrExpr) {
	    new_ne = new OrExpr ();
	  }
	  else if (expr instanceof UnionExpr) {
	    new_ne = new UnionExpr ();
	  }
	  else {
	    new_ne = new NaryExpr ();
	  }

	  int num_subs = ne.getExprsCount();
	  for (int ii=0; ii<num_subs; ii++) {
	     Expr e = copyAndLocalizeSP(ne.getExpr (ii));
	     new_ne.addSubExpr (e);
	  }
	  new_expr = new_ne;
        }

        // Number
        else if (expr instanceof de.fzi.XPath.Number) {
	  return expr;
        }

        // Variable
        else if (expr instanceof Variable) {
          Utils.error ("Unknown variable " + expr.toString());
        }
        else { // ForExpr
          Utils.error ("For loop in predicate is not supported!");
        }

	new_expr.setOperator (expr.getOperator ());
	new_expr.setPositive (expr.getPositive ());

	return new_expr;
  }

  // --------------------------------------------------------------------
  // The root_at_query should be of the form:
  // tag1[@id='x']/tag2[@id='y']/tag3/tag4
  // It may start with '/', every tag may have a single ID predicate
  static Node getContextNode (String root_at_query)
  {
	// get the root element tag
	int start = 0;
	if (root_at_query.charAt (0) == '/')
	  start = 1;
	int ii = start;
	int length = root_at_query.length ();
	while (ii < length) {
	  char ch = root_at_query.charAt (ii);
	  if ((ch == '/') || (ch == '['))
	    break;
	  ii ++;
	}
	int end = ii;
	ii = root_at_query.indexOf ("::");
	if ((ii != -1) && (ii < end))
	  start = ii + 2;
	String root_element = root_at_query.substring (start, end).trim();

	// get the document
	Document doc = Globals.getDatabase().getDocumentWithID(root_element);

	// debugging
	//Document doc = QueryOperator.getDocumentWithID (root_element, 
	//		root_at_query);

	// get the root at node
	Node n = null;
     try {
	n = org.apache.xpath.XPathAPI.selectSingleNode (doc, root_at_query);
     } catch (Exception e) {
	Utils.error (root_at_query + " error:" + e.getClass().toString());
     }

	if (n == null) {
	  Utils.error (root_at_query + " is not found on this OA!");
	}

	return n;
  }

  // --------------------------------------------------------------------
  // replace all the location paths and function calls with variable
  // references.  Then put the replaced location paths and function calls
  // into lp_sp_list.  The variables have the format prefix + number. 
  // The number increments from start_var_num.
  // 
  // return the expression with lp and sp replaced
  static Expr replaceLPSPinExpr (Expr expr, ArrayList lp_sp_list, 
				int start_var_num)
  {
	Expr new_expr = null;

        // FilterExpr
        if (expr instanceof FilterExpr) {
          FilterExpr fe = (FilterExpr) expr;
	  Expr primary = replaceLPSPinExpr (fe.getPrimary(), 
				lp_sp_list, start_var_num);
	  FilterExpr new_fe = new FilterExpr (primary);
	  new_expr = new_fe;
        }

        // FunctionCall
        else if (expr instanceof FunctionCall) {
	  int num = lp_sp_list.size() + start_var_num;
	  Variable v = new Variable (QueryOperator.var_prefix + num);
	  new_expr = v;
	  lp_sp_list.add (expr);
        }

        // Literal
        else if (expr instanceof de.fzi.XPath.Literal) {
	  return expr;
        }

        // LocationPath
        else if (expr instanceof LocationPath) {
	  int num = lp_sp_list.size() + start_var_num;
	  Variable v = new Variable (QueryOperator.var_prefix + num);
	  FilterExpr fe = new FilterExpr (v);
	  new_expr = fe;
	  lp_sp_list.add (expr);
        }

        // NaryExpr
        else if (expr instanceof NaryExpr) {
          NaryExpr ne = (NaryExpr) expr;
	  NaryExpr new_ne = null;
	  if (expr instanceof AndExpr) {
	    new_ne = new AndExpr ();
	  }
	  else if (expr instanceof OrderedExpr) {
	    if (expr instanceof AdditiveExpr)
	      new_ne = new AdditiveExpr ();
	    else if (expr instanceof EqualityExpr)
	      new_ne = new EqualityExpr ();
	    else if (expr instanceof MultiplicativeExpr)
	      new_ne = new MultiplicativeExpr ();
	    else if (expr instanceof RelationalExpr)
	      new_ne = new RelationalExpr ();
	    else
	      new_ne = new OrderedExpr ();
	  }
	  else if (expr instanceof OrExpr) {
	    new_ne = new OrExpr ();
	  }
	  else if (expr instanceof UnionExpr) {
	    new_ne = new UnionExpr ();
	  }
	  else {
	    new_ne = new NaryExpr ();
	  }

	  int num_subs = ne.getExprsCount();
	  for (int ii=0; ii<num_subs; ii++) {
	     Expr e = replaceLPSPinExpr (ne.getExpr (ii),
                                lp_sp_list, start_var_num);
	     new_ne.addSubExpr (e);
	  }
	  new_expr = new_ne;
        }

        // Number
        else if (expr instanceof de.fzi.XPath.Number) {
	  return expr;
        }

        // Variable
        else if (expr instanceof Variable) {
          Utils.error ("Unknown variable " + expr.toString());
        }
        else { // ForExpr
          Utils.error ("For loop in predicate is not supported!");
        }

	new_expr.setOperator (expr.getOperator ());
	new_expr.setPositive (expr.getPositive ());

	return new_expr;
  }

  // --------------------------------------------------------------------
  // find the identifying query for the node.
  // we make the query a relative query.
  static String findQueryForThisElement (Element n) {
	StringBuffer sb = new StringBuffer ();
	findQueryForThisElement (n, sb);
	return sb.toString ();
  }

  static void findQueryForThisElement (Element n, StringBuffer sb)
  {
	Node parent = n.getParentNode();
	if (parent instanceof Element) {
	  findQueryForThisElement ((Element) parent, sb);
	  sb.append ('/');
	}

	sb.append (n.getTagName());
	if (n.hasAttribute("id")) {
	  sb.append ("[@id='");
	  sb.append (n.getAttribute("id"));
	  sb.append ("']");
	}
  }

  // --------------------------------------------------------------------
  // test if a location path contains stored query as its last step
  // if this is true, returns the name of the stored query
  // otherwise, returns null
  static String lastStepIsStoredQuery (LocationPath lp)
  {
	String name = null;
	int num_steps = lp.getStepsCount();
	if (num_steps > 0) {
	  Step last_st = lp.getStep(num_steps-1);
	  // last step is stored_query
	  if (last_st.getNodeTest().toString().equals (
			QueryOperator.stored_query)) {
	      int num_predicates = last_st.getPredicatesCount();
	      for (int ii=0; ii<num_predicates; ii++) {
		 Expr predicate = last_st.getPredicate (ii);
		 // check if the predicate is @name = 'value'
		 if ((predicate instanceof EqualityExpr) && 
		     (((EqualityExpr)predicate).getExprsCount() == 2)){
		   Expr name_expr = ((EqualityExpr)predicate).getExpr(0);
		   Expr val_expr = ((EqualityExpr)predicate).getExpr(1);
		   if (name_expr.toString().equals("attribute::name")
		      && (val_expr instanceof FilterExpr)) {
		      val_expr = ((FilterExpr)val_expr).getPrimary();
		      if (val_expr instanceof de.fzi.XPath.Literal) {
			name = ((de.fzi.XPath.Literal)val_expr).getValue();
			break;
		      }
		   }
		 }
	      } // end of for
	  }
	} // num_steps > 0

	if (name != null) {
	    // check if the string is quoted
	    if (name.charAt(0) == '\'') {
              int len = name.length ();
              if (name.charAt(len-1) == '\'')
                name = name.substring (1, len-1);
            }
	}

	return name;
  }

  // this LocationPath is of the form /st1[@id='id1']/st2[@id='id2']/.../@attr
  // return the owner agent of the query
  // return null if the query is of bad format
  static String getOwnerAgentForUpdateSelection (LocationPath lp)
  {
        StringBuffer sb = new StringBuffer();

	int num_steps = lp.getStepsCount();
	Step st = lp.getStep(num_steps-1);
	if (st.getAxis() != Axis.ATTRIBUTE)
	  return null;

        for (int ii = num_steps-2; ii >= 0 ; ii--) {
           st = lp.getStep(ii);

	   if (st.getAxis() != Axis.CHILD) return null;

           if ((st.getPredicatesCount() == 1) && 
               (QueryAnalysis.isIdPredicate (st.getPredicate(0)))) {
                    String str = 
			((EqualityExpr) st.getPredicate(0)).getExpr(1).toString();
		    int len = str.length ();
		    if (((str.charAt(0) == '\'') && (str.charAt(len-1) == '\''))
		     || ((str.charAt(0) == '\"') && (str.charAt(len-1) == '\"'))){
			str = str.substring (1, len-1);
		    }
		    sb.append (str);
		    if (ii != 0) sb.append ('.');
           }
           else return null;
        }

        return sb.toString();
  }

  // --------------------------------------------------------------------
  // If a step in a location path has predicate other than ID predicate
  // add a predicate [@expiry = 0]
  static Expr addExpirePredicate (Expr expr)
  {
	return addExpirePredicate (expr, false);
  }

  static Expr addExpirePredicate (Expr expr, boolean expiry_any_step)
  {
	Expr new_expr = null;

        // FilterExpr
        if (expr instanceof FilterExpr) {
          FilterExpr fe = (FilterExpr) expr;
	  Expr primary = addExpirePredicate (fe.getPrimary(), expiry_any_step);
	  FilterExpr new_fe = new FilterExpr (primary);
	  new_expr = new_fe;
        }

        // FunctionCall
        else if (expr instanceof FunctionCall) {
          FunctionCall fc = (FunctionCall) expr;
	  int num_args = fc.getArgumentCount();
	  if (num_args == 0) {
	    Utils.error ("stored procedure call must have at least one arg!");
	  }
	  else if (num_args > 10) {
	    Utils.error ("too many args!");
	  }
	  FunctionCall new_fc = new FunctionCall (fc.getName ());
	  for (int ii=0; ii<num_args; ii++) {
	     new_fc.addArgument (addExpirePredicate(fc.getArgument(ii),
						    expiry_any_step));
	  }
	  new_expr = new_fc;
        }

        // Literal
        else if (expr instanceof de.fzi.XPath.Literal) {
	  return expr;
        }

        // LocationPath
        else if (expr instanceof LocationPath) {
          LocationPath lp = (LocationPath) expr;
	  LocationPath new_lp = new LocationPath (lp.isAbsolute());
	  int num_steps = lp.getStepsCount ();
	  for (int ii=0; ii<num_steps; ii++) {
	     Step st = lp.getStep (ii);
	     Step new_st = null;

             if ((st.getAxis() == Axis.ATTRIBUTE)||
		 (st.getAxis() == Axis.SELF)||
		 (st.getAxis() == Axis.PARENT))
		new_st = st;
	     else {

                new_st = new Step (st.getAxis(), st.getNodeTest());
                int  num_predicates = st.getPredicatesCount();

                boolean all_id_predicates = !expiry_any_step;
		if (num_predicates == 0)
		  all_id_predicates = false;
		else {
                 for (int jj=0; jj<num_predicates; jj++) {
                   if (all_id_predicates) {
		      if (! QueryAnalysis.isIdPredicate (st.getPredicate(jj)))
                        all_id_predicates = false;
		   }
                   Expr predicate = addExpirePredicate (st.getPredicate(jj),
							true);
                   new_st.addPredicate (predicate);
                 }
		}

                if (! all_id_predicates) {
                  // @expiry = '0'
                  new_st.addPredicate (ContinuousQuery.force_expire);
		  expiry_any_step = true;
                }
	     }

	     new_lp.addStep (new_st);
	  }
	  new_expr = new_lp;
        }

        // NaryExpr
        else if (expr instanceof NaryExpr) {
          NaryExpr ne = (NaryExpr) expr;
	  NaryExpr new_ne = null;
	  if (expr instanceof AndExpr) {
	    new_ne = new AndExpr ();
	  }
	  else if (expr instanceof OrderedExpr) {
	    if (expr instanceof AdditiveExpr)
	      new_ne = new AdditiveExpr ();
	    else if (expr instanceof EqualityExpr)
	      new_ne = new EqualityExpr ();
	    else if (expr instanceof MultiplicativeExpr)
	      new_ne = new MultiplicativeExpr ();
	    else if (expr instanceof RelationalExpr)
	      new_ne = new RelationalExpr ();
	    else
	      new_ne = new OrderedExpr ();
	  }
	  else if (expr instanceof OrExpr) {
	    new_ne = new OrExpr ();
	  }
	  else if (expr instanceof UnionExpr) {
	    new_ne = new UnionExpr ();
	  }
	  else {
	    new_ne = new NaryExpr ();
	  }

	  int num_subs = ne.getExprsCount();
	  for (int ii=0; ii<num_subs; ii++) {
	     Expr e = addExpirePredicate(ne.getExpr (ii), expiry_any_step);
	     new_ne.addSubExpr (e);
	  }
	  new_expr = new_ne;
        }

        // Number
        else if (expr instanceof de.fzi.XPath.Number) {
	  return expr;
        }

        // Variable
        else if (expr instanceof Variable) {
          Utils.error ("Unknown variable " + expr.toString());
        }
        else { // ForExpr
          Utils.error ("For loop in predicate is not supported!");
        }

	new_expr.setOperator (expr.getOperator ());
	new_expr.setPositive (expr.getPositive ());

	return new_expr;
  }


  // --------------------------------------------------------------------
  // This should be performed for the local query after fetch-all
  static Expr removeExpirePredicate (Expr expr)
  {
	Expr new_expr = null;

        // FilterExpr
        if (expr instanceof FilterExpr) {
          FilterExpr fe = (FilterExpr) expr;
	  Expr primary = removeExpirePredicate (fe.getPrimary());
	  FilterExpr new_fe = new FilterExpr (primary);
	  new_expr = new_fe;
        }

        // FunctionCall
        else if (expr instanceof FunctionCall) {
          FunctionCall fc = (FunctionCall) expr;
	  int num_args = fc.getArgumentCount();
	  if (num_args == 0) {
	    Utils.error ("stored procedure call must have at least one arg!");
	  }
	  else if (num_args > 10) {
	    Utils.error ("too many args!");
	  }
	  FunctionCall new_fc = new FunctionCall (fc.getName ());
	  for (int ii=0; ii<num_args; ii++) {
	     new_fc.addArgument (removeExpirePredicate(fc.getArgument(ii)));
	  }
	  new_expr = new_fc;
        }

        // Literal
        else if (expr instanceof de.fzi.XPath.Literal) {
	  return expr;
        }

        // LocationPath
        else if (expr instanceof LocationPath) {
          LocationPath lp = (LocationPath) expr;
	  LocationPath new_lp = new LocationPath (lp.isAbsolute());
	  int num_steps = lp.getStepsCount ();
	  for (int ii=0; ii<num_steps; ii++) {
	     Step st = lp.getStep (ii);
	     Step new_st = null;

             if ((st.getAxis() == Axis.ATTRIBUTE)||
		 (st.getAxis() == Axis.SELF)||
		 (st.getAxis() == Axis.PARENT))
		new_st = st;
	     else {

                new_st = new Step (st.getAxis(), st.getNodeTest());
                int  num_predicates = st.getPredicatesCount();

                for (int jj=0; jj<num_predicates; jj++) {
                   Expr predicate = removeExpirePredicate (st.getPredicate(jj));
		   // have to do this: isConsistencyPredicate uses string search
		   if (! QueryAnalysis.isConsistencyPredicate(predicate))
                     new_st.addPredicate (predicate);
                }
	     }

	     new_lp.addStep (new_st);
	  }
	  new_expr = new_lp;
        }

        // NaryExpr
        else if (expr instanceof NaryExpr) {
          NaryExpr ne = (NaryExpr) expr;
	  NaryExpr new_ne = null;
	  if (expr instanceof AndExpr) {
	    new_ne = new AndExpr ();
	  }
	  else if (expr instanceof OrderedExpr) {
	    if (expr instanceof AdditiveExpr)
	      new_ne = new AdditiveExpr ();
	    else if (expr instanceof EqualityExpr)
	      new_ne = new EqualityExpr ();
	    else if (expr instanceof MultiplicativeExpr)
	      new_ne = new MultiplicativeExpr ();
	    else if (expr instanceof RelationalExpr)
	      new_ne = new RelationalExpr ();
	    else
	      new_ne = new OrderedExpr ();
	  }
	  else if (expr instanceof OrExpr) {
	    new_ne = new OrExpr ();
	  }
	  else if (expr instanceof UnionExpr) {
	    new_ne = new UnionExpr ();
	  }
	  else {
	    new_ne = new NaryExpr ();
	  }

	  int num_subs = ne.getExprsCount();
	  for (int ii=0; ii<num_subs; ii++) {
	     Expr e = removeExpirePredicate(ne.getExpr (ii));
	     new_ne.addSubExpr (e);
	  }
	  new_expr = new_ne;
        }

        // Number
        else if (expr instanceof de.fzi.XPath.Number) {
	  return expr;
        }

        // Variable
        else if (expr instanceof Variable) {
          Utils.error ("Unknown variable " + expr.toString());
        }
        else { // ForExpr
          Utils.error ("For loop in predicate is not supported!");
        }

	new_expr.setOperator (expr.getOperator ());
	new_expr.setPositive (expr.getPositive ());

	return new_expr;
  }

  // --------------------------------------------------------------------
  // replace the $var in the return xpath with "."
  static String getReplacedReturnClause (ForExpr for_expr)
  {
        String return_query = for_expr.getReturnExpr().toString();
        String variable = for_expr.getLoopVariable().toString();
        StringBuffer sb = new StringBuffer();
        int start = 0;
        int next_var_pos = return_query.indexOf (variable);
        while (next_var_pos >= 0) {
            sb.append (return_query.substring (start, next_var_pos));
            sb.append ('.');
            start = next_var_pos + variable.length ();
            next_var_pos = return_query.indexOf (variable, start);
        }
        sb.append (return_query.substring (start, return_query.length()));
	return sb.toString();
  }

  // --------------------------------------------------------------------
  // testing

  public static void main (String args[])
  {
   try {
    ContinuousQuery.init ();

    BufferedReader in
      = new BufferedReader(new InputStreamReader(System.in));

    Document doc = null;
    Document doc2 = null;

    if (args.length > 0) {
      doc = DOMProcessing.fileToDOM (args[0]);
    }
    if (args.length > 1) {
      doc2 = DOMProcessing.fileToDOM (args[1]);
    }

/*
    String context_query = "/aaa";
    Node context = org.apache.xpath.XPathAPI.selectSingleNode (doc, context_query);
    QueryInfo qinfo = new QueryInfo ();
    qinfo.root = context;

    QueryOperator one = new QueryOperator ();
    one.query_info = qinfo;

    one.print ();
*/
		 
    /*
    String element_query = "aaa/bbb[@id='b2']/ccc[@id='c3']";
    Node n = org.apache.xpath.XPathAPI.selectSingleNode (doc2, element_query);
    System.out.println (findQueryForThisElement((Element)n));
    */

    while (true) {
        String query = in.readLine ();
        System.out.println (query);
        if (query.equals ("exit")) {
          break;
        }

        // Xpath processing
        Expr expr = XPathQueryParser.parsequery(query);
        System.out.println ("-----------------------------");
        System.out.println (expr.toString ());
        System.out.println ("-----------------------------");

	int rtype = QueryOperator.determineResultType (expr);
	System.out.println (QueryOperator.getResultTypeName (rtype));
/*
	Expr new_expr = removeExpirePredicate (expr);
	System.out.println (new_expr.toString());
*/

/*
	String[] ret = new String[3];
	QueryAnalysis.getRemoteQueryInfo (qinfo, (Element)n, (LocationPath)expr,
	ret);
	System.out.println ("lca: " + ret[0]);
	System.out.println ("query: " + ret[1]);
	System.out.println ("root_at: " + ret[2]);
*/

/*
	if (expr instanceof LocationPath) {
	  System.out.println (QueryAnalysis.writeXsltwithSP((LocationPath)expr,
		false, false));
	  System.out.println (QueryAnalysis.writeXsltwithSP((LocationPath)expr,
		false, true));
	  System.out.println (QueryAnalysis.writeXsltwithSP((LocationPath)expr,
		true, false));
	}
*/
/*
	String query2 = in.readLine ();
	Node n = org.apache.xpath.XPathAPI.selectSingleNode (doc2, query2);

	if (n instanceof Element) {
	  Element e = qq.mapNodetoOriginalTree ((Element)n);
	  
	  System.out.println (findQueryForThisElement(e));
	}
*/

/*
	Element root_element = doc.getDocumentElement ();
	System.out.println ("root element name: " + root_element.getTagName());
	n = org.apache.xpath.XPathAPI.selectSingleNode (root_element, query);
        if (n == null) {
          System.out.println ("from root_element: null");
        }
        else {
          System.out.println ("from root_element: exist");
        }
*/
/*
	System.out.println ("highestOwnedLevel: " + getHighestOwnedLevel (doc, (LocationPath)expr));
*/
/*
	Node n = getContextNode (query, doc);
	if (n instanceof Element) {
	  System.out.println (((Element)n).getTagName());
	}
	else {
	  System.out.println (n.toString());
	}
*/
/*`
	LocationPath lp = prepareLPforXslt ((LocationPath)expr, 0, ((LocationPath)expr).getStepsCount()-1);
	System.out.println (lp.toString());
	lp = prepareLPforXslt ((LocationPath)expr, 1, ((LocationPath)expr).getStepsCount()-2);
	System.out.println (lp.toString());
*/
/*
	ArrayList lp_sp_list = new ArrayList ();
	Expr new_expr = replaceLPSPinExpr (expr, lp_sp_list, 0);

	System.out.println (new_expr.toString());
	for (int ii=0; ii<lp_sp_list.size(); ii++) {
	   System.out.println (ii + " '" + lp_sp_list.get(ii).toString() + "'");
	}
*/
    }
   }
   catch (Throwable e) {
        System.out.println ("Exception!"); 
   }
  }

} // QueryUtils
