/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.lang.String;
import java.util.StringTokenizer;
import java.util.Vector;
import java.lang.Integer;

public class RemoteSourceInfo {
	public String mRemoteHostName;
	public int mRemotePortNumber;
	public String mRemoteDatabaseName;
	
	/** Constructor  -- not to be used right now */
	public RemoteSourceInfo(String text, int deprecated) throws Exception {
		try {
			StringTokenizer st = new StringTokenizer(text, ":");
			mRemoteHostName = st.nextToken();
			mRemotePortNumber = Integer.parseInt(st.nextToken());
			// mRemoteDatabaseName = st.nextToken();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/** The name will be of the form block100.shadyside.pittsburgh...... Ask a standalone process 
	 *  on Oakland to do this. */
	public void RemoteSourceInfo_NotUsed(String sourceName) throws Exception {
		ConfigurationManager CM = ConfigurationManager.instance();
		//System.out.println("RemoteSourceInfo(): WARNING.  dsan.net hard coded here.");
		Vector v = DNSHelper.getDNSHelper().resolveHost(sourceName + "." + CM.getDNSSuffix());
		System.out.println("RemoteSourceInfo(): Resolved ip and port: " + v);
		mRemoteHostName = (String) v.get((int) 0);
		mRemotePortNumber = Integer.parseInt((String) v.get((int) 1));
	}

	/** Suman: Names should be resolved within the Packet.Send(), which tries all the primary
	 * and secondary replicas. So this new version does not resolve the address */
	public RemoteSourceInfo(String sourceName) throws Exception {
                ConfigurationManager CM = ConfigurationManager.instance();
                mRemoteHostName =  sourceName + "." + CM.getDNSSuffix(); 
                mRemotePortNumber = CM.getOAPort(); 
        }

	
	/** toString */
	public String toString() {
		return mRemoteHostName + " " + mRemoteDatabaseName + " " + mRemotePortNumber;
	}
};
