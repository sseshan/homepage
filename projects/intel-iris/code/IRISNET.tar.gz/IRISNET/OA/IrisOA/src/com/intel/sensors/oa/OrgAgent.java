/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

/**
 * The class OrgAgent describes an Organizing Agent (OA).
 * An OA is identified by the public variable pair: (IPaddr, port).
 * The class implements the APIs to communicate with SAs and other OAs.
 *
 * @author Suman Kumar Nath
 * @version %I%, %G%
 */
class OrgAgent
{
	public String IPaddr; // IP address of the OA
	public int port;    // port on which it listens
	
	/**
	 * Constructor. Initializes the IP address.
	 *
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	
	OrgAgent() {
		try {
			InetAddress me = InetAddress.getLocalHost();
			IPaddr = me.getHostAddress();
		} catch (UnknownHostException e){
			IPaddr = "127.0.0.1";
		}
	}

	OrgAgent(String addr) { 
		IPaddr = addr;
	} // XXX: need to change later
	
	/**
	 * Loads a script on a SA. The script is dynamically linkable and executable 
	 * from the SA. 
	 *
	 * @param sa     SensingAgent object, denotes the SA to load the script
	 * @param script Script object, denotes the script to be loaded
	 *
	 * @return Globals.OK (success), SOCK_ERROR/STREAM_ERROR (failure)
	 *
	 * @author Suman Kumar Nath
	 * @version %I%, %G%
	 */
	public int LoadScript(SensingAgent sa, Script script)
	{
		Socket saSocket;
		DataOutputStream saOutStream;
		int status = Globals.OK;
		int bytesRead = 1;
		byte[] tempBuf = new byte[1024];
		
		// open the socket connection
		try {
			saSocket = new Socket(sa.IPaddr, sa.port);
			try {
				saOutStream = new 
					DataOutputStream(saSocket.getOutputStream());
			}
			catch (IOException streamEx) {
				
				//MCloseConnection();
				return Globals.STREAM_ERROR;
			}
		}
		catch (IOException sockEx) {
			return Globals.SOCK_ERROR;
		}
		
		// open the file
		FileInputStream inStream;
		try {
			inStream = new FileInputStream(script.fileName);
		}
		catch (FileNotFoundException FLEx) {
			System.out.println("File not found\n");
			return Globals.FILE_ERROR;
		}
		
		PacketHeaderLoad pkt = new PacketHeaderLoad(script.scriptName, "C");
		
		try {
                        status = pkt.SendHeader(saOutStream);
                        if (status != Globals.OK) return status;
			saOutStream.flush();
			
			// send the code
			do {
				bytesRead = inStream.read(tempBuf, 0, 1024);
				if (bytesRead > 0) {
					saOutStream.write(tempBuf, 0, bytesRead);
				}
			} while (bytesRead >= 0);
			saOutStream.flush();
			
			// close connection
			if (saSocket != null) saSocket.close();
			saOutStream = null;
		} 
		catch (IOException IOEx) {
			return Globals.STREAM_ERROR;
		}
                catch (Exception e) {
                        e.printStackTrace();
			return Globals.STREAM_ERROR;
                }
		
		return Globals.OK;
	};
	
    /**
     * Subscribes to a script on a SA. OA listens on a port and sends the scriptname, 
     * its IP address and port number to the SA. The SA executes the script which takes 
     * OA's IP and port number as parameter, filters sensor data, opens a socket 
     * connection to the OA, and sends the filtered data back to the OA through the 
     * socket. 
     *
     * @param sa     SensingAgent object, denotes the SA to load the script
     * @param script Script object, denotes the script to execute on SA
     *
     * @return a SA_Handle object with the connection between the OA and the script on SA
     *
     * @author Suman Kumar Nath
     * @version %I%, %G%
     */
	public SA_Handle Subscribe(SensingAgent sa, Script script)
	{
		DataOutputStream saOutStream;
		SA_Handle handle = new SA_Handle();
		Socket saSocket;
		//ServerSocket oaSocket;
		//try {
		//    oaSocket = new ServerSocket(0);
		//}
		//catch (IOException sockEx) {
		//    return handle;
		//}
		
		//PacketHeaderSubs pkt = new PacketHeaderSubs(IPaddr, oaSocket.getLocalPort(), script.scriptName);
		PacketHeaderSubs pkt = new PacketHeaderSubs(IPaddr, Protocol.myPortNumber, script.scriptName);
		try {
			System.out.println("OrgAgent.Subscribe(): Opening connection to "
					   + sa.IPaddr + ":" + sa.port);
			
			saSocket = new Socket(sa.IPaddr, sa.port);
			saOutStream = new DataOutputStream(saSocket.getOutputStream());
			
		}
		catch (IOException sockEx) {
			System.out.println(sockEx);
			return handle;
		}
		
		
		try {
			if (pkt.SendHeader(saOutStream) != Globals.OK)
				return handle;
			saSocket.close();
			saOutStream = null;
			//handle.socket = oaSocket.accept();	
			//handle.inStream = new DataInputStream(handle.socket.getInputStream());
			//handle.socket.setSoTimeout(5); // wait 5 msec for data 
		}
		catch  (Exception sockEx){
			System.out.println(sockEx);
			return handle;
		}
		handle.valid = true;
		return handle;
	};
	
	public int Unsubscribe(SensingAgent sa, Script script) throws Exception
	{
		DataOutputStream saOutStream;
		Socket saSocket;
		
		
		PacketHeaderUnsubs pkt = new PacketHeaderUnsubs(IPaddr, Protocol.myPortNumber,
								script.scriptName);
		
		try {
			System.out.println("OrgAgent.Unsubscribe(): Opening connection to "
					   + sa.IPaddr + ":" + sa.port);

			saSocket = new Socket(sa.IPaddr, sa.port);
			saOutStream = new DataOutputStream(saSocket.getOutputStream());
			
		}
		catch (IOException sockEx) {
			System.out.println(sockEx);

			return Globals.SOCK_ERROR;
		}
		
		
		return pkt.SendHeader(saOutStream);
		
	};
	
	/*
	public int Unsubscribe2(SensingAgent sa, Script script)
	{
		Socket saSocket;
		DataOutputStream saOutStream;
		int status = Globals.OK;
	
		
		// open the socket connection
		try {
			saSocket = new Socket(sa.IPaddr, sa.port);
			try {
				saOutStream = new 
					DataOutputStream(saSocket.getOutputStream());
			}
			catch (IOException streamEx) {
				
				//MCloseConnection();
				return Globals.STREAM_ERROR;
			}
		}
		catch (IOException sockEx) {
			return Globals.SOCK_ERROR;
		}
		
	
		PacketHeaderUnsubs pkt = new PacketHeaderUnsubs(script.scriptName, "C");
		status = pkt.SendHeader(saOutStream);
		if (status != Globals.OK) return status;
		
		return Globals.OK;
	};
	*/

    /**
     * Checks a conneciton and Reads data if available. (Non blocking)
     *
     * @param handle     SA_Handle object, specifies the socket and streams
     * @param buffer     byte array, buffer to store the data
     * @param bufflen    maximum length of the buffer
     *
     * @return number of bytes read. 0 means no data was available to read. -1 means 
     * end of file was encountered
     *
     * @author Suman Kumar Nath
     * @version %I%, %G%
     */
	public int Read(SA_Handle handle, byte[] buffer, int bufflen)
	{
		int nBytes = 0;
		if (!handle.valid) return 0;
		try {
			/*
			  if ((nBytes = handle.inStream.available()) > 0) {
			  nBytes = (nBytes > bufflen) ? bufflen : 
			  nBytes;
			  inStream.read(buffer, 0, nBytes);
			  }
			*/
			nBytes = handle.inStream.read(buffer, 0, bufflen);
			if (nBytes > 0) System.out.println("Read " + nBytes +  " Bytes\n");
		}
		catch (IOException IOEx) {
			//SocketException sockEx ) {
			return 0;
		}
		return nBytes; // -1 when end of file encountered
	}
}
