/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xpath.XPathAPI;
import org.apache.xml.utils.TreeWalker;
import org.apache.xml.utils.DOMBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.SAXException;
import org.xml.sax.InputSource;

// Imported JAVA API for XML Parsing 1.0 classes
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException; 

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

/**
 *  Very basic utility for applying an XPath epxression to a String.
 *  Takes 2 arguments:
 *     (1) a String that represents an XML document.
 *     (2) an XPath expression to apply to the string
 *
 *  @author Xalan Development Team
 *  @author Amol Deshpande
 */
public class ApplyXPathToString
{
    /** Process input args and execute the XPath.  */
    public static StringBuffer applyXPath(String XMLDocument, String xpath) throws Exception
    {

        Log.Debug("APPLYXPATH BEGIN");

        StringBuffer ret_val = new StringBuffer("");

        // Set up a DOM tree to query.
        InputSource in = new InputSource(new StringReader(XMLDocument));
        DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
        dfactory.setNamespaceAware(true);
        Document doc = dfactory.newDocumentBuilder().parse(in);

        System.out.println("#######\n");
        System.out.println(XMLDocument);
        System.out.println("*******\n");
        System.out.println(doc.toString());
        System.out.println("#######\n");

        // Set up an identity transformer to use as serializer.
        Transformer serializer = TransformerFactory.newInstance().newTransformer();
        serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes"); // "true" ?? // sknath

        // Use the simple XPath API to select a nodeIterator.
        System.out.println("Querying DOM using " + xpath);
        NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);

        // Serialize the found nodes to System.out.

        Node n;
        while ((n = nl.nextNode())!= null)
        {         
            if (isTextNode(n)) {
                // DOM may have more than one node corresponding to a 
                // single XPath text node.  Coalesce all contiguous text nodes
                // at this level
                StringBuffer sb = new StringBuffer(n.getNodeValue());
                for (
                        Node nn = n.getNextSibling(); 
                        isTextNode(nn);
                        nn = nn.getNextSibling()
                    ) {
                    sb.append(nn.getNodeValue());
                    sb.append(" ");
                }
                ret_val.append(sb);
                ret_val.append(" ");
            }
            else {
                StringWriter sw = new StringWriter();
                serializer.transform(new DOMSource(n), new StreamResult(sw));
                ret_val.append(sw.toString());
            }
            // System.out.println("*" + ret_val + "*");
            // ret_val.append("\n");
        }
        System.out.println("*" + ret_val + "*");
        Log.Debug("APPLYXPATH END");
        return ret_val;
    }

    /** Decide if the node is text, and so must be handled specially */
    static boolean isTextNode(Node n) {
        if (n == null)
            return false;
        short nodeType = n.getNodeType();
        return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
    }

    /** Main method to run from the command line.    */
    public static void main (String[] args) throws Exception
    {
        System.out.println(applyXPath("<a><b></b></a>", "//"));
    }	

} // end of class ApplyXPath

