/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
//import java.util.*;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

public class QueryDB extends Globals{
    public static void run(String ansIPaddr, int ansPort, String db, String query) 
	throws Exception {

        StringBuffer ans = new StringBuffer("");
	ans.append(QueryDB.gatherAnswer(db, query));
	String packet = ans.toString();

	DataOutputStream outStream = null;
	Socket sock;
	try {
	    sock = new Socket(ansIPaddr, ansPort);
	    outStream = new DataOutputStream(sock.getOutputStream());
	}
	catch (IOException streamEx) {
            streamEx.printStackTrace();
	    return;
	}

	System.out.println("Sending the response: " + packet);
	Packet.send(packet, outStream);
    }

    public static StringBuffer gatherAnswer(String db, String fullQuery) 
                                      throws Exception {

	StringBuffer ans = new StringBuffer("");
	StringBuffer result = new StringBuffer("");
	StringBuffer query = new StringBuffer(fullQuery);

	if (fullQuery.length() == 0) {
	    result.append("2#");
	    result.append("No query specified.");
	    return result;
	}

	int j = fullQuery.lastIndexOf("/");
	query.delete(j, query.length());

	ans.append(QueryDB.getAnswer(db, query.toString()));
	if (ans.length() > 0) {   // Able to answer query from local info
	    result.append("1#");
	    result.append(ans);
	    return result;
	}

	// Find the longest prefix that can be answered from local info,
	// considering prefixes that end just prior to a "/"

	for( int k = fullQuery.lastIndexOf("/");
	     k > 0 && ans.length() == 0;
	     k = query.toString().lastIndexOf("/") ) {
	    query.delete(k, query.length());
	    ans.append(QueryDB.getAnswer(db, query.toString()));
	}

	if (ans.length() == 0) {   // No prefix matches, answer is empty
	    result.append("1#");
	    result.append(ans);
	    return result;
	}

	String owner = QueryDB.extractOwner(ans.toString());
	InetAddress own = InetAddress.getByName(owner);
	
        ans.delete(0,ans.length());
	ans.append("Unable to complete the query: Agent " + owner 
		   + " at " + own.getHostAddress() + " is needed but unavailable.");
	    result.append("2#");
	    result.append(ans);
	    return result;
    }

    public static StringBuffer getAnswer (String db, String q) {
	StringBuffer answer = new StringBuffer();
        String dbname = "xmldb:xindice:///db/" + db;
	System.out.println("<i>(Database is: " + dbname + ")</i><br>");
	System.out.println("<i>(Query is: " + q + ")</i><p>");

	Collection col = null;
	try {
	    String driver = "org.apache.xindice.client.xmldb.DatabaseImpl";
	    Class c = Class.forName(driver);
         
	    Database database = (Database) c.newInstance();
	    DatabaseManager.registerDatabase(database);
	    col = DatabaseManager.getCollection(dbname);
   
	    XPathQueryService service =
		(XPathQueryService) col.getService("XPathQueryService", "1.0");
	    ResourceSet resultSet = service.query(q);
	    ResourceIterator results = resultSet.getIterator();
         
	    while (results.hasMoreResources()) {
		Resource res = results.nextResource();
		answer.append(res.getContent() + "<br>");
	    }
	}
	catch (XMLDBException e) {
            e.printStackTrace();
	    System.err.println("XML:DB Exception: " + e.errorCode 
			       + " " + e.getMessage());
	}
	catch (Exception e) {
            e.printStackTrace();
	    System.err.println( "Exception in QueryDB.getAnswer(): " + e.getMessage() );
	}
	finally {
	    if (col != null) {
		try {
		    col.close();
		}
		catch (XMLDBException e) {
                    e.printStackTrace();
		    System.err.println( "XML:DB Exception: " + e.getMessage() );
		}
		catch (Exception e) {
                    e.printStackTrace();
		    System.err.println( "Exception in QueryDB.getAnswer(): " + e.getMessage() );
		}
	    }
	}

	System.out.println("Answer is: " + answer.toString());
	return answer;
    }

    public static String extractOwner (String text) throws Exception {
	String ownerAgent = "owner-agent=";
	int i = text.indexOf(ownerAgent);

	if (i < 0) {
	    return "*unknown*";
	}

	int j = text.indexOf("\"", i + ownerAgent.length() + 1);
	if (j < 0) {
	    return "*unknown*";
	}

	return text.substring(i + ownerAgent.length() + 1, j);
    }
}
