/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.util.*;


// the class maintains the Lamport clock of a process.
// the data and methods are declared to be static so that the same clock is 
// shared across all the threads of the process.
// Since, sharing happens across threads, locking is needed for 
// reading/writing the Lamport clock.
class Lamport {
	private static long clock_ = 0;
	private static RWLock lock = new RWLock();

	// constructor: stats the clock from some value
	Lamport(long x) {
		clock_ = x;
	}

 	public static void setClock(long x) {
	  clock_ = x;
    }

	// current value of the Lamport clock
	public static long getClock()
	{
		long currValue;
		// lock.getReadLock();
		currValue = clock_;
		// lock.releaseLock();
		return currValue;
	}

	// increment the clock_ by one
	// should be called after each event (e.g. sending a message)
	public static long incClock()
	{
		long currValue;
		// lock.getWriteLock();
		currValue = ++clock_;
		// lock.releaseLock();
		return currValue;
	}

	// Update the clock_ to its current value or 'nextValue',
	// which one is higher
	// also increments the clock_ by one
	// should be called when the process gets Lamport clock of 
	// another process (e.g. via received message)
	public static long updateClock(long nextValue)
	{
		 long currValue = -1;
                //if (nextValue >= clock_)
                //     clock_ = nextValue +1;
                
                
		// lock.getReadLock();
		if (clock_ > nextValue) {
			// lock.getWriteLock();
			currValue = ++clock_;
			// lock.releaseLock();
		}
		// lock.releaseLock();

		if (currValue < 0) { // (clock_ < nextValue)
			// lock.getWriteLock();
			clock_ = nextValue + 1;
			currValue = clock_;
			// lock.releaseLock();
		}
		return currValue;
                
                
		//return clock_;
	}

}
