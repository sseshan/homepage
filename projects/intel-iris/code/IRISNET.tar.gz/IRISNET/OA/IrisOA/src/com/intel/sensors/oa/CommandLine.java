/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;
import org.w3c.dom.*;
import org.gnu.readline.*;

/** A Command line tool to do things with the OAs... basically, uses the Protocol.* functions
 *  to this job. 
 *
 *  @author Amol  
 *  @author Suman
 */

public class CommandLine {

	/** Any command that wants to talk to all the IPs should use this */
	public static String allIPs[] = {
		"greenfield", 
		"oakland", 
		"shadyside", 
		"10.212.3.160", /* amol's desktop */ 
		"trafford",
		"10.212.3.163", /*suman's laptop*/ 
		"10.212.3.93" /*logrus*/ 
	};
	

	public static boolean reallyQuit = false;
	public static String historyFileName = ".commandline.history";
	
	 public static final String prompt = "[31m[4mcommand >[0m";
	//public static final String prompt = "command > ";
	
	public static ServerSocket serversocket;

	public static void startServer(int port) {
		try {
			serversocket = new ServerSocket(port);
			Protocol.myPortNumber = port;
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	/** Code copied directly from the Readline.java file */
	public static void initReadline() {
		try {
			Readline.load(ReadlineLibrary.GnuReadline);
		}
		catch (UnsatisfiedLinkError ignore_me) {
			System.err.println("couldn't load readline lib. Using simple stdin.");
		}

		Readline.initReadline("myapp");

		Runtime.getRuntime().addShutdownHook(new Thread() {
				// if your version supports addShutdownHook (since 1.3)
				public void run() { 
					try {
						Readline.writeHistoryFile(historyFileName); 
						Readline.cleanup(); 
					} catch (Exception e) {
						System.out.println(e);
					}
				}
			}
						     );
		try {
			Readline.readHistoryFile(historyFileName);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Proceeding without the history");
		}
	}


	public static String listenToAndReceiveAMessage() {
		try {
			System.out.println("CommandLine.listenToAndRecieveAMessage(): Waiting for a reply...");
			Socket s = serversocket.accept();
			System.out.println("CommandLine.listenToAndRecieveAMessage(): Got a connection from "
					   + s.getInetAddress());
			DataInputStream inStream = new DataInputStream(s.getInputStream());
			Thread.sleep(300);
			if(inStream.available() != 0) {
				return Packet.receive(inStream);
			} else {
				return "<noresults/>";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// Note that: cqsetup, cquery2, cqcancel are provided for debugging
	// only. Using them will reset the Protocol port number.  You should
	// exit after the debugging.  Specially do not mix query, query2,
	// with the cq commands.
	public static String[] commands = new String[] {
		"addfile ip fileName", 
		"breakfile ip newip [more new IPs] xpathquery",
		"replicatefile ip newip [more new IPs] xpathquery",
		"simplequery ip query",
		"query query",
		"query2 resultType rootAtNode lcaHost query",
		"cqsetup rootQuery port",
		"cquery2 lcaHost query mode period(ms) lease(ms) duration(ms)",
		"cqcancel query_id",
		"addstoredquery query_for_element st_name st_query",
		"delstoredquery query_for_element st_name",
		"prettyprint ip query",
		"evict ip databasename currenttime",
		"showtree ip databasename port?",
		"dnsquery sourcename",
		"dnsupdate sourcename newport",
		"dnspurge",
		"ddnspurge document",
		"dnsupdateall port databasename",
		"ddnsupdateall ipaddress databasename",
		"dnsget",
		"exit", "quit",
		"startsensor nghhood block ipaddress portnumber probflip waittime",
		"delete ip databasename",
		"applytoall command param2 param3 .... (specify everything but the ip)",
		"applytoallf file command param2 param3 .... (specify everything but the ip, IPs are defined in file)",
		"file filename",
		"setcachingoff ip",
		"setcachingon ip",
		"resetstat ip",
		"writestat ip",
		"xupdate ip query",
		"simpleupdate ip query value",
		"shutdown ip",
		"help"
	};

	private static void addFile(String ip, int port, String fileName) throws Exception {
		FileInputStream fis = new FileInputStream(fileName);
		byte[] fileData = new byte[fis.available()];
		fis.read(fileData);
		String allData = new String(fileData);

		if(allData.indexOf(0) != -1) {
			allData = allData.substring(0, allData.indexOf(0));
		}

		// System.out.println(fileData);
		// System.out.println("Step 1");
		Protocol.sendTakeOwnershipMessage(ip, port, allData);
	}

	private static String simpleQuery(String ip, int port, String xpath) throws Exception {
		long start = System.currentTimeMillis();
		Protocol.sendSimpleQueryMessage(ip, port, xpath);
		System.out.println("Time to send the message " + (System.currentTimeMillis() - start));
		return Protocol.preprocessMessage(listenToAndReceiveAMessage());
	}

	private static String query(String xpath) throws Exception {
		try {
			Protocol.sendQueryMessageVerify("0", QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath), ConfigurationManager.instance().getOAPort(), xpath, -1, QueryAnalysis.getRoot(xpath), QueryAnalysis.getLongestNonbrachingPrefix(xpath));
		} catch (Exception e) {
			return "CONNECTION ERROR";
		}
		return Protocol.preprocessMessage(listenToAndReceiveAMessage());
		// return "<none/>";
	}

	private static String query2 (int resultType, String root_at_node,
				      String xpath, String lca_host)
			throws Exception
	{
		String host = lca_host + '.' 
			+ ConfigurationManager.instance().getDNSSuffix();
		try {
			Protocol.sendQuery2Message (
										1, resultType, root_at_node, xpath,
										host, ConfigurationManager.instance().getOAPort());
		} catch (Exception e) {
			return "CONNECTION ERROR";
		}
		return Protocol.preprocessMessage(listenToAndReceiveAMessage());
	}

	private static String query_route(String xpath) throws Exception {
		String hostName = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath);
		Protocol.sendQueryMessage("0", hostName,
					  (ConfigurationManager.instance()).getOAPort(), xpath, -1, QueryAnalysis.getRoot(xpath), hostName);
		return Protocol.preprocessMessage(listenToAndReceiveAMessage());
		// return "<none/>";
	}

    public static int getPort(StringTokenizer st) {
        // return Integer.parseInt(st.nextToken());
        return (ConfigurationManager.instance()).getOAPort();
    }

	public static QueryAPI query_api = null;

	public static long processCommand(String command) throws Exception {
		StringTokenizer st = new StringTokenizer(command);
		String cmd = st.nextToken();

		if(cmd.equals("addfile")) {
			addFile(st.nextToken(), getPort(st), st.nextToken());
		} else if(cmd.equals("breakfile") || cmd.equals("replicatefile")) {
			//String ip = st.nextToken();
			//int port = getPort(st);
			//String newip = st.nextToken();
			//int newPort = getPort(st);
			//Protocol.sendDelegateOwnershipMessage(ip, port, st.nextToken("").substring(1), newip, newPort);

			// changed by suman to support multiple destination addresses
			String ip = st.nextToken();
			int port = (ConfigurationManager.instance()).getOAPort(); //Integer.parseInt(st.nextToken());
			int ipCount = st.countTokens()-1;
			String ipList[] = new String[ipCount];
			System.out.println("IPCOUNT: " + ipCount);
			for (int i = 0; i < ipCount; i++) {
				ipList[i] = st.nextToken();
				System.out.println("Host: " + ipList[i]);
			}
			int newPort = (ConfigurationManager.instance()).getOAPort(); //Integer.parseInt(st.nextToken());
			Protocol.sendDelegateOwnershipMessage(ip, port, st.nextToken("").substring(1), ipList, newPort, cmd.equals("breakfile"));

		} else if(cmd.equals("simplequery")) {
			System.out.println(simpleQuery(st.nextToken(), getPort(st), st.nextToken("").substring(1)));
		} else if(cmd.equals("query")) {
			long t1 = System.currentTimeMillis();
			String response = query(st.nextToken("").substring(1));
			long t2 = System.currentTimeMillis();
			System.out.println(response);
			System.out.println("The query took " + (t2 - t1) + " milli seconds");
			return t2-t1;
			//Log.shutdownlogger();
		} else if(cmd.equals("query2")) {
			int resultType = Integer.parseInt (st.nextToken());
			String rootAtNode = st.nextToken();
			String lcaHost = st.nextToken();
			String xpath = st.nextToken("").substring(1);
			long t1 = System.currentTimeMillis();
			String response = 
			   query2 (resultType, rootAtNode, xpath, lcaHost);
			long t2 = System.currentTimeMillis();
		    System.out.println(response);
            System.out.println("The query took " + (t2 - t1) + " milli seconds");

			return t2-t1;
			//Log.shutdownlogger();
		} else if(cmd.equals("query_route")) {
			System.out.println(query_route(st.nextToken("").substring(1)));
		} else if(cmd.equals("prettyprint")) {
			DOMProcessing.prettyPrint(simpleQuery(st.nextToken(), getPort(st), st.nextToken("").substring(1)));
		} else if(cmd.equals("prettyprintquery")) {
			DOMProcessing.prettyPrint(query(st.nextToken("").substring(1)));
		} else if(cmd.equals("showtree")) {
			String ip = st.nextToken();
			String databaseName = st.nextToken();
			int port = getPort(st);
			DOMProcessing.prettyPrint(simpleQuery(ip, port, "/" + databaseName));
		} else if(cmd.equals("exit") || cmd.equals("quit")) {
			Readline.writeHistoryFile(historyFileName);
			reallyQuit = true;
			Readline.cleanup();
			System.exit(0);
		} else if(cmd.equals("dnsupdate")) {
			// this is probably one place where we need to know which one of the two DNS Helpers we are using
			if(DNSHelper.getDNSHelper() instanceof DynamicDNSHelper) {
				System.out.println(DNSHelper.getDNSHelper().updateHost(st.nextToken(),
										       st.nextToken(), null));
			} else if(DNSHelper.getDNSHelper() instanceof MyDNSHelper) {
				System.out.println(DNSHelper.getDNSHelper().updateHost(st.nextToken(),
										       "127.0.0.1",
										       st.nextToken()));
			}
		} else if(cmd.equals("dnsquery")) {
			System.out.println(DNSHelper.getDNSHelper().resolveHost(st.nextToken()));
		} else if(cmd.equals("dnspurge")) {
			System.out.println(DNSHelper.getDNSHelper().purgeAll());
		} else if(cmd.equals("ddnspurge")) {
			DNSHelper.getDNSHelper().removeAllOwnedHostNamesAllRecords(DOMProcessing.fileToDOM(st.nextToken()));
		} else if(cmd.equals("dnsget")) {
			StringTokenizer _st = new StringTokenizer(DNSHelper.getDNSHelper().getAll());
			int count = 1;
			System.out.print("*	");
			while(_st.hasMoreTokens()) {
				System.out.print(_st.nextToken() + "	");
				count++;
				if(count == 3) {
					System.out.println();
					count = 0;
				} 
			}
		} else if(cmd.equals("save")) {
			Readline.writeHistoryFile(historyFileName);
		} else if(cmd.equals("help")) {
			String prefix = null;
			try { prefix = st.nextToken();} catch (Exception e) {}
			for(int i = 0; i < commands.length; i++) {
			   if ((prefix == null) 
			     || (commands[i].startsWith(prefix)))
				System.out.println(commands[i]);
			}
		} else if(cmd.equals("evict")) {
			Protocol.sendEvictCacheMessage(st.nextToken(), getPort(st),
						       st.nextToken(), st.nextToken());
		} else if(cmd.equals("delete")) {
			Protocol.sendDeleteDatabaseMessage(st.nextToken(), getPort(st), st.nextToken());
		} else if(cmd.equals("dnsupdateall")) {
			Protocol.sendUpdateDNSAll("127.0.0.1", Integer.parseInt(st.nextToken()), st.nextToken());
		} else if(cmd.equals("ddnsupdateall")) {
			// same message takes care of both possibilities...
			Protocol.sendUpdateDNSAll(st.nextToken(), getPort(st), st.nextToken());
		} else if(cmd.equals("setcachingoff")) {
			Protocol.sendCachingOff(st.nextToken(), getPort(st));
		} else if(cmd.equals("setcachingon")) {
			Protocol.sendCachingOn(st.nextToken(), getPort(st));
		}  else if (cmd.equals("resetstat")) {
			Protocol.sendResetStat(st.nextToken(), (ConfigurationManager.instance()).getOAPort());
		} else if (cmd.equals("writestat")) {
			Protocol.sendWriteStat(st.nextToken(), (ConfigurationManager.instance()).getOAPort());
		} else if (cmd.equals("shutdown")) {
			Protocol.sendShutdown(st.nextToken(), (ConfigurationManager.instance()).getOAPort());
		}else if(cmd.equals("shutdownlogger")) {
			Log.shutdownlogger();
		} else if(cmd.equals("startsensor")) {
			String[] sensor_start_command = new String[] {
				"java", "com.intel.sensors.oa.FakeSensor",
				st.nextToken(), st.nextToken(), "", st.nextToken(),
				st.nextToken(), st.nextToken(), st.nextToken()};
			
			java.lang.Runtime.getRuntime().exec(sensor_start_command);
			System.out.println("Started a fake sensor");
		} else if(cmd.equals("applytoall")) {
			String commandname = st.nextToken();
			String rest = st.nextToken("").substring(1);
			for(int i = 0; i < allIPs.length; i++) {
				String _command = commandname + " " + allIPs[i] + " " + rest;
				System.out.println("Executing " + _command);
				processCommand(_command);
			}
		}else if(cmd.equals("applytoallf")) {
			String filename = st.nextToken();
			String commandname = st.nextToken();
			String rest = st.nextToken("").substring(1);
			
			BufferedReader br = new BufferedReader(new FileReader(filename));
			String _ip;
			while((_ip = br.readLine()) != null) {
				String _command = commandname + " " + _ip + " " + rest;
				System.out.println("Executing " + _command);
				processCommand(_command);
			}
		} else if(cmd.equals("file")) {
			try {
				BufferedReader br = new BufferedReader(new FileReader(st.nextToken()));
				String _command;
				while((_command = br.readLine()) != null) {
					System.out.println("CommandLine.processCommand(): Executing: "
							   + _command);
					try {
						processCommand(_command);
					} catch (Exception e) {
						e.printStackTrace();
					}
					//Thread.currentThread().sleep(5*1000);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if(cmd.equals("xupdate")) {
			String ip = st.nextToken();
		  	String query = st.nextToken("").substring(1);
			int port = ConfigurationManager.instance().getOAPort();
			String packet = Globals.COMMAND_FETCH_DONE
					+ ' ' + Globals.COMMAND_XUPDATE_FROM_SA
					+ ' ' + Protocol.getLocalIP() 
					+ ' ' + query;
		      try {
			Protocol.sendPacket (packet, ip, port, false);
		      } catch (Exception e) {
			e.printStackTrace();
		      }
			
		} else if(cmd.equals("simpleupdate")) {
			String ip = st.nextToken();
		  	String query = st.nextToken();
			String value = st.nextToken();
			String[] xpathqueries = new String[1];
			xpathqueries[0] = query;
			String[] new_values = new String[1];
			new_values[0] = value;

		      try {
			Protocol.sendNewDataMessage (ip, 
				ConfigurationManager.instance().getOAPort(),
				xpathqueries,
				new_values);
		      } catch (Exception e) {
			e.printStackTrace();
		      }
			
		} else if(cmd.equals("cqsetup")) {
		    try {
			String root_query = st.nextToken();
			int port = Integer.parseInt (st.nextToken());
			QueryAPI.init (port);
			query_api = new QueryAPI (root_query);
		    } catch (Exception e) {
			e.printStackTrace ();
		    }
		} else if(cmd.equals("cquery2")) {
		    try {
			String lca_host = st.nextToken();
			String query = st.nextToken();
			String mode = st.nextToken();
			long period = Long.parseLong (st.nextToken());
			long lease  = Long.parseLong (st.nextToken());
			long duration = Long.parseLong (st.nextToken());

			if (query_api != null) {
			  long query_id = query_api.sendContinuousQuery (
				query, lca_host, mode,
				period, lease, duration,
				new MyCQCallBack());

			  if (query_id > 0)
			    System.out.println ("query id = " + query_id);
			}
			else {
			  System.out.println ("call cqsetup first!");
			}

                    } catch (Exception e) {
                        e.printStackTrace ();
                    }
		} else if(cmd.equals("cqcancel")) {
		    try {
			long query_id = Long.parseLong (st.nextToken());
			if (query_api != null)
			  query_api.cancelQuery (query_id);
                    } catch (Exception e) {
                        e.printStackTrace ();
                    }
		} else if(cmd.equals("addstoredquery")) {
		    try {
			String query_for_element = st.nextToken();
			String st_name = st.nextToken();
			String st_query = st.nextToken("").substring(1);
			Protocol.sendAddStoredProcedureMessage (
			  query_for_element, st_name, st_query,
			  query_api.getLcaHost (query_for_element),
			  ConfigurationManager.instance().getOAPort()
			);
                    } catch (Exception e) {
                        e.printStackTrace ();
                    }
		} else if(cmd.equals("delstoredquery")) {
		    try {
			String query_for_element = st.nextToken();
			String st_name = st.nextToken();
			Protocol.sendRemoveStoredProcedureMessage (
			  query_for_element, st_name,
			  query_api.getLcaHost (query_for_element),
			  ConfigurationManager.instance().getOAPort()
			);
                    } catch (Exception e) {
                        e.printStackTrace ();
                    }
		} else {
			System.out.println("Unknown Command");
		}

		return 0;
	}
	
	public static void callMainLoop() {
		while(true) {
			try {
				String command = Readline.readline(prompt);
				if (command != null)
					processCommand(command);
			} catch (java.util.NoSuchElementException e) {
				System.out.println("Not enough arguments (I think)");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	static void writeLine(BufferedWriter bw, String line) throws Exception
	{
		bw.write(line, 0, line.length());
		bw.newLine();
		bw.flush();
	}

	public static int runExperiment(String inputFile, String outputFile)
	{
		try {
			BufferedReader br = new BufferedReader(new FileReader(inputFile));
			FileWriter fw = new FileWriter(outputFile, true);
			BufferedWriter bw = new BufferedWriter(fw);
			
			String line;
			while ( (line = br.readLine()) != null) {
				if (line.startsWith("#")) continue;
				writeLine(bw, line);
				writeLine(bw, "+++++++++++++++++++++++++++");

				double sum = 0, sumsqr = 0;
				int n = 20;
				for (int i = 0; i < n; i++) {
					long time =  processCommand(line);
					sum += time;
					sumsqr += time * time;
				}

				double avg = sum / n;
				double stdev = Math.sqrt((sumsqr - sum*sum/n)/(n-1));

				writeLine(bw, "Average: " + avg + " Stddev: " + stdev);
			}

			bw.flush();
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return 1;
		
	}
	
	public static void main(String args[]) {

		// ShutDownThread sdt = new ShutDownThread();
		// Runtime.getRuntime().addShutdownHook(sdt);

		if (args.length < 1) {
                        System.out.println("parameters: <oa.cfg> <port>");
                        return;
                }

                ConfigurationManager CM = ConfigurationManager.instance();
                CM.loadConfiguration(args[0]);
                CM.printConfiguration();

		
		// added by suman
		// CommandLine runs in two modes. 
		// When run with a single command line arg (port number of the commandline server), it runs
		// in interactive mode
		if (args.length == 2) {
			//Log.setReplayLog(Globals.LOG_IP, Globals.LOG_PORT);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			initReadline();
			startServer(Integer.parseInt(args[1]));
			System.out.println("Type \"help\" for list of commands.");
			//if (runExperiment("ex.in", "ex.out") == 1) return;

			callMainLoop();
		} 
		// when run with more than one argumanets, in the format "<oa.cfg> <DUMMY ARG> <Command>",
		// it executes the command and terminates
		// mainly added for initializing the OAs from shell scripts
		
		else if (args.length > 2){
			String command = "";
			startServer(10022);

			// skip the dummy argument and fetch the command
			for (int i = 2; i < args.length; i++) {
				command += (args[i] + " ");
			}
			//System.out.println("Executing the command:" + command);
			try {
				processCommand(command);
			}  catch (java.util.NoSuchElementException e) {
				System.out.println("Not enough arguments (I think)");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
}

/********
// We won't shutdown in response to Ctrl-C 
class ShutDownThread extends Thread {
    public void run() {
        if(! CommandLine.reallyQuit) {
            CommandLine.callMainLoop();
        }
    }
}
****** */

class MyCQCallBack implements QueryCallBack {

  public void callBack (int result_type, Object result)
  {
	System.out.println ("result_type = " 
			+ QueryOperator.getResultTypeName (result_type));

	if (result instanceof String[]) {
	  result = QueryOperator.getResultString ((String[])result);
	}

	System.out.println ((result!=null)?(String)result : "null");
  }
}
