/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;

import com.stevesoft.pat.*;

public class FetchHandler extends Thread{
	private ParsedMessage _pm = null;

	public FetchHandler(ParsedMessage pm) 
	{
		_pm  = pm;
	}

	// parse the String and extracts the external file names. 
	// The external files to be fetched are recognized by the special tag 'fetch'
	// Example: fetch='image.gif'
	private List getNamesOfFilesToFetch(String response)
	{
		ArrayList files = new ArrayList();
		int currIndex = 0, nextIndex;
		Regex re_file = new Regex("fetch\\s*=\\s*(['\"])(.*?)\\1");
		re_file.optimize();

		String tmpResponse = response;

		while (true) {
			if (re_file.search(tmpResponse)) {
				System.out.println("File name: " +re_file.stringMatched(2)); 
				files.add(re_file.stringMatched(2));
				tmpResponse = re_file.right();
			} else break;
		}
		/*
		while (true) {
			System.out.println(currIndex);
			nextIndex = response.indexOf("fetch", currIndex);
			if (nextIndex == -1) break;
			currIndex = response.indexOf("'", currIndex) + 1; // start of the filename
			nextIndex =response.indexOf("'", currIndex); // end of the filename
			System.out.println("File name: " + response.substring(currIndex, nextIndex));
			files.add(response.substring(currIndex, nextIndex));
			currIndex = nextIndex;
		}
		*/

		return files;
	}

	// fetch the files from "http://<srcIP>:4080/<filename>
	// we assume that <srcIP> (which is supposed to be an OA) 
	// runs xindice server which offers a http server on port 4080
	private void fetchFiles(List files, String srcIP)
	{
		ConfigurationManager CM = ConfigurationManager.instance();
		if (files != null) {
			Iterator iterator = files.iterator();
			WGet wget = new WGet(CM.getHTTPDocRoot());

            while (iterator.hasNext()) {
                String file = (String) iterator.next();
				String url = "http://" + srcIP + ":" + CM.getHTTPPort()+ "/" + file;
				System.out.println("Fetching external file: " + url);
				wget.save(url, true); // overwrite
			}
		}
	}

	public void run() 
	{
		if (_pm == null) return;
		ConfigurationManager CM = ConfigurationManager.instance();

		if (_pm.response != null)
			fetchFiles(getNamesOfFilesToFetch(_pm.response), _pm.srcIP);
		try {
			String packet = Globals.COMMAND_FETCH_DONE + " " + _pm.originalMessage;
			 Packet.send(packet, Protocol.getLocalIP() , Protocol.getLocalPort() );
		}  catch (Exception e) {
            System.out.println("fetchHandler.run(): Exception caught.  Please debug the code.");
            e.printStackTrace();
            return;
        }

	}

	public static void main(String args[])
	{
		ParsedMessage pm = new ParsedMessage();
		pm.srcIP = "128.2.206.1";
		pm.response = "<snapshot-image fetch='feather.gif' timestamp='123456789'/><snapshot-url timestamp='123456789'/><snapshot-image fetch \n= \"Galax.zip\"/>";
		FetchHandler fh = new FetchHandler(pm);
		fh.fetchFiles(fh.getNamesOfFilesToFetch(pm.response), pm.srcIP);
	}
}
