package com.intel.utils;

import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.stevesoft.pat.*;

import com.intel.sensors.oa.Log;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;

import com.intel.sensors.oa.*;
import org.w3c.dom.Document;

/** Job of this is to listen on a port ... can't think of any other way 
 *  to see if any data is being received by the client aksing a query.
 *
 *  @author Suman
 *  */
public class CannedQueries {
    public static ServerSocket httpServersocket;

    private static ServerSocket listenServersocket = null;

    private static String replaceAll(String src, String original, String replacement) {
	int index, last = 0;
	String result = "";
	while ( (index = src.indexOf(original, last)) >= 0) {
	    if (index >0)
		result += src.substring(last, index);
	    result += replacement;
	    last = index + original.length();
	}
	if (src.length() >= last) {
	    System.out.println("Here " + src.length() + ":" + last);
	    result += src.substring(last, src.length());
	}
	return result;
    }  

    public static void startListener(int port) {
        try {
            listenServersocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static String listenToAndReceiveAMessage() {
        try {
            Socket s = listenServersocket.accept();
	    DataInputStream inStream = new DataInputStream(s.getInputStream());
            Thread.sleep(300);
            String result = null;
            if(inStream.available() != 0) {
                result = Packet.Receive(inStream);
            } else {
                result = "<noresults/>";
            }
            s.close();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /** This accepts the initial request from the form */
    public static void run_http_server(int port) {
        httpServersocket = null;
        try {
            httpServersocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

	String XSLT1 = "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">" +
	    "<xsl:output method=\"xml\" omit-xml-declaration=\"yes\"/> <xsl:template match=\"METRIC\"> <xsl:if test=\"(";

	String XSLT2 = ")\"> <xsl:copy>" + 
	    "<xsl:apply-templates select=\"@*|node()\"/>" +
	    "</xsl:copy></xsl:if></xsl:template>";

	String XSLT3 = "<xsl:template match=\"@*|node()\"> <xsl:copy>" +
	    "<xsl:apply-templates select=\"@*|node()\"/></xsl:copy></xsl:template></xsl:stylesheet>";


        while(true) {
            Socket s = null;
            try {
                String requestString = null;
                s = httpServersocket.accept();
                System.out.println("Got a new connection... listening");
                InputStreamReader isr = new InputStreamReader(s.getInputStream());
                DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                try {
                    String str;
                    BufferedReader br = new BufferedReader(isr);
                    str = br.readLine();
		    System.out.println("Accepted: " + str);
                    while(!str.equals("")) {
                        if(str.indexOf("GET") != -1) {
                            requestString = str;
                        }
                        System.out.println("*" + str + "*");
                        str = br.readLine();
                    }
                } catch (Exception e) {
                }

                System.out.println("request String: " + requestString);
                int index = requestString.indexOf("/");
		StringTokenizer tok = new StringTokenizer(requestString.substring(index+1), " \n");
		String xpath = URLDecoder.decode(tok.nextToken()); //, "UTF-8");

		System.out.println("XPATH Query from browser: " + xpath);

                Protocol.sendQueryMessage(0, QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath), 6789, xpath, -1, QueryAnalysis.getRoot(xpath));
                ParsedMessage pm = Protocol.parseIncomingMessage(listenToAndReceiveAMessage());
                System.out.println("********** RESPONSE ************");
                System.out.println(pm.response);

		String _response = pm.response;
		// filter out the METRICs not in the query
	        //int predicateStart = xpath.indexOf("METRIC[@NAME") + 7;
		//if (predicateStart >=7 ) {
		//    int predicateEnd = xpath.indexOf("]", predicateStart);
		//    String predicate = xpath.substring(predicateStart, predicateEnd);
		//    String XSLT = XSLT1 + predicate + XSLT2 + XSLT3;
		//    System.out.println("XSLT: " + XSLT);
		//    _response = ApplyXSLTtoString.applyXSLTToString(pm.response, XSLT).toString();
		//}

		//String _response =  new String(ApplyXPathToString.applyXPath(pm.response, xpath));
		//String convertedXSLTQuery = QueryAnalysis.findXSLTQuery(xpath);
		//String _tmpresponse = ApplyXSLTtoString.applyXSLTToString(pm.response, convertedXSLTQuery).toString();
		//System.out.println("pm.response: \n========\n"+ pm.response + "\nQuery\n=======\n"+xpath);
		//System.out.println("XSLT Query\n========\n" + convertedXSLTQuery + "\nAFTER APPLYING FINAL FILTERING:\n========\n" + _tmpresponse);
                Document doc = DOMProcessing.XMLtoDOM(_response); //pm.response);
                // doc = DOMProcessing.fileToDOM("demodata.xml");
                //System.out.println(DOMProcessing.DOMtoXML(doc));
                DOMProcessing.myNormalize(doc);
                DOMProcessing.orderByIDs(doc);
		
		// get rid of unnecessary results
		Document doc2 = DOMProcessing.applyFileXSLTtoDOM(doc, "trim.xsl");
                String next_to_final_response = DOMProcessing.DOMtoXML(DOMProcessing.applyFileXSLTtoDOM(doc2, "my2html-1.xsl"));
		//System.out.println("after XSLT: \n" + next_to_final_response);
		
                StringBuffer final_response = new StringBuffer(next_to_final_response);
                int insert_at = next_to_final_response.indexOf("<font");

		if (insert_at >= 0) {
		    // must insert in reverse order; otherwise need to keep on updating insert_at
		    final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query Answer :</b> </font>" + "<br>");
		    
		    // insert the query starting point; modified
		    
		    String startingpoint = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath);
		    startingpoint = startingpoint.substring(0, startingpoint.indexOf("irisnetROOT"));
		    startingpoint = startingpoint + "dsan.net";
		    final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Starting Point :</b> </font>" + startingpoint + "<br><br>");
		    
		    
		    final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query : </b></font> /planetlab" + xpath.substring(10, xpath.length()) + "<br><br>");
		    
		    //System.out.println("XSLT RESPONSE");
		    //System.out.println(final_response);
		    
		    ///StringBuffer final_response = new StringBuffer("<html><head></head><body>"+pm.response+"</body></html>\n");
		    // dos.writeBytes("<html><head><body>Error processing the directive</body>");
		    dos.writeBytes(final_response.toString());
		} else {
		    dos.writeBytes("<html><head><body>Empty Answer</body>");
		}
		dos.write(0);
                dos.flush();
                Thread.sleep(100);
                dos.close();
                s.close();

                Log.shutdownlogger();

            } catch (Exception e) {
                e.printStackTrace();
                try { 
                    DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                    dos.writeBytes("<html><head><body>Error processing the directive</body>");
                    dos.write(0);
                    dos.flush();
                    Thread.sleep(100);
                    dos.close();
                    s.close();
                } catch (Exception ee) {
                }
                System.out.println("Continueing");
            }
        }
    }


    public static void main(String[] args) {
        try {

	    ConfigurationManager CM = ConfigurationManager.instance();
	    CM.loadConfiguration(args[0]);
	    CM.printConfiguration();

	    // start the heartbeat server
	    if (!CM.getHBIP().equals("0.0.0.0")) {
		HeartBeat hb = new HeartBeat(CM.getHBIP(), CM.getHBPort(), CM.getHBPeriod());
		Thread t1 = new Thread(hb);
		hb.run();
	    }

  
            com.intel.sensors.oa.Protocol.myPortNumber = Integer.parseInt(args[1]);

            startListener(com.intel.sensors.oa.Protocol.getLocalPort());

            run_http_server(Integer.parseInt(args[0]));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};
