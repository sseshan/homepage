/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;

/** This class will do various kinds of postprocesisng on the results returned
 *  from the Xindice (This is probably not used any more).
 * 
 *  @author Amol Deshpande
 */
public class PostprocessXindiceResults {

    /** If the document begins with <?xml version?>, delete it */
    public static StringBuffer stripXMLVersion(StringBuffer s) {
        if(s.toString().indexOf("<?xml version") != -1) {
            int i = s.toString().indexOf(">");
            s.delete(0, i+1);
        }
        return s;
    }

    /** Given two xml documents, both returns of queries on Xindice, adjust the
     *  first one so that it has the rest of teh information that the other
     *  doucment has up in the hierarchy. */
    public static StringBuffer adjustAnswers(StringBuffer ans1, StringBuffer ans2) {
        try {
            // just in case
            ans1 = stripXMLVersion(ans1);
            ans2 = stripXMLVersion(ans2);

            // find the name of the root element of the first document
            int index = ans1.toString().indexOf(" ");  
            int index2 = ans1.toString().indexOf(">");  
            int index3 = ans1.toString().indexOf("<");

            System.out.println("The two indexes are " + index + " " + index2 + " " + index3);

            // may not be a " " that ends the root name
            if((index == -1) || ((index2 != -1) && (index > index2))) {
                index = index2;
            }

            System.out.println(ans1 + " " + index + " " + index3);

            String root = ans1.substring(index3+1, index);
            System.out.println("The root is " + root + "*");

            // look for "<root" in ans2
            int indexRootBegin = ans2.toString().indexOf(root);
            int indexRootEnd = ans2.toString().lastIndexOf("/" + root) + root.length() + 1;

            if((indexRootEnd == -1) || (indexRootBegin == -1)) {
                // Hit the panic button
                System.out.println("Something wrong.");
                System.exit(1);
            }

            // prepend everything before that "indexRoot - 2" to ans1
            ans1.insert(0, ans2.substring(0, indexRootBegin-1));
            ans1.append(ans2.substring(indexRootEnd+1));

            return ans1;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println(stripXMLVersion(new StringBuffer("<?xml version>hiamol")));
        System.out.println(adjustAnswers(new StringBuffer("<amol></amol>"), new StringBuffer("<help>xyz<amol></amol>morexyz</help>")));
    }
};
