/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;
import java.lang.Thread;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

/** Take ownership of a document. Again, static functions only. */
public class ServantTakeownership extends Globals {


    /** This is slightly simplified version of the one in DOMProcessing.java file (I hope). 
		We only look at Element level. Given a particular element in the hierarchy, 
		there are a three possibilities :
		1) not present in either ... we won't even consider this element then.
		2) `owned' by one ... the one who `owns' has the authority in this scope.
		    so except for elements, we should copy everything else from that element.
			Note that one document can own a node, and other can own all children below it.
		3) not `owned' by either ... doesn't matter whose copy we use ... prefer the hereDoc
		   unless the hereDoc doesn't have that element in which case, take the other guy's.
		   
		Note that, this method suffers from the problem that it needs to construct the 
		entire document in memory, and as such, is not scalable to large documents.
     */
    private static Element mergeTwoDocuments(Element hereElm, Element newElm) {
        // sanity check that these two elements are indeed `equal'
        Utils.myassert(DOMHelper.isSpecial(hereElm));
        Utils.myassert(DOMHelper.isSpecial(newElm));
        Utils.myassert(DOMHelper.areEqual(hereElm, newElm));

        // if either one is incomplete or either one owns the subtree completely, 
		// we know what to do
        if(DOMHelper.isIncomplete(hereElm) || DOMHelper.isOwnedCompletely(newElm))
            return newElm;
        if(DOMHelper.isIncomplete(newElm) || DOMHelper.isOwnedCompletely(hereElm))
            return hereElm;

        // Neither is incomplete; neither is completely owned; 
        Element owningNode = hereElm, notOwningNode = newElm; // prefer the hereNode for this scope
        if(DOMHelper.isOwned(newElm)) {
            // but if this is true, swap
            owningNode = newElm;
            notOwningNode = hereElm;
        } 

        // make a list of special children the owningNode has; we are going to need it
        Vector v = new Vector();
        for(int i = 0; i < owningNode.getChildNodes().getLength(); i++) {
            if(DOMHelper.isSpecial(owningNode.getChildNodes().item(i))) {
                v.add(owningNode.getChildNodes().item(i));
            }
        }

        // so the return value is going to be owningNode
        for(int i = 0; i < notOwningNode.getChildNodes().getLength(); i++) {
            if(DOMHelper.isSpecial(notOwningNode.getChildNodes().item(i))) {
                // so the notOwning node has a special child; search for this special child in owning node; it must be
                // present
                Element e1 = (Element) notOwningNode.getChildNodes().item(i);
                for(int j = 0; j < v.size(); j++) {
                    if(DOMHelper.areEqual(e1, (Element) v.get(j))) {
                        owningNode.replaceChild(mergeTwoDocuments(e1, (Element) v.get(j)), (Element) v.get(j));
                    }
                } } else { 
					// we don't really care; the owning node has all the information 
					// at this scope and is prefered anyway
            }
        }
        return owningNode;
    }

    /** Merge newDoc into oldDoc.  oldDoc is updated. */
    private static void mergeDocumentInto(Document oldDoc, Document newDoc) {
        oldDoc.replaceChild(mergeTwoDocuments(oldDoc.getDocumentElement(), newDoc.getDocumentElement()), oldDoc.getDocumentElement());
    }


	public static void subscribeToSAs(String name) throws Exception {
		subscribeToSAs(Globals.getDatabase().getDocumentWithID(name));
	}

	public static void subscribeToSAs(Document doc) throws Exception {
		/** Find the SA's that are reporting to this document */
		Node[] nodes = DOMProcessing.applyXPATHtoDOM(doc, "//*[@status = 'ownsthis'][@owner-sensor]");
		String[] reportingSAs = new String[nodes.length];
		for(int i = 0; i < nodes.length; i++) {
			reportingSAs[i] = ((Element) nodes[i]).getAttribute("owner-sensor");
		}
		
		/** Load and Subscribe */
		for(int i = 0; i < reportingSAs.length; i++) {
			ParsedMessage pm = Protocol.parseIncomingMessage("S " + reportingSAs[i] + " "+ 
(ConfigurationManager.instance()).getSAPort() +" C " + Globals.SENSELET +" ENDMESSAGE");
			ServantSubs subs = new ServantSubs(pm);
			// Thread t = new Thread(subs);
			// t.start();
			
			// System.out.println("comes here");
			//System.out.println(pm);
		}
	}
	

	public static String takeOwnerShip(String document) throws Exception {
		System.out.println("ServantTakeownership.takeOwnership(): Taking ownership of new document.");

		Document newdoc = DOMProcessing.XMLtoDOM(document);
		
		String id = newdoc.getDocumentElement().getTagName();
		if(Globals.getDatabase().existsDocumentWithName(id)) {
			Document hereDoc = Globals.getDatabase().getDocumentWithID(id);
			mergeDocumentInto(hereDoc, newdoc);
			// System.out.println(DOMProcessing.DOMtoXML(hereDoc));
			System.out.println("ServantTakeownership.takeOwnership(): Old document exists.  Printing final merged document.");
			DOMProcessing.prettyPrint(hereDoc);
			Globals.getDatabase().storeDocument(hereDoc);
		} else {
			Globals.getDatabase().storeDocument(newdoc);
		}
		
		try {
			Log.claimOwnershipWithTheReplayServer(newdoc);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// update the DNS names
		System.out.println("ServantTakeownership.takeOwnership(): Updating DNS ...");
		DNSHelper.getDNSHelper().addAllOwnedHostNames(newdoc);
		

		// update the Statistics
		String hosts[] = DOMProcessing.findAllOwnedHostNames(newdoc);
		Statistics.instance().addOwnedNodes(hosts);

		System.out.println("ServantTakeownership.takeOwnership(): Finished updating DNS.");
		System.out.println("ServantTakeownership.takeOwnership(): Subscribing to new SA's");
		subscribeToSAs(newdoc);
		

		// invalidate the cache
		CacheManagement.instance().RemoveDocumentFromCache(id);

		// renew continuous query
		ContinuousQuery.renewContinuousQuery (id);

		// Everything worked out fine till now; send a SUCCESS message back; 
		// somebody is waiting
		return "SUCCESS";
		
	}
}
