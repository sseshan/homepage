/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import org.w3c.dom.*;
import java.util.*;

/** SPBuiltIn class implements the built-in stored procedures
 *  
 *  @author Shimin
 */
public class SPBuiltIn {

	// simple procedure: sumlocal
	// used only for the evaluation purpose
	// has only the local procedure
	public static String sumlocal_local (String[] orig_vals, String[] params)
	{
        double sum = 0.0;
        for (int ii=0; ii<orig_vals.length; ii++) {
			double val = Double.parseDouble (orig_vals[ii]);
			sum += val;
        }
        return Double.toString (sum);
	}

	
  // ---
  // simple procedure: sum
  // ---
  public static String sum_local (String[] orig_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum_init (String orig_val, String[] params)
  {
	  if (orig_val != null && orig_val.equals(NULL_VALUE)) return NULL_VALUE;

	  return ((orig_val!=null)?orig_val:"0");
  }
  public static String sum_compute (String[] inter_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<inter_vals.length; ii++) {
			if (inter_vals[ii].equals(NULL_VALUE)) continue;
           double val = Double.parseDouble (inter_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum_final (String inter_val, String[] params)
  {
	  if (inter_val.equals(NULL_VALUE)) return NULL_VALUE;
	  return inter_val;
  }

  // ---
  // complex procedure: count
  // ---
  public static String count_local (NodeList orig_nodes, String[] params)
  {
        return Integer.toString (orig_nodes.getLength());
  }
  public static String count_init (Node orig_node, String[] params)
  {
        return ((orig_node!=null)?"1":"0");
  }
  public static String count_compute (String[] inter_vals, String[] params)
  {
        int sum = 0;
        for (int ii=0; ii<inter_vals.length; ii++) {
           int val = Integer.parseInt (inter_vals[ii]);
           sum += val;
        }
        return Integer.toString (sum);
  }
  public static String count_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: avg 
  // ---
  public static String avg_local (String[] orig_vals, String[] params)
  {
	if (orig_vals.length == 0)
	  return "0";

        double sum = 0.0;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
           sum += val;
        }
	double avg = sum / (double) orig_vals.length;
        return Double.toString (avg);
  }
  public static String avg_init (String orig_val, String[] params)
  {
	  if (orig_val!= null &&
		  orig_val.equals(NULL_VALUE)) return "0:0";

	if (orig_val != null)
          return orig_val + ":1";
	else
	  return "0:0";
  }
  public static String avg_compute (String[] inter_vals, String[] params)
  {
	  double sum = 0.0;
	  int count = 0;
	  for (int ii=0; ii<inter_vals.length; ii++) {
		  //System.out.println("avg_compute:" + inter_vals[ii]);
		  String str = inter_vals[ii];
		  if (str.equals(NULL_VALUE)) continue;
		  
		  int colon = str.indexOf (':');
		  double val = Double.parseDouble (str.substring(0,colon));
		  sum += val;
		  int    cnt = Integer.parseInt (str.substring(colon+1,str.length()));
		  count += cnt;
	  }
	  return Double.toString (sum) + ':' + Integer.toString (count);
  }

	public static String avg_final (String inter_val, String[] params)
  {
	  if (inter_val.equals(NULL_VALUE)) return NULL_VALUE;
	  int colon = inter_val.indexOf (':');
	  double sum = Double.parseDouble (inter_val.substring(0,colon));
	  int  count = Integer.parseInt (
									 inter_val.substring(colon+1,inter_val.length()));
	  double avg = (count > 0) ? (sum / (double) count) : 0;
	  return Double.toString (avg);
  }

  // ---
  // simple procedure: max 
  // ---
  public static String max_local (String[] orig_vals, String[] params)
  {
        double max = Double.MIN_VALUE;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
	   if (max < val)
             max = val;
        }
        return Double.toString (max);
  }
  public static String max_init (String orig_val, String[] params)
  {
	  if (orig_val != null &&
		  orig_val.equals(NULL_VALUE)) return NULL_VALUE;
        return ((orig_val!=null)?orig_val : Double.toString(Double.MIN_VALUE));
  }
  public static String max_compute (String[] inter_vals, String[] params)
  {
        double max = Double.MIN_VALUE;
        for (int ii=0; ii<inter_vals.length; ii++) {
			if (inter_vals[ii].equals(NULL_VALUE)) continue;
           double val = Double.parseDouble (inter_vals[ii]);
           if (max < val)
             max = val;
        }
        return Double.toString (max);
  }
  public static String max_final (String inter_val, String[] params)
  {
	  if (inter_val.equals(NULL_VALUE)) return NULL_VALUE;
        return inter_val;
  }

  // ---
  // simple procedure: min
  // ---
  public static String min_local (String[] orig_vals, String[] params)
  {
        double min = Double.MAX_VALUE;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
           if (min > val)
             min = val;
        }
        return Double.toString (min);
  }
  public static String min_init (String orig_val, String[] params)
  {
	  if (orig_val != null &&
		  orig_val.equals(NULL_VALUE)) return NULL_VALUE;
        return ((orig_val!=null)?orig_val:Double.toString(Double.MAX_VALUE));
  }
  public static String min_compute (String[] inter_vals, String[] params)
  {
        double min = Double.MAX_VALUE;
        for (int ii=0; ii<inter_vals.length; ii++) {
			if (inter_vals[ii].equals(NULL_VALUE)) continue;
           double val = Double.parseDouble (inter_vals[ii]);
           if (min > val)
             min = val;
        }
        return Double.toString (min);
  }
  public static String min_final (String inter_val, String[] params)
  {
	  if (inter_val.equals(NULL_VALUE)) return NULL_VALUE;
        return inter_val;
  }

  // ---
  // simple procedure: echoCount
  // ---
  public static String echoCount_local (String[] orig_vals, String[] params)
  {
	System.out.println ("----------");
	System.out.println ("echoCount:");

	System.out.print ("orig_vals(" + orig_vals.length + ")= ");
	for (int ii=0; ii<orig_vals.length; ii++) {
	   System.out.print (orig_vals[ii]);
	   if (ii != orig_vals.length-1)
	     System.out.print (",");
	}
	System.out.println ();

	if (params != null) {
	System.out.print ("params(" + params.length + ")= ");
	for (int ii=0; ii<params.length; ii++) {
	   System.out.print (params[ii]);
	   if (ii != params.length-1)
	     System.out.print (",");
	}
	System.out.println ();
	}

	System.out.println ("----------");

        return Integer.toString (orig_vals.length);
  }

  // ---
  // complex procedure: echoNodeCount
  // ---
  public static String echoNodeCount_local (NodeList orig_nodes, 
					    String[] params)
  {
        if (params != null) {
        System.out.print ("params(" + params.length + ")= ");
        for (int ii=0; ii<params.length; ii++) {
           System.out.print (params[ii]);
           if (ii != params.length-1)
             System.out.print (",");
        }
        System.out.println ();
        }

        return Integer.toString (orig_nodes.getLength());
  }

  // ---
  // complex procedure: fullpath
  // ---
  public static String fullpath_init (Node orig_node, String path, 
				      String[] params)
  {
        return path;
  }
  public static String fullpath_compute (String[] inter_vals, String[] params)
  {
	int num = inter_vals.length;
	if (num == 0) 
	  return null;
	else if (num == 1) 
	  return inter_vals[0];
	else {
	  StringBuffer sb = new StringBuffer ();
	  if (inter_vals[0]!=null)
	    sb.append (inter_vals[0]);
	  for (int ii=1; ii<num; ii++) 
	     if (inter_vals[ii] != null) {
	       sb.append (' '); sb.append (inter_vals[ii]);
	     }
	  return sb.toString();
	}
  }
  public static String fullpath_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: concat
  // ---
  public static String concat_local (String[] orig_vals, String[] params)
  {
	StringBuffer sb = new StringBuffer ();

	int num = orig_vals.length;
	for (int ii=0; ii<num; ii++)
	   if (orig_vals[ii] != null)
	     sb.append (orig_vals[ii]);

	num = params.length;
	for (int ii=0; ii<num; ii++)
	   if (params[ii] != null)
	     sb.append (params[ii]);

	return sb.toString ();
  }


	

	//----------
	// Complex procedure: MultiCall
	// Computes multiple aggregates over multiple attributes
	// Example call: (compute maximum load and average bw of the CMU nodes
	//    multiCall(/irisnetROOT/site[@id='cmu']/node, 'max:load avg:bw') 
	// author: suman
	// ---------
	
	public static final int MAX_ATTRS_IN_MULTICALL = 40; 
	public static String multiCall2_init (Node orig_node, String[] params)
	{
		int colon;
		String function, attr, value;
		StringBuffer retVal = new StringBuffer(1024);
		
		//System.out.println("Orignode: " + DOMProcessing.DOMtoXML(orig_node));
				
		for (int i = 0; i < params.length; i++) {
			colon = params[i].indexOf(':');
			function = params[i].substring(0, colon);
			attr = params[i].substring(colon+1);
			//System.out.println("Function: " + function + "Attr: " + attr);
			value = orig_node.getAttributes().getNamedItem(attr).getNodeValue();
			if (function.equalsIgnoreCase("avg")) {
				retVal.append(value + ",1");
			} else
				retVal.append(value);
			if (i < params.length-1) retVal.append(",");
		}
		return retVal.toString();
	}

	// intermediate result format:
	// v1,v2,...,vn
	// For Max, Min, and Sum, there is only one element per aggregate
	// For Average, there are two elements (sum,count) per aggregate
	public static String multiCall2_compute (String[] inter_vals, String[] params)
	{
		// temporary store to accumulate the intermediate results
		double[] temp = new double[MAX_ATTRS_IN_MULTICALL]; 

		// temporary store to accumulate the 2nd component fo the tuple
		// required for aggregates like "avg"
		int[] temp2 = new int[MAX_ATTRS_IN_MULTICALL]; 

		int i, j, colon, value2;
		StringTokenizer tokens;
		String[] functions = new String[MAX_ATTRS_IN_MULTICALL];
		String level, id, smallestID=null;
		double value1;

		//System.out.println("Intermediate values:");
		//for (i = 0; i < inter_vals.length; i++)
		//	System.out.println(inter_vals[i]);
		//System.out.println("*******************");

		// 1. initialize the functions array
		for (i = 0; i < params.length; i++){
			colon = params[i].indexOf(':');
			functions[i] = params[i].substring(0, colon);
		}

		// 2. process each of the input intermediate results
		for (i = 0; i < inter_vals.length; i++) {
			tokens = new StringTokenizer(inter_vals[i], " :,");	
			for (j = 0; tokens.hasMoreTokens();j++) {
				if (functions[j].equalsIgnoreCase("MAX")) {
					value1 = Double.parseDouble(tokens.nextToken());
					if (i == 0 || value1 > temp[i]) temp[j] = value1;
				} else if (functions[j].equalsIgnoreCase("MIN")) {
					value1 = Double.parseDouble(tokens.nextToken());
					if (i == 0 || value1 < temp[i]) temp[j] = value1;
				} else if(functions[j].equalsIgnoreCase("SUM")) {
					temp[j] += Double.parseDouble(tokens.nextToken());
				} else if (functions[j].equalsIgnoreCase("AVG")) {
					temp[j] += Double.parseDouble(tokens.nextToken());
					temp2[j] += Integer.parseInt(tokens.nextToken());
				} else {
					System.out.println("Unknown function");
					tokens.nextToken();
				}
			} // for loop; process the attributes in an intermediate results
		}// for loop; process each intermediate result

		// construct the intermediate result
		StringBuffer buf = new StringBuffer(1024);
		for (i = 0; i < params.length; i++) {
			if (functions[i].equalsIgnoreCase("AVG")) {
				buf.append(Double.toString(temp[i]) + "," + 
						   Integer.toString(temp2[i]));	
			} else
				buf.append(Double.toString(temp[i]));
			
			if (i < params.length -1)
				buf.append(",");
		}
		return buf.toString();
	}

	public static String multiCall2_final (String inter_val, String[] params)
	{
		String v1, v2;

		// the only task we need to do here is to process the AVG function
		StringBuffer retVal = new StringBuffer(1024);
		StringTokenizer tokens = new StringTokenizer(inter_val, " :,");
		
		for (int i = 0; i < params.length && tokens.hasMoreTokens(); i++) {
			v1 = tokens.nextToken();
			if (params[i].toUpperCase().startsWith("AVG")) {
				v2 = tokens.nextToken();
				retVal.append(Double.parseDouble(v1)/Double.parseDouble(v2));
			} else {
				retVal.append(v1);
			}
			if (i < params.length-1)
				retVal.append(",");
		} 
		//System.out.println("final: " + inter_val + " => " 
		//			   + retVal.toString());  
        return retVal.toString();
	}
	
	//------------
	// Complex Procedure: multiCall with groupBy
	// Supports arbitrary stored procedure call
	// Author: Suman
	// Example usage:
	//    multiCall(/irisnetROOT/site[@id='CMU']/node, 'GROUPBY name', 
	//                                       'myClass:sum load', 'avg bw')
	//    multicall(/irisnetROOT/site[@id='CMU']/node, 
	//                                       'myClass:sum load', 'avg bw')
	//--------------	

	// intermediate result has the following format:
	// group1:t1|t2|...|tn\ngroup2:t1|t2|...|tn
	// note that, ti can be of the form 'v'(sum), or 'v1,v2' (average) 

	public static final String GROUP_SEPERATOR = "=";
	public static final String TUPLE_SEPERATOR = "|";
	public static final String DEFAULT_GROUP = "$";
	public static final String NULL_GROUP = "%";
	public static final String NULL_VALUE = "NULL";
	
	public static String multiCall_init (Node orig_node, String[] params)
	{
		if (orig_node == null) {
			String response =  DEFAULT_GROUP + GROUP_SEPERATOR + NULL_VALUE;
			int i = 1;
			if (params[0].indexOf("GROUPBY") >=0) i++;
			for (;i< params.length; i++)
				response = response + TUPLE_SEPERATOR + NULL_VALUE;
			return response;
		}
		try {
			int seperator;
			String function, attr, value, className, method, initResult;
			StringBuffer retVal = new StringBuffer(1024);
			int i = 0;
			StringTokenizer tokens = new StringTokenizer(params[0], " ");
			if (tokens.nextToken().equalsIgnoreCase("GROUPBY")) {
				attr = tokens.nextToken();
				Node n =  orig_node.getAttributes().getNamedItem(attr);
				if (n != null)
					value = n.getNodeValue();
				else
					value = NULL_GROUP;
				retVal.append(value + GROUP_SEPERATOR);
				i++;
			} else {
				// no GROUPBY 
				retVal.append(DEFAULT_GROUP + GROUP_SEPERATOR); // dummy group
			}
			
			//System.out.println("Orignode: " + DOMProcessing.DOMtoXML(orig_node));
			
			String[] origVals = new String[1];
			String[] paramVals = new String[1];
			for (; i < params.length; i++) {
				seperator = params[i].indexOf(' ');
				function = params[i].substring(0, seperator);
				attr = params[i].substring(seperator+1);
				
				// get class and method name
				seperator = function.indexOf(':');
				if (seperator >=0) {
					className = function.substring(0, seperator);
					method = function.substring(seperator+1);
				} else {
					className = "com.intel.sensors.oa.SPBuiltIn";
					method = function;
				}
				SPInfo spinfo = SPUtils.getStoredProcedure(className, method);
				if (spinfo != null){
					NamedNodeMap nMap = orig_node.getAttributes();
					Node n = orig_node.getAttributes().getNamedItem(attr);
					if (n != null) {
						value = n.getNodeValue();
						origVals[0] = value;
						initResult = SPUtils.SPInitCompute(spinfo, origVals, paramVals);
					} else {
						initResult = NULL_VALUE;
					}
				} else {
					initResult = NULL_VALUE;
				}
				retVal.append(initResult);
				if (i < params.length-1) retVal.append(TUPLE_SEPERATOR);
			}
			return retVal.toString();
		} catch (Exception e) {
			return DEFAULT_GROUP + GROUP_SEPERATOR + NULL_VALUE;
		}
	}

	// intermediate result has the following format:
	// group1:t1|t2|...|tn\ngroup2:t1|t2|...|tn
	// note that, ti can be of the form 'v'(sum), or 'v1,v2' (average) 

	// This helper method assumes that all the tuples between tuples[i1]
	// to tuples[i2] are from the same group; 
	static String multiCall_compute_helper(ArrayList tuples, int i1, int i2, String[] params)
	{
		int start = 0, seperator, j;
		String interVals[][] = new String[params.length][i2-i1+1];
		StringTokenizer tokens;
		String function, className, method, computeResult;
		String paramVals[] = null;
		String t = (String)tuples.get(i1);
		String groupID = t.substring(0, t.indexOf(GROUP_SEPERATOR));
		if (!groupID.equals(DEFAULT_GROUP)) {
			start++; // the first parameter is the GROUPBY command
		}

		// seperate out the tuples
		for (int i = i1; i <=i2; i++) {
			tokens = new StringTokenizer((String)tuples.get(i), 
										 GROUP_SEPERATOR + 
										 TUPLE_SEPERATOR + "\n");
			groupID = tokens.nextToken(); // skip the groupID;
			j = 0;
			while (tokens.hasMoreTokens() && j < params.length) {
				interVals[j++][i-i1] = tokens.nextToken();
			}

			while (tokens.hasMoreTokens()) {
				System.out.println("???????? " + tokens.nextToken());
			}
		}

		// call the compute function
		StringBuffer retVal = new StringBuffer(1024);
		retVal.append(groupID + GROUP_SEPERATOR);
		for (int i = start; i < params.length; i++) {
			if (!interVals[i - start][0].equals(NULL_VALUE)) {
				seperator = params[i].indexOf(' ');
				function = params[i].substring(0, seperator);
				
				// get class and method name
				seperator = function.indexOf(':');
				if (seperator >=0) {
					className = function.substring(0, seperator);
					method = function.substring(seperator+1);
				} else {
					className = "com.intel.sensors.oa.SPBuiltIn";
					method = function;
				}
				SPInfo spinfo = SPUtils.getStoredProcedure(className, method);
				if (spinfo != null)
					computeResult = SPUtils.SPCompute(spinfo, interVals[i - start], paramVals);
				else
					computeResult = NULL_VALUE;
			} else { // init() returned NULL_VALUE
				computeResult = NULL_VALUE;
			}
			retVal.append(computeResult);
			if (i < params.length -1)
				retVal.append(TUPLE_SEPERATOR);
		}

		return retVal.toString();
	}

	public static String multiCall_compute (String[] inter_vals, String[] params)
	{
		ArrayList tuples = new ArrayList(100);
		int tupleCount = 0, i, j;
		StringTokenizer tokens;
		String group1, group2;
		StringBuffer retVal = new StringBuffer(1024);;

		try {
		// add the tuples to the arraylist in sorted order
		for (i = 0; i < inter_vals.length; i++) {
			tokens = new StringTokenizer(inter_vals[i], "\n");
			while (tokens.hasMoreTokens()) {
				String newTuple = tokens.nextToken();
				for (j = 0; j < tupleCount; j++) {
					String thisTuple = (String)tuples.get(j);
					if (thisTuple.compareToIgnoreCase(newTuple) > 0) break;
				}
				tuples.add(j, newTuple);
				tupleCount ++;
			}
		}

		// call helper for each group
		i = 0; 
		String t;
		while (i < tupleCount) {
			t = (String) tuples.get(i);
			group1 = t.substring(0, t.indexOf(GROUP_SEPERATOR));
			for (j = i+1; j < tupleCount; j++) {
				t = (String) tuples.get(j); 
				group2 = t.substring(0, t.indexOf(GROUP_SEPERATOR)); 
				if (!group1.equalsIgnoreCase(group2)) break;
			}
			retVal.append(multiCall_compute_helper(tuples, i, j-1, params));
			i = j;
			if (i < tupleCount)
				retVal.append("\n");
		}
		} catch (Exception e) {
			e.printStackTrace();
			for (int ii = 0; ii < inter_vals.length; ii++)
				System.out.println(inter_vals[ii]);
		}
		return retVal.toString();
	}

	public static String multiCall_final (String inter_val, String[] params)
	{
		int i, seperator, start;
		String line, function, method, className, finalResult, value;
		StringBuffer retVal = new StringBuffer(1024);
		StringTokenizer groups = new StringTokenizer(inter_val, "\n");
		String[] paramVals = null;

		// simple error check
		if (inter_val.indexOf(GROUP_SEPERATOR) <0) {
			System.out.println("Invalid response: " + inter_val);
			return inter_val;
		}
		try {
		//System.out.println("Final: " + inter_val);
		while (groups.hasMoreTokens()) {
			line = groups.nextToken();
			StringTokenizer tokens = new StringTokenizer(line, 
								 GROUP_SEPERATOR +
								 TUPLE_SEPERATOR +
								 "\n");
			String group = tokens.nextToken();
			if (group.equals(DEFAULT_GROUP)) 
				start = 0;
			else start = 1;

			retVal.append(group + GROUP_SEPERATOR);
			for (i = start; i<params.length; i++) {
				value = tokens.nextToken();
				if (!value.equals(NULL_VALUE)) {
					seperator = params[i].indexOf(' ');
					function = params[i].substring(0, seperator);
					// get class and method name
					seperator = function.indexOf(':');
					if (seperator >=0) {
						className = function.substring(0, seperator);
						method = function.substring(seperator+1);
					} else {
						className = "com.intel.sensors.oa.SPBuiltIn";
						method = function;
					}
					SPInfo spinfo = SPUtils.getStoredProcedure(className, method);
					if (spinfo != null)
						finalResult = SPUtils.SPFinal(spinfo, value, paramVals);
					else
						finalResult = NULL_VALUE;
				} else {
					finalResult = NULL_VALUE;
				}
				retVal.append(finalResult);
				if (i < params.length -1)
					retVal.append(TUPLE_SEPERATOR);
			}
			if (groups.hasMoreTokens())
				retVal.append("\n");
		}
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("inter_val:" + inter_val);
		}
		return retVal.toString();
	}
  // ------------------------------------------------------------------------
  // testing
  public static void main (String args[])
  {
	System.out.println ("local: " + min_local (args, null));
	String[] inter_vals = new String[args.length];
	for (int ii=0; ii<args.length; ii++) {
	   inter_vals[ii] = min_init (args[ii], null);
	   System.out.println ("init(" + args[ii] + ")=" + inter_vals[ii]);
	}
	String one = min_compute (inter_vals, null);
	System.out.println ("compute=" + one);

	System.out.println ("final=" + min_final (one, null));
  }

	
	//-----
	// SPs for evaluation
	//---- 
	
  // ----------------------------------------------------------------------
  // We implement 3 versions for each SP:
  //
  //   version 0:  local node
  //   version 1:  local string
  //   version 2:  init/compute/final
  //
  // ----------------------------------------------------------------------

  // ---
  // simple procedure: sum
  // ---
  // sum0(nodes, 'attr')
  public static String sum0_local (NodeList orig_nodes, String[] params)
  {
	if (params.length != 1) return "0";
	String attribute_name = params[0];

        double sum = 0.0;
	int num_nodes = orig_nodes.getLength ();
	for (int ii=0; ii<num_nodes; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
	   sum += Double.parseDouble (value);
	}
        return Double.toString (sum);
  }
  public static String sum1_local (String[] orig_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum2_init (String orig_val, String[] params)
  {
        return ((orig_val!=null)?orig_val:"0");
  }
  public static String sum2_compute (String[] inter_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<inter_vals.length; ii++) {
           double val = Double.parseDouble (inter_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum2_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: histogram
  //
  // Usage: histogram (values, 'slots')
  //
  //  slots is of the form: n_slots|slot0_upper_bound|slot1_upper_bound|...
  //                        ...|slot_(n-2)_upper_bound
  //  it returns: n_slots|slot0_count|slot1_count|...|slot_(n-1)_count
  // ---
  // histogram0(nodes, 'attr', 'slots')
  public static String histogram0_local (NodeList orig_nodes, String[] params)
  {
        if (params.length != 2) return "";
        String attribute_name = params[0];

        // get upper_bounds
        StringTokenizer st = new StringTokenizer (params[1], "|");
        int num_slots = Integer.parseInt (st.nextToken ());
        double[] upper_bounds = new double[num_slots-1];
        for (int ii=0; ii<num_slots-1; ii++) {
           upper_bounds[ii] = Double.parseDouble (st.nextToken());
        }

        // clear counts
        int[] counts = new int[num_slots];
        for (int ii=0; ii<num_slots; ii++)
           counts[ii] = 0;

        // count
	int num_nodes = orig_nodes.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
           double val = Double.parseDouble (value);
           int pos = Arrays.binarySearch(upper_bounds, val);
           if (pos < 0) pos = -pos-1;
           counts[pos] ++;
        }

        // output
        StringBuffer sb = new StringBuffer ();
        sb.append (num_slots);
        for (int ii=0; ii<num_slots; ii++) {
           sb.append ('|'); sb.append (counts[ii]);
        }

        return sb.toString ();
  }
  public static String histogram1_local (String[] orig_vals, String[] params)
  {
	if (params.length != 1) return "";

	// get upper_bounds
	StringTokenizer st = new StringTokenizer (params[0], "|");
	int num_slots = Integer.parseInt (st.nextToken ());
	double[] upper_bounds = new double[num_slots-1];
	for (int ii=0; ii<num_slots-1; ii++) {
	   upper_bounds[ii] = Double.parseDouble (st.nextToken());
	}

	// clear counts
	int[] counts = new int[num_slots];
	for (int ii=0; ii<num_slots; ii++)
	   counts[ii] = 0;

	// count
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
	   int pos = Arrays.binarySearch(upper_bounds, val);
	   if (pos < 0) pos = -pos-1;
	   counts[pos] ++;
        }

	// output
	StringBuffer sb = new StringBuffer ();
	sb.append (num_slots);
	for (int ii=0; ii<num_slots; ii++) {
	   sb.append ('|'); sb.append (counts[ii]);
	}

        return sb.toString ();
  }
  public static String histogram2_init (String orig_val, String[] params)
  {
        if (params.length != 1) return "";

        // get num_slots
        StringTokenizer st = new StringTokenizer (params[0], "|");
        int num_slots = Integer.parseInt (st.nextToken ());

	StringBuffer sb = new StringBuffer ();
	sb.append (num_slots);
	if (orig_val == null) {
          for (int ii=0; ii<num_slots; ii++)
             sb.append ("|0");
	}
	else {
	  double val = Double.parseDouble (orig_val);
	  int ii;
	  for (ii=0; ii<num_slots-1; ii++) {
	     double upper_bound = Double.parseDouble (st.nextToken());
	     if (val <= upper_bound)
	       break;
	  }
	  for (int jj=0; jj<ii; jj++)
             sb.append ("|0");
	  sb.append ("|1");
	  for (int jj=ii+1; jj<num_slots; jj++)
             sb.append ("|0");
	}

        return sb.toString ();
  }
  public static String histogram2_compute (String[] inter_vals, String[] params)
  {
	if (params.length != 1) return "";

	// get num_slots
        StringTokenizer st = new StringTokenizer (params[0], "|");
        int num_slots = Integer.parseInt (st.nextToken ());

        // clear counts
        int[] counts = new int[num_slots];
        for (int ii=0; ii<num_slots; ii++)
           counts[ii] = 0;

	for (int jj=0; jj<inter_vals.length; jj++) {
	   st = new StringTokenizer (inter_vals[jj], "|");
	   if (!st.hasMoreTokens() ||
	       (Integer.parseInt(st.nextToken()) != num_slots))
	     continue;
	   for (int ii=0; ii<num_slots; ii++)
	      counts[ii] += Integer.parseInt(st.nextToken());
        }

        // output
        StringBuffer sb = new StringBuffer ();
        sb.append (num_slots);
        for (int ii=0; ii<num_slots; ii++) {
           sb.append ('|'); sb.append (counts[ii]);
        }
  
        return sb.toString ();
  }
  public static String histogram2_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: median
  // ---
  // median0(nodes, 'attr')
  public static String median0_local (NodeList orig_nodes, String[] params)
  {
        if (params.length != 1) return "";
        String attribute_name = params[0];

        int num_values = orig_nodes.getLength ();
        double[] values = new double[num_values];

        for (int ii=0; ii<num_values; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
           values[ii] = Double.parseDouble (value);
        }

        Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }
  public static String median1_local (String[] orig_vals, String[] params)
  {
	int num_values = orig_vals.length;
	double[] values = new double[num_values];

        for (int ii=0; ii<num_values; ii++) {
           values[ii] = Double.parseDouble (orig_vals[ii]);
        }

	Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }
  public static String median2_init (String orig_val, String[] params)
  {
        return ((orig_val!=null)?("1|" + orig_val):"0");
  }
  public static String median2_compute (String[] inter_vals, String[] params)
  {
        int count = 0;
	int length = 0;
        for (int ii=0; ii<inter_vals.length; ii++) {
	   int index = inter_vals[ii].indexOf ('|');
	   if (index > 0) {
	     count += Integer.parseInt (inter_vals[ii].substring(0,index));
	     length += inter_vals[ii].length() - index;
	   }
        }
	StringBuffer sb = new StringBuffer (length+10);
	sb.append (count);
        for (int ii=0; ii<inter_vals.length; ii++) {
           int index = inter_vals[ii].indexOf ('|');
           if (index > 0) {
	     sb.append (
		inter_vals[ii].substring(index,inter_vals[ii].length()));
           }
        }
	
        return sb.toString ();
  }
  public static String median2_final (String inter_val, String[] params)
  {
	StringTokenizer st = new StringTokenizer (inter_val, "|");
	int num_values = Integer.parseInt (st.nextToken ());
	double[] values = new double[num_values];

	for (int ii=0; ii<num_values; ii++) {
           values[ii] = Double.parseDouble (st.nextToken ());
        }

        Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }

  // ---
  // simple procedure: nameFinder
  // ---
  // nameFinder0(nodes, 'name')
  public static String nameFinder0_local (NodeList orig_nodes, String[] params)
  {
	if (params.length != 1) return "";

	String name = params[0];
	int    len  = name.length ();
	String key1 = "," + name + ",";
	String key2 = name + ",";

        int num_nodes = orig_nodes.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
           Element n = (Element) orig_nodes.item (ii);
           String value = n.getAttribute("namelist");

	   int val_len = value.length ();
	   if (val_len < len) continue;

	   if ((value.indexOf(key1) > 0) || 
		value.startsWith (key2) ||
	        name.equals(value.substring(val_len-len, val_len))) {
	     return n.getAttribute("id");
	   }
        }
        return "";
  }
  public static String nameFinder2_init (Node orig_node, String[] params)
  {
	if (params.length != 1) return "";

	String name = params[0];
	int    len  = name.length ();

	Element n = (Element)orig_node;
	String value = n.getAttribute("namelist");

	int index = value.indexOf (name);
	if ((index == 0) || ((index > 0) && (value.charAt(index-1)==','))) {
	  index += len;
	  if ((index == value.length()) || (value.charAt(index)==','))
	    return n.getAttribute("id");
	}
        return "";
  }
  public static String nameFinder2_compute (String[] inter_vals, 
					    String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
	   if (inter_vals[ii].length() > 0)
	     return inter_vals[ii];
        return "";
  }
  public static String nameFinder2_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static String nameFinder3_init (Node orig_node, String[] params)
  {
        if (params.length != 1) return "";

        String name = params[0];
        int    len  = name.length ();

        Element n = (Element)orig_node;
        String value = n.getAttribute("namelist");

        int index = value.indexOf (name);
        if ((index == 0) || ((index > 0) && (value.charAt(index-1)==','))) {
          index += len;
          if ((index == value.length()) || (value.charAt(index)==','))
            return n.getAttribute("id");
        }
        return "";
  }
  public static String nameFinder3_compute (String[] inter_vals,
                                            String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
           if (inter_vals[ii].length() > 0)
             return inter_vals[ii];
        return "";
  }
  public static String nameFinder3_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static boolean nameFinder3_prune (String inter_val, String[] params)
  {
        return ((inter_val!=null) && (inter_val.length() > 0));
  }


	/*
  // debug
  public static void main (String argv[])
  {

//	String[] params= new String[1];
//	params[0] = "3|5|10";
//	for (int ii=0; ii<argv.length; ii++)
//	   argv[ii] = histogram2_init (argv[ii], params);
//	System.out.println (histogram2_compute(argv, params));

	for (int ii=0; ii<argv.length; ii++)
           argv[ii] = median2_init (argv[ii], null);
	System.out.println (median2_final(median2_compute(argv, null), null));
  }
*/

} // SPBuiltIn
