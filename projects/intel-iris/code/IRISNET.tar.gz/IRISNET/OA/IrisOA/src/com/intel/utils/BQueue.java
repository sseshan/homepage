package com.intel.utils;

import java.util.*;

/*
 * This is a thread-safe queue that blocks automatically if you
 *	try to dequeue from an empty queue. 
 *
 * <br><br>
 *
 */

public final class BQueue
{
    private LinkedList queue = new LinkedList();
    private int	maxSize = Integer.MAX_VALUE;

    // admission control fralgs
    private boolean closed = false;
    private boolean rejectEnqueueRequests = false;

    // number of threads trying to dequeue 
    private int	 numWaitingThreads = 0;

    // timeout statics
    public static final long FOREVER = Long.MAX_VALUE;

    //-----------------------------------
    // Custom exception classes
    // ----------------------------------
    public class Exception extends RuntimeException
    {       public Exception(String s){ super(s); }
    }
    public class Closed extends Exception
    {       
	private Closed()
	{       
	    super("Tried to access closed BQueue");
	}
    }
    public class Full extends Exception
    {       
	private Full()
	{       
	    super("Attempt to enqueue item to full BQueue");
	}
    }
    public class Timedout extends Exception
    {       
	private Timedout(String s)
	{       
	    super(s);
	}
    }


    // -------------------
    // Constructors
    // -------------------
    /*
     * Constructs a queue with no upper limit on the queue size.
     */ 
    public BQueue(){}
    
    
    /*
     * Constructs a queue with the maximum queue size given by 
     * the indicated maximum number of elements.
     */
    public BQueue( int maxSize )
    {	
	this.maxSize = maxSize;
    }
    

    public synchronized final int size() {
	return queue.size();
    }

    // --------------------------------------------------
    // Operation enqueue: Enters an element to the queue
    // Optional parameters to be specifiec:
    //        Timeout: max time an element will be in the queue
    //                    after which it will be removed
    //                    if it is not dequeued by anyone
    //        RemovalCallback: callback function to call
    //                    on timeout of an element
    // --------------------------------------------------

    /*
     * Enqueue an object that will remain in the queue until it is
     * dequeued.
     */
    public synchronized final void enqueue( Object newElement )
	throws Full, Closed
    {	
	if ( closed || rejectEnqueueRequests )
	    throw new Closed();
    
	// Detect a full queue. Queues of size 0 are allowed to grow
	// indefinitely.

	if ( queue.size() >= maxSize )
	    throw new Full();
	
	queue.addLast( newElement );
	notify(); // notify the waiting threads 
    }

    // enqueue even if the queue is full or closed (force = true)
    public synchronized final void enqueue( Object newElement, 
					    boolean force)
	throws Full, Closed
    {
	if (force) {
	    queue.addLast(newElement);
	    notify();
	} else
	    enqueue(newElement);
    }

    /*
     *	Enqueue an object that will remain in the queue for at most
     *	"timeout" milliseconds. The <code>run()</code> method of the
     *	<code>removeCallback</code> object is called if the object is
     *	removed in this way.
     *
     *	If a given object is in the queue more than once, then the first
     *	occurrence of the object is removed.
     *
     * @param newElement The object to enqueue
     * @param timeout     The maximum time that the object will spend
     *			  in the queue (subject to the usual variations
     *			  that can occur if a higher-priority thread
     *			  happens to be running when the timeout occurs).
     * @param removeCallback  If non-null, the <code>run()</code> method
     *			  is called if the object is removed due to
     *			  a timeout. If <code>null</code>, nothing
     *			  in particular is done when the object is
     *			  removed.
     */

    //#enqueue.with.timeout
    public synchronized final void enqueue( final Object   newElement,
					    final long	   timeout,
					    final Runnable removeCallback )
    {
	enqueue( newElement );
	
	// start a new thread to remove the element on timeout
	new Thread() {
	    { setDaemon(true); }	
	    // a constructor for this object.
	    public void run() {
	    	try {
		    boolean stillInQueue;
		    sleep( timeout );
		    synchronized( BQueue.this ) {
			stillInQueue = queue.remove( newElement );
			
			if( stillInQueue && (queue.size()==0)
			    && rejectEnqueueRequests ) {
			    close(); // Have just removed final item,
			}
		    }
		    
		    if( stillInQueue && removeCallback != null )
			removeCallback.run();
		}
		catch( InterruptedException e ){ /* can't happen */ }
	    }
	}.start();
    }
    
    /*
     * Convenience method, calls {@link enqueue(Object,long,Runnable)} with
     * a null <code>removeCallback</code> reference.
     */
    
    public synchronized final void enqueue( final Object newElement,
					    final long	 timeout )
    {	
	enqueue( newElement, timeout, null );
    }

    /*
     * Enqueue an item, and thereafter reject any requests to enqueue
     * additional items. The queue is closed automatically when the
     * final item is dequeued.
     */
    
    public synchronized final void enqueueFinalItem( Object lastElement )
	throws Full, Closed
    {	
	enqueue( lastElement );
	rejectEnqueueRequests = true;
    }														
    //-------------------------------------------------------
    // Operation dequeue: removes an element from the queue
    // the calling thread is blocked until an element is available
    // Optional parameter: 
    //         Timeout: max time to wait for an element to be available
    //--------------------------------------------------------
    /*
     *	Dequeues an element; blocks if the queue is empty
     *	(until something is enqueued). 
     * You must ensure that
     *	there's a way to get something into the queue that does
     *  not involve calling a synchronized method of whatever
     *  class is blocked, waiting to dequeue something.
     *
     *	@param timeout	Time-out value in milliseconds. An
     *			<code>ArithmeticException</code> is thrown
     *			if this value is greater than a million years
     *		        or so.
     *
     *  @see #enqueue
     *
     *	@return the dequeued object or null if the wait timed out and
     *			nothing was dequeued.
     *
     *  @throws InterruptedException	if interrupted while blocked
     *  @throws BQueue.Timedout	if timed out while blocked
     *  @throws BQueue.Closed	        on attempt to dequeue from a 
     *                                  closed queue.
     */
    
    public synchronized final Object dequeue( long timeout ) 
	throws InterruptedException,
	Closed,
	Timedout
    {	
	if( closed )
	    throw new Closed();
	try{
	    // If the queue is empty, wait. I've put the spin lock
	    // inside an "if" so that the numWaitingThreads count doesn't
	    // jitter while inside the spin lock. A thread is not
	    // considered to be done waiting until it's actually
	    // acquired an element or the timeout is exceeded.
	    //
	    //
	    long expiration = (timeout == FOREVER)
		? FOREVER
		: System.currentTimeMillis() + timeout;
	    ;
	    
	    if( queue.size() <= 0 ){	
		++numWaitingThreads;			 
		while( queue.size() <= 0 ) {
		    wait( timeout );		   
		    
		    if( System.currentTimeMillis() > expiration ) {
			--numWaitingThreads;	
			throw new Timedout(
					   "Timed out waiting to dequeue " +
					   "from BQueue" );
		    }
		    
		    if( closed ) {
			--numWaitingThreads;
			throw new Closed();
		    }
		}
		--numWaitingThreads;			    
	    }
	    
	    Object head = queue.removeFirst();
	    
	    if( queue.size() == 0 && rejectEnqueueRequests )
		close(); // just removed final item, close the queue.
	    
	    return head;
	}
	catch( NoSuchElementException e ) {	// Shouldn't happen
	    throw new Error(
			    "Internal error (com.intel.utils.BQueue)");
	}
    }
    /*
     * Convenience method, calls {@link dequeue(long)} with a timeout of
     * FOREVER.
     */
    
    public synchronized final Object dequeue()
	throws InterruptedException,
	Closed,
	Timedout
    {	
	return dequeue( FOREVER );
    }
	
    public synchronized final boolean isEmpty()
    {	return queue.size() <= 0;
    }
    
    /******
     * Return the number of threads waiting for a message on the
     * current queue. 
     */
    
    public final synchronized int numWaitingThreads()
    {	return numWaitingThreads;
    }
    
    
    /*
     * Close the blocking queue. All threads that are blocked
     * [waiting in dequeue() for items to be enqueued] are released.
     */
    public synchronized void close()
    {	
	closed 	 = true;
	queue = null;
	notifyAll();
    }
    
    // ----------------------------------------------------
    // instance methods for apps requiring only one BQueue
    // ----------------------------------------------------
    public static BQueue INSTANCE = null;

    public static void createInstance(int length)
    {
	INSTANCE = new BQueue(length);
    }
    public static BQueue instance() {
	if (INSTANCE == null) {
	    System.out.println("NULL BQueue Instance." +
			       " Creating one with length 100");
	    createInstance(100);
	}

	return INSTANCE;
    }
    
}
