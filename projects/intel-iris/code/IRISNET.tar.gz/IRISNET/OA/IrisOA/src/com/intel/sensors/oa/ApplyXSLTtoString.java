/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

// Imported TraX classes
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMResult;

import org.xml.sax.InputSource;

import org.w3c.dom.Document;
import org.apache.xindice.xml.dom.DocumentImpl;

// Imported java.io classes
import java.io.FileOutputStream;
import java.io.IOException;	
import java.io.StringReader;
import java.io.StringWriter;

/**
 *  Very basic utility for applying an XSLT epxression to a String.
 *  Takes 2 arguments:
 *     (1) a String that represents an XML document.
 *     (2) an XSLT expression to apply to the string.
 *
 *   Can be later modified to directly work on DOM's as well.
 *
 *  @author Xalan Development Team
 *  @author Amol
 */
public class ApplyXSLTtoString
{
    public static String applyXSLTToString(String XMLDocument, String xsltQuery) throws TransformerException, TransformerConfigurationException {
        StringWriter output = new StringWriter();
        Log.logToStdOut();
        try {	
            TransformerFactory tFactory = TransformerFactory.newInstance();
            StreamSource in = new StreamSource(new StringReader(XMLDocument));
            StreamSource in2 = new StreamSource(new StringReader(xsltQuery));
            StreamResult out = new StreamResult(output);
            Log.Debug("");
            Transformer transformer = tFactory.newTransformer(in2);
            Log.Debug("");

            Utils.printClassName(transformer);

            org.apache.xalan.transformer.TransformerImpl ti = 
                (org.apache.xalan.transformer.TransformerImpl) transformer;

            Object o = ti.getStylesheet();

            Utils.printClassName(o);

            System.exit(1);

            // Document doc = new DocumentImpl();
            // DOMResult dr = new DOMResult(doc);
            // transformer.transform(in, dr);
            // System.out.println(doc.getClass().getName());
            // System.out.println(doc.toString());

            transformer.transform(in, out);
            Log.Debug("");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return output.toString();
    }

    public static void main(String args[]) {

        // String xsltQuery = "<xsl:transform version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"> <xsl:param name=\"template-uri\" /> <xsl:variable name=\"template\" select=\"document($template-uri)\" /> <xsl:variable name=\"source\" select=\"/\" /> <xsl:template match=\"/\"> <xsl:apply-templates select=\"$template/node()\" /> </xsl:template> <xsl:template match=\"*\"> <xsl:element name=\"{name()}\"> <xsl:apply-templates select=\"@* | node()\" /> </xsl:element> </xsl:template> <xsl:template match=\"@*\"> <xsl:attribute name=\"{name()}\"> <xsl:value-of select=\".\" /> </xsl:attribute> </xsl:template> <xsl:template match=\"text()\"> <xsl:if test=\"normalize-space()\"> <xsl:value-of select=\".\" /> </xsl:if> </xsl:template></xsl:transform>";
        String xsltQuery = "<xsl:transform version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"> <xsl:template match=\"*\"> <xsl:element name=\"{name()}\"> <xsl:apply-templates select=\"@* | node()\" /> </xsl:element> </xsl:template> <xsl:template match=\"@*\"> <xsl:attribute name=\"{name()}\"> <xsl:value-of select=\".\" /> </xsl:attribute> </xsl:template> <xsl:template match=\"text()\"> <xsl:value-of select=\".\" /> </xsl:template></xsl:transform>";
        String xpathQuery = "/static/usRegion/state[@id='CA']/";
        try {
            String convertedXSLTQuery = (String) QueryAnalysis.findXSLTQuery(xpathQuery, true)[0];
            System.out.println(convertedXSLTQuery);
            String xmldocument = "<static> <usRegion id=\"NE\" owner-agent=\"101\"> <state id=\"PA\" owner-agent=\"201\"> </state> </usRegion> </static>";
            System.out.println(applyXSLTToString(xmldocument, convertedXSLTQuery).toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
