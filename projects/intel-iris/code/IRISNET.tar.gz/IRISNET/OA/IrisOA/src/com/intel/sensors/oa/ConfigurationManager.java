/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class manages the OA configuration.  It maintains default 
 * settings for values not set in the configuration files and 
 * updates those settings based on the configuration file. <p>
 *
 * Currently, the configurable properties are read from the configuration
 * file. Each line in the configuration file defines one property and takes the form:
 * 'key=value'.
 * To add a new configurable property (key), follow the steps below:<p>
 *
 * <ol>
 *    <li> Define a private variable for that key, and initialize it with 
 *         the default value. For example: <p>
 *               private static String DATABASE = "nodatabase";<p>
 *    <li> Define the mutator and accessor methods for that variable. The mutator
 *         function should check the sanity of the value.<p>
 *    <li> Add the corresponding "if" statement in the loadConfig() method, 
 *         and "print" statement in the printConfig() method. 
 * </ol><p>
 */

public class ConfigurationManager{
	private static String
		VERSION = "1.0",
		DBINTERFACE = "xindice", 

		DATABASE = "nodatabase",
		DNS_SUFFIX="dsan.net",
		DNS_SERVER="default",

		// Logger server runs at LOG_IP:LOG_PORT
		LOG_IP = "0.0.0.0",
		LOG_PORT = "5678",
		
		// Sometimes OA cannot automatically retrieve local IP, 
		// in those cases we provide the local IP in the configuration file 
		LOCAL_IP="0.0.0.0",

		// HeartBeat server runs at HB_IP:HB_PORT
		HB_IP = "0.0.0.0",
		HB_PORT = "2345",

		// HTTP Document Root
		HTTP_DOC_ROOT = ".";

	private static int
		OA_PORT = 6789,
		SA_PORT = 3456,

		// HeartBeat period
		HB_PERIOD = 20,
		MAX_QUERIES = 1024,

		// socket timeout
		TIMEOUT = 1500, /* socket timeouts, milliseconds*/

		// query timeout
		QTIMEOUT = 30000, /* 30 seconds */
		// DNS related constants
		DNS_TTL = 10*60, /* seconds */
		
		// HTTP Port
		HTTP_PORT = 0;

	private static ArrayList sp_url_list = null;
	private static String[]  sp_urls = null;

	// mutator for DATABSE
	public void setDatabase(String _db) {
		DATABASE = _db;
	}
	
	// accessor for DATABASE
	public String getDatabase() {
		return DATABASE;
	}

	public void setDBInterface(String dbi) {
		DBINTERFACE = dbi;
	}

	public String getDBInterface() {
		return DBINTERFACE;
	}
	
    public void setVersion(String v) {
        VERSION = v;
    }

    public String getVersion() {
        return VERSION;
    }


	public void setDNSSuffix(String _suffix) {
		// TODO: add sanity check
		DNS_SUFFIX = _suffix;
	}
	
	public String getDNSSuffix() {
		return DNS_SUFFIX;
	}

	public void setDNSServer(String _server) {
		// TODO: add sanity check
		DNS_SERVER = _server;
	}
	
	public String getDNSServer() {
		return DNS_SERVER;
	}

	public void setLogIP(String _IP) {
		// TODO: add sanity check
		LOG_IP = _IP;
	}
	
	public String getLogIP() {
		return LOG_IP;
	}

	public void setLogPort(String _port) {
		// TODO: add sanity check
		LOG_PORT = _port;
	}
	
	public String getLogPort() {
		return LOG_PORT;
	}

	public void setDNSTTL(String _ttl) {
		// TODO: add sanity check
		DNS_TTL = Integer.parseInt(_ttl);
	}
	
	public int getDNSTTL() {
		return DNS_TTL;
	}

	
	public void setHBIP(String _ip) {
		// TODO: add sanity check
		HB_IP = _ip;
	}
	
	public String getHBIP() {
		return HB_IP;
	}

	public void setHBPort(String _port) {
		// TODO: add sanity check
		HB_PORT = _port;
	}
	
	public String getHBPort() {
		return HB_PORT;
	}
	
	private String _getLocalIP() {
		try {
			String hostname = InetAddress.getLocalHost().getHostName();
			InetAddress[] ads = InetAddress.getAllByName(hostname);
			String IP;
			for (int i=0; i<ads.length; i++) {
				IP = ads[i].getHostAddress();
				// System.out.println(IP);
				if (!IP.equals("127.0.0.1"))
					return IP;
			}
		} catch (IOException ex) {
                    ex.printStackTrace();
                    // System.exit(1);
                    return new String("127.0.0.1");
		}
		return "127.0.0.1";
	}

	public void setLocalIP(String _ip) {
		String _tmpip;
		if ( ( !_ip.equals(_tmpip = _getLocalIP())) && (!_tmpip.equals("127.0.0.1"))) {
			System.out.println("WARNING (ConfigurationManager): Using local IP " + _ip + " from the configuration file, although it seems to be " + _tmpip);
		}
		LOCAL_IP = _ip;
	}

	public String getLocalIP() {
		return LOCAL_IP;
	}

	public void setOAPort(String _port) {
		// TODO: add sanity check
		OA_PORT = Integer.parseInt(_port);
	}
	
	public int getOAPort() {
		return OA_PORT;
	}

	public void setTimeOut(String _timeOut) {
		TIMEOUT = Integer.parseInt(_timeOut);
	}
	
	public int getTimeOut() {
		return TIMEOUT;
	}
	
	public void setQTimeOut(String _timeOut) {
        QTIMEOUT = Integer.parseInt(_timeOut);
    }

    public int getQTimeOut() {
        return QTIMEOUT;
    }


	public void setSAPort(String _port) {
		// TODO: add sanity check
		SA_PORT = Integer.parseInt(_port);
	}
	
	public int getSAPort() {
		return SA_PORT;
	}
	
	public void setHBPeriod(String _period) {
		// TODO: add sanity check
		HB_PERIOD = Integer.parseInt(_period);
	}
	
	public int getHBPeriod() {
		return HB_PERIOD;
	}

	public void setMaxQueries( int _max) {
		MAX_QUERIES = _max;
	}

	public int getMaxQueries() {
		return MAX_QUERIES;
	}


	public void setHTTPPort(String port)
	{
		HTTP_PORT = Integer.parseInt(port);
	}

	public int getHTTPPort() {
		return HTTP_PORT;
	}

	public void setHTTPDocRoot(String root) {
		HTTP_DOC_ROOT = root;
	}

	public String getHTTPDocRoot() {
		return HTTP_DOC_ROOT;
	}

	// added by Shimin: urls to load stored procedures from
	public void addSpUrl (String url) {
	  	if (url != null) {
		  if (sp_url_list == null)
		    sp_url_list = new ArrayList ();
		  sp_url_list.add (url);
		  sp_urls = null;
	  	}
	}

	public String[] getSpUrls () {
		if (sp_urls == null) {
		  if (sp_url_list != null) {
		    sp_urls = new String[sp_url_list.size()];
		    for (int ii=0; ii<sp_url_list.size(); ii++)
		       sp_urls[ii] = (String) sp_url_list.get (ii);
		  }
		  else {
		    sp_urls = new String[1];
		    sp_urls[0] = "file:///tmp/test";
		  }
		}
		return sp_urls;
	}

	ConfigurationManager() {
		loadConfiguration("oa.cfg"); // default conf file
	}

	ConfigurationManager(String fName) {
		loadConfiguration(fName);
	}

	public void loadConfiguration(String fName)
	{
		String _line = "", key = "", value = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(fName));
			while((_line = br.readLine()) != null) {
				_line.trim();
				if (_line.length() == 0) continue;
				if (_line.startsWith("#")) continue;
				StringTokenizer st = new StringTokenizer(_line, "=");
				key = st.nextToken();
				value = st.nextToken();
				if (key.equalsIgnoreCase("oa port")) {
					setOAPort(value);
				} else if (key.equalsIgnoreCase("sa port")) {
					setSAPort(value);
				} else if (key.equalsIgnoreCase("dns suffix")) {
					setDNSSuffix(value);
				} else if (key.equalsIgnoreCase("dns server")) {
					setDNSServer(value);
				} else if (key.equalsIgnoreCase("log server")) {
					setLogIP(value);
				} else if (key.equalsIgnoreCase("log port")) {
					setLogPort(value);
				} else if (key.equalsIgnoreCase("database")) {
					setDatabase(value);
				} else if (key.equalsIgnoreCase("heartbeat server")){
					setHBIP(value);
				} else if (key.equalsIgnoreCase("heartbeat port")){
					setHBPort(value);
				} else if (key.equalsIgnoreCase("heartbeat period")) {
					setHBPeriod(value);
				} else if (key.equalsIgnoreCase("localip")) {
					setLocalIP(value);
				} else if (key.equalsIgnoreCase("timeout")) {
					setTimeOut(value);
				} else if (key.equalsIgnoreCase("query timeout")) {
                    setQTimeOut(value);
                } else if (key.equalsIgnoreCase("dns ttl")) {
					setDNSTTL(value);
				} else if (key.equalsIgnoreCase("sp url")) {
					addSpUrl(value);
				} else if (key.equalsIgnoreCase("version")) {
					setVersion(value);
				} else if (key.equalsIgnoreCase("dbInterface")) {
					setDBInterface(value);
				} else if (key.equalsIgnoreCase("http port")) {
					setHTTPPort(value);
				} else if (key.equalsIgnoreCase("http docroot")) {
					setHTTPDocRoot(value);
				}

				else {
					System.out.println("WARNING (ConfigurationManager): Attribute " + key +" Not recognized. ");  
				}
			} 
		} catch (Exception e) {
			System.err.println(e);
			System.err.println("Error in loading configuration file: " + fName + "Line:" + _line + ", key:" + key + ", value:" + value);
		}
		
	}


	public void printConfiguration()
	{
		System.out.println("============================");
		System.out.println("The OA is using the following configuration: ");
		if (LOCAL_IP != "127.0.0.1")
			System.out.print("OA IP: " + LOCAL_IP + ",");
		System.out.println("Protocol.IP = " + Protocol.getLocalIP());
		System.out.println("OA Port: " + OA_PORT);
		System.out.println("DNS server: " + DNS_SERVER);
		System.out.println("Socket timeout: " + TIMEOUT + " ms, Query timeout: " + QTIMEOUT + " ms");

		if (HB_IP != "0.0.0.0")
			System.out.println("Heartbeat Server: " + HB_IP+":" + HB_PORT);
		if (DATABASE != "nodatabase")
			System.out.println("Database: " + DATABASE);
		if (LOG_IP != "0.0.0.0")
			System.out.println("Log Server: " + LOG_IP + ":" + LOG_PORT);

		String[] urls = getSpUrls ();
		System.out.println ("Sp URLs:");
		for (int ii=0; ii<urls.length; ii++)
		   System.out.println ("\t" + urls[ii]);

		if (getHTTPPort() != 0) 
			System.out.println("HTTP port: " + getHTTPPort() + 
							   ", Document Root: " + getHTTPDocRoot());

		System.out.println("============================");
	}
	
	/**
	 * Set up the manager instance to follow the singleton pattern.
	 */
	private static final ConfigurationManager INSTANCE = new ConfigurationManager();
	
	public static ConfigurationManager instance() {
		return INSTANCE;
	}

	/*
	public static void main(String args[]) throws Exception
	{
		if(args.length != 1) {
			System.err.println("Usage: OA <config-file>");
			System.exit(1);
		}
		
		//int portNumber = Integer.parseInt(args[0]);
		//Globals.OA_PORT = Protocol.myPortNumber = portNumber;
		
		loadConfiguration(args[0]);
		printConfiguration();
	}
	*/
}
