From chensm@cs.cmu.edu Thu Nov  6 21:30:41 2003
Date: Wed, 05 Nov 2003 20:54:28 -0500
From: Shimin Chen <chensm@cs.cmu.edu>
To: Suman Nath <sknath@cs.cmu.edu>
Subject: local+tree

Hi Suman,

I have attached my implementation of sum, histogram and median.
Each has three different versions.

Regards,
Shimin
-- 
   ------------------------------------------------------------
    Shimin Chen                     fifth year PhD student

    Computer Science Department     Office:  WeH 8019
    Carnegie Mellon University      Phone:   (412)268-5143 (o)
    5000 Forbes Ave.                         (412)682-1529 (h)
    Pittsburgh, PA 15213-3891       Email:   chensm+@cs.cmu.edu
   -------------------------------------------------------------

    [ Part 2: "Attached Text" ]

import java.util.*;
import org.w3c.dom.*;

public class MySP {

  // ----------------------------------------------------------------------
  // We implement 3 versions for each SP:
  //
  //   version 0:  local node
  //   version 1:  local string
  //   version 2:  init/compute/final
  //
  // ----------------------------------------------------------------------

  // ---
  // simple procedure: sum
  // ---
  // sum0(nodes, 'attr')
  public static String sum0_local (NodeList orig_nodes, String[] params)
  {
	if (params.length != 1) return "0";
	String attribute_name = params[0];

        double sum = 0.0;
	int num_nodes = orig_nodes.getLength ();
	for (int ii=0; ii<num_nodes; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
	   sum += Double.parseDouble (value);
	}
        return Double.toString (sum);
  }
  public static String sum1_local (String[] orig_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum2_init (String orig_val, String[] params)
  {
        return ((orig_val!=null)?orig_val:"0");
  }
  public static String sum2_compute (String[] inter_vals, String[] params)
  {
        double sum = 0.0;
        for (int ii=0; ii<inter_vals.length; ii++) {
           double val = Double.parseDouble (inter_vals[ii]);
           sum += val;
        }
        return Double.toString (sum);
  }
  public static String sum2_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: histogram
  //
  // Usage: histogram (values, 'slots')
  //
  //  slots is of the form: n_slots|slot0_upper_bound|slot1_upper_bound|...
  //                        ...|slot_(n-2)_upper_bound
  //  it returns: n_slots|slot0_count|slot1_count|...|slot_(n-1)_count
  // ---
  // histogram0(nodes, 'attr', 'slots')
  public static String histogram0_local (NodeList orig_nodes, String[] params)
  {
        if (params.length != 2) return "";
        String attribute_name = params[0];

        // get upper_bounds
        StringTokenizer st = new StringTokenizer (params[1], "|");
        int num_slots = Integer.parseInt (st.nextToken ());
        double[] upper_bounds = new double[num_slots-1];
        for (int ii=0; ii<num_slots-1; ii++) {
           upper_bounds[ii] = Double.parseDouble (st.nextToken());
        }

        // clear counts
        int[] counts = new int[num_slots];
        for (int ii=0; ii<num_slots; ii++)
           counts[ii] = 0;

        // count
	int num_nodes = orig_nodes.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
           double val = Double.parseDouble (value);
           int pos = Arrays.binarySearch(upper_bounds, val);
           if (pos < 0) pos = -pos-1;
           counts[pos] ++;
        }

        // output
        StringBuffer sb = new StringBuffer ();
        sb.append (num_slots);
        for (int ii=0; ii<num_slots; ii++) {
           sb.append ('|'); sb.append (counts[ii]);
        }

        return sb.toString ();
  }
  public static String histogram1_local (String[] orig_vals, String[] params)
  {
	if (params.length != 1) return "";

	// get upper_bounds
	StringTokenizer st = new StringTokenizer (params[0], "|");
	int num_slots = Integer.parseInt (st.nextToken ());
	double[] upper_bounds = new double[num_slots-1];
	for (int ii=0; ii<num_slots-1; ii++) {
	   upper_bounds[ii] = Double.parseDouble (st.nextToken());
	}

	// clear counts
	int[] counts = new int[num_slots];
	for (int ii=0; ii<num_slots; ii++)
	   counts[ii] = 0;

	// count
        for (int ii=0; ii<orig_vals.length; ii++) {
           double val = Double.parseDouble (orig_vals[ii]);
	   int pos = Arrays.binarySearch(upper_bounds, val);
	   if (pos < 0) pos = -pos-1;
	   counts[pos] ++;
        }

	// output
	StringBuffer sb = new StringBuffer ();
	sb.append (num_slots);
	for (int ii=0; ii<num_slots; ii++) {
	   sb.append ('|'); sb.append (counts[ii]);
	}

        return sb.toString ();
  }
  public static String histogram2_init (String orig_val, String[] params)
  {
        if (params.length != 1) return "";

        // get num_slots
        StringTokenizer st = new StringTokenizer (params[0], "|");
        int num_slots = Integer.parseInt (st.nextToken ());

	StringBuffer sb = new StringBuffer ();
	sb.append (num_slots);
	if (orig_val == null) {
          for (int ii=0; ii<num_slots; ii++)
             sb.append ("|0");
	}
	else {
	  double val = Double.parseDouble (orig_val);
	  int ii;
	  for (ii=0; ii<num_slots-1; ii++) {
	     double upper_bound = Double.parseDouble (st.nextToken());
	     if (val <= upper_bound)
	       break;
	  }
	  for (int jj=0; jj<ii; jj++)
             sb.append ("|0");
	  sb.append ("|1");
	  for (int jj=ii+1; jj<num_slots; jj++)
             sb.append ("|0");
	}

        return sb.toString ();
  }
  public static String histogram2_compute (String[] inter_vals, String[] params)
  {
	if (params.length != 1) return "";

	// get num_slots
        StringTokenizer st = new StringTokenizer (params[0], "|");
        int num_slots = Integer.parseInt (st.nextToken ());

        // clear counts
        int[] counts = new int[num_slots];
        for (int ii=0; ii<num_slots; ii++)
           counts[ii] = 0;

	for (int jj=0; jj<inter_vals.length; jj++) {
	   st = new StringTokenizer (inter_vals[jj], "|");
	   if (!st.hasMoreTokens() ||
	       (Integer.parseInt(st.nextToken()) != num_slots))
	     continue;
	   for (int ii=0; ii<num_slots; ii++)
	      counts[ii] += Integer.parseInt(st.nextToken());
        }

        // output
        StringBuffer sb = new StringBuffer ();
        sb.append (num_slots);
        for (int ii=0; ii<num_slots; ii++) {
           sb.append ('|'); sb.append (counts[ii]);
        }
  
        return sb.toString ();
  }
  public static String histogram2_final (String inter_val, String[] params)
  {
        return inter_val;
  }

  // ---
  // simple procedure: median
  // ---
  // median0(nodes, 'attr')
  public static String median0_local (NodeList orig_nodes, String[] params)
  {
        if (params.length != 1) return "";
        String attribute_name = params[0];

        int num_values = orig_nodes.getLength ();
        double[] values = new double[num_values];

        for (int ii=0; ii<num_values; ii++) {
	   Element n = (Element) orig_nodes.item (ii);
	   String value = n.getAttribute(attribute_name);
           values[ii] = Double.parseDouble (value);
        }

        Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }
  public static String median1_local (String[] orig_vals, String[] params)
  {
	int num_values = orig_vals.length;
	double[] values = new double[num_values];

        for (int ii=0; ii<num_values; ii++) {
           values[ii] = Double.parseDouble (orig_vals[ii]);
        }

	Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }
  public static String median2_init (String orig_val, String[] params)
  {
        return ((orig_val!=null)?("1|" + orig_val):"0");
  }
  public static String median2_compute (String[] inter_vals, String[] params)
  {
        int count = 0;
	int length = 0;
        for (int ii=0; ii<inter_vals.length; ii++) {
	   int index = inter_vals[ii].indexOf ('|');
	   if (index > 0) {
	     count += Integer.parseInt (inter_vals[ii].substring(0,index));
	     length += inter_vals[ii].length() - index;
	   }
        }
	StringBuffer sb = new StringBuffer (length+10);
	sb.append (count);
        for (int ii=0; ii<inter_vals.length; ii++) {
           int index = inter_vals[ii].indexOf ('|');
           if (index > 0) {
	     sb.append (
		inter_vals[ii].substring(index,inter_vals[ii].length()));
           }
        }
	
        return sb.toString ();
  }
  public static String median2_final (String inter_val, String[] params)
  {
	StringTokenizer st = new StringTokenizer (inter_val, "|");
	int num_values = Integer.parseInt (st.nextToken ());
	double[] values = new double[num_values];

	for (int ii=0; ii<num_values; ii++) {
           values[ii] = Double.parseDouble (st.nextToken ());
        }

        Arrays.sort (values);

        return Double.toString (values[(num_values-1)/2]);
  }

  // ---
  // simple procedure: nameFinder
  // ---
  // nameFinder0(nodes, 'name')
  public static String nameFinder0_local (NodeList orig_nodes, String[] params)
  {
	if (params.length != 1) return "";

	String name = params[0];
	int    len  = name.length ();
	String key1 = "," + name + ",";
	String key2 = name + ",";

        int num_nodes = orig_nodes.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
           Element n = (Element) orig_nodes.item (ii);
           String value = n.getAttribute("namelist");

	   int val_len = value.length ();
	   if (val_len < len) continue;

	   if ((value.indexOf(key1) > 0) || 
		value.startsWith (key2) ||
	        name.equals(value.substring(val_len-len, val_len))) {
	     return n.getAttribute("id");
	   }
        }
        return "";
  }
  public static String nameFinder2_init (Node orig_node, String[] params)
  {
	if (params.length != 1) return "";

	String name = params[0];
	int    len  = name.length ();

	Element n = (Element)orig_node;
	String value = n.getAttribute("namelist");

	int index = value.indexOf (name);
	if ((index == 0) || ((index > 0) && (value.charAt(index-1)==','))) {
	  index += len;
	  if ((index == value.length()) || (value.charAt(index)==','))
	    return n.getAttribute("id");
	}
        return "";
  }
  public static String nameFinder2_compute (String[] inter_vals, 
					    String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
	   if (inter_vals[ii].length() > 0)
	     return inter_vals[ii];
        return "";
  }
  public static String nameFinder2_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static String nameFinder3_init (Node orig_node, String[] params)
  {
        if (params.length != 1) return "";

        String name = params[0];
        int    len  = name.length ();

        Element n = (Element)orig_node;
        String value = n.getAttribute("namelist");

        int index = value.indexOf (name);
        if ((index == 0) || ((index > 0) && (value.charAt(index-1)==','))) {
          index += len;
          if ((index == value.length()) || (value.charAt(index)==','))
            return n.getAttribute("id");
        }
        return "";
  }
  public static String nameFinder3_compute (String[] inter_vals,
                                            String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
           if (inter_vals[ii].length() > 0)
             return inter_vals[ii];
        return "";
  }
  public static String nameFinder3_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static boolean nameFinder3_prune (String inter_val, String[] params)
  {
        return ((inter_val!=null) && (inter_val.length() > 0));
  }


  // debug
  public static void main (String argv[])
  {
/*
	String[] params= new String[1];
	params[0] = "3|5|10";
	for (int ii=0; ii<argv.length; ii++)
	   argv[ii] = histogram2_init (argv[ii], params);
	System.out.println (histogram2_compute(argv, params));
*/
	for (int ii=0; ii<argv.length; ii++)
           argv[ii] = median2_init (argv[ii], null);
	System.out.println (median2_final(median2_compute(argv, null), null));
  }

} // MySP
