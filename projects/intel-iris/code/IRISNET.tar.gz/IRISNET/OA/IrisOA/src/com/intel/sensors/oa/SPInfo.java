/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.lang.reflect.*;

// ---------------------------------------------------------------------
//                         class SPInfo
// ---------------------------------------------------------------------

/** SPInfo contains the method information of a stored procedure.
 */
public class SPInfo {

  String   full_name;	//classname:methodname
  int      type;
  Method[] method;

  // ---
  // newInstance
  // return null if the className:methodName is not found
  // ---
  static SPInfo newInstance (String className, String methodName)
  {
	// 1. look for the local and init methods
	//    determine the type of the stored procedure
	int    t=0;
	Method mlocal=null, minit=null, minitpath=null;

	for (t = 0; t < SPUtils.SP_TYPE_TOTAL; t++) {
	   SPProtoType  ss = SPUtils.prototypes[t][SPUtils.METHOD_LOCAL];
	   mlocal = SPUtils.getMethod (className, methodName + ss.suffix,
			      ss.parameterType, ss.returnType);

	   ss = SPUtils.prototypes[t][SPUtils.METHOD_INIT];
	   minit = SPUtils.getMethod (className, methodName + ss.suffix,
			      ss.parameterType, ss.returnType);

	   ss = SPUtils.prototypes[t][SPUtils.METHOD_INITPATH];
	   minitpath = SPUtils.getMethod (className, methodName + ss.suffix,
			      ss.parameterType, ss.returnType);

	   if ((mlocal != null) || (minit != null) || (minitpath != null)) {
	     break;
	   }
	}

	if (t == SPUtils.SP_TYPE_TOTAL)
	  return null;

	// 2. create and populate an SPInfo class
	SPInfo spinfo = new SPInfo ();

	spinfo.full_name = className + ':' + methodName;
	spinfo.type = t;

	// we only accept initpath method when this is a complex procedure
	if (t == SPUtils.SP_TYPE_SIMPLE) {
	  minitpath = null;
	}
	else {
	  if (minitpath != null) minit = null;
	}

	spinfo.method = new Method[SPUtils.METHOD_TOTAL];
	spinfo.method[SPUtils.METHOD_LOCAL] = mlocal;
	spinfo.method[SPUtils.METHOD_INIT] = minit;
	spinfo.method[SPUtils.METHOD_INITPATH] = minitpath;

	if ((minit != null)||(minitpath != null)) {
	  for (int ii=SPUtils.METHOD_COMPUTE; ii<SPUtils.METHOD_TOTAL; ii++) {
	   SPProtoType  ss = SPUtils.prototypes[t][ii];
	   spinfo.method[ii] = SPUtils.getMethod (className, 
                    methodName + ss.suffix, ss.parameterType, ss.returnType);
	  }
	}
	else {
	  for (int ii=SPUtils.METHOD_COMPUTE; ii<SPUtils.METHOD_TOTAL; ii++) {
	   spinfo.method[ii] = null;
	  }
	}

	// 3. sanity check
	// a) init, compute, final are all provided?
	if ((spinfo.method[SPUtils.METHOD_INIT] != null)||
	    (spinfo.method[SPUtils.METHOD_INITPATH] != null)) {
	  if ((spinfo.method[SPUtils.METHOD_COMPUTE] == null) ||
	      (spinfo.method[SPUtils.METHOD_FINAL] == null)) {
	    
	    for (int ii=SPUtils.METHOD_INIT; ii<SPUtils.METHOD_TOTAL; ii++)
	       spinfo.method[ii] = null;
	  } 
	}

	// b) now again, local or init must be provided
	if ((spinfo.method[SPUtils.METHOD_LOCAL]!=null) ||
	    (spinfo.method[SPUtils.METHOD_INIT] != null)||
	    (spinfo.method[SPUtils.METHOD_INITPATH] != null))
	  return spinfo;
	else
	  return null;
  }

  // ---
  // boolean methods
  // ---

  boolean isSimple ()
  { return (type == SPUtils.SP_TYPE_SIMPLE); }

  boolean isComplex ()
  { return (type == SPUtils.SP_TYPE_COMPLEX); }

  boolean hasLocal ()
  { return (method[SPUtils.METHOD_LOCAL] != null); }

  boolean hasInitComputeFinal ()
  { return ((method[SPUtils.METHOD_INIT] != null)
          ||(method[SPUtils.METHOD_INITPATH] != null)); }

  boolean hasPrune ()
  { return (method[SPUtils.METHOD_PRUNE] != null); }

  boolean hasInitPath ()
  { return (method[SPUtils.METHOD_INITPATH] != null); }

} // SPInfo
