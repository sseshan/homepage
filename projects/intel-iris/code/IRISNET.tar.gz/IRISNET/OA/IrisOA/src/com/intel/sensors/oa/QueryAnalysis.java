/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Exception;

import de.fzi.XPath.*;

import com.stevesoft.pat.Regex;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

// From Xalan 
import org.apache.xalan.templates.*;
import org.apache.xalan.transformer.*;
import org.apache.xpath.XPath;
import org.apache.xml.utils.QName;

/** This class will do analysis of the queries. Hopefully, this is the only class that talks with our parser
 *  de.fzi.XPath. 
 *
 *  @author Amol */
public class QueryAnalysis 
{

    /** Find out if the query asks for all children of a child. 
	 * This is an easy case to cache without having to store the query as well. 
	 * OAInfo is needed to find out characteristics of this node .
     * Q. How do we identify such queries ?
     * A. Find the place where the current OA belongs, and check if there 
	 * are absolutely any predicates after that down in the query tree. 
	 * So each step after that can not contain any predicates.  */
    public static boolean containsAllChildrenOfAChild(String q, String currentNodeName) 
    {
        try 
        {
            Expr parsetree = getLocationPathExpression(q);

            // okay.. go over the Steps in Expr to locate the Step that has the `currentNodeName' as the node
            // System.out.println(parsetree.getClass().getName());
            if(parsetree instanceof LocationPath) 
            {
                LocationPath lp = (LocationPath) parsetree;

                int matchat = -1;
                for(int i = 0; i < lp.getStepsCount(); i++) 
                {
                    Step st = lp.getStep(i);

                    if(matchat < 0) 
                    {
                        // keep on looking for a match
                        if(st.getNodeTest() instanceof NameTest) 
                        {
                            if(st.getNodeTest().toString().equals(currentNodeName)) 
                            {
                                matchat = i;
                            }
                        }
                        else 
                        {
                            throw new Exception("The query not in the format I like");
                        }
                    }
                    else 
                    {
                        if(i > matchat+1) 
                        {
                            // System.out.println("            Going to be testing for predicates at this step; better be predicate free");
                            if(st.getPredicatesCount() != 0) 
                            {
                                // System.out.println("                There are some predicates here; returing false");
                                return false;
                            }
                        }
                    }
                }
            }
            else 
            {
                throw new Exception("The query not in the format I like");
            }

            return true;
        } catch (Exception e) 
        {
            System.out.println("Some exception... returning false");
            e.printStackTrace();
            return false;
        }
    }

    /** Get location path for a query. Just a very simple utility. */
    public static LocationPath getLocationPathExpression(String q) throws Exception 
    {
        String q2;
        if(q.charAt(0) == '/')
            q2 = q.substring(1);
        else 
            q2 = q;

        Expr parsetree = XPathQueryParser.parsequery(q2);
        return (LocationPath) parsetree;
    }

    /** Find the rootAt query given the original query and the node 
	 * at which to root at.. the key here is that there should not be 
	 * any predicates on the rootAt node other than id predicate. 
	 * Otherwise, we run into problems. Also, we should never be asked 
	 * to root at a node unless there is an id predicate on it.
     * 
     * The initial part of this code is copied from the function below. */
    public static String findRootAtQuery(String q, String nodeName) throws Exception 
    {
        return findRootAtQuery(parse(q), nodeName);
    }
    public static String findRootAtQuery(Expr parsetree, String nodeName) throws Exception 
    {
        LocationPath newLp = new LocationPath();

        // okay.. go over the Steps in Expr to locate the Step that has the `currentNodeName' as the node
        if(parsetree instanceof LocationPath) 
        {
            LocationPath lp = (LocationPath) parsetree;

            boolean matched = false;
            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                Step st = lp.getStep(i);

                if(!matched) 
                {
                    // keep on looking for a match
                    if(st.getNodeTest() instanceof NameTest) 
                    {
                        if(st.getNodeTest().toString().equals(nodeName)) 
                        {
                            matched = true;

                            // need to make sure that there are only id predicates in this step
                            Step newStep = new Step(st.getAxis(), st.getNodeTest());
                            for(int j = 0; j < st.getPredicatesCount(); j++) 
                            {
                                if(isIdPredicate(st.getPredicate(j))) 
                                {
                                    newStep.addPredicate(st.getPredicate(j));
                                }
                            }
                            newLp.addStep(newStep);
                        }
                        else 
                        {
                            newLp.addStep(st);
                        }
                    }
                    else 
                    {
                        throw new Exception("The query not in the format I like");
                    }
                }
            }
        }
        else 
        {
            // huh ? this shouldn't happen
            System.out.println("This shouldn't be happening");
            throw new Exception("this shouldn't be happening");
        }
        return "/" + newLp.toString();
    }

    /** Modify the query till the child node so that a predicate on the 
	 * childNode level can be used. */
    public static String deleteQueryAfterNode(String q, String nodeName) throws Exception 
    {
        Expr parsetree = getLocationPathExpression(q);

        LocationPath newLp = new LocationPath();

        // okay.. go over the Steps in Expr to locate the Step that has the `currentNodeName' as the node
        if(parsetree instanceof LocationPath) 
        {
            LocationPath lp = (LocationPath) parsetree;

            boolean matched = false;
            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                Step st = lp.getStep(i);

                if(!matched) 
                {
                    newLp.addStep(st);

                    // keep on looking for a match
                    if(st.getNodeTest() instanceof NameTest) 
                    {
                        if(st.getNodeTest().toString().equals(nodeName)) 
                        {
                            matched = true;
                        }
                    }
                    else
                        throw new Exception("The query not in the format I like");
                }
            }
        }
        else 
        {
            // huh ? this shouldn't happen
            System.out.println("This shouldn't be happening");
            throw new Exception("this shouldn't be happening");
        }
        return "/" + newLp.toString();
    }

    /** Modify the query to strip everything in the beginning. */
    public static String modifyQuery(String q, String currentNodeName) throws Exception 
    {
        Expr parsetree = getLocationPathExpression(q);

        LocationPath newLp = new LocationPath();

        // okay.. go over the Steps in Expr to locate the Step that has the `currentNodeName' as the node
        if(parsetree instanceof LocationPath) 
        {
            LocationPath lp = (LocationPath) parsetree;

            int matchat = -1;
            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                Step st = lp.getStep(i);

                if(matchat < 0) 
                {
                    // keep on looking for a match
                    if(st.getNodeTest() instanceof NameTest) 
                    {
                        if(st.getNodeTest().toString().equals(currentNodeName)) 
                        {
                            matchat = i;
                        }
                    }
                    else
                        throw new Exception("The query not in the format I like");
                }
                else 
                {
                    if(i > matchat)
                        newLp.addStep(st);
                }
            }
        }
        else 
        {
            // huh ? this shouldn't happen
            System.out.println("This shouldn't be happening");
            throw new Exception("this shouldn't be happening");
        }
        return newLp.toString();
    }

    /*************** Functions/constants to help in generating XSLT queries ****************/
    /*************** Functions/constants to help in generating XSLT queries ****************/
    /*************** Functions/constants to help in generating XSLT queries ****************/
    /*************** Functions/constants to help in generating XSLT queries ****************/
    /*************** Functions/constants to help in generating XSLT queries ****************/
    private static String XSLifStart(String str) 
    {
        return new String("<xsl:if test=\"" + str + "\">\n");
    }
    private final static String XSLifEnd = new String("</xsl:if>\n");
    private static String XSLwhenStart(String str) 
    {
        return new String("<xsl:when test=\"" + str + "\">\n");
    }
    private final static String XSLwhenEnd = new String("</xsl:when>\n");
    private final static String XSLotherwiseStart = new String("<xsl:otherwise>\n");
    private final static String XSLotherwiseEnd = new String("</xsl:otherwise>\n");
    private final static String XSLchooseStart = new String("<xsl:choose>\n");
    private final static String XSLchooseEnd = new String("</xsl:choose>\n");
    private static String XSLtemplateStart(int i, String str)
    {
        return new String("<xsl:template match='" + str + ((i > 0) ? "' mode='usetemplate" + literalNumbers[i] : "") + "'>\n");
    }
    private final static String XSLtemplateEnd = new String("</xsl:template>\n");
    private final static String XSLcopyStart = new String("<xsl:copy>\n");
    private final static String XSLcopyEnd = new String("</xsl:copy>\n");
    private final static String XSLapplyTemplatesAll(int i)
    { 
        // System.out.println(i);
        return new String("<xsl:apply-templates select='@*|node()[not(@status)]'/>\n" + 
                      "<xsl:apply-templates select='node()[@status]" + 
                      ((i > 0) ? "' mode='usetemplate" + literalNumbers[i] : "") +
                      "'/>\n");
    }
    private final static String XSLapplyTemplatesOnlyAttributes = new String("<xsl:apply-templates select='@*'/>\n");
    private static String XSLaddElement(String elm) 
    {
        return new String("<" + elm + "/>\n");
    }
    private final static String XSLtransformStart = new String("<xsl:transform version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'>\n");
    private final static String XSLtransformEnd = new String("</xsl:transform>\n");

    private static String XSLchoosewhenStart(String str) 
    {
        return XSLchooseStart + XSLwhenStart(str);
    }
    private final static String XSLwhenEndowStart = XSLwhenEnd + XSLotherwiseStart;

    private final static String XSLowchooseEnd = XSLotherwiseEnd + XSLchooseEnd;

    private static String XSLcopyIDAttributeOnly = XSLcopyStart + 
        "<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>" +
        "<xsl:attribute name='status'>incomplete</xsl:attribute>" +
        XSLcopyEnd;

    private static String XSLcopyIDAttributeOnlyAsksubquery = XSLcopyStart + "<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>" + XSLaddElement("asksubquery") + XSLcopyEnd;

    private static String XSLcopyIDAttributeOnlyFetchAll = XSLcopyStart + "<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>" + XSLaddElement("fetchall") + XSLcopyEnd;

    private static String XSLcopyAttributesAddLeafFinal() 
    {
        return XSLcopyStart + XSLapplyTemplatesOnlyAttributes + XSLaddElement("leaf") + XSLaddElement("final") + XSLcopyEnd;
    }
    private static String XSLcopyAttributesAddLeaf() 
    {
        return XSLcopyStart + XSLapplyTemplatesOnlyAttributes + XSLaddElement("leaf") + XSLcopyEnd;
    }

    /** Check if a given de.fzi.XPath.Predicate is a consistency predicate. This will be a simple
     *  check which assumes the predicate will be in some particular format. */
    public static boolean isConsistencyPredicate(Expr expr) 
    {
        boolean retval = expr.toString().indexOf("attribute::expiry") != -1;
        return retval;
    }

    /** Check if this is an ID predicate: 
     *     the check is : equality predicate with one attribute that is id */
    public static boolean isIdPredicate(Expr expr) 
    {
        if(expr instanceof EqualityExpr) 
        {
            if(((EqualityExpr) expr).getExpr(0) instanceof LocationPath) 
            {
                LocationPath lp = (LocationPath) ((EqualityExpr) expr).getExpr(0);
                if(lp.getStepsCount() == 1) 
                {
                    if(lp.getStep(0).toString().indexOf("attribute::id") != -1) 
                    {
                        return true;
                    }
                }
            }
        } 
        return false;
    }

    /** Check if this is an ID predicate: 
     *     the check is : equality predicate with one attribute that is id */
    public static boolean isORedIdPredicate(Expr expr) 
    {
        if(expr instanceof OrExpr) 
        {
            OrExpr orexpr = (OrExpr) expr;
            return isIdPredicate(orexpr.getExpr(0)) && isIdPredicate(orexpr.getExpr(1));
        } else { 
            return false;
        }
    }

    /** Convert the consistency predicate to this format :
     *     not(@expirytime and not(@expirytime OP time))
     */
    public static String getConsistencyPredicateModified(Expr expr) 
    {
        return expr.toString();
    }

    public static String[] literalNumbers = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven"};

    public static StringBuffer getTemplateCorrespondingToStepForSlashSlash(int currentNumber) 
    {
        StringBuffer sb = new StringBuffer();

        sb.append(XSLtemplateStart(currentNumber, "node()[@status]"));

        sb.append(XSLchooseStart);

        sb.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete']"));
        sb.append(XSLcopyIDAttributeOnlyAsksubquery);
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='complete' or @status='ownsthis']"));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAll(currentNumber));
        // sb.append(XSLaddElement("generictwo")); // For debugging purpose
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLchooseEnd);

        sb.append(XSLtemplateEnd);

        return sb;
    }

    public static StringBuffer getTemplateCorrespondingToStepForFetchAll(int currentNumber, Step st, String newquery) throws Exception 
    {
        StringBuffer sb = new StringBuffer();

        sb.append(XSLtemplateStart(currentNumber, ((NameTest) st.getNodeTest()).toString() + "[@status]"));
        sb.append(XSLcopyIDAttributeOnlyFetchAll);
        // sb.append("<fetchall query=\"" + newquery + "\"/>\n");
        sb.append(XSLtemplateEnd);

        return sb;
    }

    public static String getTemplateCorrespondingToStep(int current_template_number, 
            Step st, Step nextStep, boolean do_not_apply_consistency) throws Exception 
    {

        boolean isFinal = (nextStep == null);

        String childNodeName = null;

        int thisAxis = st.getAxis();

        if(!isFinal) 
        {
            NodeTest nt = nextStep.getNodeTest();
            if(nt instanceof NameTest) 
                childNodeName = ((NameTest) nt).toString();
            else if(nt instanceof NodeType)
                childNodeName = "*";
            else 
            {
                System.out.println("Error");
                Utils.printClassName(nextStep.getNodeTest());
                System.out.println(nextStep);
                Utils.shouldnthappen();
            }
        }

        if(thisAxis == Axis.DESCENDANT_OR_SELF)
        {
            return getTemplateCorrespondingToStepForSlashSlash(current_template_number).toString();
        }

        StringBuffer predicates_consistency_checking = new StringBuffer();
        StringBuffer predicates_static = new StringBuffer();
        StringBuffer predicates_id = new StringBuffer();
        int num_static_predicates = 0, num_id_predicates = 0, num_consistency_checking_predicates = 0;
        for(int i  = 0; i < st.getPredicatesCount(); i++) 
        {
            if(!do_not_apply_consistency && isConsistencyPredicate(st.getPredicate(i))) 
            {
                predicates_consistency_checking.append("[" + st.getPredicate(i) + "]");
                num_consistency_checking_predicates++;
            }
            else if(isIdPredicate(st.getPredicate(i))) 
            {
                predicates_id.append("[" + st.getPredicate(i).toString() + "]");
                num_id_predicates++;
            }
            else 
            {
                predicates_static.append("[" + st.getPredicate(i).toString() + "]");
                num_static_predicates++;
            }
        }

        // System.out.println("Consistency predicate is " + predicates_consistency_checking + "***");

        return getCommonTemplate(current_template_number, ((NameTest) st.getNodeTest()).toString(), predicates_id.toString(), 
                predicates_consistency_checking.toString(), predicates_static.toString(), 
                (num_static_predicates != 0) || (num_consistency_checking_predicates != 0));

    }

    public static Object[] findXSLTQuery(String q, boolean checkForFetchall) throws Exception
    {
        return findXSLTQuery(getLocationPathExpression(q), checkForFetchall);
    }

    public static String getFirstTemplate() {
        return XSLtransformStart +
                XSLtemplateStart(-1, "@* | node()[not(@status)]") + 
                XSLcopyStart + 
                XSLapplyTemplatesAll(-1) + 
                // XSLaddElement("genericone") +  // For debugging purpose
                XSLcopyEnd + 
                XSLtemplateEnd;
    }

    public static String getLastTemplate(int current_template_number) {
        StringBuffer retval = new StringBuffer();
        /* a template to copy all those "special" nodes that are below the nodes selected by the query */
        retval.append(XSLtemplateStart(current_template_number, "node()[@status]"));
        retval.append(XSLchooseStart);
        retval.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete']"));
        retval.append(XSLcopyIDAttributeOnlyAsksubquery);
        retval.append(XSLwhenEnd);
        retval.append(XSLwhenStart("self::node()[@status='complete' or @status='ownsthis']"));
        retval.append(XSLcopyStart);
        retval.append(XSLapplyTemplatesAll(current_template_number));
        // retval.append(XSLaddElement("generictwo")); // For debugging purpose
        retval.append(XSLcopyEnd);
        retval.append(XSLwhenEnd);
        retval.append(XSLchooseEnd);
        retval.append(XSLtemplateEnd);
        return retval.toString();
    }

    public static String getCommonTemplate(int current_template_number, String nodeName, String predicates_id, 
            String predicates_consistency_checking, String predicates_static, boolean static_consistency_predicates_exist) {
        StringBuffer sb = new StringBuffer();

        sb.append(XSLtemplateStart(current_template_number, nodeName + "[@status]"));

        // We are going to change from the earlier practice of predicate driven to status flag driven model; easier to
        // write queries

        sb.append(XSLchooseStart);

        // CASE 1: INCOMPLETE
        sb.append(XSLwhenStart("self::node()[@status='incomplete']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id));
        sb.append(XSLcopyIDAttributeOnlyAsksubquery);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 2: ID-COMPLETE
        sb.append(XSLwhenStart("self::node()[@status='id-complete']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id));
        sb.append(XSLchoosewhenStart(static_consistency_predicates_exist ? "false" : "true")); 
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAll(current_template_number+1));   // recurse 
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnlyAsksubquery);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 3: COMPLETE
        sb.append(XSLwhenStart("self::node()[@status='complete']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id + predicates_static));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_consistency_checking)); 
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAll(current_template_number+1)); 
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnlyAsksubquery);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 4: OWNED
        sb.append(XSLwhenStart("self::node()[@status='ownsthis']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id + predicates_static));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAll(current_template_number+1)); 
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLchooseEnd);

        sb.append(XSLtemplateEnd);

        return sb.toString();
    }


	public static Object[] findXSLTQuery(String q, boolean XSLTCachingOn, boolean checkForFetchall) throws Exception
	{
		if (XSLTCachingOn) {
			return findXSLTQuery(getLocationPathExpression(q), q, checkForFetchall);
		} else {
			return findXSLTQuery(getLocationPathExpression(q), checkForFetchall); 
		}
			
	}

	public static Object[] findXSLTQuery(Expr parseTree, String query, boolean checkForFetchall) throws Exception
	{
		CacheManagement CM = CacheManagement.instance();
		Object[] xslt = CM.GetXSLTFromCache(query);
		if (xslt != null) {
			if (Globals.DebugON)
				System.out.println("******************SUCCESS:XSLT found in cache *************************");
		} else {
			xslt = findXSLTQuery(parseTree, checkForFetchall);
			CM.AddXSLTToCache(query, xslt);
		} 

		return xslt;
	}


    public static Object[] findXSLTQuery(Expr parsetree, boolean checkForFetchall) throws Exception 
    {
        // Call the XPathQueryParser to parse the query and get a parse tree kinda structure
        // strip of the beginning "/"... for some reason this parser doesn't like it
        LocationPath lp = (LocationPath) parsetree;

        StringBuffer xsltQuery = new StringBuffer();

        xsltQuery.append(getFirstTemplate());

        /* First find out if we need to use fetch-all. If yes, then only create an XSLT query till that point. */
        int fetchallstepnumber = checkForFetchall ? findFetchAllStepNumber(parsetree) : -1;
        
        int iteratetill = (fetchallstepnumber == -1) ? lp.getStepsCount() : fetchallstepnumber + 1;

        Object[] retval = new Object[2];

        /* this is just identity transform right now... add the templates corresponding to the query. */
        int current_template_number = 0;

        LocationPath newquery = null;

        for(int i = 0; i < iteratetill; i++) 
        {
            if(i < iteratetill - 1)
            {
                xsltQuery.append(getTemplateCorrespondingToStep(current_template_number, lp.getStep(i), lp.getStep(i+1), false));
            } 
            else 
            {
                if(fetchallstepnumber == -1)
                {
                    xsltQuery.append(getTemplateCorrespondingToStep(current_template_number, lp.getStep(i), null, false));
                }
                else
                {
                    newquery = new LocationPath();
                    for(int j = iteratetill - 1; j < lp.getStepsCount(); j++) 
                    {
                        newquery.addStep(lp.getStep(j));
                    }
                    xsltQuery.append(getTemplateCorrespondingToStepForFetchAll(current_template_number, lp.getStep(i), newquery.toString()));
                }
            }

            // only upgrade the template number if this step doesn't not involve "//"
            if(lp.getStep(i).getAxis() != Axis.DESCENDANT_OR_SELF)
            {
                current_template_number++;
            }
        }

        xsltQuery.append(getLastTemplate(current_template_number));

        /* FINISH */
        xsltQuery.append(XSLtransformEnd);

        // prettyPrintXSLTQuery(xsltQuery.toString());

        retval[0] = xsltQuery.toString();
        retval[1] = newquery;
        return retval;
    }

    public static Expr parse(String q) throws Exception 
    {
        String q2;
        if(q.charAt(0) == '/') q2 = q.substring(1);
        else q2 = q;

        return XPathQueryParser.parsequery(q2);
    }


    public static String getRoot(String q) throws Exception 
    {
        return getRoot(parse(q));
    }

    public static String getRoot(Expr parsetree) throws Exception 
    {
        return ((NameTest)((LocationPath) parsetree).getStep(0).getNodeTest()).toString();
    }

    public static String modifyQueryToSendToChild(String origQuery, String newPrefix) throws Exception 
    {
        return modifyQueryToSendToChild(parse(origQuery), parse(newPrefix));
    }

    /* WARNING! Destroys the inputs. */
    private static String modifyQueryToSendToChild(Expr parseTree1, Expr parseTree2) throws Exception 
    {
        LocationPath locationPath1 = (LocationPath) parseTree1;
        LocationPath locationPath2 = (LocationPath) parseTree2;

        // System.out.println("modifyQueryToSendToChild");
        // System.out.println(parseTree1.toString());
        // System.out.println(parseTree2.toString());

        /* We must find the equivalent step in the parseTree1 that matches the *last* step in parseTree2.
         * After doing that, we just attach everything after that in parseTree1 to parseTree2.
         * If such an equivalent step is not found, we are in deep trouble.
         * In that case, just return parseTree2. This makes it even more impervative that we apply
         * the original query before sending the answer to the user. 
         *
         * The other option could be to apply the original query after fetching the data from the
         * subquery.
         */
        Step last_step = locationPath2.getStep(locationPath2.getStepsCount() - 1);
        int match_at = -1;
        for(int i = 0; i < locationPath1.getStepsCount(); i++)
        {
            // check if the steps are equivalent
            Step this_step = locationPath1.getStep(i);
            if((this_step.getNodeTest() instanceof NameTest) && 
                    (this_step.getNodeTest().toString().equals(last_step.getNodeTest().toString()))) 
            {
                // found the match
                match_at = i;
                break;
            }
        }

        if(match_at != -1)
        {
            for(int i = match_at + 1; i < locationPath1.getStepsCount(); i++) 
            {
                locationPath2.addStep(locationPath1.getStep(i));
            }
        }

        return locationPath2.toString();

        // for(int i = 0; i < locationPath2.getStepsCount() - 1; i++) 
        // {
        //      locationPath1.setStep(i, locationPath2.getStep(i));
        // }
        // // for the last step we must merge the predicates
        // Step st1 = locationPath1.getStep(locationPath2.getStepsCount()-1);
        // Step st2 = locationPath2.getStep(locationPath2.getStepsCount()-1);
        // // st2 can have only one predicate
        // st1.addPredicate(st2.getPredicate(0));
        // return locationPath1.toString();
    }

	public static String getLongestNonbrachingPrefix(String q) throws Exception 
    {
        try 
        {
            Expr expr = parse(q);
            LocationPath lp = (LocationPath) expr;

            StringBuffer ipAddress = new StringBuffer(getRoot(q));

            for(int i = 1; i < lp.getStepsCount(); i++) 
            { // skip the first step
                // check if this step is still non-branching
                Step st = lp.getStep(i);
                if((st.getPredicatesCount() == 1) && (isIdPredicate(st.getPredicate(0)))) 
                {
                    // cool... get the id predicate name from there
                    String str = ((EqualityExpr) st.getPredicate(0)).getExpr(1).toString();
                    ipAddress.insert(0, str.substring(1, str.length()-1) + ".");
                }
                else 
                {
                    break;
                }
            }
            return ipAddress.toString();
        } catch (Exception e) 
        {
            throw e;
        }
    }

    public static String getIPAddressOfLongestNonbrachingPrefix(String q) throws Exception 
    {
		return getLongestNonbrachingPrefix(q) + "." + ConfigurationManager.instance().getDNSSuffix();

    }

    /** Given a query, find the step number at which fetch-all needs to be instantiated, if at all.
      *
      * Return value of -1 means that no fetch-all is needed for this query.
      */
    public static int findFetchAllStepNumber(Expr parsetree) throws Exception
    {
        int[] backrefs = findHighestUpReferenceInQueryByStep(parsetree);
        boolean[] predicatescontainlocationpaths = findIfPredicatesContainLocationPathsByStep(parsetree);

        int ret_val = 10000; // good luck trying to write a query with 10000 steps

        for(int i = 0; i < backrefs.length; i++) 
        {
            // System.out.println(backrefs[i]);
            // System.out.println(predicatescontainlocationpaths[i]);
        }

        for(int i = 0; i < backrefs.length; i++) 
        {
            if(predicatescontainlocationpaths[i])
            {
                if((i + backrefs[i]) < ret_val)
                {
                    ret_val = i + backrefs[i];
                }
            }
        }

        return (ret_val == 10000) ? -1 : ret_val;
    }
    
    /** Given a query, for each step, find out if any of the predicates involve a '/'. We will do this
      * by simply searching for '/' in each step. */
    public static boolean[] findIfPredicatesContainLocationPathsByStep(Expr expr) throws Exception
    {
        try 
        {
            // System.out.println(expr);

            LocationPath lp = (LocationPath) expr;
            boolean[] ret_val = new boolean[lp.getStepsCount()];

            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                ret_val[i] = (lp.getStep(i).toString().indexOf("/") != -1);
            }
            return ret_val;
        } catch (Exception e) 
        {
            throw e;
        }
    }


    /** Given a query, find the highest tag name referred in the predicates for those predicates that includes a '/'. 
     * This will be used to implement the 
     * default "fetch-all" strategy. */
    public static String UnusedFindHighestUpReferenceInQuery(Expr expr) throws Exception
    {
        try 
        {
            int index = findHighestUpReferenceInQuery(expr);

            Step st = ((LocationPath) expr).getStep(index);

            return st.getNodeTest().toString();
        } catch (Exception e) 
        {
            throw e;
        }
    }

    /** Essentially, do the above for each step separately. */
    public static int[] findHighestUpReferenceInQueryByStep(Expr expr) throws Exception 
    {
        try 
        {
            LocationPath lp = (LocationPath) expr;
            int[] ret_val = new int[lp.getStepsCount()];

            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                ret_val[i] = findHighestUpReferenceInQuery(lp.getStep(i));
            }
            return ret_val;
        } catch (Exception e) 
        {
            throw e;
        }
    }

    /** Helper function to above. Returns an integer denoting the step which is the highest reference. May return
     *  negative numbers -- in fact, that is an indication of going up. */
    private static int findHighestUpReferenceInQuery(Expr expr) throws Exception 
    {
        // we don't concern with the predicates that don't include a "/"
        if(expr.toString().indexOf("/") == -1) 
        {
            return 1000;
        }

        if(expr instanceof LocationPath) 
        {
            LocationPath lp = (LocationPath) expr;
            int furthestup = 0; // default is zero
            int current_position = 0;

            // go over the steps one by one and recurse on the predicates
            for(int i = 0; i < lp.getStepsCount(); i++) 
            {
                if(lp.getStep(i).getAxis() == Axis.CHILD) 
                {
                    current_position++;
                }
                else if(lp.getStep(i).getAxis() == Axis.PARENT) 
                {
                    current_position--;
                }
                else if(lp.getStep(i).getAxis() == Axis.SELF)
                {
                    // don't do anything
                }
                else 
                {
					if (Globals.DebugON)
						System.out.println("We don't allow anything except child and parent axes in the query " + lp.getStep(i));
                    System.exit(1);
                }
                int furthestuphere = current_position + findHighestUpReferenceInQuery(lp.getStep(i));
                if(furthestup > furthestuphere) 
                {
                    furthestup = furthestuphere;
                }
            }

            return furthestup;
        }
        else if(expr instanceof NaryExpr) 
        {
            Vector v = new Vector();
            for(int i = 0; i < ((NaryExpr) expr).getExprsCount(); i++) 
            {
                v.add(((NaryExpr) expr).getExpr(i));
            }
            return findHighestUpReferenceInQuery(v);
        }
        else if(expr instanceof FilterExpr) 
        {
            // right now, I can't anticipate a query for which FilterExpr will have any predicates 
            // associated with it -- XXX Amol.
            // HANDLING THIS QUERY REQUIRES A CHANGE TO THE "DE" LIBRARY
            FilterExpr fe = (FilterExpr) expr;

            if(fe.getPredicatesCount() != 0) 
            {
				if (Globals.DebugON)
					System.out.println("This query was not anticipated -- FilterExpr has predicates associated with it");
                System.exit(1);
            }

            return findHighestUpReferenceInQuery(fe.getPrimary());

            // System.out.println("Can't handle this query right now");
            // System.exit(1);
        }
        else if(expr instanceof Literal || expr instanceof de.fzi.XPath.Number) 
        {
            return 0;
        }
        else if(expr instanceof FunctionCall) 
        {
            // This one is not that much different for NaryExpr above.
            FunctionCall fc = (FunctionCall) expr;

            Vector v = new Vector();

            for(int i = 0; i < fc.getArgumentCount(); i++) 
            {
                v.add(fc.getArgument(i));
            }
            return findHighestUpReferenceInQuery(v);
        }
        else 
        {
			if (Globals.DebugON) {
				System.out.println("Unanticipated query -- don't konw what to do wit this class");
				Utils.printClassName(expr);
				System.out.println(expr);
			}
            System.exit(0);
        }
        return 0;
    }

    /** de.fzi.XPath.Step is not a de.fzi.XPath.Expr */
    private static int findHighestUpReferenceInQuery(Step st) throws Exception 
    {
        Vector v = new Vector();
        for(int j = 0; j < st.getPredicatesCount(); j++)
            v.add(st.getPredicate(j));

        return findHighestUpReferenceInQuery(v);
    }

    /** We have too many cases where there are multiple predicates together at the same level. */
    private static int findHighestUpReferenceInQuery(Vector exprs) throws Exception 
    {
        // find the furthest-up reference in any of the predicates
        int furthestup = 0; 
        for(int j = 0; j < exprs.size(); j++) 
        {
            int highestbackref = findHighestUpReferenceInQuery((Expr) exprs.get(j));
            if(highestbackref < furthestup) 
            {
                furthestup = highestbackref;
            }
        }
        return furthestup;
    }

    private static void prettyPrintXSLTQuery(String query)
    {
        try {

            Document queryAsDocument = DOMProcessing.XMLtoDOM(query);

            DOMProcessing.myDenormalize(queryAsDocument);

            String output = DOMProcessing.DOMtoXML(queryAsDocument);

            Regex rg = new Regex("&apos;", "\"");

            output = rg.replaceAll(output);

            System.out.println(output);

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    // by Suman
    // Get the document affected by a simple xupdate query
    public static String getDocumentWrittenByXupdate(String XupdateQuery)
    {
		//System.out.println("XupdateQuery: " + XupdateQuery);
		int selectStart = XupdateQuery.indexOf("select");
		if (selectStart < 0) {
			System.out.println("ERROR:No Select predicate found within the XupdateQuery");
			return "NONE";
		} 

		int predicateStart = XupdateQuery.indexOf("/", selectStart);
		String selectQuery = XupdateQuery.substring(predicateStart+1);
		//System.out.println("selectQuery = " + selectQuery);

		// the select predicate is terminated by '/' or '"'
		StringTokenizer tokens = new StringTokenizer(selectQuery, "[/\"");
		String id = tokens.nextToken();
		
		return id;
		
    }	

   /* -------------------------------------------------------------------- */
   /*                XSLT program for xpath with Stored Procedure          */
   /* -------------------------------------------------------------------- */
   private final static String XSLtransformStartwSP = "<xsl:transform version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:SPUtils='xalan://com.intel.sensors.oa.SPUtils' exclude-result-prefixes='SPUtils'>\n";

   private final static String XSLapplyTemplatesOther = 
	"<xsl:apply-templates select='@*|text()|node()[not(@status)]'/>\n";

   private static String XSLcopyIDAttributeOnlyAddElem (String element_name,
							int which_step)
   { 
	return XSLcopyStart + 
        "<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>"
        + "<" + element_name + " step='" + which_step + "'/>\n"
	+ XSLcopyEnd;
   }

    private final static String XSLapplyTemplatesAllwText(int i)
    {
	return XSLapplyTemplatesOther +
               "<xsl:apply-templates select='node()[@status]" +
                ((i > 0) ? "' mode='usetemplate" + literalNumbers[i] : "") +
                "'/>\n";
    }

    private final static String XSLapplyTemplatesOtherStop ()
    {
	return XSLapplyTemplatesOther + XSLaddElement("stopnode");
    }


   // the beginning part of XSLT program
   static void spFirstTemplate (StringBuffer sb)
   {
	sb.append (XSLtransformStartwSP);
	sb.append (XSLtemplateStart(-1, "@*|text()|node()[not(@status)]"));
	sb.append (XSLcopyStart);
	sb.append (XSLapplyTemplatesOther);
	sb.append (XSLcopyEnd);
	sb.append (XSLtemplateEnd);
   }

   // replace all occurrences of '<' with '&lt;'
   static String spReplaceLessThan (String predicate)
   {
	int start = 0;
	int end = predicate.indexOf ('<');
	if (end == -1)
	  return predicate;

	StringBuffer sb = new StringBuffer (predicate.length() + 4);
	do {
	  sb.append (predicate.substring (start, end));
	  sb.append (" &lt;");
	  start = end + 1;
	  end = predicate.indexOf ('<', start);
	} while (end != -1);
	
	sb.append (predicate.substring (start, predicate.length()));

	return sb.toString();
   }

   // for every child:: step
    static void spChildTemplate(StringBuffer sb,
		int current_template_number, 
		String nodeName, String predicates_id, 
                String predicates_consistency_checking, 
		String predicates_static, 
		String subquery_tag, boolean stop_at_node, int which_step) {

	boolean static_consistency_predicates_exist =
		(predicates_consistency_checking.length() +
		 predicates_static.length() > 0);

	// replace all occurrences of '<' with '&lt;'
	predicates_id = spReplaceLessThan(predicates_id);
	predicates_consistency_checking = 
			spReplaceLessThan(predicates_consistency_checking);
	predicates_static = 
			spReplaceLessThan(predicates_static);

	// begin fall back template: if nothing matches
	sb.append(XSLtemplateStart(current_template_number, "node()"));
        sb.append(XSLcopyIDAttributeOnly);
	sb.append(XSLtemplateEnd);

	// begin child:: step template
        sb.append(XSLtemplateStart(current_template_number, 
				   nodeName + "[@status]"));
        sb.append(XSLchooseStart);

        // CASE 1: INCOMPLETE
        sb.append(XSLwhenStart("self::node()[@status='incomplete']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id));
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 2: ID-COMPLETE
        sb.append(XSLwhenStart("self::node()[@status='id-complete']"));
        sb.append(XSLchoosewhenStart("self::node()" + predicates_id));
	if (!static_consistency_predicates_exist && !stop_at_node) {
          sb.append(XSLcopyStart);
	  // this node satisfies the id predicate, let's move on
          sb.append(XSLapplyTemplatesAllwText(current_template_number+1));
          sb.append(XSLcopyEnd);
	}
	else {
          sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
	}
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 3: COMPLETE
        sb.append(XSLwhenStart("self::node()[@status='complete']"));
        sb.append(XSLchoosewhenStart("self::node()" 
				+ predicates_id + predicates_static));
        sb.append(XSLchoosewhenStart("self::node()" 
				+ predicates_consistency_checking)); 
        sb.append(XSLcopyStart);
	if (stop_at_node) {
	  sb.append(XSLapplyTemplatesOtherStop ());
	}
	else {
          sb.append(XSLapplyTemplatesAllwText(current_template_number+1)); 
	}
	sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
	  // the cached copy is not fresh
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        // CASE 4: OWNED
        sb.append(XSLwhenStart("self::node()[@status='ownsthis']"));
        sb.append(XSLchoosewhenStart("self::node()" 
				+ predicates_id + predicates_static));
        sb.append(XSLcopyStart);
	if (stop_at_node) {
          sb.append(XSLapplyTemplatesOtherStop ());
        }
        else {
          sb.append(XSLapplyTemplatesAllwText(current_template_number+1));
        }
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
        sb.append(XSLcopyIDAttributeOnly);
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLchooseEnd);
        sb.append(XSLtemplateEnd);
    }

    static void spSlashSlashTemplate (StringBuffer sb,
		int currentNumber, String subquery_tag, int which_step)
    { 
        sb.append(XSLtemplateStart(currentNumber, "node()[@status]"));
        sb.append(XSLchooseStart);
    
        sb.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete']")); 
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='complete' or @status='ownsthis']"));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAllwText(currentNumber));
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEnd); 

        sb.append(XSLchooseEnd);
        sb.append(XSLtemplateEnd);
    }

    static void spSlashSlashTemplateNoCaching (StringBuffer sb,
		int currentNumber, String subquery_tag, int which_step)
    { 
        sb.append(XSLtemplateStart(currentNumber, "node()[@status]"));
        sb.append(XSLchooseStart);
    
        sb.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete' or @status='complete']")); 
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='ownsthis']"));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAllwText(currentNumber));
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEnd); 

        sb.append(XSLchooseEnd);
        sb.append(XSLtemplateEnd);
    }

    // only used when we want to retrieve the whole subtree
    static void spLastTemplate(StringBuffer sb,
		int currentNumber, String subquery_tag, int which_step)
    {
        sb.append(XSLtemplateStart(currentNumber, "node()[@status]"));
        sb.append(XSLchooseStart);

        sb.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete']"));
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='complete' or @status='ownsthis']"));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAllwText(currentNumber));
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLchooseEnd);
        sb.append(XSLtemplateEnd);
    }

    static void spLastTemplateExpire(StringBuffer sb, 
		String predicates_consistency_checking,
		int currentNumber, String subquery_tag, int which_step)
    {
        sb.append(XSLtemplateStart(currentNumber, "node()[@status]"));
        sb.append(XSLchooseStart);

        sb.append(XSLwhenStart("self::node()[@status='incomplete' or @status='id-complete']"));
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='complete']"));
        sb.append(XSLchoosewhenStart("self::node()"
                                + predicates_consistency_checking));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAllwText(currentNumber));
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEndowStart);
          // the cached copy is not fresh
        sb.append(XSLcopyIDAttributeOnlyAddElem (subquery_tag, which_step));
        sb.append(XSLowchooseEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLwhenStart("self::node()[@status='ownsthis']"));
        sb.append(XSLcopyStart);
        sb.append(XSLapplyTemplatesAllwText(currentNumber));
        sb.append(XSLcopyEnd);
        sb.append(XSLwhenEnd);

        sb.append(XSLchooseEnd);
        sb.append(XSLtemplateEnd);
    }

    //   lp:         the location path
    //   node_only:  get the nodes only? not to get all the subtrees?
    //   diff_tags:  distinguish remote nodes above insterested nodes or not
    //   return the xslt program
    //
    // requirements:
    //    1. the location path should only contain child:: descendant_or_self::
    //    2. function calls in the location path have been replaced using
    //       QueryUtils.prepareLPforXslt
    //    3. no nodetype test
    public static String writeXsltwithSP (LocationPath lp, 
		boolean node_only, boolean diff_tags,
		String subtree_consistency_checking)
    {
		if (Globals.XSLTCachingON) {
			String xsltId = lp.toString() + node_only + diff_tags + 
				subtree_consistency_checking;
			CacheManagement CM = CacheManagement.instance();
			String xslt = CM.GetQ2XSLTFromCache(xsltId);
			if (xslt != null) {
				if (Globals.DebugON)
					System.out.println("******************SUCCESS:XSLT found in cache *************************");
			} else {
				xslt = writeXsltwithSP (lp, node_only, diff_tags, lp.getStepsCount(),
										subtree_consistency_checking);
				
				CM.AddQ2XSLTToCache(xsltId, xslt);
			}
			return xslt;
		} else {
			return writeXsltwithSP (lp, node_only, diff_tags, lp.getStepsCount(),
									subtree_consistency_checking);
		}
	}
	

    public static String writeXsltwithSP (LocationPath lp, 
		boolean node_only, boolean diff_tags, int iteratetill,
		String subtree_consistency_checking)
    {
        StringBuffer xsltQuery = new StringBuffer(1000+2500*iteratetill);

		writeXsltwithSP (xsltQuery, lp, node_only, diff_tags, iteratetill,
						 subtree_consistency_checking);
		
        return xsltQuery.toString ();
    }

    public static void writeXsltwithSP (StringBuffer xsltQuery,
										LocationPath lp, boolean node_only, boolean diff_tags, int iteratetill,
										String subtree_consistency_checking)
    {
		String upper_tag=null, lower_tag=null;
		if (diff_tags) {
			upper_tag="askfullsubquery";
			lower_tag="asksubquery";
		}
		else {
			upper_tag=lower_tag="asksubquery";
		}
		
		// the first template
        spFirstTemplate(xsltQuery);
		
		// process every step
        int current_number = 0;
        for(int ii = 0; ii < iteratetill; ii ++)
			{
				Step st = lp.getStep(ii);
				int axis = st.getAxis();
				int num_predicates = st.getPredicatesCount();
				
				if (axis == Axis.CHILD) {
					String node_name = null;
					if (st.getNodeTest() instanceof NameTest) {
						node_name = ((NameTest) st.getNodeTest()).toString();
					}
					else {
						Utils.error ("NodeType is not fully support!");
					}
					// get different types of predicates
					StringBuffer predicates_consistency_checking = new StringBuffer();
					StringBuffer predicates_static = new StringBuffer();
					StringBuffer predicates_id = new StringBuffer();
					for (int jj=0; jj < num_predicates; jj++) {
						Expr predicate = st.getPredicate(jj);
						String pstr = '[' + predicate.toString() + ']';
						if (isConsistencyPredicate(predicate)) {
							predicates_consistency_checking.append(pstr);
						}
						else if(isIdPredicate(predicate)) {
							predicates_id.append(pstr);
						}
						else {
							predicates_static.append(pstr);
						}
					}
					// use child template
					spChildTemplate(xsltQuery,
									current_number, node_name,
									predicates_id.toString(),
									predicates_consistency_checking.toString(),
									predicates_static.toString(),
									upper_tag,
									(ii == (iteratetill-1)) && node_only, ii);
					
					current_number++;
				}
				else if(axis == Axis.DESCENDANT_OR_SELF) {
					if (ii == iteratetill-1) {
						Utils.error ("no child test after DESCENDANT_OR_SELF!");
					}
					// use the slashslash template
					if (num_predicates > 0) {
						for (int jj=0; jj<num_predicates; jj++)
							if (! isConsistencyPredicate(st.getPredicate(jj)))
								Utils.error ("DESCENDANT_OR_SELF with predicates" +
											 " is not supported!");
						// no caching with expiry predicates
						spSlashSlashTemplateNoCaching(xsltQuery, current_number, 
													  upper_tag, ii);
					}
					else
						spSlashSlashTemplate(xsltQuery, current_number, upper_tag, ii);
				}
				else {
					Utils.error ("Not supported");
				}
			} // end of for
		
		// get all subtree?
		if (! node_only) {
			if (subtree_consistency_checking == null)
				spLastTemplate(xsltQuery, current_number, lower_tag, iteratetill);
			else
				spLastTemplateExpire(xsltQuery, subtree_consistency_checking,
									 current_number, lower_tag, iteratetill);
		}
		
		// write closing element
        xsltQuery.append(XSLtransformEnd);
    }
	
    static String queryforId (Element e)
    {
        if (e.hasAttribute("id")) {
	  return "[@id='" + e.getAttribute("id") + "']";
        } else {
	  return "";
        }
    }

    // qinfo  - the environment where the original query is evaluated
    // n      - the hanging node in a result tree
    // lp     - the original query
    // ret[]  - this procedure finds out the information necessary
    //          to ask remote query and put it in the ret array
    // ret[0]: lca host
    // ret[1]: query to ask
    // ret[2]: the root_at node, its parent is the context node for the query
    //         and we only want the subtree rooted at root_at node
    static void getRemoteQueryInfo (QueryInfo qinfo, Element n, 
				    LocationPath lp, String[] ret)
    {
	// note that: root at node will be the child of the context node
	//            with which xslt program is executed
    try {
        String lca_host = DOMProcessing.findOwnerAgent(
                        DOMProcessing.findLowestUnownedAncestor(n));
	String owner_agent_for_root_parent = qinfo.ownerAgentForRootParent ();
	ret[0] = (owner_agent_for_root_parent.length() == 0) ? lca_host:
		 lca_host + '.' + owner_agent_for_root_parent;

        String root_at = qinfo.queryForRootParent () + '/' 
		       + QueryUtils.findQueryForThisElement(n);
	ret[2] = root_at;

	// determine the query to ask
	NodeList nl = n.getElementsByTagName ("asksubquery");
        String step_string = ((Element)(nl.item(0))).getAttribute ("step");
	int which_step = Integer.parseInt (step_string);

	int num_steps = lp.getStepsCount();
	if (which_step >= num_steps) {
	  // the lp has selected an ancestor of this node
	  // in the process of getting the whole subtree, this node is missing

	  ret[1] = n.getTagName() + queryforId (n);
	}
	else if (lp.getStep(which_step).getAxis() == Axis.CHILD) {
	  StringBuffer sb = new StringBuffer ((num_steps-which_step)*16);

	  sb.append (lp.getStep(which_step).toString());
	  sb.append (queryforId (n));

	  for (int ii=which_step+1; ii<num_steps; ii++) {
	     sb.append ('/');
	     sb.append (lp.getStep(ii).toString());
	  }
	  ret[1] = sb.toString();
	}
	else {
	   // Axis.DESCENDANT_OR_SELF
	   StringBuffer sb = new StringBuffer ((num_steps-which_step)*16);

	   sb.append (n.getTagName());
	   sb.append (queryforId (n));

	   for (int ii=which_step; ii<num_steps; ii++) {
	      sb.append ('/');
	      sb.append (lp.getStep(ii).toString());
	   }
	   ret[1] = sb.toString();
	}
     } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
    }
   
   /* -------------------------------------------------------------------- */
   /* -------------------------------------------------------------------- */

    public static void testing(String query)
    {
        try 
        {
            System.out.println("Time: " + System.currentTimeMillis());

            DOMProcessing.init();

            String xsltQuery = (String) findXSLTQuery(query, true)[0];

            Document xsltQueryDoc = DOMProcessing.XMLtoDOM(xsltQuery);
            
            Document doc = DOMProcessing.fileToDOM("testing.xml");

            System.out.println("Time: " + System.currentTimeMillis());

            Transformer transformer = null;

            for(int i = 0; i < 100; i++)
            {
                // Source s = new StreamSource(new StringReader(xsltQuery));
                Source s = new DOMSource(xsltQueryDoc);
                transformer = DOMProcessing.tFactory.newTransformer(s);
            }

            System.out.println("Time: " + System.currentTimeMillis());

            for(int i = 0; i < 100; i++) 
            {
                Document ret_val = new org.apache.xindice.xml.dom.DocumentImpl();

                transformer.transform(new DOMSource(doc), new DOMResult(ret_val));
            }

            System.out.println("Time: " + System.currentTimeMillis());

            System.exit(1);
        } 
        catch (Exception e) 
        {
            System.exit(1);
        }
        System.exit(1);
    }

    public static void main(String[] args) throws Exception 
    {
        try 
        {
			String qq = "/m/a[@id='xyz']/b[@id='y' or @id='z']/c/d[@id='bac']";
			System.out.println(getIPAddressOfLongestNonbrachingPrefix(qq));
            //System.exit(0);

            String qq2 = "/m/a/b[@id='abc']/";
            System.out.println(modifyQueryToSendToChild(qq, qq2));
            System.exit(0);

			String xupdate = " <xupdate:modifications version=\"1.0\" xmlns:xupdate=\"http://www.xmldb.org/xupdate\"> <xupdate:append select=\"/addresses/address[@id = 1]\"  <xupdate:element name=\"zip\">90200</xupdate:element> </xupdate:append> </xupdate:modifications>";

			String xupdate1 = " <xupdate:modifications version=\"1.0\" xmlns:xupdate=\"http://www.xmldb.org/xupdate\"> <xupdate:variable name=\"state\" select=\"/addresses/address[@id = 1]/state\"/> <xupdate:insert-after select=\"/addresses/address[@id = 1]/country\"> <xupdate:value-of select=\"$state\"/> </xupdate:insert-after> </xupdate:modifications>";
			System.out.println(getDocumentWrittenByXupdate(xupdate));

			System.exit(0);
	
            String testq1 = "/a//c[alksdf]/d[./e]";
            String testq2 = "/a/b[@id='x']/";
            System.out.println(modifyQueryToSendToChild(testq1, testq2));
            System.exit(1);


            String q = "a/b[@id = 'Oakland' or @id = 'Shadyside'][@a > '10']/e[../name]/f/";
            q = "/x/y/a[../../b/c]";
            q = "/parkingone/usRegion/state/county/city[@id='Pittsburgh']/neighborhood[@id='Shadyside']/block[@id='1']";
            q = "/parkingone/usRegion/state/county/city[@id='Pittsburgh']/neighborhood[./block]";
            q = "/parkingone/usRegion/state/county[@id='County0']/city[@id='City0']/neighborhood[@id='Neighborhood0']";

            // q = "/test0/test1/test2/test3/test4/test5/test6/test7/test8/test9";
            // q = "/testone";
            // q = "/parkingone/usRegion/state";
            // q = "/parkingone//city[@id='Pittsburgh']/neighborhood[@id='Oakland']/";
            // q = "/parkingone/usRegion/state/county/city/neighborhood[count(./block) = 1]/";
            // q = "/parkingone/neighborhood[@id='Oakland'][count(./block) = 1]/";
            // q = "/parkingone/usRegion/state/county/city/neighborhood[@id='Oakland']/block[not(available-spaces > ../block/available-spaces)]/";
            // q = "/parkingone//neighborhood/";

            // testing(q);

            Object[] xsltQueryInformation = findXSLTQuery(q, true);
            String _xslt = (String) xsltQueryInformation[0];
            Expr newQuery = (Expr) xsltQueryInformation[1];

            // prettyPrintXSLTQuery(_xslt);
            if(newQuery != null)
                System.out.println("A fetchall is in order and the subquery to be applied later is " + newQuery.toString());


            Document dd = DOMProcessing.fileToDOM("testing1.xml");

            Transformer tf = DOMProcessing.getXSLTTransformer(_xslt);

            // TestingXSLTCreation.initTemplates();
            // System.out.println("Time :" + System.currentTimeMillis());

            // TransformerImpl fastTF = (TransformerImpl) TestingXSLTCreation.getFastXSLTTransformer(q);
            // System.out.println("Time :" + System.currentTimeMillis());

            Node answer1 = DOMProcessing.applyXSLTtoDOM(dd, tf);

            // Node answer2 = DOMProcessing.applyXSLTtoDOM(dd, fastTF);

            System.out.println(DOMProcessing.DOMtoXML(answer1));
            // System.out.println(DOMProcessing.DOMtoXML(answer2));

            System.exit(1);


            /** Debugging information about fastTF. */
            // TemplateList.TemplateWalker tw = fastTF.getStylesheet().getTemplateListComposed().getWalker();
            // ElemTemplate et;
            // System.out.println("******************************\n");
            // while((et = tw.next()) != null) 
            // {
            //     System.out.println(et.getMatch().getPatternString() + " " + et.getMode());
            //     Utils.printClassName(et.getChildNodes().item(0));
            //     Utils.printClassName(et.getChildNodes().item(0).getChildNodes().item(0));
            // }

            /*** Collecting some timing information */
            // System.out.println("TimeX :" + System.currentTimeMillis());
            // for(int i = 0; i < 100; i++) {
                // Transformer _tf = DOMProcessing.getXSLTTransformer((String) findXSLTQuery(q)[0]);
            // }
            // System.out.println("TimeXX :" + System.currentTimeMillis());
            // for(int i = 0; i < 100; i++) {
                // Transformer _tf = TestingXSLTCreation.getFastXSLTTransformer(q);
            // }
            // System.out.println("TimeXX :" + System.currentTimeMillis());
            // for(int i = 0; i < 100; i++) {
                // Node answer = DOMProcessing.applyXSLTtoDOM(dd, tf);
            // }
            // System.out.println("TimeX :" + System.currentTimeMillis());

            // System.out.println(DOMProcessing.DOMtoXML(answer));

            System.exit(1);

            for(int i = 0; i < 5; i++) 
            {
                // long time1 = System.currentTimeMillis();
                // String xslt = findXSLTQuery(q);
                // long time2 = System.currentTimeMillis();
                // Document result = DOMProcessing.applyXSLTtoDOM(dd, xslt);
                // System.out.println(DOMProcessing.DOMtoXML(result));
                // long time3 = System.currentTimeMillis();
                // System.out.println("First step = " + (time2 - time1) + " Second step = " + (time3 - time2));
            }

            System.exit(0);


            // System.out.println(findHighestUpReferenceInQuery(q));


            q = "a[@id='xyz']/b[@id='y']/c/d[@id='bac']";
            System.out.println(getIPAddressOfLongestNonbrachingPrefix(q));
            System.exit(1);

            String q2 = "a/b/";
            System.out.println(modifyQueryToSendToChild(q, q2));
            System.exit(1);

            findXSLTQuery(q, true);
            System.exit(1);

            Expr parsetree = XPathQueryParser.parsequery( q );
            System.out.println("Parsed Expression ==> " + parsetree);

            RelationalExpr ex = (RelationalExpr)((LocationPath) parsetree).getStep(0).getPredicate(0);

            if(isConsistencyPredicate(ex)) 
            {
                System.out.println(getConsistencyPredicateModified(ex));
            }
            else 
            {
                System.out.println("Error");
            }
            System.exit(1);

            Utils.printClassName(ex.getExpr(0));
            Utils.printClassName(ex.getExpr(1));
            System.out.println(ex.getExpr(0));
            System.out.println(ex.getExpr(1));
            System.out.println(ex.getExpr(0).getOperator());
            System.out.println(ex.getExpr(1).getOperatorAsString());

            LocationPath lp1 = (LocationPath) ex.getExpr(0);
            Step st1 = lp1.getStep(0);
            System.out.println(st1);


            System.exit(1);

            System.out.println(deleteQueryAfterNode(q, "d"));

            System.out.println("Partial Query ==> " + ((LocationPath)parsetree).partialQuery(2,5));
            System.out.println("Partial Query ==> " + ((LocationPath)parsetree).partialQuery(2,3));
            System.out.println("Partial Query ==> " + ((LocationPath)parsetree).partialQueryBeginning(3));
            System.out.println("Partial Query ==> " + ((LocationPath)parsetree).partialQueryEnd(3));
            System.exit(1);
            System.out.println(modifyQuery("/a/b/c/d/e/f[a=b]/", "c"));
        } catch (Exception e) 
        {
            e.printStackTrace();
        }
        System.exit(1);

        if(args.length != 2) 
        {
            System.out.println("Usage: <query> <node_name>");
            System.exit(1);
        }

        try 
        {
            if(containsAllChildrenOfAChild(args[0], args[1])) 
            {
                System.out.println("The result of this query should be cacheable");
            }
            else 
            {
                System.out.println("The result of this query is not cacheable");
            }
        } catch (Exception e) 
        {
            e.printStackTrace();
            System.exit(1);
        }
    }
};


