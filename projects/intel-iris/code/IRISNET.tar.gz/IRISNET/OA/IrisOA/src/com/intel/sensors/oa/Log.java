/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;

import org.w3c.dom.Document;

/**
 * The class Debug includes all the debugging functionalities for
 * the DSAN application.  
 *
 * @author Suman Kumar Nath
 * @version %I%, %G%
 */

public class Log {
	static boolean useLog = false;
	
	static BufferedWriter bw = null;
	static int currDebugLevel;
	static int currErrorLevel;
	static int oaPortNumber;
	static boolean toStdOut = true, toReplayLog = false;
	static String myIP = null;
	static int myPort = 0;
	static String toIP;
	static int toPort;

	Log(String fName, int portNumber)
	{
		useLog = true;
		toStdOut = false;
		myPort = oaPortNumber = portNumber;
		setLogFile(fName, portNumber);
		myIP = Protocol.getLocalIP();
		
	}
	
	Log()
	{
		useLog = true;
		myIP = Protocol.getLocalIP();
		myPort = Protocol.getLocalPort();
		toStdOut = true;
		Date dt = new Date();
		System.out.println("OA Logging started at " + dt.toString() + "\n" );
	}

     
	public static void setReplayLog(String replayServerIP, String replayServerPort)
	{
		useLog = true;
		myIP = Protocol.getLocalIP();
		myPort = Protocol.getLocalPort();
		toIP = replayServerIP;
		toPort =Integer.parseInt(replayServerPort); 
	
		toReplayLog = true;
		System.out.println("Opened socket to ReplayLog server");
		
		
		// Log the OA creation event
		sendToReplayServer("REPLAY NODE " + Lamport.getClock() + " " + myIP + " " + myPort);  
	}
	
	public static void setDebugLevel(int i) 
	{
		currDebugLevel = i;
	}
	
	public static void setErrorLevel(int i)
	{
		currErrorLevel = i;
	}

	
	public  static void Debug(String s)
	{
		if (useLog == false)
			return;

		Date dt = new Date();
		if (toStdOut || (bw == null))
			System.out.println("Log.Debug(): OA_PORT: " + oaPortNumber + "  Time: " + dt.getTime() + " : " + s);
		else {
			try {
				String st = oaPortNumber + " " + dt.getTime() + " : " + s + "\n";
				bw.write(st, 0, st.length());
				bw.flush();
			} catch(IOException ioe) {
                            ioe.printStackTrace();
				System.out.println("Error in writing to log file");
			}
		}

	}

	public  static void Debug(int debugLevel, String s)
	{
		if (debugLevel > currDebugLevel)
			Debug(s);
	}

	public  static void Error(String s)
	{
		Debug(s);
	}

	public  static void Error(int errorLevel, String s)
	{
		if (errorLevel > currErrorLevel) 
			Error(s);
	}

	public static void setLogFile(String fName, int portNumber)
	{
		useLog = true;
		toStdOut = false;
                oaPortNumber = portNumber;
		try {
			if (bw != null)
				bw.close();
			bw = new BufferedWriter(new FileWriter(fName, true));
		} catch (IOException ioe) {
                    ioe.printStackTrace();
		}
		
	}

	public static void flushDebugFile(String s)
	{
		if (useLog == false)
			return;

		try {
			bw.flush();
		} catch (IOException ioe) {
                    ioe.printStackTrace();
		}
	}

	public static void logToStdOut()
	{
		toStdOut = true;
	}

	public static void logToFile()
	{
		useLog = true;
		toStdOut = false;
		if (bw == null) // no log file defined
			{
				Calendar cal = Calendar.getInstance(); 
				String fName = "dsan_log." + cal.get(Calendar.MONTH) + "." 
					+cal.get(Calendar.DAY_OF_MONTH) + "." + cal.get(Calendar.YEAR) + "_" + 
					cal.get(Calendar.HOUR_OF_DAY) + "." + cal.get(Calendar.MINUTE) + "." + cal.get(Calendar.SECOND);
				System.out.println("No log file defined. Using " + fName + 
							    " for logging"); 
				setLogFile(fName, 8888);
			}
	}
	
	
	public static int sendToReplayServer(String line, String IP, int port)
	{
		if (useLog == false)
			return -1;

		int retVal = -1;
		if (! toReplayLog) return -1;
		try {
			retVal =  Packet.send(line, IP, port);
		} catch (Exception ex) {
		}
		return retVal;
	}	

	public static int sendToReplayServer(String line)
	{
		return sendToReplayServer(line, toIP, toPort);	
	}

        // this is a _very static_ mapping... will only work for the demo .. should really move this to the 
        // replay server
        private static String[] mapping_1 = new String[] {
            "Pittsburgh.Allegheny.PA.",
            "Oakland.Pittsburgh.Allegheny.PA.",
            "1.Oakland.Pittsburgh.Allegheny.PA.",
            "2.Oakland.Pittsburgh.Allegheny.PA.",
            "3.Oakland.Pittsburgh.Allegheny.PA.",
            "Shadyside.Pittsburgh.Allegheny.PA.",
            "1.Shadyside.Pittsburgh.Allegheny.PA."
        };

        private static String[] mapping_2 = new String[] {
            "10.212.3.211",
            "10.212.3.217",
            "10.212.3.160",
            "10.212.3.176",
            "10.212.3.163",
            "10.212.3.27",
            "10.212.3.93"
        };

        private static String[] mapping_3 = new String[] {
            "black",
            "red",
            "green",
            "brown",
            "blue",
            "gray",
            "yellow"
        };


	/** Send a message to the replay server claiming ownership */
	public static void claimOwnershipWithTheReplayServer(Document doc) {
		if (useLog == false)
			return;

		String local_ip = Protocol.getLocalIP();
		String colorhere = null;
		for(int j = 0; j < mapping_2.length; j++) {
			if(mapping_2[j].equals(local_ip)) {
				colorhere = mapping_3[j];
			}
		}
		
		
		String[] ownedHostNames = DOMProcessing.findAllOwnedHostNames(doc);
		for(int i = 0; i < ownedHostNames.length; i++) {
			if(ownedHostNames[i].indexOf("NE") > 0) {
				String matchingip = null;
				String s = ownedHostNames[i].substring(0, ownedHostNames[i].indexOf("NE"));
				System.out.println(s);
				for(int j = 0; j < mapping_1.length; j++) {
					if(mapping_1[j].equals(s)) {
						matchingip = mapping_2[j];
					}
				}
				
				if(matchingip != null) {
					Log.sendToReplayServer("REPLAY COLOR " + Lamport.getClock() + " " + matchingip + " " + colorhere);
				}
			}
		}
	}
	
	public static String failedOPsLogFile = "failedOps.log";
	private static FileWriter failedFW = null; 
	private static BufferedWriter failedBW = null;

	public static synchronized void logFailedOperation(String command)
	{
		if (failedBW == null) {
			try {
				failedFW = new FileWriter(failedOPsLogFile, true); //append data
				failedBW = new BufferedWriter (failedFW);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		try {
			Date now = new Date();
			String dateString = "#"  + now.toString() + "\n";
			failedBW.write(dateString, 0, dateString.length());
			failedBW.write(command, 0, command.length());
			failedBW.newLine();
			failedBW.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}

	// saves a string to a file. The old content of the file 
	// gets rewriten
	public static void saveInFile(String fName, String data) {
		try {
			FileWriter fw1 = new FileWriter(fName);
			BufferedWriter bw1 = new BufferedWriter(fw1);
			
			bw1.write(data, 0, data.length());
			
			bw1.flush();
			fw1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void shutdownlogger() {
        Log.sendToReplayServer("REPLAY SHUTDOWN");
		try {
			failedBW.flush();
			failedFW.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

	public static void appendLog(String logFile, String line)
	{
		if (!Globals.DebugON) return;

		
		try {
			FileWriter f = new FileWriter(logFile, true); //append data
		    BufferedWriter b = new BufferedWriter (f);
			b.write(line, 0, line.length());
            b.newLine();
            b.flush();
			f.close();
		} catch(Exception e) {
		}
	}

	public static void printRed(String st)
	{
   	 	System.out.println("[31m" + st + "[0m");	
	}

	public  static void printGreen(String st)
    	{
        	System.out.println("[32m" + st + "[0m");
    	}

}
