package com.intel.utils;

import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.stevesoft.pat.*;

import com.intel.sensors.oa.Log;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;

import com.intel.sensors.oa.*;
import org.w3c.dom.Document;

/** Job of this is to listen on a port ... can't think of any other way 
 *  to see if any data is being received by the client aksing a query.
 *
 *  @author Suman
 *  */
public class CannedQueries_threads
 {
     private static boolean DebugON = false;
     private final String logFileName = "access.log";
     private static BufferedWriter logbw = null;

     static void DEBUG(String st)
     {
	 if (DebugON)
	     System.out.println(st);
     }

     public CannedQueries_threads() {
	 try {
	     logbw = new BufferedWriter(new FileWriter(logFileName, true));
	 } catch (Exception e) {
	     e.printStackTrace();
	 }
     }

     public static synchronized void writeLog(String st) {
	 try {
	     java.util.Date d = new java.util.Date();
	     String s = d.toString() + " " + st;
	     logbw.write(s, 0, s.length());
	     logbw.newLine();	
	     logbw.flush();
	 } catch (Exception e) {};
     }

    private static String replaceAll(String src, String original, String replacement) {
	int index, last = 0;
	String result = "";
	while ( (index = src.indexOf(original, last)) >= 0) {
	    if (index >0)
		result += src.substring(last, index);
	    result += replacement;
	    last = index + original.length();
	}
	if (src.length() >= last) {
	    System.out.println("Here " + src.length() + ":" + last);
	    result += src.substring(last, src.length());
	}
	return result;
    }  

    public static ServerSocket getListenSocket() {
	ServerSocket sock;
        try {
            sock = new ServerSocket(0);
	    sock.setSoTimeout(60000); // 60 secs timeout	
        } catch (Exception e) {
            e.printStackTrace();
            //System.exit(1);
	    return null;
        }
	
	return sock;
    }

    
    public static String listenToAndReceiveAMessage(ServerSocket listenServersocket) {
        try {
            Socket s = listenServersocket.accept();
	    DataInputStream inStream = new DataInputStream(s.getInputStream());
	    System.out.println("Waiting for response..");
            //Thread.sleep(300);
	    while (inStream.available() == 0) ;	
            String result = null;
	    	
            if(inStream.available() != 0) {
                result = Packet.receive(inStream);
		System.out.println("Response received");
            } else {
                result = "<noresults/>";
		System.out.println("No response received... giving up.");
            }
	    inStream.close();
            s.close();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
	    return "<error> Operation Time Out </error>";	
        }
        //return null;
    }

    /** This accepts the initial request from the form */
    public static void run_http_server(int port) {
        ServerSocket httpServersocket = null;
        try {
            httpServersocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
	
        while(true) {
            Socket s = null;
            try {
  
                s = httpServersocket.accept();
                System.out.println("Got a new connection... listening");
                
                ProcessRequest req = new ProcessRequest(s);
		req.start();
            } catch (Exception e) {
                e.printStackTrace();
		System.out.println("Continueing");
            }
        }
    }

    private static class ProcessRequest extends Thread
    {
	Socket s;
	boolean errorFlag = false;
	static long id = 0;

	static String XSLT1 = "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">" +
	    "<xsl:output method=\"xml\" omit-xml-declaration=\"yes\"/> <xsl:template match=\"METRIC\"> <xsl:if test=\"self::node()[";

	static String XSLT2 = "]\"> <xsl:copy>" + 
	    "<xsl:apply-templates select=\"@*|node()\"/>" +
	    "</xsl:copy></xsl:if></xsl:template>";

	static String XSLT3 = "<xsl:template match=\"@*|node()\"> <xsl:copy>" +
	    "<xsl:apply-templates select=\"@*|node()\"/></xsl:copy></xsl:template></xsl:stylesheet>";


	public ProcessRequest(Socket _s) {
	    s = _s;
	}

	public void run() 
	{
	    String requestString = null, fromIrisNet = "";
	    String xpath = "NONE";
	    try {
		InputStreamReader isr = new InputStreamReader(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		BufferedReader br = new BufferedReader(isr);
		requestString = br.readLine();
				
		System.out.println("request String: " + requestString);
		StringTokenizer tokens = new StringTokenizer(requestString, " ");
		String command = tokens.nextToken();

		if (command.equalsIgnoreCase("ping")) {
		    dos.writeBytes("pong");
		    dos.write(0);
                    dos.flush();
		    dos.close();
                    s.close();
		} else if (command.equalsIgnoreCase("query")) {
		    xpath = tokens.nextToken(""); 
		
		    DEBUG("XPATH Query from browser: " + xpath);
			
		    //1.  create a socket to listen from irisnet 
		    ServerSocket listenSock = getListenSocket();
		    // 2. send the query to irisnet
		    String LCA = QueryAnalysis.getLongestNonbrachingPrefix(xpath);
		    String dstHost = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath);
		    Protocol.sendQueryMessageWithPort(""+(id++), listenSock.getLocalPort(), 
						      dstHost, 6788, xpath, -1, 
						      QueryAnalysis.getRoot(xpath), LCA, false);
		    
		    // 3. receive the response from irisnet
		    fromIrisNet = listenToAndReceiveAMessage(listenSock);
		    ParsedMessage pm = Protocol.parseIncomingMessage(fromIrisNet);
		    
		    DEBUG("********** RESPONSE ************");
		    DEBUG(pm.response);
		    
		    String _response = pm.response;
		    Document doc = DOMProcessing.XMLtoDOM(_response);
		    
		    // filter out the METRICs not in the query
		    int predicateStart = xpath.indexOf("METRIC[@NAME") + 7;
		    if (predicateStart >=7 ) {
			int predicateEnd = xpath.indexOf("]", predicateStart);
			String predicate = xpath.substring(predicateStart, predicateEnd);
			String XSLT = XSLT1 + predicate + XSLT2 + XSLT3;
			DEBUG("XSLT: " + XSLT);
			//_response = ApplyXSLTtoString.applyXSLTToString(pm.response, XSLT).toString();
			doc = DOMProcessing.applyXSLTtoDOM(doc, XSLT);
		    }
		    
		    
		    DOMProcessing.myNormalize(doc);
		    DOMProcessing.orderByIDs(doc);
		    
		    // get rid of unnecessary results
		    //System.out.println("Before trim: " + DOMProcessing.DOMtoXML(doc));
		    //Document doc2 = DOMProcessing.applyFileXSLTtoDOM(doc, "trim.xsl");
		    //System.out.println("After Trim: " + DOMProcessing.DOMtoXML(doc2));
		    String next_to_final_response = DOMProcessing.DOMtoXML(DOMProcessing.applyFileXSLTtoDOM(doc, "my2html-5.xsl"));
		    DEBUG("after XSLT: \n" + next_to_final_response);
		    
		    StringBuffer final_response = new StringBuffer(next_to_final_response);
		    
		    int insert_at = next_to_final_response.indexOf("<font");
		    
		    if (insert_at >= 0) {
			// must insert in reverse order; otherwise need to keep on updating insert_at
			final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query Answer :</b> </font>" + "<br>");
			
			// insert the query starting point; modified
			//String startingpoint = QueryAnalysis.getIPAddressOfLongestNonbrachingPrefix(xpath);
			//startingpoint = startingpoint.substring(0, startingpoint.indexOf("irisnet5ROOT"));
			//startingpoint = startingpoint + "dsan.net";
			//final_response.insert(insert_at, "<font color=\"#0000ff\"><b> Query :" + 
			//		      " </b></font> /planetlab" + xpath.substring(9, xpath.length()) + "<br><br>");
			
			DEBUG("Final Response: " + final_response);
			
			dos.writeBytes(final_response.toString());
		    } else {
			dos.writeBytes("<html><head><body>Empty Answer</body>");
			errorFlag = true;
		    }
		    dos.write(0);
		    dos.flush();
		    //Thread.sleep(100);
		    dos.close();
		    s.close();
		    //Log.shutdownlogger();
		}
            } catch (Exception e) {
                e.printStackTrace();
                try { 
                    DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                    dos.writeBytes("<html><head><body>Error: " + fromIrisNet + "</body>");
                    dos.write(0);
                    dos.flush();
                    Thread.sleep(100);
                    dos.close();
                    s.close();
                } catch (Exception ee) {
                }
		System.out.println("Continueing");
		errorFlag = true;
            }

	    CannedQueries_threads.writeLog(s.getInetAddress().toString() + " " + xpath + " " + (errorFlag? "ERROR" : "OK"));
	    System.out.println("Done processing request");
	} // run


    } // class

    public static void main(String[] args) {
	CannedQueries_threads cq = new CannedQueries_threads();
	ConfigurationManager CM = ConfigurationManager.instance();
	CM.loadConfiguration(args[0]);
	CM.printConfiguration();

	// start the heartbeat server
	if (!CM.getHBIP().equals("0.0.0.0")) {
	    HeartBeat hb = new HeartBeat(CM.getHBIP(), CM.getHBPort(), CM.getHBPeriod());
	    Thread t1 = new Thread(hb);
	    t1.start();
	}

        try {
            //Log.setReplayLog("10.212.3.211", "5678");
	
            com.intel.sensors.oa.Protocol.myPortNumber = Integer.parseInt(args[1]);

            //cq.startListener(com.intel.sensors.oa.Protocol.getLocalPort());
            cq.run_http_server(Integer.parseInt(args[0]));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};
