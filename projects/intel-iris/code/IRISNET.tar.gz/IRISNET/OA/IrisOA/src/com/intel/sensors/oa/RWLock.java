/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.io.*;
import java.util.*;

// RWLock: Read Write lock implementation 
//
// RWLock allows multiple threads to acquire a read lock 
// provided no other thread currently has a write lock on 
// the same object. A thread can acquire a write lock if no 
// other thread owns either a read lock or a write lock. 

public class RWLock
{
    // givenLocks represents the number of threads holding the read lock; 
    // it will be -1 if there is a write lock and zero if no thread is 
    // holding the lock. 
    private int givenLocks;
    
    // waitingWriters represnts the number of threads waiting to grab the lock
    // Used to give preference to the writer threads over reader ones
    // a reader thread can grab the lock only if waitingWrites is 0
    private int waitingWriters;    
  
    // Variable mutex is used to synchronize access to the RWLock object.
    private Object mutex;
    
    
    public RWLock()
    {
	mutex = new Object();
	givenLocks = 0;
	waitingWriters = 0;
    }
    

    // Methods getReadLock() and getWriteLock() will return immediately with 
    // a lock or else block the calling thread until the lock is available. 
    // Our implementation of RWLock class will give preference to the waiting 
    // writer threads over the readers, through the variable RWLock.waitingWriters. 
    // That means if we have two threads waiting to acquire the lock, the one 
    // waiting for write lock will get the lock first. You can modify the code 
    // to give preference to readers also. 

    public void getReadLock()
    {
	synchronized(mutex)
	    {
		try
		    {
			while((givenLocks == -1) || (waitingWriters != 0))
			    {
				mutex.wait();
			    }
		    }
		catch(java.lang.InterruptedException e)
		    {
			System.out.println("Exception in RWLock: " + e);
		    }
		
		givenLocks++;
	    }
    }
    
    public void getWriteLock()
    {
	synchronized(mutex)
	    {
		waitingWriters++;
		try
		    {
			while(givenLocks != 0)
			    {
				mutex.wait();
			    }
		    }
		catch(java.lang.InterruptedException e)
		    {
			System.out.println("Exception in getWriteLock: " + e);
		    }
		
		waitingWriters--;
		givenLocks = -1;
	    }
    }
    
    
    public void releaseLock()
    {	
	synchronized(mutex)
	    {
		if(givenLocks == 0)
		    return;
		
		if(givenLocks == -1)
		    givenLocks = 0;
		else
		    givenLocks--;
		mutex.notifyAll();
	    }
    }
    
    
}



