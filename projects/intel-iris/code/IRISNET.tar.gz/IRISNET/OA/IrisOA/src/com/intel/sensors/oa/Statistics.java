/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.net.*;
import java.util.*;
import org.w3c.dom.Document;

public class Statistics {
	private static final long _flushInterval = 30000; // in milliseconds
	private static long _lastFlushed;
	private static double _bytesSent;
	private static double _bytesReceived;
	private static BufferedWriter _bw = null; 

	/**
	 * Set up the manager instance to follow the singleton pattern.
	 */
	private static final Statistics INSTANCE = new Statistics();
	
	public static Statistics instance() {
		return INSTANCE;
	}
	Statistics() {
		init();
	}

	public static final void init() {
		String _logFile = "IrisStat.log";
                File _file;

                System.out.println("Calling Stat constructor");
                _bytesSent = _bytesReceived = 0;

                //for (int i = 0; i < 10; i++) {
                //        _logFile = "IrisStat" + i + ".log";
                //        _file = new File(_logFile);
                //        if (!_file.exists()) break;
                //}
                try {
                        _bw = new BufferedWriter(new FileWriter(_logFile, true));
                } catch (IOException ioe) {
                        System.out.println("Stat file could not be opened\n");
                }
                _lastFlushed = System.currentTimeMillis();

	}


	
	public  void resetStat() {
		System.out.println("Resetting stats..");
		_bytesSent = _bytesReceived = 0;
		_lastFlushed = System.currentTimeMillis();
	}

	/************************************************************
	 * Communication stats 
	 ************************************************************/
	public void bytesReceived(double bytes)
	{
		_bytesReceived += bytes;
		if ( System.currentTimeMillis() > (_lastFlushed + _flushInterval))
			writeStat();
		
	}

	public void bytesSent (double bytes)
	{
		_bytesSent += bytes;
		if ( System.currentTimeMillis() > (_lastFlushed + _flushInterval))
                        writeStat();

	}

	public void writeStat() {
		System.out.println("Writing stats");
		_lastFlushed = System.currentTimeMillis();
		String _msg = "[" + _lastFlushed + "]: bytesSent: " + _bytesSent + " bytesReceived: " + _bytesReceived + "\n";
		if (_bw == null)
			init();
		try {
			_bw.write(_msg);
			_bw.flush();
		} catch (IOException ioe) {
			System.out.println("Error in writing stats to the log file");
		}
	} 

	/**********************************************************
	 * Database stat
	 **********************************************************/

	// The class LoadStatistics keep track of the read and write load 
	// of node, document, or an OA
	private class LoadStatistics {
		double readLoad;
		long lastRead; // timestamp of last read

		double writeLoad;
		long lastWrite; // timestamp of last write

		long size; // in bytes. makes sense only for the whole document
		int ownedNodeCount; // used only for the whole document

		public LoadStatistics()
		{
			readLoad = writeLoad = 0;
			size = 0;
			ownedNodeCount = 0;
			lastRead = lastWrite = System.currentTimeMillis();
		}

		public void updateReadLoad(int count)
		{
			long current = System.currentTimeMillis();
			readLoad += count;
			
			lastRead = current;
		}

		public void updateWriteLoad(int count)
		{
			long current = System.currentTimeMillis();
			writeLoad += count;
			
			lastWrite = current;
		}

		public void updateSize(long newSize)
		{
			size = newSize;
		}

		public void updateNodeCount(int count) 
		{
			ownedNodeCount = count;
		}

		public void printLoad() 
		{
			if (readLoad > 0)
				System.out.println("\tRead load: " + readLoad);
			if (writeLoad > 0)
				System.out.println("\tWrite load: " + writeLoad);
			if (ownedNodeCount > 0)
				System.out.println("\tOwned Node Count: " + ownedNodeCount);
			if (size > 0)
				System.out.println("\tTotal size: " + size);
		}

	}
	
	LoadStatistics myLoad = new LoadStatistics(); // aggreaget load of the OA

	// For performance reason, hashtable size should be a prime number 
	// with a few prime "2n+1" expansion
	static Hashtable ownedDocuments = new Hashtable(11); 	
	static Hashtable ownedNodes = new Hashtable (89);

	// The OA should remember the new owner of the delegated nodes
	// this can be used to provide hints to the OAs who still think
	// this OA is the owner of the delegated node (because of DNS caching).
	// Currently, an OA provides hints only when it receives a query for a 
	// node it does not own any more
	static Hashtable delegatedNodes = new Hashtable(89);
	

	public final void initOwnedNodes()
	{
		DatabaseInterface db = Globals.getDatabase();
		String docs[] = db.listDocuments();
		
		for (int i = 0; i< docs.length; i++) {
			System.out.println("Document: " + docs[i]);
			Document doc = db.getDocumentWithID(docs[i]);
			String hosts[] = DOMProcessing.findAllOwnedHostNames(doc);
			addOwnedNodes(hosts);
		}
	}

	// Removes the owned nodes from the list (because the nodes 
	// have been delegated out)
	public final void removeOwnedNodes(String[] hosts) {
		for (int i = 0; i < hosts.length; i++) {
			System.out.println("\t[Statistics]: removing owned node: " + hosts[i]);
			ownedNodes.remove(hosts[i]);
		}
	}

	// removes the owned nodes, plus remembers the new owner's IP
	public final void removeOwnedNodes(String[] hosts, String newOAIP) {
		for (int i = 0; i < hosts.length; i++) {
			System.out.println("\t[Statistics]: removing owned node: " + hosts[i]);
			ownedNodes.remove(hosts[i]);
			delegatedNodes.put(hosts[i], newOAIP);
		}

		// set a timer to remove the delegated nodes after DNS_TTL time
		Timer timer = new java.util.Timer(true);
		final String[] tmpHosts = hosts;
		timer.schedule(new java.util.TimerTask() {
				public void run() {
					for (int j = 0; j < tmpHosts.length; j++) {
						System.out.println("Forgetting owner of " + tmpHosts[j]);
						delegatedNodes.remove(tmpHosts[j]);
					}
				}
			}, (long) ConfigurationManager.instance().getDNSTTL() * 1000);
	}
   

	public final void addOwnedNodes(String[] hosts) {
		for (int j = 0; j< hosts.length; j++) {
			System.out.println("\t[Statistics]: Owned: " + hosts[j]);
			ownedNodes.put(hosts[j], new LoadStatistics());
		}
	}

	public final void initOwnedDocuments()
	{
		DatabaseInterface db = Globals.getDatabase();
		String docs[] = db.listDocuments();
		
		addOwnedDocuments(docs);
	}
	
	public final boolean isOwnedNode(String nodeName){
		if (ownedNodes.get(nodeName) == null) return false;
		return true;
	}

	public final Object getNewOwner(String nodeName) {
		return delegatedNodes.get(nodeName);
	}

	public final void addOwnedDocuments(String doc) 
	{
		String docs[] = {doc};
		addOwnedDocuments(docs);
	}

	public final void addOwnedDocuments(String[] docs) 
	{
		DatabaseInterface db = Globals.getDatabase();
		for (int i = 0; i< docs.length; i++) {
			System.out.println("Document: " + docs[i]);
			LoadStatistics stat = new LoadStatistics();						
			Document doc = db.getDocumentWithID(docs[i]);
			String hosts[] = DOMProcessing.findAllOwnedHostNames(doc);
			stat.updateNodeCount(hosts.length);
			stat.updateSize(DOMProcessing.DOMtoXML(doc).length());
			ownedDocuments.put(docs[i], stat);
		}
	}

	public final void removeOwnedDocuments(String doc) {
		String docs[] = {doc};
		removeOwnedDocuments(docs);
	}

	public final void removeOwnedDocuments(String[] docs) 
	{
		for (int i = 0; i< docs.length; i++) {
			ownedDocuments.remove(docs[i]);
		}
	}

	public final void updateReadLoad(Document doc) 
	{
		String hosts[] = DOMProcessing.findAllOwnedHostNames(doc);
		LoadStatistics node;
		int i;
		for (i = 0; i < hosts.length; i++) {
			node = (LoadStatistics)ownedNodes.get(hosts[i]);
			node.updateReadLoad(1);
		}
		myLoad.updateReadLoad(i);
	}
   
	public final void updateWriteLoad(Document doc) 
	{
		String hosts[] = DOMProcessing.findAllOwnedHostNames(doc);
		LoadStatistics node;
		int i;
		for (i = 0; i < hosts.length; i++) {
			node = (LoadStatistics)ownedNodes.get(hosts[i]);
			node.updateWriteLoad(1);
		}
		myLoad.updateWriteLoad(i);
	}

	public final void printLoad()
	{
		System.out.println("OA Load: ");
		System.out.println("++++++++++++++++++++++++");
		myLoad.printLoad();

		System.out.println("My Documents: ");
		System.out.println("++++++++++++++++++++++++");
		Enumeration e1 = ownedDocuments.keys();

		while (e1.hasMoreElements()) {
			Object docName = e1.nextElement();
			System.out.println(docName.toString());
			LoadStatistics stat = (LoadStatistics)ownedDocuments.get(docName);
			stat.printLoad();
		}

		System.out.println("My Owned Nodes: ");
		System.out.println("++++++++++++++++++++++++");
		Enumeration e2 = ownedNodes.keys();

		while (e2.hasMoreElements()) {
			Object nodeName = e2.nextElement();
			System.out.println(nodeName.toString());
			LoadStatistics stat = (LoadStatistics)ownedNodes.get(nodeName);
			stat.printLoad();
		}
	}
}
