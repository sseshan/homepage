/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
   IrisNet 1.1
   An Internet-scale Resource-Intensive Sensor Network

   Copyright (c) 2002-2003, Intel Corporation
   All Rights Reserved

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions are
met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * Neither the name of Intel nor the names of its contributors may
 be used to endorse or promote products derived from this software 
 without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
package com.intel.sensors.oa;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import java.util.StringTokenizer;

/** 
 *  Top level ResponseActionEntry. Basically acts as a redirector to QueryResponseActionEntry's.
 *  
 *  @author Amol 
 */
public class OALevelResponseActionEntry extends ResponseActionEntry {
    /** List of ResponseActionEntry's for pending queries. */
    private static ResponseActionEntry[] managedQueries = new ResponseActionEntry[(ConfigurationManager.instance()).getMaxQueries()];

    OALevelResponseActionEntry() {
		super();
    }
	
	/** Process a response. */
    public void processResponse(ParsedMessage pm) 
    {
        StringTokenizer st = new StringTokenizer(pm.queryID, ":");

        int minusone = Integer.parseInt(st.nextToken());

        Utils.myassert(minusone == -1);

        int queryID = Integer.parseInt(st.nextToken());

        System.out.println(queryID + "          " + pm.queryID);

        managedQueries[queryID].processResponse(pm, st);

        /* If the ResponseActionEntry is done, remote it. */
        if(managedQueries[queryID].doneProcessing()) {
            managedQueries[queryID] = null;
        }
    }

    /** Done processing ? */
    public boolean doneProcessing()
    {
        for(int i = 0; i < (ConfigurationManager.instance()).getMaxQueries(); i++) 
        {
            if(managedQueries[i] != null)
                return false;
        }
        return true;
    }

    /** Return the final answer. This is always a document. */
    public Document getFinalAnswer() 
    {
        Utils.shouldnthappen();
        return null;
    }

    /** Add a new query */
    public void addQuery(ResponseActionEntry rae) 
    {
        // find the first null entry
        for(int i = 0; i < (ConfigurationManager.instance()).getMaxQueries(); i++) 
        {
            if(managedQueries[i] == null) 
            {
                managedQueries[i] = rae;
                rae.setParent(this);
                rae.setUniqueID(i);
                return;
            }
        }

        System.out.println("Way too many pending queries... exiting");
        System.exit(1);
    }

    /** Remove a new query */
    public void removeQuery(ResponseActionEntry rae) 
    {
        managedQueries[rae.getUniqueID()] = null;
    }

	/** Purge the query entries who are sitting here for 
		a long time.
		Added by Suman
	**/
	public void purgeQueries(long ageMillis)
	{
		int MaxQueries = (ConfigurationManager.instance()).getMaxQueries();
		long now = System.currentTimeMillis();
		
		for (int i = 0; i < MaxQueries; i++)
			{
				if  ( (managedQueries[i]!= null) &&
					  ( (now - managedQueries[i].getCreationTime()) > ageMillis)) {
					System.out.println("Purging old queries...");
					managedQueries[i] = null;
				}
			}
		
	}
	
}
