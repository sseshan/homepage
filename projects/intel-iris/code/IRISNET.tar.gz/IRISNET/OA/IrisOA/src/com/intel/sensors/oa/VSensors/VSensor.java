/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network

             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

      * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

      * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa.VSensors;


import HTTPClient.*;
import java.io.*;
import java.util.*;

public class VSensor {

	class Configuration {
		public String hostName; // name of this host
		public String xpath; // xpath defining the logical node to be updated
		public String rootNode;
		public String nodeName; // logical name of this node
		public long sleepTime = 600; // period of update
		public boolean everythingOK = true;

		public Configuration(String confFile) {
			try {
				FileReader fr = new FileReader(confFile);
				BufferedReader br = new BufferedReader(fr);
				String line;
				while ( (line = br.readLine()) != null) {
					if (line.startsWith("#")) continue;
					line.trim();
					if (line.length() == 0) continue; // empty line
					
					int pos = line.indexOf('=');
					String attr = line.substring(0, pos).trim();
					String value = line.substring(pos+1).trim();

					if (attr.equalsIgnoreCase("HOSTNAME"))
						hostName = value;
					else if (attr.equalsIgnoreCase("NODENAME"))
						nodeName = value;
					else if (attr.equalsIgnoreCase("XPATH")) {
						xpath = value;
						StringTokenizer tokens = new StringTokenizer(value, " /");
						rootNode = tokens.nextToken();
					}
					else if (attr.equalsIgnoreCase("SLEEPTIME"))
						sleepTime = Long.parseLong(value);
					else
						System.out.println("Unknown attribute " + attr + " in " + confFile);

				}
			} catch (Exception e) {
				everythingOK = false;
				e.printStackTrace();
			}
		} // constructor

		public String toString() {
			return "HostName: " + hostName + ", XPath: " + xpath + ", NodeName: " + nodeName
				+ ", SleepTime: " + sleepTime;
		}
    } // class Configuration

	public Configuration conf = null;

    public static String simpleGet(String _uri) {
        try {
            URI uri = new URI(_uri);

            HTTPConnection con = new HTTPConnection(uri);
            HTTPResponse rsp = con.Get(uri.getPath(), uri.getQueryString());
            if (rsp.getStatusCode() >= 300) {
                System.err.println("Received Error: "+rsp.getReasonLine());
                System.err.println(rsp.getText());
                return "";
            } else {
                String data = rsp.getText();
                con.stop();
                return data;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

	// the following function performs the following tasks:
	// (1) Collects data from the sensors
	// (2) Sends the xupdates to the OAs
	// updates can be periodic, can be triggered
	// The method should run as a seperate thread
	// needs to be implemented seperately for each VSensor 
    public void scheduleAcquisition() 
    {
		System.out.println("Not implemented");
    }

	// returns a new snapshot of the sensor data 
	public String toString() {
		return "Not implemented";
	}

	// returns a well-formed xupdate query
	public String toXupdate() {
		return "Not implemented";
	}
	
	public String toXUpdate(String sensedData) {
		return "Not implemented";
	}
}
