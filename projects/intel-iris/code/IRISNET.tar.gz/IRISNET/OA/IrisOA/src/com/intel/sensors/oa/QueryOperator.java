/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.io.*;
import java.util.*;

// sixpath
import de.fzi.XPath.*;

// dom
import org.w3c.dom.*;

// xslt transformer
import javax.xml.transform.*;

// ---------------------------------------------------------------------
//                         class QueryOperator
// ---------------------------------------------------------------------

/** QueryOperator class implements the super class for the dynamic
 *  query operators.  The query operators form a query evaluation tree
 *  for the distributed XPath query.  The operator tree is also used in 
 *  continuous query processing to remember current partial results and 
 *  produce a final result asap when there is a change.
 *
 *  @author Shimin
 */
public class QueryOperator {

  // ---
  // static members
  // ---
  static final boolean QueryOperator_debugging = false;

  public static final int RESULT_SUBTREE = 0;
  public static final int RESULT_NODE    = 1;
  public static final int RESULT_TEXT    = 2;
  public static final int RESULT_ATTR    = 3;
  public static final int RESULT_STRING  = 4;
  public static final int RESULT_UNKNOWN = -1;
  public static final int RESULT_MIN     = RESULT_UNKNOWN;
  public static final int RESULT_MAX     = RESULT_STRING;
  public static final int RESULT_ERROR   = -2;	// only used in packets

  public static final String var_prefix  = "IrIsVar";
  public static final String inter_suffix= "_InterVal";
  public static final String stored_query= "stored_query";

  public static final String query_stopnodes = 
			"descendant-or-self::node()[./stopnode]";
  public static final String query_asksubquery = 
			"descendant-or-self::node()[./asksubquery]";

  public static final String[] empty_string_output = new String[0];
  private static NodeList empty_node_list = null;

  // must be called after SPUtils.init (...)
  public static NodeList emptyNodeList ()
  {
	if (empty_node_list == null) {
	  empty_node_list = getResultNodeList (SPUtils.simple_dom);
	}
	return empty_node_list;
  }

  public static boolean isResultTree (int result_type)
  {
	return ((result_type==RESULT_NODE) || (result_type==RESULT_SUBTREE));
  }

  public static boolean isResultString (int result_type)
  {
	return (result_type >= RESULT_TEXT);
  }

  public static String getResultTypeName (int result_type)
  {
	switch (result_type) {
	case RESULT_SUBTREE:	return "RESULT_SUBTREE";
	case RESULT_NODE:	return "RESULT_NODE";
	case RESULT_TEXT:	return "RESULT_TEXT";
	case RESULT_ATTR:	return "RESULT_ATTR";
	case RESULT_STRING:	return "RESULT_STRING";
	case RESULT_UNKNOWN:	return "RESULT_UNKNOWN";
	default:		return "Illegal result type";
	}
  }

  // get the node list from result
  // the result node is marked by xslt program
  // n is a node in the result tree
  public static NodeList getResultNodeList (Node n)
  {
	NodeList nl = null;

     try {
	nl = org.apache.xpath.XPathAPI.selectNodeList (n, query_stopnodes);
     } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
	return nl;
  }

  // map a result tree node to its counterpart in the original tree
  public Element mapNodetoOriginalTree (Element n)
  {
	String query = QueryUtils.findQueryForThisElement (n);
	int slash = query.indexOf ('/');
	if (slash != -1) {
	  // remove the root element part 
	  query = query.substring (slash+1, query.length());
	}
	else {
	  // ask for the root element itself
	  return (Element) query_info.root;
	}

	Element new_n = null;
    try {
	new_n = (Element) org.apache.xpath.XPathAPI.selectSingleNode (
			query_info.root, query);
    } catch (Exception e) {
	Utils.error ("Can't map a node to the original tree!");
    }

	return new_n;
  }

  // get String from String[]
  // If there is a single string in the array, return the string itself.
  // For multiple strings, we return a comma separated list.
  public static String getResultString (String[] res)
  {
	if (res.length == 1) {
	  return res[0];
	}
	else if (res.length > 0) {
	  int total = 1;
	  for (int ii=0; ii<res.length; ii++)
	     total += res[ii].length();
	  StringBuffer sb = new StringBuffer (total+res.length);
	  sb.append (res[0]);
	  for (int ii=1; ii<res.length; ii++) {
	     sb.append (',');
	     sb.append (res[ii]);
	  }
	  return sb.toString ();
	}
	else return "";
  }

  // Suppose user provided result type is RESULT_UNKNOWN
  // this method determines the query result type for xpath
  public static int determineResultType (Expr xpath)
  {
        // --- LocationPath ---
        if (xpath instanceof LocationPath) {
          LocationPath lp = (LocationPath) xpath;
	  if (lp.getStepsCount() == 0)
	    return RESULT_SUBTREE;

          if (lp.getStep(lp.getStepsCount()-1).getAxis() == Axis.ATTRIBUTE) {
                  return RESULT_ATTR;
          }
          else if (QueryUtils.lastStepIsStoredQuery(lp)!=null) {
                  return RESULT_STRING;
          }
          else {
                  return RESULT_SUBTREE;
          }
        }

        // --- FilterExpr ---
        else if (xpath instanceof FilterExpr) {
	   FilterExpr fe = (FilterExpr) xpath;

           xpath = fe.getPrimary ();

           // FunctionCall | Literal | Number
           if ((xpath instanceof FunctionCall)
             ||(xpath instanceof de.fzi.XPath.Literal)
             ||(xpath instanceof de.fzi.XPath.Number)) {
	     return RESULT_STRING;
           }
           // VariableReference
           else if (xpath instanceof Variable) {
	     return (fe.getLocationPath()!=null)?
		     determineResultType ((Expr) fe.getLocationPath()):
		     RESULT_SUBTREE;
           }
           // ( Expr )
           else {
	     return determineResultType (xpath);
           }
        }

        // --- ForExpr ---
        else if (xpath instanceof ForExpr) {
	  return determineResultType (((ForExpr)xpath).getReturnExpr());
        }

        // --- NaryExpr ---
        else {
	  Utils.error ("don't support direct relational or numerical"
                       +" operators\n" + xpath.toString());
	  // won't reach here
	  return RESULT_UNKNOWN;
        }
  }

  // ---
  // instance members
  // ---

  private QueryOperator   parent;
  private int             parent_index;  // which child of parent?
  private ArrayList       children;

  private   int             result_type = RESULT_UNKNOWN;
  protected int             lca_bound = -2;
  protected QueryInfo       query_info;

  // constructors
  public QueryOperator ()
  {
	parent = null;
	children = new ArrayList ();
  }

  // this constructor also adds the object into the child list of parent
  public QueryOperator (QueryOperator my_parent)
  {
	parent = my_parent;
	children = new ArrayList ();
	if (parent != null) {
	  parent_index = parent.addChild (this);

	  lca_bound = parent.lca_bound;
	  query_info = parent.query_info;
	}
  }

  // mutators and accessors
  public void setParent (QueryOperator my_parent, int pindex)
  {
	parent = my_parent;
	parent_index = pindex;
  }

  public QueryOperator getParent ()
  {
	return parent;
  }

  public int getParentIndex ()
  {
	return parent_index;
  }

  public int getChildCount ()
  {
	return children.size ();
  }

  public int addChild (QueryOperator a_child)
  {
	int index = -1;
	if (a_child != null) {
	  index = children.size ();
	  children.add (index, a_child);
	}
	return index;
  }

  public QueryOperator getChild (int index)
  {
	return (QueryOperator) (children.get (index));
  }

  public void removeLastChild ()
  {
	QueryOperator ch = (QueryOperator) children.remove (children.size()-1);
	ch.parent = null;
  }

  public void removeAllChildren ()
  {
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++) {
	   getChild (ii).parent = null;
	}
	children.clear ();
  }

  public void setChild (int index, QueryOperator ch)
  {
	children.set (index, ch);
  }

  public void setResultType (int rtype)
  {
	result_type = rtype;
	if ((result_type < RESULT_MIN) || (result_type > RESULT_MAX)) {
	  System.err.println ("QueryOperator::setResultType error!");
	  Utils.shouldnthappen ();
	}
  }

  public int getResultType ()
  {
	return result_type;
  }

  public boolean isResultTree ()
  {
	return isResultTree (result_type);
  }

  public boolean isResultString ()
  {
	return isResultString (result_type);
  }


  // ---
  // virtual methods that should be implemented by the subclasses
  // ---

  // By default, call expandRemotely of all children
  void expandRemotely ()
  {
	// make recursive calls to children
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++)
	   getChild(ii).expandRemotely ();
  }

  // This must be overriden by sub classes
  // rewriting the operator subtree to propagate the SPInitComputeOperator
  // return true if result is ready, false otherwise
  boolean rewrite (SPInitComputeOperator s)
  {
	Utils.error ("QueryOperator::rewrite is called directly!");
	return false;
  }

  // By default, call terminate of all children
  void terminate ()
  {
	// make recursive calls to children
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++)
	   getChild(ii).terminate ();
  }

  void terminateLocally ()
  {
	// make recursive calls to children
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++)
	   getChild(ii).terminateLocally ();
  }

  // This must be overriden by sub classes
  // up call from children
  void resultReady (int which_child)
  {
	Utils.error ("QueryOperator::resultReady is called directly!");
  }

  // This must be overriden by sub classes
  Object getResult ()
  {
	Utils.error ("QueryOperator::getResult is called directly!");
	return null;
  }

  public String simpleClassName ()
  {
	String name = getClass().toString();
	if (name.startsWith ("class com.intel.sensors.oa."))
	  return name.substring (27);
	else
	  return name;
  }

  // print out the information about the QueryOperator
  void print ()
  {
	// 1. check parent - children relationship
	if (parent != null) {
	  if (parent.getChild (parent_index) != this) {
	    System.out.println ("parent pointer error!");
	  }
	}
	for (int ii=0; ii<getChildCount (); ii++) {
	   QueryOperator ch = getChild (ii);
	   if ((ch.parent != this)||(ch.parent_index != ii)) {
	     System.out.println ("child " + ii + " error!");
	   }
	}

	// 2. print information
	// System.out.print (simpleClassName () + ":");
	if (parent != null)
	  System.out.println ("parent=" + parent.simpleClassName() + " index=" +
			     parent_index);
	else 
	  System.out.println ("no parent");
	System.out.print ("context=" + query_info.queryForRoot());
	System.out.print (query_info.continuous?",continuous":",snapshot");
	System.out.print ("," + getResultTypeName(result_type));
	System.out.println (",lca_bound=" + lca_bound);
	System.out.println ("------------------------------------------------");

	// 3. call print for all children
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++)
	   getChild(ii).print ();
  }

  // -----------------------------------
  // testing

  public static BufferedReader stdin;

  static {
    if (QueryOperator_debugging) {
      if (true) {
        try {
          stdin = new BufferedReader(new InputStreamReader(System.in));
        } catch (Exception e) {
	  System.out.println ("Exception to create stdin");
        }
      } else {
	stdin = null;
      }
    }
  }

/*
  public static Object buildRoot (String root_at_node, String query, 
					  int rtype, long queryId)
  {
	System.out.println ("buildRoot(" + root_at_node + ", "
			     + query + ", "
			     + getResultTypeName (rtype) + ", "
			     + queryId + ")");
	System.out.println ("===============");

	RootOperator  r = new RootOperator ();
	boolean ret = r.setup (root_at_node, query, rtype, queryId);
	System.out.println ("finish root set up: " + ret);
	System.out.println ("===============");

	r.print ();
	System.out.println ("===============");

	System.out.print ("buildRoot finish local: go on?");
	try{
	  stdin.readLine ();
	} catch (Exception e) {
	  Utils.error ("readLine in buildRoot");
	}
	// -------------------------

	if (!ret) {
	  r.expandRemotely ();
          r.print ();
          System.out.println ("===============");
	  try{
	  stdin.readLine ();
	  } catch (Exception e) {
	  Utils.error ("readLine in buildRoot");
	  }
	}

	Object result = r.getResult ();

	System.out.println ("result:");
	if (result == null) {
	  System.out.println ("null");
	}
	else if (result instanceof Node) {
	  DOMProcessing.prettyPrint ((Node) result);
	  System.out.println (DOMProcessing.DOMtoXML ((Node) result));
	}
	else {
	  System.out.print ("(" + ((String[])result).length + ")=");
	  System.out.println (getResultString ((String[])result));
	}
	System.out.println ("===============");

	System.out.print ("buildRoot return: go on?");
	try{
	  stdin.readLine ();
	} catch (Exception e) {
	  Utils.error ("readLine in buildRoot");
	}
	// -------------------------

	return result;
  }

  public static Document getDocumentWithID (String root_element_tag, 
					    String root_at_query)
  {
	System.out.println ("getDocumentWithID (" + root_element_tag
			   + ", " + root_at_query + ")");
	Document doc = null;

    try {
	String filename = stdin.readLine ();
	doc = DOMProcessing.fileToDOM (filename);
	System.out.println ("reading " + filename + " successful");
	System.out.println ("===============");
    } catch (Exception e) {
	Utils.error ("getDocumentWithID: " + e.getClass().toString()
		+ ':' + e.getMessage ());
    }
	return doc;
  }
*/

  public static void main (String args[])
  {
   try {
      String[] urls = new String[1];
      urls[0] = "file:///tmp/test/";
      SPUtils.init (urls);

	// get params to call buildRoot
	String root_at_node, query;
	int    rtype;
	long   queryId;

	if (false) {
	  String input = null;
	  System.out.print ("root_at_node:"); input = stdin.readLine ();
	  root_at_node = input;

	  System.out.print ("query:"); input = stdin.readLine ();
	  query = input;

	  System.out.print ("rtype(int):"); input = stdin.readLine ();
	  rtype = Integer.parseInt (input);

	  System.out.print ("queryid(long):"); input = stdin.readLine ();
	  queryId = Long.parseLong (input);
	}
	else {
	  root_at_node = "aaa";
	  query = "/aaa/bbb[@id='b1']/ccc/ddd[./@val ='v1']";
	  rtype = 4;
	  queryId = 567L;
	}

	//buildRoot (root_at_node, query, rtype, queryId);
   }
   catch (Throwable e) {
	System.out.println ("Exception!");
	e.printStackTrace (System.out);
   }
  }

} // QueryOperator

// ---------------------------------------------------------------------
//                         class RootOperator
// ---------------------------------------------------------------------

class RootOperator extends QueryOperator {

  long    query_id;	// query id assigned by the client asking the query
  String  client_ip;
  int     client_port;

  // for continuous query processing
  ContinuousQuery  continuous_query = null;

  boolean setup (long queryId, int rtype, String root_at_node, String query,
		 String src_ip, int src_port)
  {
	return setup (queryId, rtype, root_at_node,
		      null, query,
		      src_ip, src_port);
  }

  boolean setup (long queryId, int rtype, String root_at_node, 
		 String expiry_subtree, String query,
		 String src_ip, int src_port)
  {
	// 1. set up result_type etc.
	query_id = queryId;
	setResultType (rtype);
	client_ip = src_ip;
	client_port = src_port;

	// 2. set up query info
	QueryInfo qinfo = new QueryInfo ();
	query_info = qinfo;
	qinfo.root = QueryUtils.getContextNode (root_at_node);
	qinfo.subtree_consistency_checking = expiry_subtree;

	Expr expr = null;
	try {
	  expr = XPathQueryParser.parsequery (query);
	} catch (Exception e) {
	  Utils.error (e.getClass().toString() + ':' + e.getMessage());
	}

	if (query.startsWith ("continuous")) {
	  if (expr instanceof FilterExpr) {
	    FilterExpr fe = (FilterExpr) expr;
	    Expr primary = fe.getPrimary();
	    if (primary instanceof FunctionCall) {
	      FunctionCall fc = (FunctionCall) primary;
  	      if (fc.getName().equals ("continuous")) {

	    	  // this is a continous query
		  qinfo.continuous = true;

		  int num_args = fc.getArgumentCount();
		  if (num_args < 1) {
		    Utils.error ("continuous query: xpath is missing!");
		  }
	 	  expr = fc.getArgument(0);
		
		  String[] params = new String[num_args-1];
		  for (int ii=1; ii<num_args; ii++) {
		     Expr arg = fc.getArgument(ii);
		     if (arg instanceof de.fzi.XPath.Literal) {
		       params[ii-1] = ((de.fzi.XPath.Literal)arg).getValue ();
		     }
		     else {
		       params[ii-1] = arg.toString ();
		     }
		  }

		  // more fields in query_info, use the params to set up them
		  ContinuousQuery.parseParams (params, query_info);

if (QueryOperator_debugging) {
System.out.print ("continous query:");
for (int ii=0; ii<params.length; ii++) {
     System.out.print (params[ii]);
     if (ii != params.length-1)
       System.out.print (",");
}
System.out.println ();
}

		  // check if this Continuous Query exists or not
		  ContinuousQuery c_query =
			ContinuousQuery.getCQuery (query_info.queryForRoot(),
						   expr.toString(), 
						   query_info.mode);	  
		  if (c_query != null) {
		    // existing query
		    c_query.insertClient (this);
		    continuous_query = c_query;
		    return false;
		  }

		  if (query_info.lease == 0) {
		    // terminating an unexisting query?
		    return false;
		  }

		  // create new continuous query
		  c_query = ContinuousQuery.create (this, expr);
		  continuous_query = c_query;
		  query_info.subtree_consistency_checking = "[expiry='0']";

		  if (query_info.mode == 0) {
		    // mode0: set the sub query_info to reflect snapshot query
		    qinfo = new QueryInfo ();
		    qinfo.root = query_info.root;
		    qinfo.subtree_consistency_checking = "[expiry='0']";
		  }
		  // other modes: sub query_info reflects continuous query

	      } // continuous
	    } // FunctionCall
	  } // FilterExpr
	} // query.startsWith ("continuous")

	// 3. build sub xpath operator
	SubXpathOperator sub = new SubXpathOperator (this);
	if (query_info.continuous) {
	  // disable caching
	  expr = continuous_query.xpath_no_caching;
	}
	sub.setup (qinfo, expr, rtype);

	if (rtype == RESULT_UNKNOWN) {
	  setResultType (sub.getResultType());
	}

	// 4. return
	boolean ret = sub.expandLocally ();

	if (query_info.continuous && ret) {
	  continuous_query.firstResultAlreadySent (getChild(0).getResult ());
	}

if (QueryOperator_debugging) {
System.out.println ("RootOperator.setup return = " + ret);
print ();
}

	return ret;
  }

  void resultReady (int which_child)
  {
	if (! query_info.continuous) 
	  processResult ();
	else
	  continuous_query.resultReady (getChild(0).getResult ());
  }

  // This is the only place: generate Reply2 normal response
  String generateResponse (Object obj)
  {
        String response = null;
        if (obj == null) {
          response = "null";
        }
        else if (obj instanceof Node) {
          response = DOMProcessing.DOMtoXML((Node)obj);
          if (getResultType() == RESULT_UNKNOWN)
            setResultType (RESULT_SUBTREE);
        }
        else {
          // result string
          String[] reply = (String[]) obj;

	  // allocate buffer
          int total = reply.length + 50;
          for (int ii=0; ii<reply.length; ii++)
             total += reply[ii].length();
          StringBuffer sb = new StringBuffer (total);

	  // generate response
          sb.append (reply.length);
          for (int ii=0; ii<reply.length; ii++) {
             sb.append (' '); sb.append (reply[ii].length());
	     sb.append (' '); sb.append (reply[ii]);
          }

	  // finish
          response = sb.toString ();
          if (getResultType() == RESULT_UNKNOWN)
            setResultType (RESULT_STRING);
        }

	return response;
  }

  void processResult ()
  {
	// this method should send query result to client

	Object obj = getChild(0).getResult ();
	String response = generateResponse (obj);

    try {
	Protocol.enqueueReply2Message (query_id, getResultType(), response,
				    client_ip, client_port, false);
    } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
    }

if (QueryOperator_debugging) {
  System.out.println ("RootOperator.processResult:");
  if ((obj != null) && (obj instanceof Node))
    DOMProcessing.prettyPrint ((Node)obj);
  System.out.println (response);
}

  }

  Object getResult ()
  {
	return getChild(0).getResult ();
  }
                                                                                
  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	System.out.println ("query_id=" + query_id);
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // RootOperator

// ---------------------------------------------------------------------
//                         class SubXpathOperator
// ---------------------------------------------------------------------

class SubXpathOperator extends QueryOperator {

  static final int QUERY_TYPE_SP       = 0;  // sp(xpath, params,...)
  static final int QUERY_TYPE_FOR      = 1;  // for loop
  static final int QUERY_TYPE_BASIC    = 2;  // basic location path
  static final int QUERY_TYPE_FORWARD  = 3;  // forward reference in predicate
  static final int QUERY_TYPE_BACKWARD = 4;  // backward reference in predicate
  static final int QUERY_TYPE_COMPLEX  = 5;  // backward + '//' etc.
  static final int QUERY_TYPE_CONSTANT = 6;  // string or number
  static final int QUERY_TYPE_REMOTE   = 7;  // ask remote query
  static final int QUERY_TYPE_ATTR     = 8;  // xpath = @attr
  static final int QUERY_TYPE_UNKNOWN  = -1;

  // ---
  // instance fields
  // ---
  Expr xpath;		// the xpath to evaluate (after determineQueryType())
			// SP:  FunctionCall
			// FOR: ForExpr
			// BASIC, FORWARD, BACKWARD, COMPLEX: LocationPath
			// CONSTANT: Literal or Number

  int  query_type = QUERY_TYPE_UNKNOWN;	// the query type of the xpath
  			// query type determines the subtree operators
  int  which_step;	// SP, FOR, BASIC, CONSTANT: not used
			// FORWARD: 1st step with forward ref in predicate
			// BACKWARD: highest up (backward) reference
			// COMPLEX: 1st step with location path in predicate
			// the step value: /aaa/bbb/ccc
			//                -1 0  1   2
	
  String[] result;	// this is for the QUERY_TYPE_CONSTANT
  String   sq_name;	// this is for stored query

  // ---
  // instance methods
  // ---

  SubXpathOperator (QueryOperator my_parent)
  { super(my_parent); }

  // setup should be called before any other calls
  void setup (QueryInfo qinfo, Expr expr, int rtype)
  {
	query_info = qinfo;
	xpath = expr;
	sq_name = null;

	if (! checkBeginningDots (rtype))
	  return;

	// set up query_type and which_step
	determineQueryType ();

	if (query_info.continuous) {
	  if ((query_type!=QUERY_TYPE_SP) &&
	      (query_type!=QUERY_TYPE_CONSTANT) &&
	      (query_type!=QUERY_TYPE_BASIC) &&
	      (query_type!=QUERY_TYPE_ATTR)) {
	    Utils.error ("Please use mode=pulling for this query:"
			 + xpath.toString());
	  }
	}

	// set up result_type
	switch (query_type) {
	  case QUERY_TYPE_SP:
	  case QUERY_TYPE_CONSTANT:
		if ((rtype != RESULT_UNKNOWN) && (! isResultString (rtype)))
		  Utils.error ("Type conflict at " + expr.toString());
		rtype = RESULT_STRING;
		break;
	  case QUERY_TYPE_FOR:
		break;
	  case QUERY_TYPE_BASIC:
	  case QUERY_TYPE_FORWARD:
	  case QUERY_TYPE_BACKWARD:
	  case QUERY_TYPE_COMPLEX:
	  case QUERY_TYPE_ATTR:
		LocationPath lp = (LocationPath) xpath;
		if (lp.getStep (lp.getStepsCount() - 1).getAxis ()
		    == Axis.ATTRIBUTE) {
		  if ((rtype != RESULT_UNKNOWN) && (!isResultString (rtype)))
		    Utils.error ("Type conflict at " + expr.toString());
		  rtype = RESULT_ATTR;
		}
		else if ((sq_name!=null) || ((query_type!=QUERY_TYPE_BASIC)
			&& (QueryUtils.lastStepIsStoredQuery(lp)!=null))) {
		  if ((rtype != RESULT_UNKNOWN) && (!isResultString (rtype)))
                    Utils.error ("Type conflict at " + expr.toString());
		  rtype = RESULT_STRING;
		}
		else { 
		 if (rtype == RESULT_UNKNOWN)
		   rtype = RESULT_SUBTREE;
		 else if (isResultString (rtype))
		   rtype = RESULT_TEXT;
		}
		break;
	}

	setResultType (rtype);

	if (query_type == QUERY_TYPE_CONSTANT) {
	  result = new String[1];
	  if (xpath instanceof de.fzi.XPath.Literal) {
	    result[0] = ((de.fzi.XPath.Literal)xpath).getValue ();
	    if (result[0].charAt(0) == '\'') {
	      String r = result[0]; int len = r.length ();
	      if (r.charAt(len-1) == '\'')
	        result[0] = r.substring (1, len-1);
	    }
	    if (result[0].charAt(0) == '\"') {
	      String r = result[0]; int len = r.length ();
	      if (r.charAt(len-1) == '\"')
	        result[0] = r.substring (1, len-1);
	    }
	  }
	  else { // must be Number
	    result[0] = ((de.fzi.XPath.Number)xpath).toString ();
	  }
	}
	else if (query_type == QUERY_TYPE_ATTR) {

	  // get the attribute value directly without using xslt program
	  LocationPath lp = (LocationPath) xpath;
	  String attr = lp.getStep(0).getNodeTest().toString();

	  // we change the query format for continuous query
	  // so that we can handle it as a basic xpath query
	  if (query_info.continuous) {
	    // compose a new location path
	    Element n = (query_info.root instanceof Element)?
			((Element)query_info.root) :
			((Document)query_info.root).getDocumentElement ();
	    String new_query = n.getTagName() + "/@" + attr;
	    Expr new_expr = null;
	    try {
		new_expr = XPathQueryParser.parsequery(new_query);
	    } catch (Exception e) {
	     Utils.error ("can't parse simple xpath?");
	    }

	    setup (qinfo, new_expr, RESULT_ATTR);
	    return;
	  }// continuous query

	  String value = null;
	  if (query_info.root instanceof Element) {
	    value = ((Element)query_info.root).getAttribute (attr);
	  }
	  if ((value != null) && (value.length()>0)) {
	    result = new String[1]; result[0] = value;
	  }
	  else {
	    result = empty_string_output;
	  }
	  
	}
  }

  // deal with location paths that begin with a series of ../ or ./
  // assume: xpath and query_info are set
  // return true, if the check passes and normal processing can be performed
  // return false, if the check fails, and the query will be forwarded to
  //               another OA by using a remote query operator
  boolean checkBeginningDots (int rtype)
  {
	// 1. check passes if xpath is not LocationPath
	if (!(xpath instanceof LocationPath))
	  return true;

	// 2. check passes if the location path does not begin with ../ or ./
	LocationPath lp = (LocationPath) xpath;
	int axis = lp.getStep (0).getAxis ();
	if ((axis != Axis.PARENT) && (axis != Axis.SELF))
	  return true;

	// 3. rewrite the query to remove the beginning dots
	// e will be the new context node, new_lp will be the new location path
	Element e = (Element) query_info.root;
	LocationPath new_lp = new LocationPath ();

	int num_steps = lp.getStepsCount();
	int ii;
	for (ii=0; ii<num_steps; ii++) {
	   Step st = lp.getStep (ii);
	   axis = st.getAxis ();
	   if (axis == Axis.PARENT) {
	     if (e.getParentNode () instanceof Element)
	       e = (Element) e.getParentNode ();
	   }
	   else if (axis == Axis.SELF) {
	   }
	   else {
	     break;
	   }
	   if (st.getPredicatesCount () > 0) {
	     Utils.error ("predicates with parent or self axis" + 
			  " are not supported!");
	   }
	}

	new_lp.addStep (new Step (Axis.CHILD, new NameTest (e.getTagName())));

	for (; ii<num_steps; ii++) {
	     new_lp.addStep (lp.getStep (ii));
	}

	// 4. check passes if the new context node is owned by this OA
	if (e.getAttribute("status").equals("ownsthis")) {
	  // rewrite the query
	  lca_bound = -2;
	  QueryInfo qinfo = new QueryInfo (query_info, e);
	  query_info = qinfo;
	  xpath = new_lp;

	  return true;
	}

	// 5. check fails

	// build a RemoteQueryOperator
	RemoteQueryOperator rq = new RemoteQueryOperator (this);

	// get host, subquery, and root_at
        String lca_host = DOMProcessing.findOwnerAgent(e);
        String query    = new_lp.toString();
        String root_at  = QueryUtils.findQueryForThisElement(e);

        // create remote query operator
        rq.setup (rtype, lca_host, query, root_at);

	query_type = QUERY_TYPE_REMOTE;
	setResultType (rtype);

        return false;
  }

  // ---
  // determine query type:
  //    xpath is the output of sixpath parser.
  //    we set query_type and which_step.
  //    we may reset xpath to some lower level Expr in the parsed tree.
  // ---
  void determineQueryType ()
  {
	// LocationPath
	if (xpath instanceof LocationPath) {
	  determineQueryType ((LocationPath) xpath);
	}

	// FilterExpr
	else if (xpath instanceof FilterExpr) {
	  determineQueryType ((FilterExpr) xpath);
	}

	// ForExpr
	else if (xpath instanceof ForExpr) {
	  query_type = QUERY_TYPE_FOR;
        }

	// NaryExpr
	else {
	  Utils.error ("don't support direct relational or numerical"
                       +" operators\n" + xpath.toString());
	}
  }

  void determineQueryType (FilterExpr fe)
  {
	 if ((fe.getPredicatesCount() != 0)||(fe.getLocationPath() != null)) {
	    Utils.error ("don't allow FilterExpr with predicates"
                         +" or location path\n" + fe.toString());
	 }

	 xpath = fe.getPrimary ();

	 // FunctionCall
	 if (xpath instanceof FunctionCall) {
	   query_type = QUERY_TYPE_SP;
	 }

	 // Literal | Number
	 else if ((xpath instanceof de.fzi.XPath.Literal)
	        ||(xpath instanceof de.fzi.XPath.Number)) {
	    query_type = QUERY_TYPE_CONSTANT;
	 }

	 // VariableReference
	 else if (xpath instanceof Variable) {
	    Utils.error ("Unknown variable: " + xpath.toString());
	 }

	 // ( Expr )
	 else {
	    determineQueryType ();
	 }
  }

  // Here we assume that predicates do not contain absolute location
  // paths. Absolute location paths should be evaluated separately.
  // We assume that absolute values have already been replaced with
  // Literals.
  //
  // Moreover, we assume attributes do not have predicates.
  void determineQueryType (LocationPath lp)
  {
	int num_steps = lp.getStepsCount ();

	// 0. check if this is @attr only
	if (num_steps == 1) {
	  Step ss = lp.getStep (0);
	  if (ss.getAxis () == Axis.ATTRIBUTE) {
	    query_type = QUERY_TYPE_ATTR;
	    return;
	  }
	}

	// 1. compute the current position and highest up reference
	//    for every step
	//    if there is a descendant or descentant_or_self axis,
        //    the curpos of steps after it will be set to -1.

	// the current position
	int[] curpos  = new int[num_steps];
	// highest reference relative to the current step
	int[] highestref = new int[num_steps];

	boolean is_basic = true;
	boolean has_backward_ref = false;

	int pos = -1;  // root
	for (int ii=0; ii<num_steps; ii++) {
	   Step ss = lp.getStep (ii);
	   int axis = ss.getAxis ();

	   switch (axis) {
	   case Axis.ATTRIBUTE:
		if (ii != num_steps-1) 
		  Utils.error ("attribute should be the last step!");
		break;
	   case Axis.CHILD:
		pos ++;
		break;
	   case Axis.DESCENDANT:
		pos ++;
		// curpos[] is the min possible position
		break;
	   case Axis.DESCENDANT_OR_SELF:
		// curpos[] is the min possible position
		break;
	   case Axis.PARENT:
		pos --;
		break;
	   case Axis.SELF:
		// do nothing
		break;
	   default:
		Utils.error (Axis.getAxisName (axis) + " not supported!");
	   }

	   curpos[ii] = pos;
	   if ((axis==Axis.ATTRIBUTE) || (ss.toString().indexOf("/") == -1)) {
	     // predicates do not contain location path
	     highestref[ii] = 1;
	   }
	   else {
	     is_basic = false;

	     highestref[ii] = findHighestUpRef (ss);
	     // contain location path: <0 backward ref, =0 forward ref

	     if (highestref[ii] < 0) {
	       has_backward_ref = true;
	     }
	   }// end of else

	} // end of for

	// 2. basic query? (predicates do not contain location paths)
	if (is_basic) {
	  query_type = QUERY_TYPE_BASIC;
	  sq_name = QueryUtils.lastStepIsStoredQuery (lp);
	  return;
	}

	// 3. backward query?
	if (has_backward_ref && (lp.toString().indexOf (stored_query)==-1)) {
	  // compute the highest up reference
	  int highest = num_steps;
	  int highest_ii = -1;
	  for (int ii=0; ii<num_steps; ii++)
	     if (highestref[ii] < 0) {// backward ref
	       int ref = curpos[ii] + highestref[ii];
	       if (ref < highest) {
	         highest = ref;
		 highest_ii = ii;
	       }
	     }

	  if (lca_bound < -1) {
	    // lca_bound has not been initiated yet
	    // delayed initiation. When there is no backward ref,
	    // we don't need to do this. 
	    lca_bound = QueryUtils.getHighestOwnedLevel (query_info.root, lp);
	  }

	  // if reference is within the LCA, we can use fetch all to process it
	  if (highest >= lca_bound) {
	    // compute the first step at the highest up reference
	    for (int ii=0; ii<highest_ii; ii++)
	       if (curpos[ii] == highest) {
	  	 which_step = ii;
		 break;
	       }

	    // is there any predicate with forward location path earlier
	    // than which_step?
	    boolean earlier_forward_ref = false;
	    for (int ii=0; ii<=which_step; ii++)
	       if (highestref[ii] == 0) {
		 earlier_forward_ref = true;
	  	 break;
	       }
	    if (! earlier_forward_ref) { // no such forward ref
	      query_type = QUERY_TYPE_BACKWARD;
	      return;
	    } // ! earlier_forward_ref
	  } // highest >= lca_bound
	}

	// Four cases reach this point:
	// case 1. no predicate contains backward reference
	// case 2. contains stored query (not basic)
	// case 3. backward ref above LCA
	// case 4. there is a forward ref earlier than the highest up ref
	//         position

	// 4. look for the first predicate containing location path
	for (int ii=0; ii<num_steps; ii++)
	   if (highestref[ii] <= 0) {
	     which_step = ii;
	     break;
	   }
	if (highestref[which_step] == 0) {
	  query_type = QUERY_TYPE_FORWARD;
	}
	else {
	  query_type = QUERY_TYPE_COMPLEX;
	}
  }

  // return the highest reference: 0~self, -1~parent, -2~grandparent
  int findHighestUpRef (Step ss)
  {
	int highest = 0;
	for (int ii=ss.getPredicatesCount()-1; ii>=0; ii--) {
	   int ref = findHighestUpRef (ss.getPredicate (ii));
	   if (ref < highest)  // min
	     highest = ref;
	}
// debug begin
//System.out.println ("findHighestUpRef (Step " + ss.toString() + ") = " + highest);
// debug end
	return highest;
  }

  int findHighestUpRef (Expr expr)
  {
	int highest = 0;

	// FilterExpr
	if (expr instanceof FilterExpr) {
	  FilterExpr fe = (FilterExpr) expr;
	  if ((fe.getPredicatesCount() != 0)||(fe.getLocationPath() != null)) {
	    Utils.error ("don't allow FilterExpr with predicates"
                         +" or location path\n" + fe.toString());
	  }
	  highest = findHighestUpRef (fe.getPrimary());
	}

	// FunctionCall
	else if (expr instanceof FunctionCall) {
	  FunctionCall fc = (FunctionCall) expr;
	  for (int ii=fc.getArgumentCount()-1; ii>=0; ii--) {
	     int ref = findHighestUpRef (fc.getArgument(ii));
	     if (ref < highest)
               highest = ref;
	  }
	}

	// Literal
	else if (expr instanceof de.fzi.XPath.Literal) {
	  // do nothing
	}

	// LocationPath
	else if (expr instanceof LocationPath) {
	  LocationPath lp = (LocationPath) expr;
	  int pos = 0;

          int num_steps = lp.getStepsCount ();
          for (int ii=0; ii<num_steps; ii++) {
             Step ss = lp.getStep (ii);
             int axis = ss.getAxis ();
	     int ref = 0;

             switch (axis) {
             case Axis.ATTRIBUTE:
                  if (ii != num_steps-1)
                    Utils.error ("attribute should be the last step!");
                  break;

             case Axis.CHILD:
             case Axis.DESCENDANT:
		  pos ++;
		  ref = findHighestUpRef (ss);
                  break;
		  
             case Axis.DESCENDANT_OR_SELF:
             case Axis.SELF:
		  ref = findHighestUpRef (ss);
                  break;

	     case Axis.PARENT:
		  pos --;
		  ref = findHighestUpRef (ss);
	  	  break;

             default:
                  Utils.error (Axis.getAxisName (axis) + " not supported!");
             }

	     ref += pos;
	     if (ref < highest)
	       highest = ref;
          }
	}

	// NaryExpr
	else if (expr instanceof NaryExpr) {
	  NaryExpr ne = (NaryExpr) expr;
	  for (int ii=ne.getExprsCount()-1; ii>=0; ii--) {
	     int ref = findHighestUpRef (ne.getExpr(ii));
	     if (ref < highest)
	       highest = ref;
	  }
	}

	// Number
	else if (expr instanceof de.fzi.XPath.Number) {
	  // do nothing
	}

	// Variable
	else if (expr instanceof Variable) {
	  Utils.error ("Unknown variable " + expr.toString());
	}
	else { // ForExpr
	  Utils.error ("For loop in predicate is not supported!");
	}
// debug begin
//System.out.println ("findHighestUpRef (Expr " + expr.toString() + ") = " + highest);
// debug end

	return highest;
  }

  // ---
  // expandLocally: expand SubXpathOperator
  // ---
  // We build subtrees based on the query_type
  boolean expandLocally ()
  {
        switch (query_type) {
          case QUERY_TYPE_SP:
		return expandSPLocally ();
          case QUERY_TYPE_FOR:
		return expandFORLocally ();
          case QUERY_TYPE_BASIC:
		return expandBASICLocally ();
          case QUERY_TYPE_FORWARD:
          case QUERY_TYPE_COMPLEX:
		return expandFORWARDCOMPLEXLocally ();
          case QUERY_TYPE_BACKWARD:
		return expandBACKWARDLocally ();
          case QUERY_TYPE_CONSTANT:
	  case QUERY_TYPE_ATTR:
		return true;
	  case QUERY_TYPE_REMOTE:
		return false;
        }
	return true;
  }

  boolean expandSPLocally ()
  {
	FunctionCall fc = (FunctionCall) xpath;

	String className = fc.getPrefix ();
	String methodName = fc.getLocalName ();
	int num_args = fc.getArgumentCount ();

	if (num_args == 0) {
	  Utils.error (fc.toString() + " does not have args");
	}

	if (className == null) {
	  // we implement the built-in functions in class SPBuiltIn
	  className = "com.intel.sensors.oa.SPBuiltIn";
	}

	boolean is_intermediate = false;
	if (methodName.endsWith (inter_suffix)) {
	  methodName = methodName.substring (0, 
			methodName.length() - inter_suffix.length());
	  is_intermediate = true;
	}

	// 1. get stored procedure
	SPInfo spinfo = SPUtils.getStoredProcedure (className, methodName);
	if (spinfo == null) {
	  Utils.error (className + ':' + methodName + " is not found");
	}

	// 2. get intermediate result only
	if (is_intermediate) {
	    if (! spinfo.hasInitComputeFinal ()) {
	      Utils.error (className + ':' + methodName + " in-network part"
			+ " missing");
	    }

	    // get all the params
	    String[] params = new String[num_args-1];
	    for (int ii=1; ii<num_args; ii++) {
	       params[ii-1] = null;

	       Expr arg = fc.getArgument(ii);
	       if (arg instanceof FilterExpr) {
		 arg = ((FilterExpr)arg).getPrimary();
		 if (arg instanceof de.fzi.XPath.Literal) {
	            String str = ((de.fzi.XPath.Literal)arg).getValue ();
		    int len = str.length ();
                    if(((str.charAt(0) == '\'') && (str.charAt(len-1) == '\''))
                    ||((str.charAt(0) == '\"') && (str.charAt(len-1) == '\"'))){
                        str = str.substring (1, len-1);
                    }
	            params[ii-1] = str;
		 }
	       }

	       if (params[ii-1] == null)
	         Utils.error ("Internal error! params are not recognized!");
	    }

	    // build a SPInitComputeOperator
            SPInitComputeOperator one = new SPInitComputeOperator (null);
            one.setup (spinfo, params); 
            one.query_info = query_info;
            one.lca_bound = lca_bound;

            // set up SubXpathOperator
            SubXpathOperator subxpath = new SubXpathOperator (this);
            subxpath.setup (query_info, fc.getArgument (0),
                            (spinfo.isSimple()?RESULT_STRING:RESULT_NODE));
            boolean ret = subxpath.expandLocally ();

            ret = (subxpath.rewrite (one) || ret);

            return ret;
	}

	// ---
	// get final result
	// ---

	// 3. params will always be snapshot query
	QueryInfo qinfo;
	if (query_info.continuous) {
	  qinfo = new QueryInfo ((Element)query_info.root);
	}
	else {
	  qinfo = query_info;
	}

	boolean ready = false;

	// 4. if the method can be pushed down into network?
	if (spinfo.hasInitComputeFinal ()) {
	  // yes

	  // create a SPFinalOperator
	  SPFinalOperator sp = new SPFinalOperator (this);
          sp.setup (spinfo, fc.getArgument (0), num_args-1);

          // create and expand all the params
	  if (num_args > 1) {
            for (int ii=1; ii<num_args; ii++) {
              SubXpathOperator  argxpath = new SubXpathOperator (sp);
              argxpath.setup (qinfo, fc.getArgument (ii), RESULT_STRING);

              if (argxpath.expandLocally ())
	        ready = sp.processResult (ii-1);
           }
	  }
	  else {
	    ready = sp.expandMajorXpath ();
	    if (ready)
	       sp.processResult (0);
	  }
	}
	else {
	  // no

	  // create a SPLocalOperator
	  SPLocalOperator sp = new SPLocalOperator (this);
	  sp.setup (spinfo, fc.getArgument (0), num_args-1);

	  // create and expand all the params
	  if (num_args > 1) {
	   for (int ii=1; ii<num_args; ii++) {
	      SubXpathOperator  argxpath = new SubXpathOperator (sp);
	      argxpath.setup (qinfo, fc.getArgument (ii), RESULT_STRING);

	      if (argxpath.expandLocally ())
	        ready = sp.processResult (ii-1);
	   }
	  }
	  else {
	    ready = sp.expandMajorXpath ();
	    if (ready)
	       sp.processResult (0);
	  }
	}

	return ready;
  }

  boolean expandFORLocally ()
  {
    try {
	ForExpr for_expr = (ForExpr)xpath;
	Expr in_expr = for_expr.getInExpr ();

	// 1. use subxpath to analyze the in clause 
	// make sure the in clause is a basic xpath
	int in_query_type = QUERY_TYPE_UNKNOWN;
	{
	  SubXpathOperator one = new SubXpathOperator (null);
	  one.setup (query_info, in_expr, RESULT_NODE);

	  in_query_type = one.query_type;
	}

	// 2. replace the $var in the return xpath with "."
	String replaced_return_query = 
			QueryUtils.getReplacedReturnClause(for_expr);
	Expr replaced_return_xpath = XPathQueryParser.parsequery (
						replaced_return_query);
	  // determine the result type of the return clause
	  if (getResultType() == RESULT_UNKNOWN) {
	    setResultType (determineResultType (replaced_return_xpath));
	  }


	// perform optimization for basic location path
	if (in_query_type == QUERY_TYPE_BASIC) {

          // 3. write xslt program
	  LocationPath lp = (LocationPath) in_expr;
          LocationPath copy_lp = QueryUtils.prepareLPforXslt (lp);
          String xslt_query = QueryAnalysis.writeXsltwithSP (copy_lp,
                                true, false,
                                query_info.subtree_consistency_checking);

          // 4. apply xslt program
          Transformer t = DOMProcessing.getXSLTTransformer(xslt_query);
          Document local_result =
                        DOMProcessing.applyXSLTtoDOM (query_info.root, t);

          int num_sources = 0;
          // 5. get stop nodes
          NodeList stop_nodes = getResultNodeList (local_result);
          if (stop_nodes.getLength () > 0)
            num_sources ++;

          // 6. get asksubquery nodes
          Node[] hanging_nodes = DOMProcessing.applyXPATHtoDOM (local_result,
                                query_asksubquery);
          if (hanging_nodes.length > 0)
            num_sources ++;

          // 7. build operator subtree
          MergeOperator merge;

          if (isResultTree ()) {
            // RESULT_SUBTREE, RESULT_NODE
            TreeMergeOperator tmerge = new TreeMergeOperator (this);
            tmerge.beginSetup (local_result, num_sources, getResultType ());
            merge = tmerge;
          }
          else {
            // RESULT_TEXT, RESULT_ATTR
            StringMergeOperator smerge = new StringMergeOperator (this);
            smerge.beginSetup (num_sources, getResultType ());
            merge = smerge;
          }

          int index = 0;

          // add addMergeSource
          if (stop_nodes.getLength () > 0) {

	    SubXpathMergeSource sbm = new SubXpathMergeSource ();
	    sbm.setup (this, replaced_return_xpath);

            merge.addMergeSource (index, sbm, stop_nodes);
            index ++;
          } // num_stop_nodes > 0

          if (hanging_nodes.length > 0) {
            RemoteMergeSource rms = new RemoteMergeSource ();
            rms.setup (this);
            merge.addMergeSource (index, rms, hanging_nodes);
          }

          merge.finishSetup ();

          return merge.expandAllLocally ();
	}

	// non-basic location path
	else if ((in_query_type>=QUERY_TYPE_FORWARD)&&
	 	 (in_query_type<=QUERY_TYPE_COMPLEX)) {

	  ForOperator for_op = new ForOperator (this);
	  return for_op.setup (in_expr, replaced_return_xpath);
	}

	// invalid types
	else {
	  Utils.error ("Invalid in-clause for a for loop!");
	}

    } catch (Exception e) { 
	e.printStackTrace ();
        Utils.error (e.getClass().toString() + ':' + e.getMessage ());
    }
        return false;
  }

  boolean expandBASICLocally ()
  {
	int rtype = getResultType ();
	LocationPath lp = (LocationPath) xpath;

	// 1. write xslt program
	LocationPath copy_lp = QueryUtils.prepareLPforXslt (lp);
	   // special processing for stored query
	   if (sq_name != null) {
		// fold stored_query[@name='...'] into predicate
	     LocationPath new_lp = new LocationPath (copy_lp.isAbsolute());
	     int num_steps = copy_lp.getStepsCount ();
	     for (int ii=0; ii<num_steps-1; ii++)
		new_lp.addStep (copy_lp.getStep (ii));

	     Step st = copy_lp.getStep (num_steps-1);
	     LocationPath sq_lp = new LocationPath ();
	     sq_lp.addStep (st);
	     new_lp.getStep (num_steps-2).addPredicate (sq_lp);

	     copy_lp = new_lp;
	   }
	String xslt_query = QueryAnalysis.writeXsltwithSP (copy_lp,
				(rtype != RESULT_SUBTREE),
				false, 
				query_info.subtree_consistency_checking);

	// 2. apply xslt program
	Transformer t = DOMProcessing.getXSLTTransformer(xslt_query);
	Document local_result = 
			DOMProcessing.applyXSLTtoDOM (query_info.root, t);

if (QueryOperator_debugging) {
  System.out.println ("expandBASICLocally: " + copy_lp.toString());
  DOMProcessing.prettyPrint (local_result);
  System.out.println (DOMProcessing.DOMtoXML (local_result));
  try{
   if (stdin != null) QueryOperator.stdin.readLine ();
  } catch (Exception e) {
   Utils.error ("readLine in buildRoot");
  }
}

	// 3. get asksubquery nodes
	Node[] hanging_nodes = null;
	try{
	  hanging_nodes = DOMProcessing.applyXPATHtoDOM (local_result,
				query_asksubquery);
	} catch (Exception e) {
	  Utils.error (e.getClass().toString() + ':' + e.getMessage());
	}

	if (hanging_nodes.length == 0) {
	  if (sq_name == null) {
	      // Well, the query is answered locally!
	      // then we simply form a localResultOperator
	      String attribute_name = null;
	      if (rtype == RESULT_ATTR) {
                Step last_step = lp.getStep (lp.getStepsCount()-1);
                attribute_name = last_step.getNodeTest().toString();
              }
	      LocalResultOperator lr = new LocalResultOperator (this);
	      lr.setup (local_result, rtype, attribute_name);
	      return true;
	  }
	  else {
	      // we create a StoredQueryOperator
	      StoredQueryOperator sq = new StoredQueryOperator (this);
	      return sq.setup (sq_name, local_result);
	  }
	}

	// 4. build operator subtree
	MergeOperator merge;

	if (isResultTree ()) {
	  // RESULT_SUBTREE, RESULT_NODE
	  TreeMergeOperator tmerge = new TreeMergeOperator (this);
	  tmerge.beginSetup (local_result, 2, rtype);
	  merge = tmerge;
	}
	else {
	  // RESULT_TEXT, RESULT_ATTR
	  StringMergeOperator smerge = new StringMergeOperator (this);
	  smerge.beginSetup (2, rtype);
	  merge = smerge;
	}

	if (sq_name == null) {
	  // add LocalResultMergeSource
	  LocalResultMergeSource lms = new LocalResultMergeSource ();
	  lms.setup (this, local_result);
	  Node[] lms_nodes = new Node[1];
	  lms_nodes[0] = null;
	  merge.addMergeSource (0, lms, lms_nodes);
	}
	else {
	  // add StoredQueryMergeSource
	  StoredQueryMergeSource sqm = new StoredQueryMergeSource ();
	  sqm.setup (sq_name, local_result);
	  Node[] empty_nodes =  new Node[1];
	  empty_nodes[0] = null;
	  merge.addMergeSource (0, sqm, empty_nodes);
	}

	// add RemoteMergeSource
	RemoteMergeSource rms = new RemoteMergeSource ();
	rms.setup (this);
	merge.addMergeSource (1, rms, hanging_nodes);

	merge.finishSetup ();

	return merge.expandAllLocally ();
  }

  boolean expandFORWARDCOMPLEXLocally ()
  {
    try {
	int rtype = getResultType ();
        LocationPath lp = (LocationPath) xpath;

        // 1. write xslt program
        LocationPath copy_lp = QueryUtils.prepareLPforXslt (lp, 0,which_step-1);
	  // for step(which_step), only add predicates that do not contain
	  // '/' location paths.
	{ Step st = lp.getStep (which_step);
	  Step new_st = new Step (st.getAxis(), st.getNodeTest());
	  int  num_predicates = st.getPredicatesCount();
          for (int ii=0; ii<num_predicates; ii++) {
	     Expr predicate = st.getPredicate(ii);
	     if (predicate.toString().indexOf('/') == -1) {
               new_st.addPredicate (QueryUtils.copyAndLocalizeSP (predicate));
	     }
          }
	  copy_lp.addStep (new_st);
	}
	String xslt_query = QueryAnalysis.writeXsltwithSP (copy_lp,
                                true, false,
				query_info.subtree_consistency_checking);

        // 2. apply xslt program
        Transformer t = DOMProcessing.getXSLTTransformer(xslt_query);
        Document local_result =
                        DOMProcessing.applyXSLTtoDOM (query_info.root, t);

if (QueryOperator_debugging) {
  System.out.println ("expandFORWARDLocally: " + copy_lp.toString());
  DOMProcessing.prettyPrint (local_result);
  System.out.println (DOMProcessing.DOMtoXML (local_result));
  try{
   if (stdin != null) QueryOperator.stdin.readLine ();
  } catch (Exception e) {
   Utils.error ("readLine in buildRoot");
  }
}

	int num_sources = 0;
        // 3. get stop nodes
        NodeList stop_nodes = getResultNodeList (local_result);
	if (stop_nodes.getLength () > 0)
	  num_sources ++;

        // 4. get asksubquery nodes
        Node[] hanging_nodes = DOMProcessing.applyXPATHtoDOM (local_result,
                                query_asksubquery);
	if (hanging_nodes.length > 0)
	  num_sources ++;

        // 5. build operator subtree
        MergeOperator merge;

        if (isResultTree ()) {
          // RESULT_SUBTREE, RESULT_NODE
          TreeMergeOperator tmerge = new TreeMergeOperator (this);
          tmerge.beginSetup (local_result, num_sources, rtype);
          merge = tmerge;
        }
        else {
          // RESULT_TEXT, RESULT_ATTR
          StringMergeOperator smerge = new StringMergeOperator (this);
          smerge.beginSetup (num_sources, rtype);
          merge = smerge;
        }

	int index = 0;

	// add IfOperator
	if (stop_nodes.getLength () > 0) {

	  // predicate computation ==> stored procedure calls
	  ArrayList query_for_predicates = new ArrayList ();

	  Step st = lp.getStep (which_step);
	  int  num_predicates = st.getPredicatesCount();

	  ArrayList lp_sp_list = new ArrayList ();
	  StringBuffer sb = new StringBuffer ();

	  for (int ii=0; ii<num_predicates; ii++) {
	     Expr predicate = st.getPredicate(ii);
	     if (predicate.toString().indexOf('/') != -1) {
	       lp_sp_list.clear ();
	       sb.delete (0, sb.length());

	       Expr replaced = QueryUtils.replaceLPSPinExpr (
				predicate, lp_sp_list, 0);

	       int num_found = lp_sp_list.size();
	       if ((num_found == 1) && 
		   (lp_sp_list.get(0) instanceof LocationPath) &&
		   (findHighestUpRef((Expr)lp_sp_list.get(0))==0)) {
		 // a single forward location path
		 LocationPath this_expr = (LocationPath) lp_sp_list.get(0);
		 if (predicate instanceof LocationPath) {
		   if (this_expr.getStep (this_expr.getStepsCount()-1).getAxis()
		     == Axis.ATTRIBUTE) 
		     sb.append ("com.intel.sensors.oa.SPUtils:attrExist(");
		   else
		     sb.append ("com.intel.sensors.oa.SPUtils:nodeExist(");
		   sb.append (this_expr.toString());
		   sb.append (')');
		 }
		 else {
		   sb.append ("com.intel.sensors.oa.SPUtils:exprTrueExist(");
		   sb.append (this_expr.toString());
		   sb.append (",\"*[");
		   sb.append (replaced.toString());
		   sb.append ("]\",'$");
		   sb.append (var_prefix);
		   sb.append ("0')");
		 }
	       }
	       else {
		 // other cases
		 sb.append ("com.intel.sensors.oa.SPUtils:testExpr(\"*[");
		 sb.append (replaced.toString());
		 sb.append ("]\"");
		 for (int jj=0; jj<num_found; jj++) {
		    Expr this_expr = (Expr) lp_sp_list.get (jj);
		    sb.append (",'$"); sb.append (var_prefix); sb.append (jj);
		    sb.append ("',"); sb.append (this_expr.toString());
		 }
		 sb.append (")");
	       }
	      query_for_predicates.add (
			XPathQueryParser.parsequery(sb.toString()));
	     } // end of if
	  } // end of for

	  // rest_query
	  StringBuffer my_sb = new StringBuffer ();
	  my_sb.append (st.getNodeTest().toString());
	  for (int kk=which_step+1; kk<lp.getStepsCount (); kk++) {
	     my_sb.append ('/'); my_sb.append (lp.getStep (kk).toString());
	  }
	  String rest_query = my_sb.toString();

	  IfMergeSource ifm = new IfMergeSource ();
	  ifm.setup (this, query_for_predicates, rest_query);

	  merge.addMergeSource (index, ifm, stop_nodes);
	  index ++;
        } // num_stop_nodes > 0

        // add addMergeSource
        if (hanging_nodes.length > 0) {
          RemoteMergeSource rms = new RemoteMergeSource ();
          rms.setup (this);
          merge.addMergeSource (index, rms, hanging_nodes);
        }

        merge.finishSetup ();

        return merge.expandAllLocally ();

   } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage ());
   }
	return false;
  }

  boolean expandBACKWARDLocally ()
  {
        int rtype = getResultType ();
        LocationPath lp = (LocationPath) xpath;
                                                                                
        // 1. write xslt program
        LocationPath copy_lp = QueryUtils.prepareLPforXslt (lp, 0, which_step);
        String xslt_query = QueryAnalysis.writeXsltwithSP (copy_lp, 
                                true, false,
				query_info.subtree_consistency_checking);
                                                                                
        // 2. apply xslt program
        Transformer t = DOMProcessing.getXSLTTransformer(xslt_query);
        Document local_result =
                        DOMProcessing.applyXSLTtoDOM (query_info.root, t);
                                                                                
if (QueryOperator_debugging) {
  System.out.println ("expandBACKWARDLocally: " + copy_lp.toString());
  DOMProcessing.prettyPrint (local_result);
  System.out.println (DOMProcessing.DOMtoXML (local_result));
  try{
   if (stdin != null) QueryOperator.stdin.readLine ();
  } catch (Exception e) {
   Utils.error ("readLine in buildRoot");
  }
}

	// number of sources to the Merge Operator
	int num_sources = 0;

	// 3. get stop nodes
	NodeList stop_nodes = getResultNodeList (local_result);
	if (stop_nodes.getLength() > 0) {
	  num_sources ++;
	}
                                                                                
        // 4. get asksubquery nodes
        Node[] hanging_nodes = null;
        try{
          hanging_nodes = DOMProcessing.applyXPATHtoDOM (local_result,
                                query_asksubquery);
        } catch (Exception e) {
          Utils.error (e.getClass().toString() + ':' + e.getMessage());
        }
	if (hanging_nodes.length > 0)
	  num_sources ++;

        // 5. build operator subtree
        MergeOperator merge;

        if (isResultTree ()) {
          // RESULT_SUBTREE, RESULT_NODE
          TreeMergeOperator tmerge = new TreeMergeOperator (this);
          tmerge.beginSetup (local_result, num_sources, rtype);
          merge = tmerge;
        }
        else {
          // RESULT_TEXT, RESULT_ATTR
          StringMergeOperator smerge = new StringMergeOperator (this);
          smerge.beginSetup (num_sources, rtype);
          merge = smerge;
        }

	// add LocalFetchAllMergeSource
	int index = 0;
	if (stop_nodes.getLength() > 0) {
	  // prepare the xslt program to process the rest of the query
	  copy_lp = QueryUtils.prepareLPforXslt (lp, which_step, 
				lp.getStepsCount ()-1);
	  // remove expiry attribute! since everything is fresh
	  copy_lp = (LocationPath) 
		    QueryUtils.removeExpirePredicate ((Expr) copy_lp);

	  xslt_query = QueryAnalysis.writeXsltwithSP (copy_lp,
				(rtype != RESULT_SUBTREE),
				false,
				query_info.subtree_consistency_checking);
	  t = DOMProcessing.getXSLTTransformer(xslt_query);

	  LocalFetchAllMergeSource lf = new LocalFetchAllMergeSource ();
	  lf.setup (this, t);

	  merge.addMergeSource (index, lf, stop_nodes);
	  index ++;
	}

        // add addMergeSource
	if (hanging_nodes.length > 0) {
          RemoteMergeSource rms = new RemoteMergeSource ();
          rms.setup (this);
          merge.addMergeSource (index, rms, hanging_nodes);
	}

        merge.finishSetup ();

	return merge.expandAllLocally ();
  }

  // ---
  // expandRemotely
  // ---
  void expandRemotely ()
  {
	if ((query_type != QUERY_TYPE_CONSTANT)
	  &&(query_type != QUERY_TYPE_ATTR)) {
	  super.expandRemotely ();
	}
  }
  
  // ---
  // rewrite for stored procedure
  // ---
  boolean rewrite (SPInitComputeOperator s)
  {
	if ((query_type != QUERY_TYPE_CONSTANT)
	  &&(query_type != QUERY_TYPE_ATTR)) {
	  
	  return getChild(0).rewrite (s);
	}
	else {
          // insert a copy of the SPInitComputeOperator 
          // in the middle of this and its parent

          SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();

          middle.setParent (getParent(), getParentIndex());
          getParent().setChild (getParentIndex(), middle);

          int pindex = middle.addChild (this);
          setParent (middle, pindex);

          // set up result
          middle.processResult (pindex);

	  return true;
	}
  }

  // ---
  // terminate
  // ---
  void terminate ()
  {
        if ((query_type != QUERY_TYPE_CONSTANT)
          &&(query_type != QUERY_TYPE_ATTR)) {
	  super.terminate ();
	}
  }

  // ---
  // resultReady
  // ---
  void resultReady (int which_child)
  {
	getParent().resultReady (getParentIndex());
  }

  // ---
  // getResult
  // ---
  Object getResult ()
  {
        if ((query_type != QUERY_TYPE_CONSTANT)
          &&(query_type != QUERY_TYPE_ATTR)) {
	  return getChild(0).getResult ();
	}
	else {
	  return result;
	}
  }

  static String  getQueryTypeName (int qtype)
  {
	switch (qtype) {
	case QUERY_TYPE_SP:		return "QUERY_TYPE_SP";
	case QUERY_TYPE_FOR:		return "QUERY_TYPE_FOR";
	case QUERY_TYPE_BASIC:		return "QUERY_TYPE_BASIC";
	case QUERY_TYPE_FORWARD:	return "QUERY_TYPE_FORWARD";
	case QUERY_TYPE_BACKWARD:	return "QUERY_TYPE_BACKWARD";
	case QUERY_TYPE_COMPLEX:	return "QUERY_TYPE_COMPLEX";
	case QUERY_TYPE_CONSTANT:	return "QUERY_TYPE_CONSTANT";
	case QUERY_TYPE_REMOTE:		return "QUERY_TYPE_REMOTE";
	case QUERY_TYPE_ATTR:		return "QUERY_TYPE_ATTR";
	case QUERY_TYPE_UNKNOWN:	return "QUERY_TYPE_UNKNOWN";
	default:			return "Illegal query type!";
	}
  }

  void print ()
  {
	// print class name
	System.out.println ("[" + simpleClassName () + "]");

	// print field states
	System.out.println ("query_type=" + getQueryTypeName (query_type));
	if (xpath != null)
	  System.out.println ("xpath=" + xpath.toString() 
			     + ",which_step=" + which_step);
	else
	  System.out.println ("xpath=null");

	if (query_type == QUERY_TYPE_CONSTANT) {
	  System.out.println ("result=" + result[0]);
	}
	if (query_type == QUERY_TYPE_ATTR) {
	  if (result.length > 0)
	    System.out.println ("result=" + result[0]);
	}
	if (sq_name != null) {
	  System.out.println ("sq_name=" + sq_name);
	}

	// call super.print to print super class fields and children
	super.print ();
  }

} // SubXpathOperator

// ---------------------------------------------------------------------
//                         class MergeSource
// ---------------------------------------------------------------------
class MergeSource {

  // create a child operator for merge
  // Element e is the hanging node/stop node/etc for the child operator.
  // expand the operator locally. 
  // return true if the operator does not involve remote operation.
  // return false otherwise.
  boolean expandOperator (Element e, MergeOperator merge)
  {
	Utils.error ("MergeSource::expandOperator is called directly!");
	return false;
  }

  String simpleClassName ()
  {
        String name = getClass().toString();
        if (name.startsWith ("class com.intel.sensors.oa."))
          return name.substring (27);
        else
          return name;
  }

  void print ()
  {
	System.out.println (simpleClassName ());
  }

} // MergeSource

class SubXpathMergeSource extends MergeSource {

  QueryOperator merge_parent;
  Expr          xpath;
  int           result_type;
  
  void setup (QueryOperator mergeParent, String query)
  {
        merge_parent = mergeParent;
        result_type = merge_parent.getResultType();
     try {
        xpath = XPathQueryParser.parsequery (query);
     } catch (Exception e) {
        Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  void setup (QueryOperator mergeParent, Expr query)
  {
        merge_parent = mergeParent;
        result_type = merge_parent.getResultType();
        xpath = query;
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
        // create SubXpathOperator
        SubXpathOperator one = new SubXpathOperator (merge);
        one.lca_bound = -2;
        Element mapped_el = merge_parent.mapNodetoOriginalTree (e);
        QueryInfo qinfo = new QueryInfo (merge_parent.query_info, mapped_el);
        one.setup (qinfo, xpath, result_type);

	return one.expandLocally ();
  }
} // SubXpathMergeSource

// ---------------------------------------------------------------------
//                         class LocalResultOperator
// ---------------------------------------------------------------------
class LocalResultMergeSource extends MergeSource {

  SubXpathOperator sub;
  Node             local_result;
  String	   attribute_name;
  int              result_type;

  void setup (SubXpathOperator sub_xpath, Node local_result_tree)
  {
	sub = sub_xpath;
	local_result = local_result_tree;
	attribute_name = null;
	result_type = sub.getResultType();
	if (sub.getResultType() == QueryOperator.RESULT_ATTR) {
	  LocationPath lp = (LocationPath) sub.xpath;
          Step last_step = lp.getStep (lp.getStepsCount()-1);
          attribute_name = last_step.getNodeTest().toString();
        }
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
	LocalResultOperator lr = new LocalResultOperator (merge);
	lr.setup (local_result, result_type, attribute_name);

	return true;
  }
} // LocalResultMergeSource

class LocalResultOperator extends QueryOperator {

  Node     local_result;    // the local result tree

  NodeList local_nodelist;
  String   attribute_name=null;  // valid when RESULT_ATTR
  String[] string_result;   // the result for RESULT_ATTR or RESULT_TEXT

  boolean  update_pending = false;

  LocalResultOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (Node local_result_tree, int rtype, String attr_name)
  {
	local_result = (local_result_tree instanceof Document)?
		        ((Document)local_result_tree).getDocumentElement ():
			local_result_tree;
	setResultType (rtype);

	if (isResultString (rtype)) {

	  NodeList nl = getResultNodeList (local_result);
	  local_nodelist = nl;
	  int num_nodes = nl.getLength ();
	  string_result = new String[num_nodes];

	  if (rtype == RESULT_ATTR) {
	    attribute_name = attr_name;
	    for (int ii=0; ii<num_nodes; ii++) {
	       Element n = (Element) nl.item (ii);
	       string_result[ii] = n.getAttribute(attribute_name);
	    }
	  }
	  else {
	    // RESULT_TEXT
	    for (int ii=0; ii<num_nodes; ii++) {
	       Node n = nl.item (ii);
	       StringBuffer sb = new StringBuffer ();
	       try {
	          Node child = n.getFirstChild ();
	          while (child != null) {
		    if (child instanceof org.w3c.dom.Text) {
		      sb.append (((org.w3c.dom.Text)child).getData ());
		    }
		    child = child.getNextSibling ();
	          }
	       } catch (Exception e) {
		  Utils.error (e.getClass().toString() + e.getMessage());
	       }
	       string_result[ii] = sb.toString().trim();
	    } // end of for
	  }

	  // since we have used [@attr], the result node must have the attribute
	  // for text, if the node does not contain text, the result string will
	  // be "" (empty string).

	  if (query_info.continuous && (query_info.mode == 1)) {
	    registerNodeList (nl);
	  }

	} // isResultString (rtype)

	  // tree result types
	else {
	  if (query_info.continuous && (query_info.mode == 1)) {
	    if (getResultType () == RESULT_SUBTREE)
	      registerSubTree (query_info.ownerAgentForRootParent(), 
			     (Element) local_result);
	    else { // RESULT_NODE
	      local_nodelist = getResultNodeList (local_result);
	      registerNodeList (local_nodelist);
	    }
	  }
	}
  }

  // for RESULT_SUBTREE
  void registerSubTree (String owner_agent_for_root_parent, Element root)
  {
	// we only register owned ID-able elements
	String status = root.getAttribute("status");
        if ((status != null) && status.equals("ownsthis")) {
                                                                                
	    // 1. get the owner_agent for this element
	    String owner_agent = null;
	    { String idHere =  root.hasAttribute("id")?
                               root.getAttribute("id"): root.getTagName();
              owner_agent = (owner_agent_for_root_parent.length()>0)?
                          (idHere + '.' + owner_agent_for_root_parent):
                          (idHere);
	    }

	    // 2. register this element
	    NodeInterested ni = new NodeInterested ();
	    ni.local_op = this; ni.node_interested = root;
	    ContinuousQuery.registerNode (owner_agent, ni);

	    // 3. check all the child elements
	    Node ch = root.getFirstChild();
	    while (ch != null) {
		if (ch instanceof Element) {
		  registerSubTree (owner_agent, (Element) ch);
		}
		ch = ch.getNextSibling();
	    }
        }
  }

  void unregisterSubTree (String owner_agent_for_root_parent, Element root)
  {
        // unregister owned ID-able elements
        String status = root.getAttribute("status");
        if ((status != null) && status.equals("ownsthis")) {
                                                                                
            // 1. get the owner_agent for this element
            String owner_agent = null;
            { String idHere =  root.hasAttribute("id")?
                               root.getAttribute("id"): root.getTagName();
              owner_agent = (owner_agent_for_root_parent.length()>0)?
                          (idHere + '.' + owner_agent_for_root_parent):
                          (idHere);
            }
                                                                                
            // 2. unregister this element
            ContinuousQuery.unregisterNode (owner_agent, root);
                                                                                
            // 3. check all the child elements
            Node ch = root.getFirstChild();
            while (ch != null) {
                if (ch instanceof Element) {
                  unregisterSubTree (owner_agent, (Element) ch);
                }
                ch = ch.getNextSibling();
            }
        }
  }

  // for RESULT_TEXT, RESULT_ATTR, and RESULT_STRING and RESULT_NODE
  void registerNodeList (NodeList nl)
  {
	String owner_agent_for_root_parent = 
			query_info.ownerAgentForRootParent ();

        int num_nodes = nl.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
           Element n = (Element) nl.item (ii);

	   // we only register owned ID-able elements
	   String status = n.getAttribute("status");
           if ((status != null) && status.equals("ownsthis")) {

	     // 1. get the owner_agent for the element
	     String local_owner_agent = DOMProcessing.findOwnerAgent(n);
	     String owner_agent = (owner_agent_for_root_parent.length() > 0) ?
                 	(local_owner_agent + '.' + owner_agent_for_root_parent):
			(local_owner_agent);

	     // 2. register this element
	     NodeInterested ni = new NodeInterested ();
             ni.local_op = this; ni.node_interested = n;
	   
	     ContinuousQuery.registerNode (owner_agent, ni);
	   }
        }
  }

  void unregisterNodeList (NodeList nl)
  {
        String owner_agent_for_root_parent =
                        query_info.ownerAgentForRootParent ();
                                                                                
        int num_nodes = nl.getLength ();
        for (int ii=0; ii<num_nodes; ii++) {
           Element n = (Element) nl.item (ii);
                                                                                
           // we only register owned ID-able elements
           String status = n.getAttribute("status");
           if ((status != null) && status.equals("ownsthis")) {
                                                                                
             // 1. get the owner_agent for the element
             String local_owner_agent = DOMProcessing.findOwnerAgent(n);
             String owner_agent = (owner_agent_for_root_parent.length() > 0) ?
                        (local_owner_agent + '.' + owner_agent_for_root_parent):                        (local_owner_agent);
                                                                                
             // 2. unregister this element
             ContinuousQuery.unregisterNode (owner_agent, n);
           }
        }
  }

  // update a node
  void updateNode (Element n, String attr, String new_value)
  {
	if (attribute_name != null) {//RESULT_ATTR
	  if (! attribute_name.equals (attr))
	    return;
	}

	try {
	  n.setAttribute (attr, new_value);
	} catch (Exception e) {
	  Utils.error (e.getClass().toString() + ':' + e.getMessage());
	}

	update_pending = true;
  }

  // this will only be called for continuous query
  void resultReady (int which_child)
  {
	// prepare results
        if (isResultString ()) {
                                                                                
          NodeList nl = local_nodelist;
          int num_nodes = nl.getLength ();
                                                                                
          if (attribute_name != null) {//RESULT_ATTR
            for (int ii=0; ii<num_nodes; ii++) {
               Element n = (Element) nl.item (ii);
               string_result[ii] = n.getAttribute(attribute_name);
            }
          }
          else {
            // RESULT_TEXT
            for (int ii=0; ii<num_nodes; ii++) {
               Node n = nl.item (ii);
               StringBuffer sb = new StringBuffer ();
               try {
                  Node child = n.getFirstChild ();
                  while (child != null) {
                    if (child instanceof org.w3c.dom.Text) {
                      sb.append (((org.w3c.dom.Text)child).getData ());
                    }
                    child = child.getNextSibling ();
                  }
               } catch (Exception e) {
                  Utils.error (e.getClass().toString() + e.getMessage());
               }
               string_result[ii] = sb.toString().trim();
            } // end of for
          }
        } // isResultString ()

        // notify parent of the new result
        getParent().resultReady (getParentIndex());

	update_pending = false;
  }

  void expandRemotely () 
  { 	// do nothing
  }

  void terminate ()
  { 	// do nothing unless this is continuous query
	if (query_info.continuous && (query_info.mode == 1)) {
	  if (getResultType () != RESULT_SUBTREE)
	    unregisterNodeList (local_nodelist);
	  else
	    unregisterSubTree (query_info.ownerAgentForRootParent(),
                               (Element) local_result);
	}
  }

  void terminateLocally ()
  {
	terminate ();
  }

  Object getResult ()
  {
	if (isResultString())
	  return string_result;
	else
          return local_result;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
        // insert a copy of the SPInitComputeOperator
        // in the middle of this and its parent
                                                                                
        SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();
                                                                                
        middle.setParent (getParent(), getParentIndex());
        getParent().setChild (getParentIndex(), middle);
                                                                                
        int pindex = middle.addChild (this);
        setParent (middle, pindex);

	// set up result
	middle.processResult (pindex);

	return true;
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	if (isResultString()) {
	  // string
	  if (getResultType() == RESULT_ATTR) {
	    System.out.println ("attribute_name=" + attribute_name);
	  }
	  System.out.print ("string_result(" + string_result.length + ")=");
	  for (int ii=0; ii<string_result.length; ii++) {
	     System.out.print ("'" + string_result[ii] + "'");
	     if (ii != string_result.length-1)
	       System.out.print (",");
	  }
	  System.out.println ();
	}
	else {
	  // tree
	  System.out.println ("local_result:");
	  DOMProcessing.prettyPrint (local_result);
	}
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // LocalResultOperator

// ---------------------------------------------------------------------
//                         class LocalFetchAllOperator
// ---------------------------------------------------------------------
class LocalFetchAllMergeSource extends MergeSource {

  SubXpathOperator sub;
  Transformer      t;
  String           attribute_name;
  int              result_type;

  void setup (SubXpathOperator sub_xpath, Transformer transformer)
  {
	sub = sub_xpath;
	t = transformer;
	attribute_name = null;
	result_type = sub.getResultType();
	if (sub.getResultType() == QueryOperator.RESULT_ATTR) {
	  LocationPath lp = (LocationPath) sub.xpath;
          Step last_step = lp.getStep (lp.getStepsCount()-1);
          attribute_name = last_step.getNodeTest().toString();
        }
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
	LocalFetchAllOperator op = new LocalFetchAllOperator (merge);
	Element mapped_el = sub.mapNodetoOriginalTree (e);

	op.setup (mapped_el, t, result_type, attribute_name);

        return op.expandLocally ();
  }
} // LocalFetchAllMergeSource

class LocalFetchAllOperator extends QueryOperator {

  Element  root_at_node;	// the subtree of the node is to be fetched
  Transformer t;		// compiled xslt corresponding to the rest of
				// the query
  String   attribute_name;

  Document dom_result;		// contains the dom tree of applying t to
				// the fetched subtree
  String[] string_result;	// contains result if string result is required

  LocalFetchAllOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (Element root_at, Transformer transformer, int rtype,
	      String attr_name)
  {
	root_at_node = root_at;
	t = transformer; 
	attribute_name = attr_name;

	setResultType (rtype);

	dom_result = null;
  }

  // create sub xpath operator
  // returns true if the sub xpath can be answered locally
  boolean expandLocally ()
  {
	// get a new query info for the sub xpath operator
	QueryInfo qinfo = new QueryInfo (query_info, root_at_node);

	// get the query string tag
	Expr expr = null;
	try {
        expr = XPathQueryParser.parsequery(root_at_node.getTagName());
	} catch (Exception e) {
	  System.err.println ("Can not parse a simple xpath expression?");
	  Utils.shouldnthappen ();
	}

	// create sub xpath operator
	SubXpathOperator  get_subtree = new SubXpathOperator (this);
	get_subtree.lca_bound = -2;
	get_subtree.setup (qinfo, expr, RESULT_SUBTREE);

	if (get_subtree.expandLocally ()) {
	  processResult ();
	  return true;
	}
	
	return false;
  }

  void resultReady (int which_child)
  {
	processResult ();

	// notify parent
        getParent().resultReady (getParentIndex());
  }

  void processResult ()
  {
	// the result should be a full subtree
	Node n = (Node) getChild(0).getResult();

	if (n == null) {
	  dom_result = null; string_result = empty_string_output;
	  return;
	}

	// apply xslt
	Document local_result = DOMProcessing.applyXSLTtoDOM (n, t);

	// get the result
	dom_result = local_result;
        if (isResultString ()) {
  
          NodeList nl = getResultNodeList (local_result);
          int num_nodes = nl.getLength ();
          string_result = new String[num_nodes];

          if (getResultType() == RESULT_ATTR) {
            for (int ii=0; ii<num_nodes; ii++) {
               Element el = (Element) nl.item (ii);
               string_result[ii] = el.getAttribute(attribute_name);
            }
          }
          else {
            // RESULT_TEXT
            for (int ii=0; ii<num_nodes; ii++) {
               Node node = nl.item (ii);
               StringBuffer sb = new StringBuffer ();
               try {
                  Node child = node.getFirstChild ();
                  while (child != null) {
                    if (child instanceof org.w3c.dom.Text) {
                      sb.append (((org.w3c.dom.Text)child).getData ());
                    }
                    child = child.getNextSibling ();
                  }
               } catch (Exception e) {
                  Utils.error (e.getClass().toString() + ':' + e.getMessage());
               }
               string_result[ii] = sb.toString().trim();
            } // end of for
          }
        } // isResultString (rtype)
  }
  
  Object getResult ()
  {
	if (isResultString())
          return string_result;
        else if (dom_result != null)
          return dom_result.getDocumentElement ();
	else
	  return null;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
        // insert a copy of the SPInitComputeOperator
        // in the middle of this and its parent

        SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();

        middle.setParent (getParent(), getParentIndex());
        getParent().setChild (getParentIndex(), middle);

        int pindex = middle.addChild (this);
        setParent (middle, pindex);

        if (dom_result != null) {
          // set up result
          middle.processResult (pindex);
	  return true;
        }
	else {
	  return false;
	}
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");

        // print field states
	System.out.println ("root_at_node=" + root_at_node.getTagName() +
			    QueryAnalysis.queryforId (root_at_node));
	if (attribute_name != null)
	  System.out.println ("attribute_name=" + attribute_name);

      if (dom_result != null)
        if (isResultString()) {
          // string
          System.out.print ("string_result(" + string_result.length + ")=");
          for (int ii=0; ii<string_result.length; ii++) {
             System.out.print ("'" + string_result[ii] + "'");
             if (ii != string_result.length-1)
               System.out.print (",");
          }
          System.out.println ();
        }
        else {
          // tree
          System.out.println ("dom_result:");
          DOMProcessing.prettyPrint (dom_result);
        }

        // call super.print to print super class fields and children
        super.print ();
  }

} // LocalFetchAllOperator

// ---------------------------------------------------------------------
//                         class RemoteQueryOperator
// ---------------------------------------------------------------------
class RemoteMergeSource extends MergeSource {

  SubXpathOperator sub;
  String[]         ret;
  int              result_type;

  void setup (SubXpathOperator sub_xpath)
  {
	sub = sub_xpath;
	ret = new String[3];
	result_type = sub.getResultType();
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
      if (sub.query_type != SubXpathOperator.QUERY_TYPE_FOR) {
        // get host, subquery, and root_at
        QueryAnalysis.getRemoteQueryInfo (sub.query_info, e, 
				(LocationPath)sub.xpath, ret);
        String lca_host = ret[0];
        String query    = ret[1];
        String root_at  = ret[2];

        // create remote query operator
        RemoteQueryOperator rq = new RemoteQueryOperator (merge);
        rq.setup (result_type, lca_host, query, root_at);

	return false;
      }
      else {
	// for loop
	ForExpr for_expr = (ForExpr)sub.xpath;

        // get host, subquery, and root_at
        QueryAnalysis.getRemoteQueryInfo (sub.query_info, e,
                      (LocationPath)for_expr.getInExpr(), ret);
        String lca_host = ret[0];
        String query    = ret[1];
        String root_at  = ret[2];

	query = "for " + for_expr.getLoopVariable().toString()
		+ " in " + query
		+ " return " + for_expr.getReturnExpr().toString();

        // create remote query operator
        RemoteQueryOperator rq = new RemoteQueryOperator (merge);
        rq.setup (result_type, lca_host, query, root_at);

        return false;
      }
  }
} // RemoteMergeSource

class RemoteQueryOperator extends QueryOperator {

  String   lca_host_name;
  String   query;
  String   root_at_node;
  Document dom_result;
  String[] string_result;

  long     query_id = -1;

  RemoteQueryOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (int rtype, String host, String subquery, String root_at)
  {
	setResultType (rtype);
	lca_host_name = host;
	query = subquery;
	root_at_node = root_at;
	dom_result = null;
	string_result = null;
  }

  void expandRemotely ()
  {
	// ask remote query
     try {
        RemoteSourceInfo rsi = new RemoteSourceInfo(lca_host_name);

	if (query_id == -1)
	  query_id = QueryNotify.register (this);

	String my_query = query;
	if (query_info.continuous) {
	  my_query = "continuous(" + query 
		   + ",'mode=" + query_info.mode
		   + "','period=" + query_info.period
		   + "','lease=" + query_info.lease
		   + "')";
	}

	// Note that we also send the subtree_consistency_checking
	Protocol.enqueueQuery2Message (
		query_id, getResultType(), root_at_node, 
		query_info.subtree_consistency_checking, my_query,
		rsi.mRemoteHostName, rsi.mRemotePortNumber,
		false);

	// debugging
/*
	Object ret = QueryOperator.buildRoot (root_at_node, query,
				getResultType(), 123L);

	if (ret == null) {
	  resultReady ();
	}
	else if (ret instanceof Node) {
	  resultReady (DOMProcessing.DOMtoXML ((Node)ret));
	}
	else {
	  resultReady ((String[])ret);
	}
*/
     } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  void terminate ()
  {
	QueryNotify.cancel (query_id);

	// if this is a continous query, send termination message
        if (query_info.continuous)
     try {
        RemoteSourceInfo rsi = new RemoteSourceInfo(lca_host_name);
                                                                                
        String my_query = "continuous(" + query
                   + ",'mode=" + query_info.mode
                   + "','period=" + query_info.period
                   + "','lease=0')";
                                                                                
        Protocol.enqueueQuery2Message (
                query_id, getResultType(), root_at_node, 
		null, my_query,
                rsi.mRemoteHostName, rsi.mRemotePortNumber,
		false);
                                                                                
     } catch (Exception e) {
        Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  void terminateLocally ()
  {
	QueryNotify.cancel (query_id);
  }

  // should be called when we need a tree
  void resultReady (String reply)
  {
    if (isResultTree () || (getResultType() == RESULT_UNKNOWN)) {

      if (getResultType() == RESULT_UNKNOWN)
	setResultType (RESULT_SUBTREE);

      if ((reply == null) || (reply.length() == 0)) {
	dom_result = null;
      }
      else {
       try {
	dom_result = DOMProcessing.XMLtoDOM (reply);
       } catch (Exception e) {
	Utils.error ("Remote result error:" + e.getClass().toString());
       } 
      }
	// notify parent
        getParent().resultReady (getParentIndex());

	// cancel registration if not continuous query
	if (! query_info.continuous)
	  terminate ();

	// ---
	// caching: we only cache the result when it is a subtree
	if (getResultType() == RESULT_SUBTREE) {
	  if (ServantReply.cacheResponse) {
            CacheManagement.CacheResponse(reply, root_at_node);
          }
	}
    }
  }

  void resultReady (String[] reply)
  {
	if (isResultString () || (getResultType() == RESULT_UNKNOWN)) {

          if (getResultType() == RESULT_UNKNOWN)
    	    setResultType (RESULT_STRING);

	  string_result = (reply != null)? reply : empty_string_output;

	  // notify parent
          getParent().resultReady (getParentIndex());

  	  // cancel registration if not continuous query
	  if (! query_info.continuous)
	    terminate ();
	}
  }

  // when result is null
  void resultReady ()
  {
	dom_result = null;
	string_result = empty_string_output;
	// notify parent
	getParent().resultReady (getParentIndex());

	// cancel registration if not continuous query
	if (! query_info.continuous)
	  terminate ();
  }

  Object getResult ()
  {
	if ( isResultString() )
	  return string_result;
	else if (dom_result != null)
	  return dom_result.getDocumentElement ();
	else
	  return null;
  }

  boolean rewrite (SPInitComputeOperator s)
  {
	StringBuffer sb = new StringBuffer ();

	sb.append (s.spinfo.full_name);
	sb.append (inter_suffix); sb.append ('(');
	sb.append (query);

	String[] params = s.params;
	for (int ii=0; ii<params.length; ii++) {
	   sb.append (",'"); sb.append (params[ii]); sb.append ("'");
	}
	sb.append (')');

	query = sb.toString ();

	setResultType (RESULT_STRING);

	return false;
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	System.out.println ("lca_host_name=" + lca_host_name
			+ ", query=" + query
			+ ", root_at_node=" + root_at_node);
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // RemoteQueryOperator

// ---------------------------------------------------------------------
//                         class MergeOperator
// ---------------------------------------------------------------------
class MergeOperator extends QueryOperator {

  MergeSource[]		merge_source;
  ArrayList		nodes;			// nodes for all sources
  int[]			offsets;		// offsets[i-1]~offsets[i]-1
						// are nodes for source i
  int        		num_result_avail;
  int			num_to_expand_next;	// control child creation
  int			start_node;		// [start, end-1] are current
  int			end_node;		// children

  SPInitComputeOperator spic=null;		// after rewriting
						// remember the stored procedure

  MergeOperator (QueryOperator my_parent)
  { super(my_parent); }

  // set up the fields
  // beginSetup, addMergeSource, addMergeSource, ..., finishSetup
  void beginSetup (int num_merge_source, int rtype)
  {
	merge_source = new MergeSource[num_merge_source];
	nodes = new ArrayList ();
	offsets = new int[num_merge_source];

	num_result_avail = 0;
	start_node = end_node = 0;
	num_to_expand_next = 0;

	setResultType (rtype);
  }

  // the index must be increasing
  void addMergeSource (int index, MergeSource ms, ArrayList nodes_for_ms)
  {
	merge_source[index] = ms;
	nodes.addAll (nodes_for_ms);
	offsets[index] = nodes.size ();
  }

  void addMergeSource (int index, MergeSource ms, Node[] nodes_for_ms)
  {
	merge_source[index] = ms;
	for (int ii=0; ii<nodes_for_ms.length; ii++)
	   nodes.add (nodes_for_ms[ii]);
	offsets[index] = nodes.size ();
  }

  void addMergeSource (int index, MergeSource ms, NodeList nodes_for_ms)
  {
	merge_source[index] = ms;
	int num = nodes_for_ms.getLength ();
	for (int ii=0; ii<num; ii++)
	   nodes.add (nodes_for_ms.item(ii));
	offsets[index] = nodes.size ();
  }

  void finishSetup () { }

  // creating child operators
  // return true if all expanded operators do not involve remote operations
  // return false otherwise.
  boolean expandAllLocally ()
  {
	int num_nodes_not_expanded = nodes.size () - end_node;
	return (expandLocally (num_nodes_not_expanded) 
		== num_nodes_not_expanded);
  }

  // set up num_to_expand_next, then call expandNextBunchLocally ()
  boolean expandNextBunchLocally (int num_at_once)
  {
	num_to_expand_next = num_at_once;
	return expandNextBunchLocally ();
  }

  boolean expandNextBunchLocally ()
  {
	int num;
	do {
	  num = num_to_expand_next;
	  if (end_node + num > nodes.size()) {
	    num = nodes.size() - end_node;
	    if (num == 0)
	      return true;
	  }
	} while (expandLocally(num) == num);
	return false;
  }

  // Last bunch of children have finished
  // this method creates num of children by calling MergeSource.expandOperator
  // return the number of children that do not involve remote operation
  protected int expandLocally (int num)
  {
	removeAllChildren ();

	int start = end_node;
	int end   = start + num;

	if (start >= nodes.size ()) {
	  start_node = end_node = nodes.size ();
	  return 0;
	}

	if (end > nodes.size ()) {
	  end = nodes.size ();
	}

	// 1. look for the MergeSource for the start node
	//    start < nodes.size ()
	int index = 0;
	for (; start >= offsets[index]; index ++);

	// 2. generate operators
	int num_ready = 0;
	int which_child = 0;
	MergeSource ms;

	int ii = start;
	for (; end > offsets[index]; index ++) {
	   ms = merge_source[index];
	   for (; ii < offsets[index]; ii++) {
	        Element e = (Element) nodes.get (ii);
		boolean ret = ms.expandOperator (e, this);
		if (spic != null)
		  ret = (getChild(which_child).rewrite (spic) || ret);
	        if (ret) {
		  processResult (which_child, ii);
		  num_ready ++;
	        }
	        which_child ++;
	   }
	}
	ms = merge_source[index];
        for (; ii < end; ii++) {
                Element e = (Element) nodes.get (ii);
		boolean ret = ms.expandOperator (e, this);
		if (spic != null)
		  ret = (getChild(which_child).rewrite (spic) || ret);
	        if (ret) {
                  processResult (which_child, ii);
                  num_ready ++;
                }
                which_child ++;
        }

	// 3. set start_node and end_node
	start_node = start;
	end_node = end;

	return num_ready;
  }

  // this method will be overridden by sub class
  boolean isResultReady (int which_node)
  {
	return false;
  }

  void expandRemotely ()
  {
        // make recursive calls to children
        int num_children = getChildCount ();
        for (int ii=0; ii<num_children; ii++)
	  if (query_info.continuous || !isResultReady(start_node+ii))
            getChild(ii).expandRemotely ();
  }

  // get result
  void resultReady (int which_child)
  {
	int which_node = start_node + which_child;

	processResult (which_child, which_node);

	if ((num_result_avail == end_node) && !query_info.continuous) {
	  if ((num_to_expand_next>0) && (!expandNextBunchLocally ()))
	    super.expandRemotely ();
	}

	if (num_result_avail == nodes.size()) {
          // notify parent
          getParent().resultReady (getParentIndex());
	}
  }

  void processResult (int which_child, int which_node) {}

  void print ()
  {
        // print field states
	System.out.println ("merge_source(" + merge_source.length + ")=");
	for (int ii=0; ii<merge_source.length; ii++) {
	   System.out.print (" (" + ii + ") ");
	   merge_source[ii].print ();
	}

	int kk = 0;
	for (int index = 0; index < offsets.length; index ++) {
	   System.out.print ("nodes from source " + index 
			     + " (" + (offsets[index]-kk) +  "):");
	   for (; kk<offsets[index]; kk++) {
	      if (nodes.get (kk) instanceof Element) {
	        Element e = (Element) nodes.get (kk);
	        if (e != null)
	          System.out.print (e.getTagName() 
				  + QueryAnalysis.queryforId(e));
	        else
		  System.out.print ("null");
	      }
	      else {
		String e = (String) nodes.get (kk);
		System.out.print ((e!=null)?e:"null");
	      }

	      if (kk != offsets[index]-1)
		System.out.print (",");
	   }
	   System.out.println ();
	}

	System.out.println ("num_result_avail=" + num_result_avail
			+ ", num_to_expand_next=" + num_to_expand_next
			+ ", start_node=" + start_node
			+ ", end_node=" + end_node);
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // MergeOperator

// ---------------------------------------------------------------------
//                         class TreeMergeOperator
// ---------------------------------------------------------------------
class TreeMergeOperator extends MergeOperator {

  Node       result;
  boolean[]  child_result_ready;

  TreeMergeOperator (QueryOperator my_parent)
  { super(my_parent); }

  void beginSetup (Node local_result_tree, int num_merge_source, int rtype)
  {
	super.beginSetup (num_merge_source, rtype);
        result = (local_result_tree instanceof Document)?
                  ((Document)local_result_tree).getDocumentElement ():
                  local_result_tree;
  }

  void finishSetup ()
  {
	int num_children = nodes.size ();
	child_result_ready = new boolean[num_children];
	for (int ii=0; ii<num_children; ii++)
	   child_result_ready[ii] = false;
  }

  boolean isResultReady (int which_node)
  {
        return child_result_ready[which_node];
  }

  // which_child:  which child operator?
  // which_node:   index of nodes array
  // child can return null to indicate that a sub query finds no result
  void processResult (int which_child, int which_node)
  {
	if (!child_result_ready[which_node]) {
	  num_result_avail ++;
	  child_result_ready[which_node] = true;
	}

	Element e = (Element) nodes.get (which_node);
	if (e != null) {
          // record child result
          Element child_result = (Element)(getChild(which_child).getResult());
	  if (child_result != null) {
	    // child is successful
            Node parent = e.getParentNode ();
            parent.replaceChild (child_result, e);
	    nodes.set (which_node, child_result);

	    if (e == result) {
	      result = child_result;
	    }
	  }
	} // e != null
  }
  
  Object getResult ()
  {
	return result;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
	// 1. generate a StringMergeOperator and copy MergeOperator fields
	StringMergeOperator smerge = new StringMergeOperator (null);

	// parent parent_index
	smerge.setParent (getParent(), getParentIndex());
	getParent().setChild (getParentIndex(), smerge);

	// children
	int num_children = getChildCount ();
	for (int ii=0; ii<num_children; ii++) {
	   QueryOperator ch = getChild (ii);
	   smerge.addChild (ch);
	   ch.setParent (smerge, ii);
	}

	// other QueryOperator fields
	smerge.setResultType (RESULT_STRING);
	smerge.lca_bound = lca_bound;
	smerge.query_info = query_info;

	// MergeOperator fields
	smerge.merge_source = merge_source;
	smerge.nodes = nodes;
	smerge.offsets = offsets;

	smerge.num_result_avail = num_result_avail;
	smerge.num_to_expand_next = num_to_expand_next;
	smerge.start_node = start_node;
	smerge.end_node = end_node;

	// 2. set up StringMergeOperator fields
	smerge.result = null;

	String empty = "";
	int num_nodes = nodes.size();
        smerge.child_result = new ArrayList (num_nodes);
        for (int ii=0; ii<num_nodes; ii++) {
           smerge.child_result.add (ii, child_result_ready[ii]?empty:null);
	}

	// 3. call rewrite of the StringMergeOperator
	return smerge.rewrite (s);
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	System.out.println ("result:");
	DOMProcessing.prettyPrint (result);

	System.out.print ("child_result_ready: ");
	for (int ii=0; ii<child_result_ready.length; ii++)
	   if (child_result_ready[ii]) {
	     System.out.print (ii + ",");
	   }
	System.out.println ();
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // TreeMergeOperator

// ---------------------------------------------------------------------
//                         class StringMergeOperator
// ---------------------------------------------------------------------
class StringMergeOperator extends MergeOperator {

  String[]   result;
  ArrayList  child_result;	// array list of String[]

  boolean    check_pruning = false;
  boolean    pruned = false;

  StringMergeOperator (QueryOperator my_parent)
  { super(my_parent); }

  void finishSetup ()
  {
	result = empty_string_output;
	int num_children = nodes.size();
	child_result = new ArrayList (num_children);
	for (int ii=0; ii<num_children; ii++)
	   child_result.add (ii, null);
  }

  boolean isResultReady (int which_node)
  {
        return (child_result.get(which_node)!=null);
  }

  // if pruned return true, otherwise return false
  boolean checkPrune (int which_node)
  {
	if (pruned) return true;

        Object ch_result = child_result.get (which_node);
        if (ch_result != null) {
          String inter_val = getResultString ((String[]) ch_result);
          pruned = spic.callPrune (inter_val);
	  if (pruned) {
	    result = (String[]) ch_result;
	    return true;
	  }
        }

	return false;
  }

  // which_child:  which child operator?
  // which_node:   index of nodes array
  // child can return null or empty string[] to indicate no result
  void processResult (int which_child, int which_node)
  {
        // increment num_result_avail
        if (child_result.get(which_node) == null) {
          num_result_avail ++;
        }
                                                                                
        // record child result
	Object ch_input = getChild(which_child).getResult();
	if (ch_input == null)
	  ch_input = empty_string_output;
	child_result.set (which_node, ch_input);

	if (num_result_avail == nodes.size()) {
            // allocate result array
            int total = 0;
            for (int ii=0; ii<num_result_avail; ii++) {
	       String[] r = (String[]) child_result.get (ii);
	       if (r != null)
                 total += r.length;
	    }
            result = new String[total];
                                                                                
            // copy String references
            int kk=0;
            for (int ii=0; ii<num_result_avail; ii++) {
	       String[] r = (String[]) child_result.get (ii);
	       if (r != null) {
                 int length = r.length;
                 for (int jj=0; jj<length; jj++)
                    result[kk++] = r[jj];
               }
	    }

	} // num_result_avail == nodes.size()
	else if (check_pruning) {
	  checkPrune (which_node);
	} // check_pruning
  }

  // get result
  void resultReady (int which_child)
  {
	if (! check_pruning) {
	  super.resultReady (which_child);
	  return;
	}

	if (! pruned) {
          int which_node = start_node + which_child;
          processResult (which_child, which_node);

	  if (pruned) {
	    // notify parent
            getParent().resultReady (getParentIndex());

	    return;
	  }
                                                                                
          if ((num_result_avail == end_node) && !query_info.continuous) {
            if ((num_to_expand_next>0) && (!expandNextBunchLocally ()))
              super.expandRemotely ();
          }
                                                                                
          if (num_result_avail == nodes.size()) {
            // notify parent
            getParent().resultReady (getParentIndex());
          }
	}
  }

  Object getResult ()
  {
        return result;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
	spic = s;

        // 1. insert a copy of the SPComputeOperator 
        //    in the middle of this and its parent
        SPComputeOperator middle = s.getCopyOfComputeOperator ();

        middle.setParent (getParent(), getParentIndex());
        getParent().setChild (getParentIndex(), middle);

        int pindex = middle.addChild (this);
        setParent (middle, pindex);

	setResultType (RESULT_STRING);

	// 2. call rewrite on all children and get child results if necessary
	int num_children = getChildCount ();
        for (int ii=0; ii<num_children; ii++) {
	   boolean ret = getChild(ii).rewrite (s);
	   int which_node = start_node+ii;
           if (child_result.get(which_node) != null) {
	      // the child result is already available, record child result
              child_result.set (which_node, getChild(ii).getResult());
           }
	   else if (ret)
	      processResult (ii, which_node);
	}

	// 3. if the current children all return true, expand more children
	if ((num_result_avail == end_node) && !query_info.continuous) {
          if (num_to_expand_next>0)
	     expandNextBunchLocally ();
        }

	// 3.5 if we can prune, return true
	if (spic.spinfo.hasPrune () && !query_info.continuous) {
	  check_pruning = true;
	}

	if (check_pruning) {
	  int num_nodes = nodes.size();
	  for (int ii=0; ii<num_nodes; ii++)
	     if (checkPrune (ii))
		break;

	  if (pruned) {
	    // set up parent result
            middle.processResult (pindex);

	    return true;
	  }
	}

	// 4. if the combined result is ready
        if (num_result_avail == nodes.size()) {
	  // generate the result[]
	  processResult (0, start_node);
	  // set up parent result
          middle.processResult (pindex);

	  return true;
        }
	else {
	  return false;
	}
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	for (int ii=0; ii<child_result.size(); ii++) {
	   String[] r = (String[]) child_result.get (ii);
	   if (r != null) {
	     System.out.print ("child " + ii + " result (" + r.length + ")=");
	     for (int jj=0; jj<r.length; jj++) {
	        System.out.print (r[jj]);
		if (jj != r.length-1)
		  System.out.print (",");
	     }
	     System.out.println ();
	   }
	}
	if (check_pruning) {
	  System.out.println ("pruned=" + pruned);
	}
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // StringMergeOperator

// ---------------------------------------------------------------------
//                         class ForOperator
// ---------------------------------------------------------------------
class ForOperator extends QueryOperator {

  Expr    replaced_return_expr;

  boolean expanded;
  SPInitComputeOperator spic;

  ForOperator (QueryOperator my_parent)
  { super(my_parent); }

  // return true if all the results are locally available
  // otherwise return false
  boolean setup (Expr inExpr, Expr replacedReturnExpr)
  {
	setResultType (getParent().getResultType());

	replaced_return_expr = replacedReturnExpr;
	expanded = false;
	spic = null;

	// set up child 0: the SubXpathOperator to compute in expr
	SubXpathOperator sub = new SubXpathOperator (this);
        sub.setup (query_info, inExpr, RESULT_NODE);

	if (sub.expandLocally ()) {
	  return expandReturnExpr ();
	}
	else return false;
  }

  // return true if the return expr can be answered locally
  // otherwise return false
  boolean expandReturnExpr ()
  {
	expanded = true;

	// 1. get the in expr result
	Node local_result = (Node) (getChild(0).getResult());
	NodeList stop_nodes = getResultNodeList (local_result);

        // 2. child 1 is a merge operator
        MergeOperator merge;

        if (isResultTree ()) {
          // RESULT_SUBTREE, RESULT_NODE
          TreeMergeOperator tmerge = new TreeMergeOperator (this);
          tmerge.beginSetup (local_result, 1, getResultType ());
          merge = tmerge;
        }
        else {
          // RESULT_TEXT, RESULT_ATTR
          StringMergeOperator smerge = new StringMergeOperator (this);
          smerge.beginSetup (1, getResultType ());
          merge = smerge;
        }

        SubXpathMergeSource sbm = new SubXpathMergeSource ();
        sbm.setup (this, replaced_return_expr);

        merge.addMergeSource (0, sbm, stop_nodes);

	merge.finishSetup ();

	boolean ret = merge.expandAllLocally ();
        return ret;
  }

  void expandRemotely ()
  {
	if (! expanded)
	  getChild(0).expandRemotely ();
	else
	  getChild(1).expandRemotely ();
  }

  boolean rewrite (SPInitComputeOperator s)
  {
	if (! expanded) {
	  spic = s;
	  return false;
	}
	else {
	  return getChild(1).rewrite (s);
	}
  }

  void resultReady (int which_child)
  {
	if (! expanded) {
	  boolean ret = expandReturnExpr ();
	  if (spic != null)
	    ret = rewrite (spic);
	  if (! ret) {
	    getChild(1).expandRemotely ();
	    return;
	  }
	}

	getParent().resultReady (getParentIndex());
  }

  Object getResult ()
  {
	return getChild(1).getResult ();
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");

        // print field states
        System.out.println ("expanded=" + expanded);
        System.out.println ("replaced_return_expr="
                        + replaced_return_expr.toString());

        // call super.print to print super class fields and children
        super.print ();
  }

} // ForOperator

// ---------------------------------------------------------------------
//                         class IfOperator
// ---------------------------------------------------------------------
class IfMergeSource extends MergeSource {

  SubXpathOperator sub;
  ArrayList        query_for_predicates;
  int              num_predicates;
  Expr		   rest_xpath;
  int              result_type;

  void setup (SubXpathOperator sub_xpath, ArrayList predicates_queries, 
	      String rest_query)
  {
	sub = sub_xpath;
	query_for_predicates = predicates_queries;
	num_predicates = query_for_predicates.size ();
	result_type = sub.getResultType();
     try {
	rest_xpath = XPathQueryParser.parsequery (rest_query);
     } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage());
     }
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
	// create IfOperator
        IfOperator ifop = new IfOperator (merge);
        Element mapped_el = sub.mapNodetoOriginalTree (e);
        ifop.setup (num_predicates, rest_xpath, mapped_el, result_type);

	// create the and children
        QueryInfo qinfo = new QueryInfo (sub.query_info, mapped_el);

        boolean ifop_ready = false;
        for (int jj=0; jj<num_predicates; jj++) {
           SubXpathOperator s = new SubXpathOperator (ifop);
           s.setup (qinfo, (Expr) query_for_predicates.get(jj), 
		    QueryOperator.RESULT_STRING);
           if (s.expandLocally ()) {
             ifop_ready = ifop.processResult (jj);
           }
	}

        return ifop_ready;
  }
} // IfMergeSource

class IfOperator extends QueryOperator {

  // there will be several children representing predicates
  // The final result is the "and" of their results
  int       num_and_children;
  String[]  child_result;
  int       num_and_avail;	// how many children have finished?
  boolean   current_and_result; // the "and" of the results of finished children

  // if the predicate evaluates to true, we expand the operator
  // and ask the sub query on the element
  boolean   expanded;
  Expr      sub_query;
  Element   root_element;
  SPInitComputeOperator spic = null;

  IfOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (int num_predicates, Expr query, Element root, int rtype)
  {
	num_and_children = num_predicates;
	child_result = new String[num_and_children];
	for (int ii=0; ii<num_and_children; ii++)
	   child_result[ii] = null;
	num_and_avail = 0;
	current_and_result = true;

	expanded = false;
	sub_query = query;
	root_element = root;

	setResultType (rtype);
  }

  // add a sub xpath node and execute the sub query
  boolean expandLocally ()
  {
	expanded = true;

	int rtype = getResultType ();
	if (spic != null) {
	  rtype = (spic.spinfo.isSimple()?RESULT_STRING:RESULT_NODE);
	}

	SubXpathOperator sub_xpath = new SubXpathOperator (this);
	sub_xpath.lca_bound = -2;
	QueryInfo qinfo = new QueryInfo (query_info, root_element);
	sub_xpath.setup (qinfo, sub_query, rtype);

	boolean ret = sub_xpath.expandLocally ();
	if (spic != null) {
	  ret = (sub_xpath.rewrite (spic) || ret);
	}
	return ret;
  }

  // terminate the sub xpath node
  void stopExpand ()
  {
	expanded = false;

	getChild(num_and_children).terminate ();
	removeLastChild ();
  }

  void expandRemotely ()
  {
	if (expanded) {
	  getChild(num_and_children).expandRemotely ();
	}
	else {
          for (int ii=0; ii<num_and_children; ii++)
	     if (child_result[ii] == null)
               getChild(ii).expandRemotely ();
	}
  }

  void resultReady (int which_child)
  {
	if (processResult (which_child, true))
	  getParent().resultReady (getParentIndex());
  }

  private boolean getBoolean (String result)
  {
	return ((result!=null)&&(result.charAt(0) == '1'));
  }

  private void computeCurrentAndResult ()
  {
	current_and_result = true;
	for (int ii=0; ii<num_and_children; ii++)
	   if (child_result[ii] != null)
	     if (! getBoolean(child_result[ii])) {
	       current_and_result = false;
	       break;
	     }
  }

  boolean processResult (int which_child)
  {
	return processResult (which_child, false);
  }

  // if final result is determined, return true
  boolean processResult (int which_child, boolean remote_expand)
  {
	// ---
	// if which_child is an and test
	// ---
	if (which_child < num_and_children) {
	  // 1. get result
	  String[] input = (String[]) getChild(which_child).getResult();
	  String result = ((input!=null)&&(input.length!=0))?
			  getResultString (input):"0";

	  // 2. compute current_and_result
	  if (child_result[which_child] == null) {
	    child_result[which_child] = result;
	    num_and_avail ++;
	    current_and_result = current_and_result && getBoolean(result);
	  }
	  else { // child_result[which_child] != null
	    child_result[which_child] = result;
	    computeCurrentAndResult ();
	  }

	  // 3. take actions according to current_and_result
	  if (current_and_result) {
	    if ((num_and_avail == num_and_children) && !expanded) {
		boolean ret = expandLocally ();
		if (!ret && remote_expand)
		  expandRemotely ();  
		return ret;
	    }
	    return false;
	  }
	  else {
	    if (expanded) stopExpand ();
	    return true;
	  }
	}

        // ---
        // if which_child is the expanded sub xpath operator
        // ---
	else {
	  return true;
	}
  }

  Object getResult ()
  {
	if (expanded)
	  return getChild(num_and_children).getResult ();
	else
	  return (isResultString () ? empty_string_output :null);
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
	spic = s;
	setResultType (RESULT_STRING);

	if (expanded) {
	  return getChild(num_and_children).rewrite (s);
	}
	else {
	  return !current_and_result;
	}
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
   
        // print field states
	System.out.println ("num_and_children=" + num_and_children);
	System.out.print ("child_result=");
	for (int ii=0; ii<num_and_children; ii++) {
	   System.out.print ((child_result[ii]==null)?"null":child_result[ii]);
	   if (ii != num_and_children-1)
	     System.out.print (",");
	}
	System.out.println ();
	System.out.println ("num_and_avail=" + num_and_avail);
	System.out.println ("current_and_result=" + current_and_result);
	System.out.println ("expanded=" + expanded);
	System.out.println ("sub query=" + sub_query.toString());
	System.out.println ("root_element=" + root_element.getTagName()
			+ QueryAnalysis.queryforId (root_element));

        // call super.print to print super class fields and children
        super.print ();
  }

} // IfOperator

// ---------------------------------------------------------------------
//                         class SPFinalOperator
// ---------------------------------------------------------------------
class SPFinalOperator extends QueryOperator {
  SPInfo   spinfo;
  Expr     major_xpath;
  String[] params;
  String[] result;
  boolean  has_result = false;

  int      num_param_ready;
  boolean  expanded;

  SPFinalOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (SPInfo info, Expr main_xpath, int nparams)
  {
        spinfo = info;
        major_xpath = main_xpath; 
        params = new String[nparams];
        for (int ii=0; ii<nparams; ii++)
           params[ii] = null;

        result = new String[1];
        result[0] = null;

        num_param_ready = 0;
        expanded = false;
  
        setResultType (RESULT_STRING);
  }

  void expandRemotely ()
  {
        if (! expanded) {
          // expand the params
          int num_children = getChildCount ();
          for (int ii=0; ii<num_children; ii++)
             if (params[ii] == null)
               getChild(ii).expandRemotely ();
        }
        else {
          // expand the major xpath
          int num_children = getChildCount ();
          getChild (num_children-1).expandRemotely ();
        }
  }

  void terminate ()
  {
	super.terminate ();
	// SPUtils.unloadStoredProcedure (spinfo);
  }

  void resultReady (int which_child)
  {
	String old_result = result[0];
	boolean old_has_result = has_result;

        if (processResult (which_child)) {
	  // filtering out the same result
	  if (old_has_result
	      &&(((old_result!=null)&&old_result.equals(result[0]))
	      || ((old_result==null)&&(result[0]==null))) )
	    return;

          // notify parent
          getParent().resultReady (getParentIndex());
        }
        else {
          // two cases here: params are not all available
          //                 or expanded but major_xpath needs remote op
          if (expanded) {
            QueryOperator qq = getChild (params.length);
            qq.expandRemotely ();
          }
        }
  }

  private void processParamResult (int which_child)
  {
          // collect result for params
          if (params[which_child] == null) {
            num_param_ready ++;
          }

          params[which_child] = getResultString (
                        (String[])getChild(which_child).getResult());
  }

  // return true if the major xpath can be answered locally
  boolean expandMajorXpath ()
  {
          expanded = true;

	  // set up SubXpathOperator
          SubXpathOperator subxpath = new SubXpathOperator (this);
          subxpath.setup (query_info, major_xpath,
                            (spinfo.isSimple()?RESULT_STRING:RESULT_NODE));
	  boolean ret = subxpath.expandLocally ();

	  ret = (subxpath.rewrite (getCopyOfInitComputeOperator()) || ret);

          return ret;
  }

  SPInitComputeOperator getCopyOfInitComputeOperator ()
  {
        SPInitComputeOperator one = new SPInitComputeOperator (null);
        one.setup (spinfo, params);
        one.query_info = query_info;
        one.lca_bound = lca_bound;

        return one;
  }

  private void computeFinalResult (int which_child)
  {
	  String[] input = (String[])(getChild(which_child).getResult());
	  if ((input!=null) && (input.length!=0)) {
            String inter_val = getResultString (input);
            result[0] = SPUtils.SPFinal (spinfo, inter_val, params);
	  }
	  else {
	    result[0] = SPUtils.SPInitFinalEmpty (spinfo, params);
	  }
	  has_result = true;
  }

  // in continuous query, params won't change
  // returns true only when the final result is computed!
  boolean processResult (int which_child)
  {
        if (which_child < params.length) {

          processParamResult (which_child);

          if (num_param_ready < params.length)
            return false;

          if (! expanded) {
            // when all the params are ready, expand the major xpath
            if (! expandMajorXpath ())
               return false;
          }

        } // which_child < params.length

        computeFinalResult (params.length);

        return true;
  }

  Object getResult ()
  { 
        return result;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
        // insert a copy of the SPInitComputeOperator
        // in the middle of this and its parent
                                                                                
        SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();
                                                                                
        middle.setParent (getParent(), getParentIndex());
        getParent().setChild (getParentIndex(), middle);
                                                                                
        int pindex = middle.addChild (this);
        setParent (middle, pindex);

        if (result[0] != null) {
          // set up result
          middle.processResult (pindex);
	  return true;
        }
	else {
	  return false;
	}
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
        System.out.println ("className:methodName=" + spinfo.full_name);
        System.out.println ("major_xpath=" + major_xpath.toString());
        System.out.print ("params(" + params.length + ")=");
        for (int ii=0; ii<params.length; ii++) {
           System.out.print ((params[ii]!=null)? params[ii] : "null");
           if (ii != params.length-1)
             System.out.print (",");
        }
        System.out.println ();
        System.out.println ("num_param_ready=" + num_param_ready);
        System.out.println ("expanded=" + expanded);
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // SPFinalOperator

// ---------------------------------------------------------------------
//                         class SPComputeOperator
// ---------------------------------------------------------------------
class SPComputeOperator extends QueryOperator {
  SPInfo   spinfo;
  String[] params;
  String[] result;
  boolean  empty_result;
  boolean  has_result = false;

  SPComputeOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (SPInfo my_spinfo, String[] my_params)
  {
        spinfo = my_spinfo;
        params = my_params;
        result = new String[1];
	empty_result = true;
	setResultType (RESULT_STRING);
  }

  void resultReady (int which_child)
  {
	boolean old_has_result = has_result;
	boolean old_empty_result = empty_result;
	String  old_result = result[0];

	processResult (which_child);

	// filter out the same result
	if (old_has_result &&
	    ((old_empty_result && empty_result) ||
	     (!old_empty_result && !empty_result && 
	       old_result.equals (result[0]))))
	  return;

        // notify parent
        getParent().resultReady (getParentIndex());
  }

  void processResult (int which_child)
  {
        // get result from child and call sp_initcompute
        String[] inter_vals = (String[])(getChild(which_child).getResult());
	empty_result = ((inter_vals==null) || (inter_vals.length==0));
	if (! empty_result) {
          result[0] = SPUtils.SPCompute (spinfo, inter_vals, params);
	  if (result[0] == null)
	    result[0] = "";
	}
        has_result = true;
  }

  Object getResult ()
  {
        return (empty_result ? empty_string_output : result);
  }

  // rewrite for stored procedure won't happen here

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
        System.out.println ("className:methodName=" + spinfo.full_name);
        System.out.print ("params(" + params.length + ")=");
        for (int ii=0; ii<params.length; ii++) {
           System.out.print ((params[ii]!=null)? params[ii] : "null");
           if (ii != params.length-1)
             System.out.print (",");
        }
        System.out.println ();
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // SPComputeOperator

// ---------------------------------------------------------------------
//                         class SPInitComputeOperator
// ---------------------------------------------------------------------
class SPInitComputeOperator extends QueryOperator {
  SPInfo   spinfo;
  String[] params;
  String[] result; 
  boolean  empty_result;
  boolean  has_result = false;

  SPInitComputeOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (SPInfo my_spinfo, String[] my_params)
  {
	spinfo = my_spinfo;
	params = my_params;
	result = new String[1];
	result[0] = null;
	empty_result = true;
	setResultType (RESULT_STRING);
  }

  void resultReady (int which_child)
  {
        boolean old_has_result = has_result;
        boolean old_empty_result = empty_result;
        String  old_result = result[0];

	processResult (which_child);

        // filter out the same result
        if (old_has_result &&
            ((old_empty_result && empty_result) ||
             (!old_empty_result && !empty_result &&
               old_result.equals (result[0]))))
          return;

	// notify parent
	getParent().resultReady (getParentIndex());
  }

  void processResult (int which_child)
  {
        // get result from child and call sp_initcompute
        if (spinfo.isSimple ()) {
          String[] orig_vals = (String[])(getChild(which_child).getResult());
	  empty_result = ((orig_vals==null) || (orig_vals.length==0));
	  if (! empty_result) {
            result[0] = SPUtils.SPInitCompute (spinfo, orig_vals, params);
	  }
        }
        else {
          Node n = (Node) (getChild(which_child).getResult());
          NodeList orig_nodes = (n!=null)? getResultNodeList (n) : 
				emptyNodeList () ;
	  empty_result = (orig_nodes.getLength() == 0);
	  if (! empty_result) {
	    if (spinfo.hasInitPath ())
              result[0] = 
		SPUtils.SPInitCompute (spinfo, query_info, orig_nodes, params);
	    else
              result[0] = SPUtils.SPInitCompute (spinfo, orig_nodes, params);
	  }
        }

	if (! empty_result && (result[0]==null))
	  result[0] = "";

	has_result = true;
  }

  Object getResult ()
  {
        return (empty_result ? empty_string_output : result);
  }

  // rewrite for stored procedure won't happen here

  SPInitComputeOperator getCopyOfInitComputeOperator ()
  {
	SPInitComputeOperator one = new SPInitComputeOperator (null);
	one.setup (spinfo, params);
	one.query_info = query_info;
	one.lca_bound = lca_bound;

	return one;
  }

  SPComputeOperator getCopyOfComputeOperator ()
  {
	SPComputeOperator one = new SPComputeOperator (null);
	one.setup (spinfo, params);
	one.query_info = query_info;
	one.lca_bound = lca_bound;

	return one;
  }

  boolean callPrune (String inter_val)
  {
	return SPUtils.SPPrune (spinfo, inter_val, params);
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
        System.out.println ("className:methodName=" + spinfo.full_name);
        System.out.print ("params(" + params.length + ")=");
        for (int ii=0; ii<params.length; ii++) {
           System.out.print ((params[ii]!=null)? params[ii] : "null");
           if (ii != params.length-1)
             System.out.print (",");
        }
        System.out.println ();
	if (result[0] != null) {
	  System.out.println ("result=" + result[0]);
	}
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // SPInitComputeOperator

// ---------------------------------------------------------------------
//                         class SPLocalOperator
// ---------------------------------------------------------------------
class SPLocalOperator extends QueryOperator {
  SPInfo   spinfo;
  Expr     major_xpath;
  String[] params;
  String[] result;

  int      num_param_ready;
  boolean  expanded;

  boolean  has_result = false;

  SPLocalOperator (QueryOperator my_parent)
  { super(my_parent); }

  void setup (SPInfo info, Expr main_xpath, int nparams)
  {
	spinfo = info;
	major_xpath = main_xpath;
	params = new String[nparams];
	for (int ii=0; ii<nparams; ii++)
	   params[ii] = null;

	result = new String[1];
	result[0] = null;

	num_param_ready = 0;
	expanded = false;

	setResultType (RESULT_STRING);
  }

  void expandRemotely ()
  {
	if (! expanded) {
	  // expand the params
	  int num_children = getChildCount ();
          for (int ii=0; ii<num_children; ii++)
	     if (params[ii] == null)
               getChild(ii).expandRemotely ();
	}
	else {
	  // expand the major xpath
	  int num_children = getChildCount ();
	  getChild (num_children-1).expandRemotely ();
	}
  }

  void terminate ()
  {
	super.terminate ();
	// SPUtils.unloadStoredProcedure (spinfo);
  }

  void resultReady (int which_child)
  {
        String old_result = result[0];
        boolean old_has_result = has_result;

	if (processResult (which_child)) {
          // filtering out the same result
          if (old_has_result
              &&(((old_result!=null)&&old_result.equals(result[0]))
              || ((old_result==null)&&(result[0]==null))) )
            return;

	  // notify parent
	  getParent().resultReady (getParentIndex());
	}
	else {
	  // two cases here: params are not all available
	  //                 or expanded but major_xpath needs remote op
	  if (expanded) {
	    QueryOperator qq = getChild (params.length);
	    qq.expandRemotely ();
	  }
	}
  }

  private void processParamResult (int which_child)
  {
          // collect result for params
          if (params[which_child] == null) {
            num_param_ready ++;
          }
                                                                                
          params[which_child] = getResultString (
                        (String[])getChild(which_child).getResult());
  }

  // return true if the major xpath can be answered locally
  boolean expandMajorXpath ()
  {
          expanded = true;

          SubXpathOperator subxpath = new SubXpathOperator (this);
          subxpath.setup (query_info, major_xpath,
                            (spinfo.isSimple()?RESULT_STRING:RESULT_NODE));
                                                                                
          return subxpath.expandLocally ();
  }

  private void computeFinalResult (int which_child)
  {
        if (spinfo.isSimple ()) {
            String[] orig_vals = (String[])(getChild(which_child).getResult());
	    if (orig_vals == null)
	      orig_vals = empty_string_output;
            result[0] = SPUtils.SPLocal (spinfo, orig_vals, params);
        }
        else {
            Node n = (Node) (getChild(which_child).getResult());
            NodeList orig_nodes = (n!=null) ? getResultNodeList (n)
				  : emptyNodeList ();
            result[0] = SPUtils.SPLocal (spinfo, orig_nodes, params);
        }

	has_result = true;
  }


  // returns true only when the final result is computed!
  boolean processResult (int which_child)
  {
        if (which_child < params.length) {

	  processParamResult (which_child);

          if (num_param_ready < params.length)
            return false;
                                                                                
	  if (! expanded) {
            // when all the params are ready, expand the major xpath
	    if (! expandMajorXpath ())
	       return false;
	  }

        } // which_child < params.length

	computeFinalResult (params.length);
                                                                                
	return true;
  }

  Object getResult ()
  { 
        return result;
  }

  // rewrite for stored procedure
  boolean rewrite (SPInitComputeOperator s)
  {
	// insert a copy of the SPInitComputeOperator 
	// in the middle of this and its parent

	SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();

	middle.setParent (getParent(), getParentIndex());
	getParent().setChild (getParentIndex(), middle);

	int pindex = middle.addChild (this);
	setParent (middle, pindex);

	if (result[0] != null) {
          // set up result
          middle.processResult (pindex);
	  return true;
	}
	else {
	  return false;
	}
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");
                                                                                
        // print field states
	System.out.println ("className:methodName=" + spinfo.full_name);
	System.out.println ("major_xpath=" + major_xpath.toString());
	System.out.print ("params(" + params.length + ")=");
	for (int ii=0; ii<params.length; ii++) {
	   System.out.print ((params[ii]!=null)? params[ii] : "null");
	   if (ii != params.length-1)
	     System.out.print (",");
	}
	System.out.println ();
	System.out.println ("num_param_ready=" + num_param_ready);
	System.out.println ("expanded=" + expanded);
                                                                                
        // call super.print to print super class fields and children
        super.print ();
  }

} // SPLocalOperator

// ---------------------------------------------------------------------
//                         class StoredQueryOperator
// ---------------------------------------------------------------------
class StoredQueryMergeSource extends MergeSource {

  String	name;		// stored query name
  Node		local_result;	// contain parent nodes of the stored queries

  void setup (String sq_name, Node local_result_tree)
  {
	name = sq_name;
	local_result = local_result_tree;
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {
	StoredQueryOperator  sq = new StoredQueryOperator (merge);
	return sq.setup (name, local_result);
  }

} // StoredQueryMergeSource

class ExpandedStoredQueryMergeSource extends MergeSource {

  QueryOperator    qop; 
  String	   name;
  
  void setup (QueryOperator q, String sq_name)
  {
	qop = q;
	name = sq_name;
  }

  boolean expandOperator (Element e, MergeOperator merge)
  {     
	// 1. get the stored query from the element
	String query = null;
	NodeList nl = e.getElementsByTagName (QueryOperator.stored_query);
	for (int ii=nl.getLength()-1; ii>=0; ii--) {
	   Element ch = (Element) nl.item (ii);
	   String temp = ch.getAttribute ("name");
	   if ((temp != null) && (temp.equals(name))) {
	     query = ch.getAttribute ("query"); 
	     break;
	   }
	} 
	if ((query == null) || (query.length() == 0)) {
	  Utils.error ("stored query not found!");
	}

	// 1.5 if this is a continuous query, retrieve the attribute
	if (query.startsWith ("continuous")) {
	  query = '@' + name;
	}

	// 2. create sub xpath operator
	Expr expr = null;
	try {
	   expr = XPathQueryParser.parsequery(query);
	}
	catch (Exception ex) {
	  Utils.error (ex.getClass().toString() + ':' + ex.getMessage ());
	}
	QueryInfo qinfo = new QueryInfo (qop.query_info, 
					 qop.mapNodetoOriginalTree(e));
	SubXpathOperator sx = new SubXpathOperator (merge);
	sx.setup (qinfo, expr, QueryOperator.RESULT_STRING);
	
        return sx.expandLocally ();
  }

} // ExpandedStoredQueryMergeSource

class StoredQueryOperator extends QueryOperator {

  boolean ready;

  StoredQueryOperator (QueryOperator my_parent)
  { super(my_parent); }

  // returns true if the answer is available locally
  boolean setup (String sq_name, Node local_result)
  {
	setResultType (RESULT_STRING);

	// child 0 is LocalResultOperator
	LocalResultOperator lr = new LocalResultOperator (this);
	lr.setup (local_result, RESULT_NODE, null);

	// child 1 is StringMergeOperator
	StringMergeOperator merge = new StringMergeOperator (this);
	merge.beginSetup (1, RESULT_STRING);

	// add ExpandedStoredQueryMergeSource
	ExpandedStoredQueryMergeSource sqm = 
		new ExpandedStoredQueryMergeSource ();
	sqm.setup (this, sq_name);

	// get the list of nodes to ask stored query
        Node n = (Node) getChild(0).getResult();
	NodeList nl = (n!=null)? getResultNodeList (n) : emptyNodeList();

	merge.addMergeSource (0, sqm, nl);
	merge.finishSetup ();

	ready = merge.expandAllLocally ();
	return ready;
  }

  void expandRemotely ()
  {
	if (! ready)
	  getChild(1).expandRemotely ();
  }

  boolean rewrite (SPInitComputeOperator s)
  {
        // insert a copy of the SPInitComputeOperator 
        // in the middle of this and its parent

        SPInitComputeOperator middle = s.getCopyOfInitComputeOperator ();

        middle.setParent (getParent(), getParentIndex());
        getParent().setChild (getParentIndex(), middle);

        int pindex = middle.addChild (this);
        setParent (middle, pindex);

        if (ready) {
          // set up result
          middle.processResult (pindex);
	  return true;
        }
	else {
	  return false;
	}
  }

  void resultReady (int which_child)
  {
	ready = true;
        getParent().resultReady (getParentIndex());
  }

  Object getResult ()
  {
        return getChild(1).getResult ();
  }

  void print ()
  {
        // print class name
        System.out.println ("[" + simpleClassName () + "]");

        // print field states
	System.out.println ("ready=" + ready);

        // call super.print to print super class fields and children
        super.print ();
  }

} // StoredQueryOperator
