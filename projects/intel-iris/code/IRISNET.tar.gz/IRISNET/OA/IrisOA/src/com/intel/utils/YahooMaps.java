/* -*-  Mode:Java; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.utils;

import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.util.StringTokenizer;

import com.stevesoft.pat.*;

import com.intel.sensors.oa.Log;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;

/** Job of this is to listen on a port ... can't think of any other way 
 *  to see if any data is being received by the client aksing a query.
 *
 *  @author Amol
 *  */
public class YahooMaps {
    public ServerSocket serversocket;

    public static final String defaultCSZ = "15213";

    /** Remember the current state */
    public String startingPoint = null;
    public String destination = null;
    public String startCSZ = null;
    public String endCSZ = null;
    public String covered = null;
    public String handicapped = null;
    public String price = null;
    public boolean done = false;
    public int yahooMapsID = 0;

    public final String[] destinationNames = new String[] {"Intel", "WeanHall", "WQED", "UniversityCenter", "CarnegieMuseum"};
    public final String[] destinations = new String[] {"417 South Craig", "4800 Forbes", "4802 Fifth Ave", "5010 Forbes", "4600 Forbes"};
    public final String[] destinationCSZs = new String[] {"15213", "15213", "15213", "15213", "15213"};

    public YahooMaps(String startingPoint_, String scsz, String destination_, String dcsz) {
        startingPoint = startingPoint_; 
        destination = destination_;
        startCSZ = scsz;
        endCSZ = dcsz;
    }

    public YahooMaps(String startingPoint_, String scsz, String destinationName, String _covered, String _handicapped, String _price) {
        startingPoint = startingPoint_; 
        startCSZ = scsz;
        for(int i = 0; i < destinationNames.length; i++) {
            if(destinationNames[i].equals(destinationName)) {
                destination = destinations[i];
                endCSZ = destinationCSZs[i];
                break;
            }
        }
        covered = _covered;
        handicapped = _handicapped;
        price = _price;
    }

    /** Given a socket, send the driving directions between the startingPoint and the destination.
     *  Also, update the startingPoint. 
     *  
     *  Sets : boolean indicating whether this YahooMaps is done and can be removed */
    public void processRequest(Socket s) {
        try {
            com.intel.sensors.oa.DemoQuerying.firstSearchFailed = false;
            boolean found_a_parking_spot = true;
            String realDestination_1 = com.intel.sensors.oa.DemoQuerying.findAddressOfClosestAvailableParkingSpot(destination, covered, handicapped, price);
            if(realDestination_1 == null) {
                found_a_parking_spot = false;
                realDestination_1 = destination;
            }
            StringTokenizer st = new StringTokenizer(realDestination_1);
            String realDestination = st.nextToken();

            while(st.hasMoreTokens()) {
                realDestination += "+" + st.nextToken();
            }


            System.out.println("Getting directions between " + startingPoint + " and " +  realDestination);

            String yahooResult = null;
            if((startCSZ != null) && (endCSZ != null)) {
                yahooResult = getDrivingDirections(startingPoint, startCSZ, realDestination, endCSZ);
            } else {
                yahooResult = getDrivingDirections(startingPoint, defaultCSZ, realDestination, defaultCSZ);
            }

            System.out.println("Got results from yahoo");
            // System.out.println(yahooResult);
            startingPoint = getNewLocation(yahooResult);

            yahooResult = insertParkingSpotInfo(yahooResult, realDestination_1, found_a_parking_spot);

            // shouldn't refresh if this is done
            if(startingPoint != null) {
                yahooResult = insertRefresh(yahooResult, 30, yahooMapsID);
            } else {
                done = true;
            }
            startCSZ = "15213";

            // send the data back
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            dos.writeBytes(yahooResult);
            dos.write(0);
            dos.flush();
            Thread.sleep(100);
            dos.close();

            s.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static String insertRefresh(String str, int refreshseconds, int referenceid) {
        int index = str.indexOf("head");
        int insertAt = index + 5;       // "head" + ">"
        StringBuffer sb = new StringBuffer(str);
        sb.insert(insertAt, "<meta http-equiv=refresh content=\"" + refreshseconds + "; URL=http://oakland:7111/" + referenceid + "\">");
        sb.insert(insertAt, "<font size=\"-1\"> <a href=\"http://oakland:7111/" + referenceid +"\"> Click for refresh </a></font>");
        return sb.toString();
    }

    public static String insertParkingSpotInfo(String str1, String str2, boolean found_a_parking_spot) {
        int index = str1.indexOf("body");
        int insertAt = index + 5;       // "body" + ">"
        StringBuffer sb = new StringBuffer(str1);

        if(found_a_parking_spot) {
            sb.insert(insertAt, "<H2> Current Closest Available Parking Spot is at <i>" + str2 + "</i><br> Please follow directions shown below. </H2>");
        } else {
            sb.insert(insertAt, "<H2> No Parking Spot found with the given requirements. <br> Here are the directions to the destination. </H2>");
        }
        return sb.toString();
    }


    public static String getDrivingDirections(String street1, String csz1, String street2, String csz2) {
        try {
            // call yahoo maps to get a html document
            HttpClient hclient = new HttpClient();
            hclient.startSession("maps.yahoo.com", 80);
            GetMethod gm = new GetMethod("/py/ddResults.py");

            StringBuffer queryString = new StringBuffer("Pyt=Tmap&newFL=Use+Address+Below");
            queryString.append("&newaddr=");
            queryString.append(street1);
            queryString.append("&newcsz=");
            queryString.append(csz1);
            queryString.append("&newcountry=us");
            queryString.append("newTFL=Use+Address+Below");
            queryString.append("&newtaddr=");
            queryString.append(street2);
            queryString.append("&newtcsz=");
            queryString.append(csz2);
            queryString.append("&newtcountry=us");
            queryString.append("&Submit=Get+Directions");

            gm.setQueryString(queryString.toString());

            System.out.println(gm.getQueryString());

            hclient.executeMethod(gm);
            String response = gm.getResponseBodyAsString();
            // System.out.println(response);
            return response;
        } catch (Exception e) {
            return null;
        }
    }

    public static void getDrivingDirectionIntersections(String yahooResult, Vector intersections, Vector distances) {
        // Regex.dotDoesntMatchCR = false;
        // Regex rg = new Regex("<TR><TD width=.*>.*<td width=.*>.*<td width=.*>.*</td>");
        // rg = new Regex("<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" width=\"700\">.*/table>");


        Regex rg_first = new Regex("<TD width=\"72%\">.*(<b>.*</b>).*</TD>");
        Regex rg_first_a = new Regex("<TD ALIGN=\"CENTER\" width=\"11%\">(.*)</TD>");
        Regex rg_second = new Regex("<b>.*</b>");
        Regex rg_third = new Regex("</?b>", "");
        Regex rg_fourth = new Regex(" ", "+");
        rg_first.optimize();
        rg_second.optimize();
        rg_third.optimize();

        while(true) {
            if(rg_first.search(yahooResult)) {
                if(rg_second.search(rg_first.stringMatched())) {
                    intersections.add(rg_fourth.replaceAll(rg_third.replaceAll(rg_second.stringMatched())));
                } else {
                    return;
                }

                // get the distance
                yahooResult = rg_first.right();
                rg_first_a.search(yahooResult);
                distances.add(Float.valueOf(rg_first_a.stringMatched(1)));
            } else {
                return;
            }
            yahooResult = rg_first.right();
        }
    }

    public static void printDrivingDirection(Vector v, Vector v2) {
        for(int i = 0; i < v.size(); i++) {
            System.out.println((i+1) + ". " + v.get(i).toString() + " " + v2.get(i).toString());
        }
    }

    public String getNewLocation(String yahooResult) {
        Vector intersections = new Vector();
        Vector distances = new Vector(); 
        getDrivingDirectionIntersections(yahooResult, intersections, distances);
        String newlocation = null;
        printDrivingDirection(intersections, distances);

        if(intersections.size() != 1) {
            // go backwards on distances and find the first place where we exceed 2 miles
            float total = 0;
            int index = 0;
            for(int i = distances.size()-1; i >= 0; i--) {
                total += ((Float) distances.get(i)).floatValue();
                if(total > 2.0) {
                    System.out.println("Total gets higher than minimum at step " + i);
                    index = i;
                    break;
                }
            }
            if(index == distances.size() - 1) {
                index = distances.size() - 2;
            }

            newlocation = intersections.get(index).toString() + "+at+" + intersections.get(index+1).toString();
            if(newlocation.equals(startingPoint)) { 
                // some weird mistake;; take a combination of hte next two instead
                if(distances.size() != index+2) {
                    newlocation = intersections.get(index+1).toString() + "+at+" + intersections.get(index+2).toString();
                } else {
                    newlocation = null;
                } 
            }
        }
        return newlocation;
    }

    public void iterateThroughLocations(String destination, String startingPoint) {
        for(int i = 0; i < 5; i++) {

            System.out.println("Getting directions between " + startingPoint + " and " + destination);
            String s = getDrivingDirections(startingPoint, "15213", destination, "15213"); 
            System.out.println("Got results from yahoo");

            if((startingPoint = getNewLocation(s)) != null) {
                System.out.println();
                System.out.println();
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                }
            } else {
                break;
            }
        }
    }

    public static YahooMaps[] pendingYahooMaps = new YahooMaps[100];

    /** Add to the pending requests */
    public static void addToPending(YahooMaps ym) {
        for(int i = 0; i < pendingYahooMaps.length; i++) {
            if(pendingYahooMaps[i] == null) {
                ym.yahooMapsID = i;
                pendingYahooMaps[i] = ym;
                return;
            }
        }
    }
    
    /** This accepts the initial request from the form */
    public static void run_http_server(int port) {
        for(int i = 0; i < 100; i++) 
            pendingYahooMaps[i] = null;

        ServerSocket serversocket = null;
        try {
            serversocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        while(true) {
            Socket s = null;
            try {
                String requestString = null;
                s = serversocket.accept();
                System.out.println("Got a new connection... listening");
                InputStreamReader isr = new InputStreamReader(s.getInputStream());
                try {
                    String str;
                    BufferedReader br = new BufferedReader(isr);
                    str = br.readLine();
                    while(!str.equals("")) {
                        if(str.indexOf("GET") != -1) {
                            requestString = str;
                        }
                        System.out.println("*" + str + "*");
                        str = br.readLine();
                    }
                } catch (Exception e) {
                }

                System.out.println(requestString);

                // the request string can be of two types
                if(requestString.indexOf("newsearch") != -1) {
                    // new search
                    Regex rg = new Regex("startst=(.*)&startcsz=(.*)&destination=(.*)&covered=(.*)&handicapped=(.*)&price=(.*)&");
                    if(rg.search(requestString)) {
                        YahooMaps ym = new YahooMaps(rg.stringMatched(1), rg.stringMatched(2), rg.stringMatched(3), rg.stringMatched(4), rg.stringMatched(5), rg.stringMatched(6));
                        addToPending(ym);
                        ym.processRequest(s);
                        if(ym.done) { // shouldn't really happen, but what the heck
                            pendingYahooMaps[ym.yahooMapsID] = null;
                        }
                    }
                } else {
                    System.out.println("This is an old request");
                    // old search; find the old YahooMaps
                    Regex rg = new Regex("/([^ ]*)");
                    if(rg.search(requestString)) {
                        int id = Integer.parseInt(rg.stringMatched(1));
                        System.out.println("Request for id = " + id);
                        pendingYahooMaps[id].processRequest(s);
                        if(pendingYahooMaps[id].done) {
                            pendingYahooMaps[id] = null;
                        }
                    }
                }

                s.close();
            } catch (Exception e) {
                e.printStackTrace();
                try { 
                    DataOutputStream dos = new DataOutputStream(s.getOutputStream());
                    dos.writeBytes("<html><head><body>Error processing the directive</body>");
                    dos.write(0);
                    dos.flush();
                    Thread.sleep(100);
                    dos.close();
                    s.close();
                } catch (Exception ee) {
                }
                System.out.println("Continueing");
            }
        }
    }


    public static void main(String[] args) {
        try {
            // String startingPoint = args[0];
            // String destination = args[1];

            // iterateThroughLocations(startingPoint, destination);
            // System.exit(1);

            // YahooMaps nl = new YahooMaps(Integer.parseInt(args[0]));
            // nl.startingPoint = args[1];
            // nl.destination = args[2];
            // nl.run();

            //Log.setReplayLog("10.212.3.211", "5678");
	    //Log.setReplayLog(com.intel.sensors.oa.Globals.LOG_IP, com.intel.sensors.oa.Globals.LOG_PORT);

            com.intel.sensors.oa.Protocol.myPortNumber = Integer.parseInt(args[1]);

            com.intel.sensors.oa.DemoQuerying.startListener(com.intel.sensors.oa.Protocol.getLocalPort());

            run_http_server(Integer.parseInt(args[0]));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
};
