/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
//import java.util.*;
import java.util.StringTokenizer;
import java.util.Vector;

import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;

import de.fzi.XPath.XPathQueryParser;
import de.fzi.XPath.Expr;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

/** Provides the methods for processing a query request */
public class ServantQuery {

    static boolean useFastXSLTTransform = false;
	
	/** Given a query, figure out the answer we can provide and send off queries to other OAs if
	 *  required */

	public static String ackQuery(String hostName) {
		Statistics stat = Statistics.instance();
		
		String localHost = "localhost";
		
		try {
			localHost = InetAddress.getLocalHost().getHostName();
		} catch (Exception e) {};

		// first see if this OA owns the queried node
		
		if (hostName.equals(Protocol.getLocalIP()) ||
			hostName.equals(localHost) ||
			stat.isOwnedNode(hostName) ) {
			return "SUCCESS";
		} else {
			System.out.println("Host not found: " + hostName);
			Object newOwner = stat.getNewOwner(hostName);
			if (newOwner != null)
				return "DELEGATEDTO " + newOwner.toString();
			else 
				return "DELEGATEDFROM " + Protocol.getLocalIP();
		} 
		
	}

	public static void processRequest(ParsedMessage pm) throws Exception 
    {
		boolean subqueryIssued = true;	
		if (Globals.DebugON)
			System.out.println("ServantQuery.processRequest(): Processing query.");

        Expr parsedExpression = QueryAnalysis.getLocationPathExpression(pm.query);

		// Ask the XindiceInterface to find the answer to this XSLT Query and return it as
		// a DOM; send the XPath query as well.
		if (Globals.DebugON)
			System.out.println("ServantQuery.processRequest(): Getting document from query on XML DB");
		Document doc = Globals.getDatabase().getDocumentContainingAnswer(parsedExpression);

		if (Globals.DebugON)
			System.out.println("ServantQuery.processRequest(): Transforming query to XSLT query");

        Transformer t = null;
        Expr subqueryToAsk = null;
        if(useFastXSLTTransform) {
            t = FastXSLTCreation.getFastXSLTTransformer(parsedExpression);
        } else {

            // convert it to an XSLT query
			Object[] retvals;
			if (Globals.DocCachingON) {
				retvals = QueryAnalysis.findXSLTQuery(parsedExpression, pm.query, true);
			} else {
				retvals = QueryAnalysis.findXSLTQuery(parsedExpression, true);
			}
            Utils.myassert(retvals.length == 2);
            String xsltQuery = (String) retvals[0];
            subqueryToAsk = (Expr) retvals[1];
            t = DOMProcessing.getXSLTTransformer(xsltQuery);
        }

        if (Globals.DebugON)
			System.out.println("ServantQuery.processRequest(): Applying XSLT query to document");

        Node answer = DOMProcessing.applyXSLTtoDOM(doc, t);

		if (Globals.DebugON) {
			System.out.println("ServantQuery.processRequest(): Result after applying the XSLT query:");
			DOMProcessing.prettyPrint(answer);
		}

		if (Globals.keepStat) {
			Statistics.instance().updateReadLoad((Document)answer);
			Statistics.instance().printLoad();
		}
		// root the answer at pm.rootAtNode
		// String rootAtQuery = QueryAnalysis.deleteQueryAfterNode(fullQuery.toString(), pm.rootAtNode);
		String rootAtQuery = QueryAnalysis.findRootAtQuery(parsedExpression, pm.rootAtNode);
		Node answerNode = DOMProcessing.applyXPATHtoDOM((Document)answer, rootAtQuery)[0];

		if (Globals.DebugON){
			System.out.println("ServantQuery.processRequest(): After rooting the document at the required node");
			DOMProcessing.prettyPrint(answerNode);
		}

        /* Create a pending meta query entry to take care of any missing information. */
        QueryResponseActionEntry qEntry = new QueryResponseActionEntry(pm, answerNode);
        ResponseActionEntry.getOALevelResponseActionEntry().addQuery(qEntry);


        /** Step 1 :
          * Find nodes at which subquery needs to be asked. These are identified by 
          * searching for the "asksubquery" tags.
          *
          * For each such "hanging" node, find the closest ancestor that is not owned, and ask that
          * ancestor for that part of the data. */
		
		// find nodes which satisfy our criterion ie. which are hanging
		Node[] hangingNodes = DOMProcessing.applyXPATHtoDOM(answerNode, "//asksubquery");
        for(int i = 0; i < hangingNodes.length; i++) 
            hangingNodes[i] = hangingNodes[i].getParentNode();

		Node[] lowestAncestors = new Node[hangingNodes.length];
		for(int i = 0; i < hangingNodes.length; i++) {
			lowestAncestors[i] = DOMProcessing.findLowestUnownedAncestor(hangingNodes[i]);
		}
		
		if (Globals.DebugON)
			System.out.println("ServantQuery.processRequest(): These are the hanging nodes:");
		for(int i = 0; i < hangingNodes.length; i++) {
			//System.out.println("**********");
			DOMProcessing.printNode(hangingNodes[i]);
			if(lowestAncestors[i] != null) {
				if (Globals.DebugON)
					System.out.println("ServantQuery.processRequest(): It's lowest ancestors are:");
				DOMProcessing.printNode(lowestAncestors[i]);
			}
			else 
				System.out.println("none");
		}
		
		RemoteSourceInfo rsi = null;
		if(hangingNodes.length != 0) {
			for(int i = 0; i < hangingNodes.length; i++) {
				if(lowestAncestors[i] != null) {
					try {
						String targetNode = DOMProcessing.findOwnerAgent(lowestAncestors[i]);
						rsi = new RemoteSourceInfo(targetNode);
						String newPrefix = DOMProcessing.findQueryForThisNode(hangingNodes[i]);
						String modifiedQuery = QueryAnalysis.modifyQueryToSendToChild(pm.query, newPrefix);
						if (Globals.DebugON) {
							System.out.println("ServantQuery.processRequest(): New Prefix:");
							System.out.println(newPrefix);
							
							System.out.println("ServantQuery.processRequest(): Modified Query:");
							System.out.println(modifiedQuery);
						}
						BasicResponseActionEntry baqe = new BasicResponseActionEntry();
						qEntry.addActionQueryEntry(hangingNodes[i], baqe);

						// parallelly issue the subqueries
						subqueryIssued = true;
						// final variable declarations. To be used within the inner loop
						final String _id = baqe.getGlobalID();
						final String _host = rsi.mRemoteHostName;
						final int _port = rsi.mRemotePortNumber;
						final String _query = modifiedQuery;
						final String _tag = ((Element) hangingNodes[i]).getTagName();
						final QueryResponseActionEntry _qe = qEntry;
						final String _target = targetNode;
						new Thread() {
							public void run() {
								try {
									Protocol.sendQueryMessage(_id, _host, _port, _query, -1, _tag, _target);                                                                } catch (Exception e) {
										_qe.decrementPending();
										Packet.addToBlackList(_host);
									}
							}
						}.start();
						
						//Protocol.sendQueryMessage(baqe.getGlobalID(), 
						// 					  rsi.mRemoteHostName, 
						//					  rsi.mRemotePortNumber, 
						//					  modifiedQuery,
						//					  -1,
						//					  ((Element) hangingNodes[i]).getTagName(),
						//					  targetNode);
					} catch (Exception ex) {
						qEntry.decrementPending();
						if (rsi != null)
							Packet.addToBlackList(rsi.mRemoteHostName);

					}
				} 
                else 
                {
					qEntry.decrementPending();
					if (rsi != null)
						Packet.addToBlackList(rsi.mRemoteHostName);

				}
			}
			
		} 

		rsi = null;
        /** STEP 2 : If the subqueryToAsk is non-null, we have a fetch-all situation here.
          * Do the appropriate things. */
        if(subqueryToAsk != null)
        {
            Node[] fetchallNodes = DOMProcessing.applyXPATHtoDOM(answerNode, "//*[./fetchall]");
			if (Globals.DebugON) {
				System.out.println("ServantQuery.processRequest(): Number of fetchall nodes is " + fetchallNodes.length);
				System.out.println("ServantQuery.processRequest(): Fetchall subquerytoask is " + subqueryToAsk);
			}

            for(int i = 0; i < fetchallNodes.length; i++)
            {
				try {
					String query = DOMProcessing.findQueryForThisNode(fetchallNodes[i]);
					String targetNode = DOMProcessing.findOwnerAgent(fetchallNodes[i]);
					rsi = new RemoteSourceInfo(targetNode);
					
					// create appropriate ResponseActionEntry.
					FetchAllResponseActionEntry farae = new FetchAllResponseActionEntry(subqueryToAsk);
					qEntry.addActionQueryEntry(fetchallNodes[i], farae);
					
					// parallelly issue the subqueries
					subqueryIssued = true;
					// final variable declarations. To be used within the inner loop
					final String _id = farae.getGlobalID();
					final String _host = rsi.mRemoteHostName;
					final int _port = rsi.mRemotePortNumber;
					final String _query = query;
					final String _tag = ((Element) fetchallNodes[i]).getTagName();
					final QueryResponseActionEntry _qe = qEntry;
					final String _target = targetNode;
					new Thread() {
						public void run() {
							try {
								Protocol.sendQueryMessage(_id, _host, _port, _query, -1, _tag, _target);                                                                } catch (Exception e) {
									_qe.decrementPending();
									Packet.addToBlackList(_host);
								}
						}
					}.start();
					
					//Protocol.sendQueryMessage(farae.getGlobalID(), 
					//					  rsi.mRemoteHostName, 
					//					  rsi.mRemotePortNumber, 
					//					  query, 
					//					  -1,
					//					  ((Element) fetchallNodes[i]).getTagName(), 
					//					  targetNode);
				} catch (Exception ex) {
					qEntry.decrementPending();
					if (rsi != null)
						Packet.addToBlackList(rsi.mRemoteHostName);
				}
            }
        }

		// wait for possible socket timeout
		// needs to be replaced by barriers
		if (subqueryIssued)
			Thread.currentThread().sleep(ConfigurationManager.instance().getTimeOut() + 500);

	System.out.println("numPending: " + qEntry.getPending());		

        /** We might have actually the full answer here. This is signified by not having added
		 * any queryEntries to this structure. */
        if(qEntry.doneProcessing()) 
			{
				qEntry.sendReplyBack();
				((OALevelResponseActionEntry) qEntry.getParent()).removeQuery(qEntry);
			}
	}
	
	public static void main(String[] args) {
		try {
			String packet;
			packet = "Q 127.0.0.1 80 1 8 city /usRegion/state/county/city/neighborhood[@id='Oakland' or @id='Shadyside']/block/";
			
			ParsedMessage pm = Protocol.parseIncomingMessage(packet);
			System.out.println(pm);
			
			ServantQuery query = new ServantQuery();
			// XindiceInterface.initializeCollection("parkingpittsburgh");
			// query.run(pm, null);
			
			System.exit(1);
			
			// StringBuffer s = XindiceInterface.getAnswer("parkingoakland", "//neighborhood");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			// System.out.println(s);
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			System.out.println("***************************************************\n");
			// System.out.println(ApplyXPathToString.applyXPath(s.toString(), args[3]));
			
			// query.gatherAnswer(args[0], args[1]);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
