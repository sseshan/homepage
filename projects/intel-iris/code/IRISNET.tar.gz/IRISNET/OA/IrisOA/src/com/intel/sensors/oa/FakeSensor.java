/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.lang.Exception;
import java.lang.Integer;
import java.lang.String;

/**  Fake Sensor.
  *
  *  @author Amol */
public class FakeSensor extends java.lang.Thread {

    // 8 queries ... 6 for parkingspots, 1 for block/available-space, and 1 for time
    private String[] xpathQueries = new String[8];  

    private String[] currentState = new String[8];

    private String destinationIP = "";

    private int destinationPort = -1;

    private java.util.Random random = null;

    private double probFlip = 0.2;

    private int waitTime = 1;

    FakeSensor(String query, String IP, int port) {
        xpathQueries[0] = query;
        currentState[0] = "no";
        destinationPort = port;
        destinationIP = IP; 
        random = new java.util.Random(port);
    }

    FakeSensor(String nghhood, String block, String parkingSpace, String IP, int port, double _probFlip, int _waitTime) {
        for(int i = 0; i < 6; i++) {
            xpathQueries[i] = generateParkingspaceQuery(nghhood, block, String.valueOf(i+1));
            currentState[i] = "no";
        }

        xpathQueries[6] = generateBlockAvailableSpaceQuery(nghhood, block);
        currentState[6] = "6";
        xpathQueries[7] = generateBlockExpiryTimeQuery(nghhood, block);
        currentState[7] = String.valueOf(System.currentTimeMillis());

        destinationPort = port;
        destinationIP = IP; 
        random = new java.util.Random(port);
        probFlip = _probFlip;
        waitTime = _waitTime;
    }

    public void run() {
        while(true) {
            // check if the state should be flipped
            for(int i = 0; i < 6; i++) {
                if(random.nextDouble() < probFlip) {
                    if(currentState[i].equals("yes")) {
                        currentState[i] = "no";
                        currentState[6] = String.valueOf(Integer.parseInt(currentState[6]) + 1);
                    } else {
                        currentState[i] = "yes";
                        currentState[6] = String.valueOf(Integer.parseInt(currentState[6]) - 1);
                    }
                }
            }

            try {
                currentState[7] = String.valueOf(System.currentTimeMillis());
                Protocol.sendNewDataMessage(destinationIP, destinationPort, xpathQueries, currentState);
            } catch (Exception e) {
                // e.printStackTrace();
            }

            // go to sleep
            try {
                Thread.sleep(waitTime * 1000);
            } catch (Exception e) {
            }
        }
    }

    public static String generateParkingspaceQuery(String nghhood, String block, String parkingspace) {
        return "/parkingone/usRegion/state/county/city[@id='Pittsburgh']/neighborhood[@id='" + nghhood + "']/block[@id='" + 
                                block  + "']/parkingSpace[@id='" + parkingspace + "']/usage/in-use";
    }

    public static String generateBlockAvailableSpaceQuery(String nghhood, String block) {
        return "/parkingone/usRegion/state/county/city[@id='Pittsburgh']/neighborhood[@id='" + nghhood + "']/block[@id='" + 
                                block  + "']/available-spaces/total";
    }

    public static String generateBlockExpiryTimeQuery(String nghhood, String block) {
        return "/parkingone/usRegion/state/county/city[@id='Pittsburgh']/neighborhood[@id='" + nghhood + "']/block[@id='" + 
                                block  + "']/@expiry";
    }

    public static void main(String args[]) {
        if(args.length != 7) {
            System.out.println("usage: FakeSensor <nghhood> <block> <parkingspace> <destinationIP>  <destinationPort> <flipProb> <waitTime>\n");
            System.exit(1);
        }
        FakeSensor fs = new FakeSensor(args[0], args[1], args[2], args[3], Integer.parseInt(args[4]), Double.parseDouble(args[5]), Integer.parseInt(args[6]));
        fs.run();
    }
};
