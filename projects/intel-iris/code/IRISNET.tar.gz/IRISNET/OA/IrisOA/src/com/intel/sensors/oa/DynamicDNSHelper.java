/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.net.*;
import java.io.*;
import java.util.*;
import java.lang.Thread;
import org.w3c.dom.Document;
import java.lang.Process;

/** Dynamic DNS Helper to talk to the Dynamic DNS server. 
 *
 *  @author Amol */
public class DynamicDNSHelper extends DNSHelper {
	ConfigurationManager CM = ConfigurationManager.instance();
	public Vector resolveHost(String sourceName) {
		try {
			Vector ret = new Vector();
			ret.add(InetAddress.getByName(sourceName).getHostAddress());
			ret.add(Integer.toString(CM.getOAPort()));
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	private int TTL = 120; // seconds
	
	private Process nsupdateProcess = null;
	
	private BufferedWriter bwNSUpdateProcess = null;
	
		private void startNSUpdateProcess() throws Exception {
		if(nsupdateProcess == null)  {
			nsupdateProcess = Runtime.getRuntime().exec("/usr/bin/nsupdate");
			bwNSUpdateProcess = new BufferedWriter(new OutputStreamWriter(nsupdateProcess.getOutputStream()));
			if (CM.getDNSServer() != "default")
				executeCommandUsingNSUpdate("server " + CM.getDNSServer());
		}
	}
	
	private void endNSUpdateProcess() throws Exception {
		if(nsupdateProcess != null) {
			bwNSUpdateProcess.flush();
			bwNSUpdateProcess.close();
			nsupdateProcess.waitFor();
			nsupdateProcess = null;
			bwNSUpdateProcess = null;
		}
	}
	
	private void executeCommandsUsingNSUpdate(String[] commands) throws Exception {
		String sendCommand = "send";
		if(nsupdateProcess == null) 
			startNSUpdateProcess();
		
		for(int i = 0; i < commands.length; i++) {
			System.out.println("DynamicDNSHelper.executeCommandUsingNSUpdate(): Sending command:");
			System.out.println(commands[i]);
			bwNSUpdateProcess.write(commands[i], 0, commands[i].length());
			bwNSUpdateProcess.newLine();
			//bwNSUpdateProcess.newLine();
			bwNSUpdateProcess.write(sendCommand, 0, sendCommand.length());
			bwNSUpdateProcess.newLine();
			bwNSUpdateProcess.flush();
		}
		//bwNSUpdateProcess.write(sendCommand, 0, sendCommand.length());
	}
	
	private void executeCommandUsingNSUpdate(String command) throws Exception {
		if(nsupdateProcess == null) 
			startNSUpdateProcess();
		
		System.out.println("DynamicDNSHelper.executeCommandUsingNSUpdate(): Sending command:");
		System.out.println(command);
		bwNSUpdateProcess.write(command, 0, command.length());
		bwNSUpdateProcess.newLine();
		bwNSUpdateProcess.newLine();
		bwNSUpdateProcess.flush();
	}
	
	// ignore new port
	public String updateHost(String source, String newIP, String newPort) throws Exception {
		startNSUpdateProcess();
		executeCommandUsingNSUpdate("update add " + source + " " + TTL + " A " + newIP);
		endNSUpdateProcess();
		return "Success";
	}
	
	public String purgeAll() throws Exception {
		throw new Exception("Cant do that with dynamic dns");
		// String message = "PURGEALL\n";
		// String response = sendMessage(message);
		// return response;
	}
	
	public String getAll() throws Exception {
		return "Can't execute this command with dynamic DNS\n";
		// String message = "GETALL\n";
		// String response = sendMessage(message);
		// return response;
	}
	
	public void removeAllOwnedHostNames(Document doc) throws Exception {
		//boolean b = true;
        //        if (b) return;

		// sendMessage("REMOVEIP " + Protocol.getLocalIP() /*"127.0.0.1"*/ + " " + Protocol.getLocalPort());
		String[] ownedHostNames = DOMProcessing.findAllOwnedHostNames(doc);
		String[] commands = new String[ownedHostNames.length];
		for(int i = 0; i < ownedHostNames.length; i++) {
			//System.out.println(ownedHostNames[i]);
			//commands[i] = new String("update delete " + ownedHostNames[i] + "." + CM.getDNSSuffix() +" A " + Protocol.getLocalIP());
			commands[i] = new String("update delete " + ownedHostNames[i] + "." + CM.getDNSSuffix());	// sknath
		}
		startNSUpdateProcess();
		executeCommandsUsingNSUpdate(commands);
		endNSUpdateProcess();
	}
	
	public void removeAllOwnedHostNamesAllRecords(Document doc) throws Exception {
		//boolean b = true;
		//if (b) return;
		// sendMessage("REMOVEIP " + Protocol.getLocalIP() /*"127.0.0.1"*/ + " " + Protocol.getLocalPort());
		String[] ownedHostNames = DOMProcessing.findAllOwnedHostNames(doc);
		String[] commands = new String[ownedHostNames.length];
		for(int i = 0; i < ownedHostNames.length; i++) {
			// System.out.println(ownedHostNames[i]);
			//commands[i] = new String("update delete " + ownedHostNames[i] + "." + CM.getDNSSuffix() +" A");
			commands[i] = new String("update delete " + ownedHostNames[i] + "." + CM.getDNSSuffix()); // sknath		
		}
		startNSUpdateProcess();
		executeCommandsUsingNSUpdate(commands);
		endNSUpdateProcess();
	}
	
	public void addAllOwnedHostNames(Document doc) throws Exception {
		//boolean b = true;
		//if (b) return;

		String[] ownedHostNames = DOMProcessing.findAllOwnedHostNames(doc);
		String[] commands = new String[ownedHostNames.length];
		String localIP = Protocol.getLocalIP();

		for(int i = 0; i < ownedHostNames.length; i++) {
			// System.out.println(ownedHostNames[i]);
			commands[i] = new String("update add " + ownedHostNames[i] + "."
						 + CM.getDNSSuffix() + " " + TTL + " A "
						 + localIP);
		}

		startNSUpdateProcess();
		executeCommandsUsingNSUpdate(commands);
		endNSUpdateProcess();
	}
	
	public void main(String args[]) {
		// resolveHost("amol");
		// updateHost("amol", "127.0.0.1 300");
		// resolveHost("amol.amol");
	}
};
