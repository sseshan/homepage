/* -*-  Mode:Java; c-basic-offset:8; tab-width:8; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.utils;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.Integer;


public class MyDNS {

	static String DNS_SUFFIX = ".dsan.net";

	private static ServerSocket serversocket;
	
	private static int num_entries = 0;
	private static String[] sourceNames = new String[1000];
	private static String[] ipPorts = new String[1000];
	
	public static String findIPPort(String source) {
		int max = -1, indexMax = -1;
		for(int i = 0; i < num_entries; i++) {
			if(source.endsWith(sourceNames[i])) {
				int len = sourceNames[i].length();
				if(max < len) {
					max = len;
					indexMax = i;
				}
			}
		}
		return ipPorts[indexMax];
	}
	
	public static void updateIPPort(String source, String newIPPort) {
		for(int i = 0; i < num_entries; i++) {
			if(source.equals(sourceNames[i])) {
				ipPorts[i] = newIPPort;
				return;
			}
		}
		sourceNames[num_entries] = source;
		ipPorts[num_entries] = newIPPort;
		num_entries++;
	}
	
	public static void run(int port, String baseIPPort) {
		try {
			serversocket = new ServerSocket(port);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		updateIPPort("", baseIPPort);
		
		try {
			while(true) {
				Socket s = serversocket.accept();
				InputStreamReader isr = new InputStreamReader(s.getInputStream());
				DataOutputStream dos = new DataOutputStream(s.getOutputStream());
				try {
					String str;
					BufferedReader br = new BufferedReader(isr);
					str = br.readLine();
					System.out.println("REQUEST : " + str);
					StringTokenizer st = new StringTokenizer(str);
					String command = st.nextToken();
					if(command.equals("RESOLVE")) {
						String sourcename = st.nextToken();
						String response = findIPPort(sourcename) + "\n";
						dos.writeBytes(response);
						dos.write(0);
						dos.flush();
						System.out.println("Sent response " + response);
					} else if(command.equals("UPDATE")) {
						String sourcename = st.nextToken() + DNS_SUFFIX;
						
						String newIPPort = st.nextToken("").substring(1);
						updateIPPort(sourcename, newIPPort);
						System.out.println("Updated " + sourcename + " to " + newIPPort + "\n");
						dos.writeBytes("SUCCESS\n");
						dos.write(0);
						dos.flush();
					} else if(command.equals("PURGEALL")) {
						num_entries = 1;
						dos.writeBytes("SUCCESS\n");
						dos.write(0);
						dos.flush();
					} else if(command.equals("REMOVEIP")) {
						String IPPort = st.nextToken("").substring(1);
						for(int i = 0; i < num_entries; i++) {
							if(ipPorts[i].equals(IPPort)) {
								sourceNames[i] = "this-should-never-appear-as-an-ip";
							}
						}
						dos.writeBytes("SUCCESS\n");
						dos.write(0);
						dos.flush();
					} else if(command.equals("GETALL")) {
						StringBuffer sb = new StringBuffer();
						for(int i = 0; i < num_entries; i++) {
							sb.append(sourceNames[i]);
							sb.append(" ");
							sb.append(ipPorts[i]);
							sb.append(" ");
						}
						sb.append("\n");
						dos.writeBytes(sb.toString());
						dos.write(0);
						dos.flush();
					} else {
						System.out.println("Invalid Command");
						continue;
					}
					
					s.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public static void main(String[] args) {
		if (args.length <= 0) {
			System.out.println("Usage: java MyDNS port      port=6001 usually");
			System.exit(1);
		}

		try {
			System.out.println("Using " + DNS_SUFFIX + " as dns suffix.");
			MyDNS.run(Integer.parseInt(args[0]), "127.0.0.1 -1");
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
};
