/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network
 
             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
package com.intel.sensors.oa;

import java.lang.reflect.*;

import java.util.*;
import java.io.*;
import java.net.*;

import org.w3c.dom.*;

// ---------------------------------------------------------------------
//                         class SPUtils
// ---------------------------------------------------------------------

/** SPUtils class provides methods to call a user-defined stored procedure
 *  
 *  @author Shimin
 */
public class SPUtils {

  // ---
  // static fields
  // ---

      // this is the class loader for loading user-provided classes
  static URLClassLoader  loader;

      // To add new types:
      // 1. add a type constant and change the TOTAL value
      // 2. add the prototype definition in initProtoTypes()

      // constants for stored procedure types
  static final int SP_TYPE_SIMPLE  = 0;
  static final int SP_TYPE_COMPLEX = 1;
  static final int SP_TYPE_TOTAL   = 2;

      // constants for method types
  static final int METHOD_LOCAL   = 0;
  static final int METHOD_INIT    = 1;
  static final int METHOD_INITPATH= 2;
  static final int METHOD_COMPUTE = 3;
  static final int METHOD_FINAL   = 4;
  static final int METHOD_PRUNE   = 5;
  static final int METHOD_TOTAL   = 6;

  static SPProtoType[][] prototypes;

      // hashtable to index SPInfo
  static Hashtable  sp_hashtable;

      // a very simple dom used to evaluate predicate
  static Document   simple_dom;

  // ---
  // initialization
  // ---

  static void init (String[] url_list)
  {
	loader = createClassLoader (url_list);

	initProtoTypes ();

	sp_hashtable = new Hashtable (37);

      try{
	simple_dom = DOMProcessing.XMLtoDOM (
		"<?xml version='1.0' encoding='utf-8'?><simple/>");
      } catch (Exception e) {
	Utils.error ("DOMProcessing.XMLtoDOM does not work!");
      }
  }

  // create a class loader from a set of url string specs
  static URLClassLoader createClassLoader (String[] url_list)
  {
	URLClassLoader  ll = null;

    try {
	int   num_urls = url_list.length;
	URL[] urls = new URL[num_urls];
	for (int ii=0; ii<num_urls; ii++) {
	   urls[ii] = new URL (url_list[ii]);
	}

	ll = new URLClassLoader (urls);

    } catch (MalformedURLException e) {
	Utils.error ("SPUtils.createClassLoader " + e.getMessage ());
    } catch (SecurityException e) {
	Utils.error (e.getMessage ());
    }

	return ll;
  }

  // initiate the prototypes
  static void initProtoTypes ()
  {
	// 1. allocate 2D array
	prototypes = new SPProtoType[SP_TYPE_TOTAL][];
	for (int ii=0; ii<SP_TYPE_TOTAL; ii++) {
	   prototypes[ii] = new SPProtoType[METHOD_TOTAL];
	   for (int jj=0; jj<METHOD_TOTAL; jj++)
	      prototypes[ii][jj] = new SPProtoType ();
	}

	// 2. get all the needed Class types
	String a_string = "";
	Class class_String       = a_string.getClass();

	String[] a_string_array = new String[1];
	Class class_String_array = a_string_array.getClass();

	Class class_Node         = null;	// these are interfaces
	Class class_NodeList     = null;
	try {
	   class_Node         = Class.forName ("org.w3c.dom.Node");
	   class_NodeList     = Class.forName ("org.w3c.dom.NodeList");
	}
	catch (Exception e) {
	  // these Class types are basic and we shouldn't encounter any errors
	  e.printStackTrace ();
	  System.exit (1);
	}

	Class class_boolean = boolean.class;

	// 3. initiate the prototypes
	   SPProtoType  ss, pp;

	   // simple METHOD_LOCAL
	   // String local (String[] orig_vals, String[] params)
	   ss = prototypes[SP_TYPE_SIMPLE][METHOD_LOCAL];
	   ss.suffix = "_local";
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_String_array;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

	   // simple METHOD_INIT
	   // String init (String orig_val, String[] params)
	   ss = prototypes[SP_TYPE_SIMPLE][METHOD_INIT];
	   ss.suffix = "_init";
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_String;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

	   // simple METHOD_INITPATH
	   // String init (String orig_val, String path, String[] params)
	   ss = prototypes[SP_TYPE_SIMPLE][METHOD_INITPATH];
	   ss.suffix = "_init";
	   ss.parameterType = new Class[3];
	   ss.parameterType[0] = class_String;
	   ss.parameterType[1] = class_String;
	   ss.parameterType[2] = class_String_array;
	   ss.returnType       = class_String;

	   // simple METHOD_COMPUTE
	   // String compute (String[] inter_vals, String[] params)
	   ss = prototypes[SP_TYPE_SIMPLE][METHOD_COMPUTE];
	   ss.suffix = "_compute";
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_String_array;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

	   // simple METHOD_FINAL
	   // String final (String inter_val, String[] params)
	   ss = prototypes[SP_TYPE_SIMPLE][METHOD_FINAL];
	   ss.suffix = "_final";
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_String;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

           // simple METHOD_PRUNE
           // boolean prune (String inter_val, String[] params)
           ss = prototypes[SP_TYPE_SIMPLE][METHOD_PRUNE];
           ss.suffix = "_prune";
           ss.parameterType = new Class[2];
           ss.parameterType[0] = class_String;
           ss.parameterType[1] = class_String_array;
           ss.returnType       = class_boolean;



	   // complex METHOD_LOCAL
	   // String local (NodeList orig_nodes, String[] params)
	   ss = prototypes[SP_TYPE_COMPLEX][METHOD_LOCAL];
	   pp = prototypes[SP_TYPE_SIMPLE][METHOD_LOCAL];
	   ss.suffix = pp.suffix;
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_NodeList;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

	   // complex METHOD_INIT
	   // String init (Node orig_node, String[] params)
	   ss = prototypes[SP_TYPE_COMPLEX][METHOD_INIT];
	   pp = prototypes[SP_TYPE_SIMPLE][METHOD_INIT];
	   ss.suffix = pp.suffix;
	   ss.parameterType = new Class[2];
	   ss.parameterType[0] = class_Node;
	   ss.parameterType[1] = class_String_array;
	   ss.returnType       = class_String;

	   // complex METHOD_INITPATH
	   // String init (Node orig_node, String path, String[] params)
	   ss = prototypes[SP_TYPE_COMPLEX][METHOD_INITPATH];
	   pp = prototypes[SP_TYPE_SIMPLE][METHOD_INITPATH];
	   ss.suffix = pp.suffix;
	   ss.parameterType = new Class[3];
	   ss.parameterType[0] = class_Node;
	   ss.parameterType[1] = class_String;
	   ss.parameterType[2] = class_String_array;
	   ss.returnType       = class_String;

	   // complex METHOD_COMPUTE
	   // String compute (String[] inter_vals, String[] params)
	   ss = prototypes[SP_TYPE_COMPLEX][METHOD_COMPUTE];
	   pp = prototypes[SP_TYPE_SIMPLE][METHOD_COMPUTE];
	   ss.suffix = pp.suffix;
	   ss.parameterType = pp.parameterType;
	   ss.returnType = pp.returnType;

	   // complex METHOD_FINAL
	   // String final (String inter_val, String[] params)
	   ss = prototypes[SP_TYPE_COMPLEX][METHOD_FINAL];
	   pp = prototypes[SP_TYPE_SIMPLE][METHOD_FINAL];
	   ss.suffix = pp.suffix;
	   ss.parameterType = pp.parameterType;
	   ss.returnType = pp.returnType;

           // complex METHOD_PRUNE
           // boolean prune (String inter_val, String[] params)
           ss = prototypes[SP_TYPE_COMPLEX][METHOD_PRUNE];
           pp = prototypes[SP_TYPE_SIMPLE][METHOD_PRUNE];
	   ss.suffix = pp.suffix;
	   ss.parameterType = pp.parameterType;
	   ss.returnType = pp.returnType;
  }

  // ---
  // basic utilities for invoking a method
  // ---

  // get className.methodName that has parameterType and returnType
  // and is a static method
  // return null if the method is not found
  static Method getMethod (String className, String methodName, 
                           Class[] parameterType, Class returnType)
  {
	Method mm = null;
    try {
	Class cc = Class.forName (className, true, loader);
	mm = cc.getMethod (methodName, parameterType);

	if (! Modifier.isStatic (mm.getModifiers ())) {
	  mm = null;
	}
	else if (mm.getReturnType () != returnType) {
	  if ((returnType != null)||
              (!mm.getReturnType().toString().equals("void"))) {
	    mm = null;
	  }
	}
    } catch (Exception e) {
	//Utils.warning (e.getClass().toString() + ':' 
	//	     + className + ':' + methodName);
	mm = null;
    }
	return mm;
  }

  // invoke a static method
  static Object invokeStaticMethod (Method method, Object[] args)
  {
	Object ret = null;
    try {
	ret = method.invoke (null, args);
    } catch (Exception e) {
	e.printStackTrace ();
        Utils.error (e.getClass().toString() + ':' + e.getMessage ());
    }
	return ret;
  }

  // ---
  // basic utilities for managing stored procedure
  // ---

  // look for the className:methodName in hash table, if not found,
  // then try to load the method.
  // return null if className:methodName is not found anywhere.
  static SPInfo getStoredProcedure (String className, String methodName)
  {
	// 1. check hash table
	String key = className + ':' + methodName;
	Object ret = sp_hashtable.get (key);
	if (ret != null) {
	  return (SPInfo) ret;
	}

	// 2. get a new instance of SPInfo
	SPInfo spinfo = SPInfo.newInstance (className, methodName);

	if (spinfo != null) {
	  sp_hashtable.put (key, spinfo);
	}

	return spinfo;
  }

  static void unloadStoredProcedure (SPInfo spinfo)
  {
	sp_hashtable.remove (spinfo.full_name);
  }

  static void unloadStoredProcedure (String className, String methodName)
  {
	String key = className + ':' + methodName;
	sp_hashtable.remove (key);
  }


  // ---
  // basic utilities for using the stored procedure
  // ---

  // simple procedure
  static String SPLocal (SPInfo spinfo, String[] orig_vals, String[] params)
  {
	Object[] args = new Object[2];
	args[0] = orig_vals;
	args[1] = params;
	String ret = (String) 
		invokeStaticMethod (spinfo.method[METHOD_LOCAL], args);
	return ret;
  }

  static String SPInitCompute (SPInfo spinfo, 
			       String[] orig_vals, String[] params)
  {
	int num_vals = orig_vals.length;
	String[] inter_vals = new String[num_vals];

	Object[] args = new Object[2];
	args[1] = params;
	for (int ii=0; ii<num_vals; ii++) {
	   args[0] = orig_vals[ii];
	   inter_vals[ii] =  (String)
		invokeStaticMethod (spinfo.method[METHOD_INIT], args);
	}

	String ret;

	if (num_vals > 1) {
	  args[0] = inter_vals;
	  ret = (String)
		invokeStaticMethod (spinfo.method[METHOD_COMPUTE], args);
	}
	else {
	  ret = inter_vals[0];
	}

	return ret;
  }

  static String SPCompute (SPInfo spinfo, String[] inter_vals, String[] params)
  {
	int num_vals = inter_vals.length;

	if (num_vals == 1) {
	  return inter_vals[0];
	}

	Object[] args = new Object[2];
	args[0] = inter_vals;
	args[1] = params;
	String ret = (String)
		     invokeStaticMethod (spinfo.method[METHOD_COMPUTE], args);
	return ret;
  }

  static String SPFinal (SPInfo spinfo, String inter_val, String[] params)
  {
	Object[] args = new Object[2];
	args[0] = inter_val;
	args[1] = params;
	String ret = (String)
		     invokeStaticMethod (spinfo.method[METHOD_FINAL], args);
	return ret;
  }

  static boolean SPPrune (SPInfo spinfo, String inter_val, String[] params)
  {
        Object[] args = new Object[2];
        args[0] = inter_val;
        args[1] = params;
        Boolean ret = (Boolean)
                     invokeStaticMethod (spinfo.method[METHOD_PRUNE], args);
        return ret.booleanValue();
  }

  // when there is no orig_val
  static String SPInitFinalEmpty (SPInfo spinfo, String[] params)
  {
     if (! spinfo.hasInitPath ()) {
        Object[] args = new Object[2];
        args[0] = null;
        args[1] = params;
        String inter_val = (String)
                invokeStaticMethod (spinfo.method[METHOD_INIT], args);
        return SPFinal (spinfo, inter_val, params);
     }
     else {
        Object[] args = new Object[3];
        args[0] = null;
        args[1] = null;
        args[2] = params;
        String inter_val = (String)
                invokeStaticMethod (spinfo.method[METHOD_INITPATH], args);
        return SPFinal (spinfo, inter_val, params);
     }
  }

  // complex procedure
  static String SPLocal (SPInfo spinfo, NodeList orig_nodes, String[] params)
  {
	Object[] args = new Object[2];
	args[0] = orig_nodes;
	args[1] = params;
	String ret = (String) 
		invokeStaticMethod (spinfo.method[METHOD_LOCAL], args);
	return ret;
  }

  static String SPInitCompute (SPInfo spinfo, 
			       NodeList orig_nodes, String[] params)
  {
	int num_vals = orig_nodes.getLength();
	String[] inter_vals = new String[num_vals];

	Object[] args = new Object[2];
	args[1] = params;
	for (int ii=0; ii<num_vals; ii++) {
	   args[0] = orig_nodes.item(ii);
	   inter_vals[ii] =  (String)
		invokeStaticMethod (spinfo.method[METHOD_INIT], args);
	}

	String ret;

	if (num_vals > 1) {
	  args[0] = inter_vals;
	  ret = (String)
		invokeStaticMethod (spinfo.method[METHOD_COMPUTE], args);
	}
	else {
	  ret = inter_vals[0];
	}

	return ret;
  }

  // complex procedure and init with full path
  static String SPInitCompute (SPInfo spinfo, QueryInfo qinfo,
			       NodeList orig_nodes, String[] params)
  {
	int num_vals = orig_nodes.getLength();
	String[] inter_vals = new String[num_vals];

	Object[] args = new Object[3];
	args[2] = params;
	for (int ii=0; ii<num_vals; ii++) {
	   Node n = orig_nodes.item(ii);
	   if (n instanceof Element) {
	     args[0] = n;
	     if (qinfo != null) {
	       args[1] = qinfo.queryForRootParent () + '/' 
                       + QueryUtils.findQueryForThisElement((Element)n);
	     }
	     else {  // note that this must be called from xsltCall
	       args[1] = QueryUtils.findQueryForThisElement((Element)n);
	     }
	     inter_vals[ii] =  (String)
		invokeStaticMethod (spinfo.method[METHOD_INITPATH], args);
	   }
	   else {
	     inter_vals[ii] = null;
	   }
	}

	String ret;

	if (num_vals > 1) {
	  Object[] cargs = new Object[2];
	  cargs[0] = inter_vals;
	  cargs[1] = params;
	  ret = (String)
		invokeStaticMethod (spinfo.method[METHOD_COMPUTE], cargs);
	}
	else {
	  ret = inter_vals[0];
	}

	return ret;
  }

  // ---
  // xsltCall to handle xslt local function call
  // ---

  static String xsltCall (String class_name, String method_name,
			  NodeList xpath_result, String[] params)
  {
	if (class_name.equals ("BuiltIn"))
	  class_name = "com.intel.sensors.oa.SPBuiltIn";

	SPInfo spinfo = getStoredProcedure (class_name, method_name);

        if (spinfo == null) {
	  Utils.error ("stored procedure " + class_name + ":" + method_name
			+ " is not found!");
	}

	// complex procedure?
	if (spinfo.isComplex ()) {
	  if (spinfo.hasLocal ())
	    return SPLocal (spinfo, xpath_result, params);
	  else if (spinfo.hasInitPath ())
	    return SPFinal (spinfo, 
			    SPInitCompute (spinfo, null, xpath_result, params),
			    params);
	  else
	    return SPFinal (spinfo, 
			    SPInitCompute (spinfo, xpath_result, params),
			    params);
	}

	// simple procedure
	// needs text conversion
	int num_nodes = xpath_result.getLength();
	String[] orig_vals = new String[num_nodes];
    try {
	for (int ii=0; ii<num_nodes; ii++) {
	   Node n = xpath_result.item (ii);
	   if (n instanceof org.w3c.dom.Attr) {
	     orig_vals[ii] = ((org.w3c.dom.Attr)n).getValue ();
	   }
	   else if (n instanceof org.w3c.dom.Text) {
	     orig_vals[ii] = ((org.w3c.dom.Text)n).getData().trim();
	   }
	   else if (n instanceof Element) {
               StringBuffer sb = new StringBuffer ();
               Node child = n.getFirstChild ();
               while (child != null) {
                    if (child instanceof org.w3c.dom.Text) {
                      sb.append (((org.w3c.dom.Text)child).getData ());
                    }
                    child = child.getNextSibling ();
               }
               orig_vals[ii] = sb.toString().trim();
	   }
	   else {
	     Utils.error ("Wrong xpath to simple procedure!");
	   }
	}
    } catch (Exception e) {
	Utils.error (e.getClass().toString() + ':' + e.getMessage ());
    }

	// now call the simple procedure
	if (spinfo.hasLocal ())
	  return SPLocal (spinfo, orig_vals, params);
	else
	  return SPFinal (spinfo,
			  SPInitCompute (spinfo, orig_vals, params),
			  params);
  }

  // if the xpath is only a literal
  static String xsltCall (String class_name, String method_name,
			  String xpath_result, String[] params)
  {
	if (class_name.equals ("BuiltIn"))
	  class_name = "com.intel.sensors.oa.SPBuiltIn";

        SPInfo spinfo = getStoredProcedure (class_name, method_name);
                                                                                
        if ((spinfo == null) || (spinfo.isComplex ())) {
	  Utils.error ("simple procedure " + class_name + ":" + method_name
			+ " is not found!");
	}

	String[] orig_vals = new String[1];
	orig_vals[0] = xpath_result;

	if (spinfo.hasLocal ())
	  return SPLocal (spinfo, orig_vals, params);
	else
	  return SPFinal (spinfo,
			  SPInitCompute (spinfo, orig_vals, params),
			  params);
  }

  // xsltCall with various number of parameters
  // since java does not support variable arguments
  public static String xsltCall0 (String class_name, String method_name,
			  NodeList xpath_result)
  {
	String[] params = new String[0];
	return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall1 (String class_name, String method_name,
			  NodeList xpath_result, String param0)
  {
	String[] params = new String[1];
	params[0] = param0;
	return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall2 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1)
  {
        String[] params = new String[2];
        params[0] = param0;
        params[1] = param1;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall3 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
			  String param2)
  {
        String[] params = new String[3];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall4 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3)
  {
        String[] params = new String[4];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall5 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4)
  {
        String[] params = new String[5];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall6 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
			  String param5)
  {
        String[] params = new String[6];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall7 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6)
  {
        String[] params = new String[7];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall8 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7)
  {
        String[] params = new String[8];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall9 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7,
			  String param8)
  {
        String[] params = new String[9];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        params[8] = param8;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall10 (String class_name, String method_name,
                          NodeList xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7,
                          String param8, String param9)
  {
        String[] params = new String[10];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        params[8] = param8;
        params[9] = param9;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  // xsltCall with various number of parameters
  // since java does not support variable arguments
  public static String xsltCall0 (String class_name, String method_name,
			   String  xpath_result)
  {
	String[] params = new String[0];
	return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall1 (String class_name, String method_name,
			   String  xpath_result, String param0)
  {
	String[] params = new String[1];
	params[0] = param0;
	return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall2 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1)
  {
        String[] params = new String[2];
        params[0] = param0;
        params[1] = param1;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall3 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
			  String param2)
  {
        String[] params = new String[3];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall4 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3)
  {
        String[] params = new String[4];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall5 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4)
  {
        String[] params = new String[5];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall6 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
			  String param5)
  {
        String[] params = new String[6];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall7 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6)
  {
        String[] params = new String[7];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall8 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7)
  {
        String[] params = new String[8];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall9 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7,
			  String param8)
  {
        String[] params = new String[9];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        params[8] = param8;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  public static String xsltCall10 (String class_name, String method_name,
                           String  xpath_result, String param0, String param1,
                          String param2, String param3, String param4,
                          String param5, String param6, String param7,
                          String param8, String param9)
  {
        String[] params = new String[10];
        params[0] = param0;
        params[1] = param1;
        params[2] = param2;
        params[3] = param3;
        params[4] = param4;
        params[5] = param5;
        params[6] = param6;
        params[7] = param7;
        params[8] = param8;
        params[9] = param9;
        return xsltCall (class_name, method_name, xpath_result, params);
  }

  // ------------------------------------------------------------------------
  // the predicate_expr should have the form: *[predicate]
  static boolean evaluateXpathPredicate (String predicate_expr)
  {
	Node n = null;
     try {
	n = org.apache.xpath.XPathAPI.selectSingleNode (
				simple_dom, predicate_expr);
     } catch (Exception e) {
	Utils.error ("Evaluating " + predicate_expr + ":" 
		     + e.getClass().toString());
     }
	return (n != null);
  }

  // ------------------------------------------------------------------------
  //  Stored Procedures to facillitate query processing
  // ------------------------------------------------------------------------

  // ---
  // Node Existence Test: complex procedure
  // Usage:
  //         String nodeExist (locationPath)
  //         return "1" if such nodes exist
  //         return "0" if not exists
  // ---
  public static String nodeExist_local (NodeList orig_nodes, String[] params)
  {
        return  (orig_nodes.getLength()>0)?"1":"0";
  }
  public static String nodeExist_init (Node orig_node, String[] params)
  {
        return (orig_node!=null)?"1":"0";
  }
  public static String nodeExist_compute (String[] inter_vals, String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
	   if (inter_vals[ii].charAt(0) == '1')
	     return "1";
        return "0";
  }
  public static String nodeExist_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static boolean nodeExist_prune (String inter_val, String[] params)
  {
        return ((inter_val!=null) && (inter_val.length() > 0) &&
	        (inter_val.charAt(0) == '1'));
  }

  // ---
  // Attr Existence Test: simple procedure
  // Usage:
  //         String attrExist (locationPath/@attr)
  //         return "1" if such attr exists
  //         return "0" if not exists
  // ---
  public static String attrExist_local (String[] orig_vals, String[] params)
  {
        return  (orig_vals.length>0)?"1":"0";
  }
  public static String attrExist_init (String orig_val, String[] params)
  {
        return (orig_val!=null)?"1":"0";
  }
  public static String attrExist_compute (String[] inter_vals, String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
           if (inter_vals[ii].charAt(0) == '1')
             return "1";
        return "0";
  }
  public static String attrExist_final (String inter_val, String[] params)
  {
        return inter_val;
  }
  public static boolean attrExist_prune (String inter_val, String[] params)
  {
        return ((inter_val!=null) && (inter_val.length() > 0) &&
	        (inter_val.charAt(0) == '1'));
  }


  // ---
  // Test if there exists a node that satisfies an expression
  // Simple procedure
  // Usage:
  //		exprTrueExist (location_path, expr, mark)
  //		it replaces mark in expr with the value of location_path,
  //		then evaluate the expr.
  //            expr is of the form *[predicate] and mark is in the predicate
  //
  //            return "1" if true
  //            return "0" if no node satisfies the expr
  // ---
  public static String exprTrueExist_local (String[] orig_vals, String[] params)
  {
	if (orig_vals.length == 0)
	  return "0";

	String expr = params[0];
	String mark = params[1];

	int start  = expr.indexOf (mark);
	int end    = start + mark.length();
	String start_string = expr.substring (0,start) + "'";
	String end_string = "'" + expr.substring (end, expr.length());

	for (int ii=0; ii<orig_vals.length; ii++) {
	   String predicate_expr = start_string + orig_vals[ii] + end_string;
	   if (evaluateXpathPredicate (predicate_expr))
	     return "1";
	}
	return "0";
  }
  public static String exprTrueExist_init (String orig_val, String[] params)
  {
	if (orig_val == null)
	  return "0";

	String expr = params[0];
	String mark = params[1];

	int start = expr.indexOf (mark);
	int end   = start + mark.length();
	String predicate_expr = expr.substring (0,start) 
				+ "'" + orig_val + "'" 
				+ expr.substring (end, expr.length());
	return evaluateXpathPredicate (predicate_expr)? "1" : "0";
  }
  public static String exprTrueExist_compute (String[] inter_vals, 
					      String[] params)
  {
        for (int ii=0; ii<inter_vals.length; ii++)
	   if (inter_vals[ii].charAt(0) == '1')
	     return "1";
        return "0";
  }
  public static String exprTrueExist_final (String inter_val, String[] params)
  {
	return inter_val;
  }
  public static boolean exprTrueExist_prune (String inter_val, String[] params)
  {
        return ((inter_val!=null) && (inter_val.length() > 0) &&
	        (inter_val.charAt(0) == '1'));
  }

  // ---
  // Test if an expression is satisfied by a combination of inputs
  // Simple local procedure
  // Usage:
  //		testExpr (expr, mark1, input1, mark2, input2, ...)
  //
  //		inputs are comma separated list of values.
  //		testExpr enumerates all the combinations of the input values.
  //		For each combination, it replaces the marks with the values
  //		in the expr and evaluate the expr.
  //
  //            expr is of the form *[predicate][predicate]
  //
  //            return "1" if there exists a combination that satisfies
  //		           the expr.
  //            return "0" if no combination satisfies the expr
  // ---
  public static String testExpr_local (String[] orig_vals, String[] params)
  {
	// 1. divide the input into value arrays
	int num_inputs = params.length / 2;
	String expr = orig_vals[0];
	if (num_inputs == 0) {
	  return evaluateXpathPredicate(expr)? "1" : "0";
	}

	String[][] input = new String[num_inputs][];

	ArrayList  temp = new ArrayList ();
	for (int ii=0; ii<num_inputs; ii++) {
	   String this_input = params[2*ii+1];

	   // make sure every input has some values
	   if (this_input.length() == 0)
	     return "0";

	   // put all the substrings separated by comma into temp
	   temp.clear ();
	   int start = 0;
	   int end = this_input.indexOf (',');
	   while (end != -1) {
		temp.add (this_input.substring (start, end));
		start = end + 1;
		end = this_input.indexOf (',', start);
	   }
	   temp.add (this_input.substring (start, this_input.length()));

	   // allocate String[] and store the string references
	   int num_vals = temp.size();
	   input[ii] = new String[num_vals];
	   for (int jj=0; jj<num_vals; jj++)
	      input[ii][jj] = (String) temp.get (jj);
	} // end of for

	// 2. get all the marks and their positions in the expr
	String[] mark = new String[num_inputs];
	int[] pos = new int[num_inputs];

	for (int ii=0; ii<num_inputs; ii++) {
	   String this_mark = params[2*ii];
	   mark[ii] = this_mark;
	   pos[ii] = expr.indexOf (this_mark);
	}

	// 3. sort the pos[], mark[], input[] arrays according to the pos
	for (int ii=0; ii<num_inputs-1; ii++) {
	   int index = ii;
	   int p = pos[ii];
	   for (int jj=ii+1; jj<num_inputs; jj++)
	      if (pos[jj] < p) {
	        p = pos[jj]; index = jj;
	      }

	   if (index != ii) {
	     // swap
	     p=pos[ii]; pos[ii]=pos[index]; pos[index]=p;
	     String t1=mark[ii]; mark[ii]=mark[index]; mark[index]=t1;
	     String[] t2=input[ii]; input[ii]=input[index]; input[index]=t2;
	   }
	}

	// 4. get the fixed part of the predicate expr
	String[] fixed = new String[num_inputs+1];
	{
	  fixed[0] = expr.substring (0, pos[0]) + "'";
	  int start = pos[0] + mark[0].length();
	  for (int ii=1; ii<num_inputs; ii++) {
	     fixed[ii] = "'" + expr.substring (start, pos[ii]) + "'";
	     start = pos[ii] + mark[ii].length();
	  }
	  fixed[num_inputs] = "'" + expr.substring (start, expr.length());
	}

	// 5. test all the combinations
	// let's do some optimizations on the inner loop
	// we select the maximum number of values as the inner loop
	// so that we can keep the other parts of the query string fixed longer.

	// input[inner].length = max (input[ii].length)
	int inner = 0;
	for (int ii=1; ii<num_inputs; ii++)
	   if (input[ii].length > input[inner].length)
	     inner = ii;

	// we enumerate the pre and post part by taking moduli
	int pre_outer_iterations = 1;
	for (int ii=0; ii<inner; ii++)
	   pre_outer_iterations *= input[ii].length;

	int post_outer_iterations = 1;
	for (int ii=inner+1; ii<num_inputs; ii++)
	   post_outer_iterations *= input[ii].length;

	for (int pre_ii = 0; pre_ii < pre_outer_iterations; pre_ii ++) {
	   String pre_string = "";
	   int rest = pre_ii;
	   // pre_ii = i0 + i1*l0 + i2*(l0*l1) + ...
	   for (int ii=0; ii<inner; ii++) {
	      int index = rest;
	      rest = rest / input[ii].length;
	      index -= rest * input[ii].length;
	      pre_string += fixed[ii] + input[ii][index];
	   }
	   pre_string += fixed[inner];

	   for (int post_ii = 0; post_ii < post_outer_iterations; post_ii ++) {
	      String post_string = "";
	      rest = post_ii;
	      for (int ii=inner+1; ii<num_inputs; ii++) {
	         int index = rest;
	         rest = rest / input[ii].length;
	         index -= rest * input[ii].length;
		 post_string += fixed[ii] + input[ii][index];
	      }
	      post_string += fixed[num_inputs];

	      // inner loop
	      for (int ii=0; ii<input[inner].length; ii++) {
		 if (evaluateXpathPredicate (pre_string + 
				input[inner][ii] + post_string))
		   return "1";
	      }
	   } // end of post loop
	} // end of pre loop

	return "0";
  }

  // ------------------------------------------------------------------------

  // testing
  public static void main (String args[])
  {
	try {
	  String[] urls = new String[1];
	  urls[0] = "file:///tmp/test/";
	  init (urls);

/*
	  SPInfo spinfo = getStoredProcedure ("com.intel.sensors.oa.SPUtils",
					      "attrExist");
	  System.out.println ("prune: " + spinfo.hasPrune ());
	  if (spinfo.hasPrune ()) {
	    boolean ret = SPPrune (spinfo, "1", null);
	    System.out.println ("return: " + ret);
	    ret = SPPrune (spinfo, "0", null);
	    System.out.println ("return2: " + ret);
	  }
*/
	  if (args.length == 2) {
	    SPInfo spinfo = getStoredProcedure (args[0], args[1]);
	    if (spinfo != null) {
	      System.out.println ("isSimple: " + spinfo.isSimple());
	      System.out.println ("isComplex: " + spinfo.isComplex());
	      System.out.println ("hasLocal: " + spinfo.hasLocal());
	      System.out.println ("hasInitComputeFinal: " 
				+ spinfo.hasInitComputeFinal());
	      System.out.println ("hasPrune: " + spinfo.hasPrune());
	      System.out.println ("hasInitPath: " + spinfo.hasInitPath());
	    }
	    else {
	      System.out.println ("Can't find " + args[0] + ":" + args[1]);
	    }
	  }

	} catch (Exception e) {
	  Utils.error (e.getMessage());
	}
  }

} // SPUtils

// ---------------------------------------------------------------------
//                         class SPProtoType
// ---------------------------------------------------------------------

/** SPProtoType holds a method prototype.
 */
class SPProtoType {

  String  suffix;
  Class[] parameterType;
  Class   returnType;

} // SPProtoType
