/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network

             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

      * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

      * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa;

import java.net.*;
import java.io.*;

//
// TimedSocket.java
// 
//

/**
  * This class offers a timeout feature on socket connections.
  * A maximum length of time allowed for a connection can be 
  * specified, along with a host and port.
  *
  * This feature is required for jdk 1.3 or earlier version, since they
  * don't have any timeout mechanisms for Socket connection.
  * (Socket.setSoTimeout() of jdk 1.3 requires a connected socket, and affects
  * subsequent reads/writes on that socket. But an effort to create
  * a socket to a currently down host may take a few minutes before it fails)
  *
  * This class can be replaced by jdk 1.4's socket connection timeout feature.

  * 
  */
public class TimedSocket
{
	/**
	  * Attempts to connect to a service at the specified address
	  * and port, for a specified maximum amount of time.
	  *
	  *	@param	addr	Address of host
	  *	@param	port	Port of service
	  * @param	delay	Delay in milliseconds
	  */
	public static Socket getSocket ( InetAddress addr, int port, int delay) throws InterruptedIOException, IOException
	{
		// Create a new socket thread, and start it running
		SocketThread st = new SocketThread( addr, port );
		st.start();

		int timer = 0;
		Socket sock = null;

		for (;;)
		{
			// Check to see if a connection is established
			if (st.isConnected())
			{
				// Yes ...  assign to sock variable, and break out of loop
				sock = st.getSocket();
				break;
			}
			else
			{
				// Check to see if an error occurred
				if (st.isError())
				{
					// No connection could be established
					throw (st.getException());
				}

				try
				{
					// Sleep for a short period of time
					Thread.sleep ( POLL_DELAY );
				}
				catch (InterruptedException ie) {}

				// Increment timer
				timer += POLL_DELAY;

				// Check to see if time limit exceeded
				if (timer > delay)
				{
					// Can't connect to server
					throw new InterruptedIOException("Could not connect for " + delay + " milliseconds");
				}
			}
		}

		return sock;
	}

	/**
	  * Attempts to connect to a service at the specified address
	  * and port, for a specified maximum amount of time.
	  *
	  *	@param	host	Hostname of machine
	  *	@param	port	Port of service
	  * @param	delay	Delay in milliseconds
	  */
	public static Socket getSocket ( String host, int port, int delay) throws InterruptedIOException, IOException
	{
		// Convert host into an InetAddress, and call getSocket method
		InetAddress inetAddr = InetAddress.getByName (host);

		return getSocket ( inetAddr, port, delay );
	}

	public static void main(String args[]) throws Exception
	{
		try
		{
			//InetAddress addr = InetAddress.getByName("192.168.0.3");
			//Socket s = TimedSocket.getSocket (addr, 80, 5000);
			Socket s = TimedSocket.getSocket ("192.168.0.3", 80, 5000);
			s.close();
			System.out.println ("connected");
		}
		catch (IOException ioe)
		{
			System.out.println ("time out");
		}

	}

	// Inner class for establishing a socket thread
	// within another thread, to prevent blocking.
	static class SocketThread extends Thread
	{
		// Socket connection to remote host
		volatile private Socket m_connection = null;
		// Hostname to connect to
		private String m_host       = null;
		// Internet Address to connect to
		private InetAddress m_inet  = null;
		// Port number to connect to
		private int    m_port       = 0;
		// Exception in the event a connection error occurs
		private IOException m_exception = null;

		// Connect to the specified host and port number
		public SocketThread ( String host, int port)
		{
			// Assign to member variables
			m_host = host;
			m_port = port;
		}

		// Connect to the specified host IP and port number
		public SocketThread ( InetAddress inetAddr, int port )
		{
			// Assign to member variables
			m_inet = inetAddr;
			m_port = port;
		}

		public void run()
		{
			// Socket used for establishing a connection
			Socket sock = null;

			try
			{
				// Was a string or an inet specified
				if (m_host != null)
				{
					// Connect to a remote host - BLOCKING I/O
					sock = new Socket (m_host, m_port);
				}
				else
				{
					// Connect to a remote host - BLOCKING I/O
					sock = new Socket (m_inet, m_port);
				}
			}
			catch (IOException ioe)
			{
				// Assign to our exception member variable
				m_exception = ioe;
				return;
			}

			// If socket constructor returned without error,
			// then connection finished
			m_connection = sock;
		}

		// Are we connected?
		public boolean isConnected()
		{
			if (m_connection == null)
				return false;
			else
				return true;
		}

		// Did an error occur?
		public boolean isError()
		{
			if (m_exception == null)
				return false;
			else
				return true;
		}

		// Get socket
		public Socket getSocket()
		{
			return m_connection;
		}

		// Get exception
		public IOException getException()
		{
			return m_exception;
		}
	}

	// Polling delay for socket checks (in milliseconds)
	private static final int POLL_DELAY = 100;
}
