/* -*-  Mode:Java; c-basic-offset:4; tab-width:4; indent-tabs-mode:t -*- */
/*
                           IrisNet 1.1
        An Internet-scale Resource-Intensive Sensor Network

             Copyright (c) 2002-2003, Intel Corporation
                          All Rights Reserved

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

      * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

      * Neither the name of Intel nor the names of its contributors may
      be used to endorse or promote products derived from this software
      without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

package com.intel.sensors.oa.VSensors;
import com.intel.sensors.oa.*;
import HTTPClient.*;
import java.io.*;
import java.util.*;

public class PLabSA {
	public static void main (String[] args) {
		if (args.length < 2) {
			System.out.println("parameters: <config_file> <dest_OA>");
			return;
		}

		SliceStat slicestat = new SliceStat(args[0], "http://localhost:2840/slicestat");
		ProcSensor procSensor = new ProcSensor(args[0], "http://localhost:7890/proc");
		/*
		// the code between this try block is a hack to cope with the
		// fact that I did not put slicestat in the schema. Thus 
		// the local dataabse may not have any slicestat element and 
		// the "update" command in the infinite for loop may fail 
		// while trying to "delete" the old element.
		// The code here sends delete and add xupdates seperately, thus
		// if the local database does not have the slicestat element, it will fail
		// without affcting the 'append' xupdate after that 
		try {
			String data = slicestat.toString();
			Protocol.sendXupdate(slicestat.toXupdate(data, true, false), args[1]);
			Protocol.sendXupdate(slicestat.toXupdate(data, false, true), args[1]);
		} catch (Exception e1) {
			System.out.println("Error in initializing database");
			e1.printStackTrace();
		}
		*/
		HeartBeat hb = new HeartBeat("3346");
		Thread t1       = new Thread(hb);
		t1.start();


		for (;;) {
			try {
				if (slicestat.everythingOK) {
					//String xupdate = slicestat.toXupdate();
					String delete = slicestat.updateXDelete();
					String append = slicestat.updateXInsert();
										
					try { 
						//Protocol.sendXupdate(xupdate, args[1]);
						System.out.println(delete);
						Protocol.sendXupdate(delete, args[1]);
						Thread.currentThread().sleep(1000);
						System.out.println(append);
                        Protocol.sendXupdate(append, args[1]);
					} catch (Exception ee) {
						// ignore if the OA is down
					}
				}

				// procSensor
				if (procSensor.everythingOK) {
					String delete = procSensor.updateXDelete();
                    String append = procSensor.updateXInsert();

                    try {
                        //Protocol.sendXupdate(xupdate, args[1]);
                        System.out.println(delete);
                        Protocol.sendXupdate(delete, args[1]);
                        Thread.currentThread().sleep(1000);
                        System.out.println(append);
                        Protocol.sendXupdate(append, args[1]);
                    } catch (Exception ee) {
                        // ignore if the OA is down
                    }
                }

				
				if (slicestat.conf.everythingOK)
					Thread.currentThread().sleep(slicestat.conf.sleepTime * 1000);
				else
					System.exit(1);
			} catch (Exception e) {
				e.printStackTrace();
				break;
			}
		}

	}
}
